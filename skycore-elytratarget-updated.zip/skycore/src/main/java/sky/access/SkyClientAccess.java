package sky.access;

import sky.SkyInit;

public interface SkyClientAccess extends WindowAccess {
    SkyInit SKY_CORE = SkyInit.getInstance();
}
