package sky.access;

import net.minecraft.client.render.Tessellator;

public interface RenderAccess {
    net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
    Tessellator tessellator = Tessellator.getInstance();
}
