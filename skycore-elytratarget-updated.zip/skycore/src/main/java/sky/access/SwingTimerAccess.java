package sky.access;

import sky.util.MsTimer;

/** Exposes the timer tracking how long ago an entity last swung its arm. */
public interface SwingTimerAccess {
    MsTimer skycore$getLastSwing();
}
