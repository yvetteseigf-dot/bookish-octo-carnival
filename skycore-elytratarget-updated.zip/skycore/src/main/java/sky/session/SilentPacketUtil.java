package sky.session;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.network.packet.Packet;
import sky.access.MinecraftAccess;

/**
 * Sends packets without firing the normal outgoing-packet event once.
 *
 * <p>The connection mixin consumes a packet from this list before it creates
 * an event, matching the original one-shot suppression behavior.</p>
 */
public final class SilentPacketUtil implements MinecraftAccess {
    private static final List<Packet<?>> silentPackets = new ArrayList<>();

    private SilentPacketUtil() {
    }

    public static void sendSilentPacket(Packet<?> packet) {
        if (packet == null || mc.getNetworkHandler() == null) {
            return;
        }
        silentPackets.add(packet);
        mc.getNetworkHandler().sendPacket(packet);
    }

    public static boolean consumeSilent(Packet<?> packet) {
        for (int i = 0; i < silentPackets.size(); i++) {
            if (silentPackets.get(i) == packet) {
                silentPackets.remove(i);
                return true;
            }
        }
        return false;
    }

    public static List<Packet<?>> getSilentPackets() {
        return silentPackets;
    }

    public static void clearSilentPackets() {
        silentPackets.clear();
    }

    public static void sendPacket(Packet<?> packet) {
        if (packet == null || mc.getNetworkHandler() == null) {
            return;
        }
        mc.getNetworkHandler().sendPacket(packet);
    }
}
