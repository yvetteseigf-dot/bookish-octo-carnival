package sky.session;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.network.packet.s2c.play.GameMessageS2CPacket;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import sky.SkyInit;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.util.text.CommandFeedback;
import sky.util.CooldownTimer;
import sky.util.inventory.InventoryUtil;
import sky.access.SkyClientAccess;

/**
 * Walks the HolyWorld lobby menus to hop onto a requested lite anarchy after a disconnect.
 */
public final class AnarchyReconnectHandler implements SkyClientAccess {
    private final CooldownTimer stopWatch;

    private int anarchy;
    private boolean lobby;

    public AnarchyReconnectHandler() {
        stopWatch = new CooldownTimer();
        EventManager.register(this);
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (anarchy == 0 || !event.isReceive()) {
            return;
        }
        if (event.getPacket() instanceof GameMessageS2CPacket message) {
            String text = message.content().getString().toLowerCase();
            // Incoming HolyWorld join-failure chat ("хаб" / "не удалось")
            if (!text.contains("хаб") && text.contains("не удалось")) {
                CommandFeedback.displayInfo("Cannot join this anarchy");
                anarchy = 0;
            }
        }
    }

    @EventTarget
    public void onTick(PlayerUpdateEvent event) {
        if (anarchy == 0 || mc.player == null) {
            return;
        }
        ServerDetector serverHandler = SkyInit.getInstance().getServerHandler();
        if (!serverHandler.isHolyWorld()) {
            anarchy = 0;
            return;
        }
        int currentAnarchy = serverHandler.getAnarchy();
        if (lobby) {
            if (currentAnarchy == -1) {
                lobby = false;
            } else if (mc.getNetworkHandler() != null) {
                mc.getNetworkHandler().sendChatCommand("hub");
            }
            return;
        }
        if (currentAnarchy == anarchy) {
            anarchy = 0;
            return;
        }
        if (mc.currentScreen instanceof GenericContainerScreen containerScreen
                // HolyWorld lite-anarchy selector GUI title
                && containerScreen.getTitle().getString().equals("Выбор Лайт анархии:")) {
            boolean pageMenu = ((GenericContainerScreenHandler) containerScreen.getScreenHandler())
                    .getInventory().size() < 10;
            int[] page = anarchy < 15 ? new int[] {0, 0}
                    : anarchy < 33 ? new int[] {1, 14}
                    : anarchy < 48 ? new int[] {2, 32}
                    : new int[] {3, 47};
            if (pageMenu) {
                InventoryUtil.clickSlot(page[0], 0, SlotActionType.PICKUP, false);
            } else {
                InventoryUtil.clickSlot(17 + anarchy - page[1], 0, SlotActionType.PICKUP, false);
            }
            return;
        }
        if (stopWatch.every(500L) && mc.getNetworkHandler() != null) {
            mc.getNetworkHandler().sendChatCommand("lite");
        }
    }

    public void reconnect(int anarchy) {
        if (anarchy > 0 && anarchy < 64) {
            this.anarchy = anarchy;
            this.lobby = true;
        } else {
            CommandFeedback.displayInfo("Invalid lite anarchy number");
        }
    }
}
