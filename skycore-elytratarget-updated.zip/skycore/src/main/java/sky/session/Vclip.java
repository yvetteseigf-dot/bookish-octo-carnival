package sky.session;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import sky.util.text.CommandFeedback;
import sky.command.Command;
import sky.command.DoubleArgumentParser;

public class Vclip extends Command {
    public Vclip() {
        super("vclip");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("up").executes(context -> {
            double offset = findOffset(mc.player.getBlockPos(), true);
            double x = mc.player.getX();
            double y = mc.player.getY();
            double z = mc.player.getZ();
            for (int i = 0; i < 3; i++) {
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(
                        mc.player.isOnGround(), mc.player.horizontalCollision));
            }
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    x, y + offset, z, false, mc.player.horizontalCollision));
            mc.player.setPosition(x, y + offset, z);
            CommandFeedback.displayInfo("Teleported " + (int) offset + " blocks up");
            return 1;
        }));

        builder.then(literal("down").executes(context -> {
            double offset = findOffset(mc.player.getBlockPos(), false);
            double x = mc.player.getX();
            double y = mc.player.getY();
            double z = mc.player.getZ();
            for (int i = 0; i < 3; i++) {
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(
                        mc.player.isOnGround(), mc.player.horizontalCollision));
            }
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    x, y + offset, z, false, mc.player.horizontalCollision));
            mc.player.setPosition(x, y + offset, z);
            CommandFeedback.displayInfo("Teleported " + (int) offset + " blocks down");
            return 1;
        }));

        builder.then(arg("distance", DoubleArgumentParser.create()).executes(context -> {
            Double distance = context.getArgument("distance", Double.class);
            double x = mc.player.getX();
            double y = mc.player.getY();
            double z = mc.player.getZ();
            for (int i = 0; i < 3; i++) {
                mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(
                        mc.player.isOnGround(), mc.player.horizontalCollision));
            }
            mc.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    x, y + distance, z, false, mc.player.horizontalCollision));
            mc.player.setPosition(x, y + distance, z);
            if (distance > 0.0D) {
                CommandFeedback.displayInfo("Teleported " + distance + " blocks up");
            } else {
                CommandFeedback.displayInfo("Teleported " + distance + " blocks down");
            }
            return 1;
        }));
    }

    private double findOffset(BlockPos pos, boolean toUp) {
        if (toUp) {
            for (int offset = 3; offset < 255; offset++) {
                BlockPos candidate = pos.add(0, offset, 0);
                BlockPos above = candidate.up();
                if (mc.world.getBlockState(candidate).isAir() && mc.world.getBlockState(above).isAir()) {
                    return candidate.getY() - mc.player.getY();
                }
            }
        } else {
            for (int offset = -1; offset > -255; offset--) {
                BlockPos candidate = pos.add(0, offset, 0);
                BlockPos below = candidate.down();
                BlockPos floor = below.down();
                boolean solidCeiling = !mc.world.getBlockState(candidate).isAir();
                boolean belowIsAir = mc.world.getBlockState(below).isAir();
                boolean floorIsAir = mc.world.getBlockState(floor).isAir();
                if (solidCeiling && belowIsAir && floorIsAir) {
                    return floor.getY() - mc.player.getY();
                }
            }
        }
        return 0.0D;
    }
}
