package sky.session;

import net.minecraft.client.MinecraftClient;

/** Maintains the animated title state used by the client-window mixin. */
public class WindowTitleAnimator {
    private static WindowTitleAnimator INSTANCE;

    private boolean isUserPhase;
    private int animationTick;
    private boolean isRemoving;
    private String currentTitle;
    private final int delayTicks;
    private int pauseTicks;
    String user;
    private final int pauseDuration;

    private WindowTitleAnimator() {
        animationTick = 0;
        isRemoving = true;
        isUserPhase = true;
        pauseTicks = 0;
        delayTicks = 1;
        pauseDuration = 100;
        user = MinecraftClient.getInstance().getSession().getUsername();

        String name = "Unknown";
        currentTitle = "<User: " + name + ">";
    }

    public static WindowTitleAnimator getInstance() {
        if (INSTANCE == null) {
            INSTANCE = new WindowTitleAnimator();
        }
        return INSTANCE;
    }

    public void updateTitle() {
        if (pauseTicks > 0) {
            pauseTicks--;
            return;
        }

        if (animationTick >= delayTicks) {
            String targetTitle = "| beta test | Build 0.01 04/03/2025";
            String nextTitle;
            if (isRemoving) {
                if (currentTitle.length() > 1) {
                    nextTitle = currentTitle.substring(0, currentTitle.length() - 1);
                } else {
                    nextTitle = "<";
                    isRemoving = false;
                }
            } else if (currentTitle.length() < targetTitle.length()) {
                nextTitle = targetTitle.substring(0, currentTitle.length() + 1);
            } else {
                nextTitle = targetTitle;
                isRemoving = true;
                isUserPhase = !isUserPhase;
                pauseTicks = pauseDuration;
            }

            currentTitle = nextTitle;
            animationTick = 0;
        }

        animationTick++;
    }

    public String getCurrentTitle() {
        return "SkyCore 1.21.4 - " + user;
    }
}
