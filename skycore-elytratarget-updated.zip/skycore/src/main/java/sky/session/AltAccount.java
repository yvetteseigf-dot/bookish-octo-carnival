package sky.session;

import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.client.session.Session;

/** One saved offline (or previously used) Minecraft session. */
public final class AltAccount {
    private final String username;
    private final UUID uuid;
    private final String accessToken;
    private final Session.AccountType accountType;

    public AltAccount(String username, UUID uuid, String accessToken, Session.AccountType accountType) {
        this.username = username;
        this.uuid = uuid;
        this.accessToken = accessToken == null ? "0" : accessToken;
        this.accountType = accountType == null ? Session.AccountType.LEGACY : accountType;
    }

    public static AltAccount offline(String username) {
        String normalized = normalizeUsername(username);
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + normalized).getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return new AltAccount(normalized, uuid, "0", Session.AccountType.LEGACY);
    }

    public static AltAccount fromSession(Session session) {
        if (session == null) {
            return null;
        }
        UUID uuid = session.getUuidOrNull();
        if (uuid == null) {
            return offline(session.getUsername());
        }
        return new AltAccount(session.getUsername(), uuid, session.getAccessToken(), session.getAccountType());
    }

    public Session toSession() {
        return new Session(username, uuid, accessToken, Optional.empty(), Optional.empty(), accountType);
    }

    public String getUsername() {
        return username;
    }

    public UUID getUuid() {
        return uuid;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public Session.AccountType getAccountType() {
        return accountType;
    }

    public boolean isOffline() {
        return accountType == Session.AccountType.LEGACY
                || accessToken == null
                || accessToken.isEmpty()
                || "0".equals(accessToken);
    }

    public static String normalizeUsername(String username) {
        return username == null ? "" : username.trim();
    }

    public static boolean isValidUsername(String username) {
        String normalized = normalizeUsername(username);
        if (normalized.length() < 1 || normalized.length() > 16) {
            return false;
        }
        for (int i = 0; i < normalized.length(); i++) {
            char character = normalized.charAt(i);
            if (character != '_' && !Character.isLetterOrDigit(character)) {
                return false;
            }
        }
        return true;
    }

    public boolean sameName(String other) {
        return username.equalsIgnoreCase(normalizeUsername(other));
    }

    @Override
    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof AltAccount other)) {
            return false;
        }
        return username.equalsIgnoreCase(other.username);
    }

    @Override
    public int hashCode() {
        return username.toLowerCase(Locale.ROOT).hashCode();
    }
}
