package sky.session;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import sky.SkyInit;
import sky.util.text.CommandFeedback;
import sky.command.Command;

/** Reconnects to an anarchy world, optionally to an explicitly requested one. */
public final class Rct extends Command {
    public Rct() {
        super("rct");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(context -> reconnect(SkyInit.getInstance().getServerHandler().getAnarchy()));
        builder.then(arg("anarchy", IntegerArgumentType.integer(1, 63))
            .executes(context -> reconnect(context.getArgument("anarchy", Integer.class))));
    }

    private int reconnect(int anarchy) {
        ServerDetector serverHandler = SkyInit.getInstance().getServerHandler();
        if (!serverHandler.isHolyWorld()) {
            CommandFeedback.displayInfo("RCT does not work on this " + Formatting.RED + "server");
            return 1;
        }
        if (serverHandler.isPvp()) {
            CommandFeedback.displayInfo("You are in " + Formatting.RED + "PvP mode");
            return 1;
        }

        SkyInit.getInstance().getRctRepository().reconnect(anarchy);
        return 1;
    }
}
