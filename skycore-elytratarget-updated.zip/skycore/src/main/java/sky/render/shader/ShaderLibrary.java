package sky.render.shader;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sky.debug.BlurDebugLogger;
import sky.util.StreamUtil;

import java.io.InputStream;
import java.util.Optional;

public final class ShaderLibrary {
    private static boolean blurShadersLoaded;
    private static boolean mainMenuShadersLoaded;
    private static boolean liquidGlassShadersLoaded;
    private static boolean defaultShadersLoaded;
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore");
    private static final ShaderRegistry REGISTRY = new ShaderRegistry();

    private ShaderLibrary() {
    }

    public static void loadBlurShaders() {
        BlurDebugLogger.log("ShaderLibrary", "blur=" + blurShadersLoaded + " defaults=" + defaultShadersLoaded);
        loadDefaultShaders();
        if (blurShadersLoaded) {
            BlurDebugLogger.log("ShaderLibrary", "already loaded " + BlurDebugLogger.describeRegistryShader("blurred_round_rect"));
            return;
        }

        blurShadersLoaded = true;
        registerIfMissing("blurred_round_rect", "fragment/blurred_round_rect.fsh");
        registerIfMissing("light_kawase_down", "fragment/light_kawase_down.fsh");
        registerIfMissing("light_kawase_up", "fragment/light_kawase_up.fsh");
        BlurDebugLogger.log("ShaderLibrary", "registered " + BlurDebugLogger.describeRegistryShader("blurred_round_rect"));
    }

    public static void loadMainMenuShaders() {
        if (mainMenuShadersLoaded) {
            return;
        }

        mainMenuShadersLoaded = true;
        registerIfMissing("main_menu_background", "fragment/main_menu_background.fsh");
        registerIfMissing("main_menu_button", "fragment/main_menu_button.fsh");
        registerIfMissing("skycore_main_bg", "fragment/skycore_main_bg.fsh");
        registerIfMissing("skycore_menu_button", "fragment/skycore_menu_button.fsh");
        registerIfMissing("skycore_moon_bg", "fragment/skycore_moon_bg.fsh");
    }

    public static void loadDefaultShaders() {
        if (defaultShadersLoaded) {
            return;
        }

        defaultShadersLoaded = true;
        registerIfMissing("round_rect", "fragment/round_rect.fsh");
        registerIfMissing("round_rect_outline", "fragment/round_rect_outline.fsh");
        registerIfMissing("gradient", "fragment/gradient.fsh");
        registerIfMissing("circle", "fragment/circle.fsh");
        registerIfMissing("round_texture", "fragment/round_texture.fsh");
        registerIfMissing("blurred_round_rect", "fragment/blurred_round_rect.fsh");
        registerIfMissing("block_overlay", "fragment/block_overlay.fsh");
        registerIfMissing("gradient_bar", "fragment/gradient_bar.fsh");
        registerIfMissing("ring_arc", "fragment/ring_arc.fsh");
        registerIfMissing("ring_arc_flow", "fragment/ring_arc_flow.fsh");
        registerIfMissing("round_rect_outline_flow", "fragment/round_rect_outline_flow.fsh");
    }

    public static void loadLiquidGlassShaders() {
        if (liquidGlassShadersLoaded) {
            return;
        }

        liquidGlassShadersLoaded = true;
        registerIfMissing("liquid_glass", "core/liquidglass/liquid.vsh", "core/liquidglass/liquid.fsh");
    }

    public static ShaderRegistry getRegistry() {
        return REGISTRY;
    }

    private static void registerIfMissing(String name, String fragmentPath) {
        registerIfMissing(name, "vertex/passthrough.vsh", fragmentPath);
    }

    private static void registerIfMissing(String name, String vertexPath, String fragmentPath) {
        Optional<ManagedShader> existing = REGISTRY.find(name);
        if (existing.isPresent()) {
            return;
        }

        ManagedShader program = buildProgram(vertexPath, fragmentPath);
        if (program.isLinked()) {
            REGISTRY.register(name, program);
            if (name.contains("blur") || name.contains("kawase")) {
                BlurDebugLogger.log("ShaderLibrary", "linked " + name);
            }
            return;
        }

        LOGGER.error("Failed to link shader '{}'", name);
        if (name.contains("blur") || name.contains("kawase")) {
            BlurDebugLogger.log("ShaderLibrary", "failed " + name + " " + fragmentPath);
        }
    }

    private static ManagedShader buildProgram(String fragmentPath) {
        return buildProgram("vertex/passthrough.vsh", fragmentPath);
    }

    private static ManagedShader buildProgram(String vertexPath, String fragmentPath) {
        return ManagedShaderBuilder.create()
                .attach(vertexPath, 35633)
                .attach(fragmentPath, 35632)
                .link()
                .build();
    }

    private static String readShader(String path) {
        InputStream stream = ShaderLibrary.class.getResourceAsStream("/assets/skycore/shaders/" + path);
        if (stream == null) {
            LOGGER.error("Shader not found: /assets/skycore/shaders/{}", path);
            return "";
        }
        return StreamUtil.readText(stream);
    }
}
