package sky.render.shader;

import com.google.common.collect.Maps;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Color;
import java.nio.FloatBuffer;
import java.util.Map;

public class ManagedShader {
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore");
    private static final int VERTEX_SHADER = GL20.GL_VERTEX_SHADER;
    private static final int FRAGMENT_SHADER = GL20.GL_FRAGMENT_SHADER;
    private static final FloatBuffer matrixBuffer = BufferUtils.createFloatBuffer(16);

    private static int vao = -1;
    private static int vbo = -1;

    private final Map<String, Integer> uniformLocations;
    private final int programId;
    private int previousProgram;
    private boolean linked;

    public ManagedShader() {
        this.linked = true;
        this.uniformLocations = Maps.newLinkedHashMap();
        this.programId = GL20.glCreateProgram();
    }

    public void setColor(String name, Color color) {
        GL20.glUniform4f(
                uniform(name),
                color.getRed() / 255.0F,
                color.getGreen() / 255.0F,
                color.getBlue() / 255.0F,
                color.getAlpha() / 255.0F);
    }

    public int getProgramId() {
        return programId;
    }

    public void bind(Matrix4f contextMatrix) {
        if (!linked) {
            return;
        }

        previousProgram = GL11.glGetInteger(GL20.GL_CURRENT_PROGRAM);
        GL20.glUseProgram(programId);

        Matrix4f projection = RenderSystem.getProjectionMatrix();
        Matrix4f modelView = new Matrix4f(RenderSystem.getModelViewMatrix()).mul(contextMatrix);

        matrixBuffer.clear();
        projection.get(matrixBuffer);
        matrixBuffer.rewind();
        setMatrix("ProjMat", matrixBuffer);

        matrixBuffer.clear();
        modelView.get(matrixBuffer);
        matrixBuffer.rewind();
        setMatrix("ModelViewMat", matrixBuffer);

        MinecraftClient client = MinecraftClient.getInstance();
        setVec2("resolution", client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
    }

    public void setInt(String name, int value) {
        GL20.glUniform1i(uniform(name), value);
    }

    private void setMatrix(String name, FloatBuffer buffer) {
        GL20.glUniformMatrix4fv(uniform(name), false, buffer);
    }

    public void link() {
        GL20.glBindAttribLocation(programId, 0, "Position");
        GL20.glBindAttribLocation(programId, 1, "UV0");
        GL20.glLinkProgram(programId);
        if (GL20.glGetProgrami(programId, GL20.GL_LINK_STATUS) == 0) {
            LOGGER.error("Program link error: {}", GL20.glGetProgramInfoLog(programId));
            linked = false;
        }
    }

    private int uniform(String name) {
        return uniformLocations.computeIfAbsent(name, key -> GL20.glGetUniformLocation(programId, key));
    }

    public void setVec3(String name, float x, float y, float z) {
        GL20.glUniform3f(uniform(name), x, y, z);
    }

    public void setVec2(String name, float x, float y) {
        GL20.glUniform2f(uniform(name), x, y);
    }

    public void attachSource(String source, int type) {
        int shader = GL20.glCreateShader(type);
        GL20.glShaderSource(shader, source);
        GL20.glCompileShader(shader);
        if (GL20.glGetShaderi(shader, GL20.GL_COMPILE_STATUS) == 0) {
            LOGGER.error("Shader compile error: {}", GL20.glGetShaderInfoLog(shader));
            linked = false;
            return;
        }

        GL20.glAttachShader(programId, shader);
    }

    public void bind() {
        bind(new Matrix4f());
    }

    public boolean isLinked() {
        return linked;
    }

    public void setFloat(String name, float value) {
        GL20.glUniform1f(uniform(name), value);
    }

    public static void drawQuad(float x, float y, float width, float height) {
        ensureQuadBuffers();
        float[] vertices = {
                x, y + height, 0.0F, 0.0F, 1.0F,
                x + width, y + height, 0.0F, 1.0F, 1.0F,
                x + width, y, 0.0F, 1.0F, 0.0F,
                x, y + height, 0.0F, 0.0F, 1.0F,
                x + width, y, 0.0F, 1.0F, 0.0F,
                x, y, 0.0F, 0.0F, 0.0F
        };
        int previousVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int previousBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, vertices, GL15.GL_DYNAMIC_DRAW);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        GL30.glBindVertexArray(previousVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, previousBuffer);
    }

    private static void ensureQuadBuffers() {
        if (vao != -1) {
            return;
        }

        int previousVao = GL11.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int previousBuffer = GL11.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);
        vao = GL30.glGenVertexArrays();
        vbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(vao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 20, 0L);
        GL20.glEnableVertexAttribArray(1);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 20, 12L);
        GL30.glBindVertexArray(previousVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, previousBuffer);
    }

    public void unbind() {
        GL20.glUseProgram(0);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public void setVec4(String name, float x, float y, float z, float w) {
        GL20.glUniform4f(uniform(name), x, y, z, w);
    }
}
