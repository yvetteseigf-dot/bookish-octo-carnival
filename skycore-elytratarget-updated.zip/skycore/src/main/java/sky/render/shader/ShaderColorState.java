package sky.render.shader;

import com.mojang.blaze3d.systems.RenderSystem;

public final class ShaderColorState {
    private static final ColorState COLOR = new ColorState();

    private ShaderColorState() {
    }

    public static void color4f(float red, float green, float blue, float alpha) {
        RenderSystem.assertOnRenderThread();
        if (red == COLOR.red && green == COLOR.green && blue == COLOR.blue && alpha == COLOR.alpha) {
            return;
        }

        COLOR.red = red;
        COLOR.green = green;
        COLOR.blue = blue;
        COLOR.alpha = alpha;
        RenderSystem.setShaderColor(red, green, blue, alpha);
    }

    private static final class ColorState {
        private float red = 1.0F;
        private float green = 1.0F;
        private float blue = 1.0F;
        private float alpha = 1.0F;
    }
}
