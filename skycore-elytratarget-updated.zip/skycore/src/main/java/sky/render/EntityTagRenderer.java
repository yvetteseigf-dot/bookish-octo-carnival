package sky.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.joml.Vector4d;
import sky.SkyInit;
import sky.module.misc.NameProtect;
import sky.module.misc.ScoreboardHealth;
import sky.module.visuals.Tags;
import sky.util.inventory.EffectDisplayUtil;
import sky.util.inventory.EnchantmentUtil;
import sky.util.entity.EntityNameUtil;
import sky.util.render.EntityProjectionUtil;
import sky.util.combat.HealthUtil;
import sky.util.entity.NameTagTargetFilter;
import sky.util.text.TextUtil;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;

public final class EntityTagRenderer {
    private static final float ITEM_TAG_PADDING_LEFT = 1.0f;
    private static final float TAG_PADDING_RIGHT = 1.5f;
    private static final float ITEM_TAG_PADDING_RIGHT = 1.0f;
    private static final int TAG_FONT_SIZE = 13;
    private static final float TAG_RECT_HEIGHT = 11.0f;
    private static final float ITEM_SLOT_STEP = 10.5f;
    private static final int TAG_HEAD_SIZE = 8;
    private static final float TAG_ITEM_ICON_SIZE = 8.0f;
    private static final float TAG_ITEM_ICON_SCALE = 0.5f;
    private static final float TAG_ICON_GAP = 1.0f;
    private static final double MAX_DISTANCE = 128.0d;
    private static final float TAG_RADIUS = 2.5f;
    private static final float HELD_PADDING_LEFT = 0.5f;
    private static final int EFFECT_FONT_SIZE = 11;
    private static final float ENCHANT_LINE_STEP = 6.0f;
    private static final Color BACKGROUND_COLOR = new Color(0, 0, 0, 55);
    private static final float TAG_PADDING_LEFT = 1.5f;
    private static final int HELD_FONT_SIZE = 12;
    private static final float HELD_PADDING_RIGHT = 0.5f;
    private static final Color FRIEND_BACKGROUND_COLOR = new Color(0, 120, 0, 80);

    private final MinecraftClient client;
    private final ItemStack[] armorScratch;

    public EntityTagRenderer() {
        this.client = MinecraftClient.getInstance();
        this.armorScratch = new ItemStack[4];
    }

    public void render(DrawContext context, MatrixStack matrices, float screenWidth, float screenHeight, float delta) {
        Tags module = Tags.INSTANCE;
        if (!module.isEnabled() || this.client.world == null || this.client.player == null) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        FontRenderer font = FontRegistry.getMedium(TAG_FONT_SIZE);
        FontRenderer heldFont = FontRegistry.getMedium(HELD_FONT_SIZE);
        FontRenderer enchantFont = module.viewEnchants.get() ? FontRegistry.getMedium(10) : null;
        if (renderer == null || font == null) {
            return;
        }

        boolean showItems = module.rendering.is("Items");
        DrawHelper.beginHudRenderBatch();
        try {
            for (Entity entity : this.client.world.getEntities()) {
                if (!EntityProjectionUtil.isInView(entity)) {
                    continue;
                }
                if (!isInRange(entity)) {
                    continue;
                }
                if (entity instanceof ItemEntity itemEntity) {
                    if (!showItems) {
                        continue;
                    }
                    float[] anchor = EntityProjectionUtil.projectGuiPoint(itemEntity, delta, 0.5f);
                    if (anchor == null) {
                        continue;
                    }
                    renderItemTag(context, matrices, renderer, font, module, itemEntity, anchor);
                    continue;
                }
                if (!(entity instanceof LivingEntity living) || !living.isAlive()) {
                    continue;
                }
                if (!NameTagTargetFilter.isEntityTarget(living, module)) {
                    continue;
                }
                float[] anchor = projectEntity(living, delta);
                if (anchor != null) {
                    renderEntityTag(context, matrices, renderer, font, heldFont, enchantFont, module, living, anchor);
                }
            }
        } finally {
            DrawHelper.endHudRenderBatch();
        }
    }

    private void renderEntityTag(DrawContext context, MatrixStack matrices, DrawHelper renderer, FontRenderer font,
                                 FontRenderer heldFont, FontRenderer enchantFont, Tags module, LivingEntity entity,
                                 float[] anchor) {
        Text displayName = EntityNameUtil.resolveEntityDisplayName(entity);
        Text nameBlock = buildNameBlockComponent(entity, displayName);
        boolean friend = false;
        if (entity instanceof PlayerEntity player
                && SkyInit.getInstance() != null
                && SkyInit.getInstance().getFriendManager() != null
                && player.getGameProfile() != null) {
            friend = SkyInit.getInstance().getFriendManager().isFriend(player.getGameProfile().getName());
        }
        boolean scoreboardHealth = ScoreboardHealth.INSTANCE.isEnabled();
        float health = scoreboardHealth ? HealthUtil.getHealth(entity) : entity.getHealth();
        int roundedHealth = Math.max(0, Math.round(health));
        String healthText = friend ? "[F]" : "[" + roundedHealth + "]";
        Color healthColor = friend ? new Color(85, 255, 85) : new Color(255, 68, 68);

        float nameWidth = font.getTextWidth(nameBlock);
        float spaceWidth = font.getWidth(" ");
        float healthWidth = font.getWidth(healthText);
        float contentWidth = nameWidth + spaceWidth + healthWidth;
        boolean drawHead = module.viewHead.get() && entity instanceof AbstractClientPlayerEntity;
        ItemStack mainHand = entity.getMainHandStack();
        boolean drawItemIcon = module.viewItemIcon.get() && !mainHand.isEmpty();
        float headReserve = drawHead ? TAG_HEAD_SIZE + TAG_ICON_GAP : 0.0f;
        float itemReserve = drawItemIcon ? TAG_ICON_GAP + TAG_ITEM_ICON_SIZE : 0.0f;
        float rectWidth = contentWidth + TAG_PADDING_LEFT + TAG_PADDING_RIGHT + headReserve + itemReserve;
        float centerX = anchor[0];
        float rectY = anchor[1] - TAG_RECT_HEIGHT - 3.0f;
        float rectX = centerX - rectWidth / 2.0f;
        Color background = friend ? FRIEND_BACKGROUND_COLOR : BACKGROUND_COLOR;

        drawTagBackground(renderer, matrices, rectX, rectY, rectWidth, TAG_RECT_HEIGHT, TAG_RADIUS, background);

        float textX = rectX + TAG_PADDING_LEFT;
        if (drawHead) {
            AbstractClientPlayerEntity player = (AbstractClientPlayerEntity) entity;
            SkinTextures textures = player.getSkinTextures();
            if (textures != null) {
                int headX = Math.round(textX);
                int headY = Math.round(rectY + (TAG_RECT_HEIGHT - TAG_HEAD_SIZE) / 2.0f);
                PlayerSkinDrawer.draw(context, textures, headX, headY, TAG_HEAD_SIZE, -1);
                textX = headX + TAG_HEAD_SIZE + TAG_ICON_GAP;
            }
        }
        String combined = nameBlock.getString() + " " + healthText;
        float nameY = fontTextY(font, combined, rectY) - 0.5f;
        font.drawText(matrices, nameBlock, textX, nameY, Color.WHITE);
        textX += nameWidth + spaceWidth;
        font.draw(healthText, textX, fontPlainY(font, healthText, rectY) - 0.5f, healthColor, matrices);
        if (drawItemIcon) {
            float iconX = textX + healthWidth + TAG_ICON_GAP;
            float iconY = rectY + (TAG_RECT_HEIGHT - TAG_ITEM_ICON_SIZE) / 2.0f;
            renderer.drawStack(context, matrices, mainHand, iconX, iconY, TAG_ITEM_ICON_SCALE);
        }

        if (module.viewArmor.get()) {
            drawArmorRow(context, matrices, renderer, enchantFont, entity, centerX, rectY);
        }

        float extraY = anchor[2] + ENCHANT_LINE_STEP;
        if (module.viewItem.get()) {
            extraY = drawHeldItems(matrices, renderer, heldFont, entity, centerX, extraY, background);
        }
        if (module.viewEffects.get()) {
            drawEffects(matrices, entity, centerX, extraY);
        }
    }

    private Text buildNameBlockComponent(LivingEntity entity, Text nameComponent) {
        if (!(entity instanceof PlayerEntity player)) {
            return Text.empty().append(nameComponent);
        }

        String profileName = player.getGameProfile().getName();
        String alias = NameProtect.shouldProtectInTags(player) ? NameProtect.getProtectedAlias() : profileName;
        Text result = Text.empty().append(nameComponent);
        if (!profileName.isEmpty() && !profileName.equals(alias)) {
            result = TextUtil.replaceLiteral(result, profileName, alias);
        }
        String scoreboardName = player.getNameForScoreboard();
        if (scoreboardName != null && !scoreboardName.isEmpty()
                && !scoreboardName.equals(profileName) && !scoreboardName.equals(alias)) {
            result = TextUtil.replaceLiteral(result, scoreboardName, alias);
        }
        return result;
    }

    private void drawTagBackground(DrawHelper renderer, MatrixStack matrices, float x, float y, float width,
                                   float height, float radius, Color color) {
        renderer.drawSolidRect(x, y, width, height, color, matrices);
    }

    private void drawTagBackground(DrawHelper renderer, MatrixStack matrices, float x, float y, float width,
                                   Color color) {
        drawTagBackground(renderer, matrices, x, y, width, TAG_RECT_HEIGHT, TAG_RADIUS, color);
    }

    private void drawTagBackground(DrawHelper renderer, MatrixStack matrices, float x, float y, float width,
                                   float height, Color color) {
        drawTagBackground(renderer, matrices, x, y, width, height, TAG_RADIUS, color);
    }

    private float fontTextY(FontRenderer font, String text, float rectTop) {
        return fontPlainY(font, text, rectTop) + TAG_PADDING_LEFT;
    }

    private float fontPlainY(FontRenderer font, String text, float rectTop) {
        return rectTop + (TAG_RECT_HEIGHT - font.getLineHeight(text)) / 2.0f + 0.5f;
    }

    private void drawArmorRow(DrawContext context, MatrixStack matrices, DrawHelper renderer, FontRenderer enchantFont,
                              LivingEntity entity, float centerX, float baseY) {
        int filled = 0;
        for (ItemStack stack : entity.getArmorItems()) {
            this.armorScratch[filled++] = stack;
        }
        while (filled < this.armorScratch.length) {
            this.armorScratch[filled++] = ItemStack.EMPTY;
        }

        ItemStack mainHand = entity.getMainHandStack();
        ItemStack offHand = entity.getOffHandStack();
        float armorY = baseY - 15.0f;
        float totalWidth = 0.0f;
        for (int slot = 3; slot >= 0; slot--) {
            if (!this.armorScratch[slot].isEmpty()) {
                totalWidth += ITEM_SLOT_STEP;
            }
        }
        if (!mainHand.isEmpty()) {
            totalWidth += ITEM_SLOT_STEP;
        }
        if (!offHand.isEmpty()) {
            totalWidth += ITEM_SLOT_STEP;
        }
        if (totalWidth <= 0.0f) {
            return;
        }

        float offset = -totalWidth / 2.0f + 4.0f;
        for (int slot = 0; slot < 6; slot++) {
            ItemStack stack = resolveArmorSlot(slot, mainHand, offHand);
            if (stack.isEmpty()) {
                continue;
            }
            if (enchantFont != null) {
                drawEnchantments(enchantFont, matrices, stack, centerX + offset + 4.0f, armorY - 4.0f);
            }
            renderer.drawStack(context, matrices, stack, centerX + offset, armorY, 0.5f);
            offset += ITEM_SLOT_STEP;
        }
    }

    private Color rarityColor(ItemStack stack) {
        Formatting formatting = stack.getRarity().getFormatting();
        Integer color = formatting.getColorValue();
        return color != null ? new Color(color) : Color.WHITE;
    }

    private void renderItemTag(DrawContext context, MatrixStack matrices, DrawHelper renderer, FontRenderer font,
                               Tags module, ItemEntity itemEntity, float[] anchor) {
        ItemStack stack = itemEntity.getStack();
        Text name = module.viewDisplayName.get() ? stack.getName() : stack.getItem().getName(stack);
        name = TextUtil.replaceSymbols(name);
        int count = stack.getCount();
        String countSuffix = count > 1 ? " x" + count : "";
        MutableText styled = Text.empty().append(name).formatted(stack.getRarity().getFormatting());
        if (count > 1) {
            styled.append(Text.literal(countSuffix));
        }
        String measure = name.getString() + countSuffix;
        float textWidth = font.getWidth(measure);
        boolean drawIcon = module.viewItemIcon.get() && !stack.isEmpty();
        float iconReserve = drawIcon ? TAG_ITEM_ICON_SIZE + TAG_ICON_GAP : 0.0f;
        float centerX = anchor[0];
        float rectY = anchor[1] - TAG_RECT_HEIGHT - 3.0f;
        float rectWidth = textWidth + ITEM_TAG_PADDING_LEFT + ITEM_TAG_PADDING_RIGHT + iconReserve;
        float rectX = centerX - rectWidth / 2.0f;
        drawTagBackground(renderer, matrices, rectX, rectY, rectWidth, TAG_RECT_HEIGHT, 0.0f, BACKGROUND_COLOR);
        float textX = rectX + ITEM_TAG_PADDING_LEFT;
        if (drawIcon) {
            float iconY = rectY + (TAG_RECT_HEIGHT - TAG_ITEM_ICON_SIZE) / 2.0f;
            renderer.drawStack(context, matrices, stack, textX, iconY, TAG_ITEM_ICON_SCALE);
            textX += TAG_ITEM_ICON_SIZE + TAG_ICON_GAP;
        }
        float textY = rectY + (TAG_RECT_HEIGHT - font.getLineHeight(measure)) / 2.0f + TAG_PADDING_LEFT;
        font.drawText(matrices, styled, textX, textY, Color.WHITE);
    }

    private Text buildHeldItemComponent(Tags module, ItemStack stack) {
        Text name = module.viewDisplayName.get() ? stack.getName() : stack.getItem().getName(stack);
        return TextUtil.replaceSymbols(Text.empty().append(name).formatted(stack.getRarity().getFormatting()));
    }

    private void drawHeldItemLine(DrawHelper renderer, MatrixStack matrices, FontRenderer itemFont, ItemStack stack,
                                  float centerX, float y, Color blockColor) {
        String text = buildHeldItemComponent(Tags.INSTANCE, stack).getString();
        float rectWidth = itemFont.getWidth(text) + HELD_PADDING_LEFT + HELD_PADDING_RIGHT;
        float rectX = centerX - rectWidth / 2.0f;
        drawTagBackground(renderer, matrices, rectX, y, rectWidth, TAG_RECT_HEIGHT, 0.0f, blockColor);
        Color color = rarityColor(stack);
        float textY = y + (TAG_RECT_HEIGHT - itemFont.getLineHeight(text)) / 2.0f;
        itemFont.drawCentered(text, centerX, textY, color, matrices);
    }

    private float[] projectEntity(Entity entity, float tickDelta) {
        Vector4d vec = EntityProjectionUtil.getGuiVector4D(entity, tickDelta);
        if (vec == null) {
            return null;
        }
        float x = (float) ((vec.x + vec.z) / 2.0d);
        float y = (float) vec.y;
        float w = (float) vec.w;
        return new float[] {x, y, w};
    }

    private String toRomanNumeral(int value) {
        if (value <= 0) {
            return "";
        }
        String[] numerals = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return value < numerals.length ? numerals[value] : String.valueOf(value);
    }

    private float drawHeldItems(MatrixStack matrices, DrawHelper renderer, FontRenderer itemFont,
                                LivingEntity entity, float centerX, float startY, Color blockColor) {
        if (itemFont == null) {
            return startY;
        }
        float y = startY;
        ItemStack mainHand = entity.getMainHandStack();
        if (!mainHand.isEmpty()) {
            drawHeldItemLine(renderer, matrices, itemFont, mainHand, centerX, y, blockColor);
            y += 12.0f;
        }
        ItemStack offHand = entity.getOffHandStack();
        if (!offHand.isEmpty()) {
            drawHeldItemLine(renderer, matrices, itemFont, offHand, centerX, y, blockColor);
            y += 12.0f;
        }
        return y;
    }

    private void drawEnchantments(FontRenderer font, MatrixStack matrices, ItemStack stack, float itemCenterX,
                                  float startY) {
        float y = startY;
        for (String enchantment : EnchantmentUtil.getEnchantments(stack)) {
            float width = font.getWidth(enchantment);
            font.draw(enchantment, itemCenterX - width / 2.0f, y, Color.WHITE, matrices);
            y -= ENCHANT_LINE_STEP;
        }
    }

    private ItemStack resolveArmorSlot(int slot, ItemStack mainHand, ItemStack offHand) {
        if (slot == 0) {
            return offHand;
        }
        if (slot == 5) {
            return mainHand;
        }
        int index = 4 - slot;
        if (index >= 0 && index < this.armorScratch.length) {
            return this.armorScratch[index];
        }
        return ItemStack.EMPTY;
    }

    private boolean isInRange(Entity entity) {
        return this.client.player.squaredDistanceTo(entity) <= MAX_DISTANCE * MAX_DISTANCE;
    }

    private void drawEffects(MatrixStack matrices, LivingEntity entity, float centerX, float startY) {
        Collection<StatusEffectInstance> effects = entity.getStatusEffects();
        if (effects.isEmpty()) {
            return;
        }
        FontRenderer font = FontRegistry.getRegular(EFFECT_FONT_SIZE);
        if (font == null) {
            return;
        }

        List<EffectLine> lines = new ArrayList<>(effects.size());
        for (StatusEffectInstance instance : effects) {
            int duration = instance.getDuration();
            if (duration <= 20) {
                continue;
            }
            StatusEffect effect = instance.getEffectType().value();
            var effectId = Registries.STATUS_EFFECT.getId(effect);
            if (effect == null || effectId == null) {
                continue;
            }
            String path = effectId.getPath();
            int argb = EffectDisplayUtil.getEffectArgb(path);
            String name = effect.getName().getString();
            int level = instance.getAmplifier() + 1;
            StringBuilder builder = new StringBuilder(name);
            if (level > 1) {
                builder.append(' ').append(toRomanNumeral(level));
            }
            builder.append(' ').append(EffectDisplayUtil.formatDuration(duration));
            String text = builder.toString();
            lines.add(new EffectLine(text, font.getWidth(text), argb));
        }
        if (lines.size() > 1) {
            lines.sort(Comparator.comparingDouble(line -> line.width));
        }

        float lineHeight = font.getLineHeight("A") + 2.0f;
        for (int i = 0; i < lines.size(); i++) {
            EffectLine line = lines.get(i);
            font.draw(line.text, centerX - line.width / 2.0f, startY + i * lineHeight,
                    new Color(line.color, true), matrices);
        }
    }

    private static final class EffectLine {
        private final String text;
        private final float width;
        private final int color;

        private EffectLine(String text, float width, int color) {
            this.text = text;
            this.width = width;
            this.color = color;
        }
    }
}
