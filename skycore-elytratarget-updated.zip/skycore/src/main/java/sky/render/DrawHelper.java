package sky.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import sky.debug.BlurDebugLogger;
import sky.util.render.BlendStateUtil;
import sky.util.render.ColorUtil;
import sky.util.math.CornerRadii;
import sky.util.render.HudScaleUtil;
import sky.util.render.TextureFilterUtil;

import java.awt.Color;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Optional;
import sky.render.framebuffer.BlurManager;
import sky.render.shader.ShaderLibrary;
import sky.render.shader.ManagedShader;

public final class DrawHelper {
    private static final FloatBuffer LEGACY_QUAD_BUFFER =
            ByteBuffer.allocateDirect(120).order(ByteOrder.nativeOrder()).asFloatBuffer();

    private static DrawHelper instance;
    private static int hudLiquidGlassScopeDepth;
    private static int legacyQuadVbo;
    private static int legacyQuadVao;

    public static void init() {
        instance = new DrawHelper();
    }

    public static DrawHelper get() {
        return instance;
    }


    public void drawSolidRect(float x, float y, float width, float height, Color color, MatrixStack matrices) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();
        float red = color.getRed() / 255.0F;
        float green = color.getGreen() / 255.0F;
        float blue = color.getBlue() / 255.0F;
        float alpha = color.getAlpha() / 255.0F;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        buffer.vertex(matrix, x, y + height, 0.0F).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + width, y + height, 0.0F).color(red, green, blue, alpha);
        buffer.vertex(matrix, x + width, y, 0.0F).color(red, green, blue, alpha);
        buffer.vertex(matrix, x, y, 0.0F).color(red, green, blue, alpha);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    public void drawRoundedRect(float x, float y, float width, float height, Color color, MatrixStack matrices) {
        drawRoundedRect(x, y, width, height, 0.0F, color, matrices);
    }

    public void drawRoundedRect(float x, float y, float width, float height, float radius, Color color, MatrixStack matrices) {
        drawRoundedRect(x, y, width, height, CornerRadii.all(radius), color, matrices);
    }

    public void drawRoundedRect(float x, float y, float width, float height, CornerRadii radii, Color color, MatrixStack matrices) {
        ShaderLibrary.loadDefaultShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("round_rect");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null) {
            drawSolidRect(x, y, width, height, color, matrices);
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        program.bind(matrices.peek().getPositionMatrix());
        float scale = HudScaleUtil.getScale();
        program.setVec2("location", x * scale, window.getHeight() - height * scale - y * scale);
        program.setVec2("rectSize", width * scale, height * scale);
        program.setVec4("radii", radii.topLeft(), radii.topRight(), radii.bottomRight(), radii.bottomLeft());
        program.setColor("color", color);
        BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
        program.unbind();
    }

    public void drawRoundedOutline(float x, float y, float width, float height, float radius, float thickness,
                                   Color color, MatrixStack matrices) {
        drawRoundedOutline(x, y, width, height, CornerRadii.all(radius), thickness, color, matrices);
    }

    public void drawRoundedOutline(float x, float y, float width, float height, CornerRadii radii, float thickness,
                                   Color color, MatrixStack matrices) {
        ShaderLibrary.loadDefaultShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("round_rect_outline");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null) {
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        program.bind(matrices.peek().getPositionMatrix());
        float scale = HudScaleUtil.getScale();
        program.setVec2("location", x * scale, window.getHeight() - height * scale - y * scale);
        program.setVec2("rectSize", width * scale, height * scale);
        program.setVec4("radii", radii.topLeft(), radii.topRight(), radii.bottomRight(), radii.bottomLeft());
        program.setFloat("thickness", Math.max(thickness, 0.35F));
        program.setVec2("smoothness", 0.5F, 1.0F);
        program.setColor("color", new Color(0, 0, 0, 0));
        program.setColor("outlineColor", color);
        BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
        program.unbind();
    }

    public void drawGradientRoundedRect(float x, float y, float width, float height, float radius, Color topLeft,
                                        Color topRight, Color bottomLeft, Color bottomRight, MatrixStack matrices) {
        ShaderLibrary.loadDefaultShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("gradient");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null) {
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        program.bind(matrices.peek().getPositionMatrix());
        float scale = HudScaleUtil.getScale();
        program.setVec2("location", x * scale, window.getHeight() - height * scale - y * scale);
        program.setVec2("rectSize", width * scale, height * scale);
        program.setVec4("radii", radius, radius, radius, radius);
        program.setColor("topLeftColor", topLeft);
        program.setColor("topRightColor", topRight);
        program.setColor("bottomLeftColor", bottomLeft);
        program.setColor("bottomRightColor", bottomRight);
        BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
        program.unbind();
    }

    public void drawVerticalGradientRoundedRect(float x, float y, float width, float height, float radius,
                                                Color topColor, Color bottomColor, MatrixStack matrices) {
        drawGradientRoundedRect(x, y, width, height, radius, topColor, topColor, bottomColor, bottomColor, matrices);
    }

    public void drawCircle(float centerX, float centerY, float radius, Color color, MatrixStack matrices) {
        ShaderLibrary.loadDefaultShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("circle");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null) {
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        float size = radius * 2.0F;
        float drawX = centerX - radius;
        float drawY = centerY - radius;

        program.bind(matrices.peek().getPositionMatrix());
        float scale = HudScaleUtil.getScale();
        program.setVec2("location", drawX * scale, window.getHeight() - size * scale - drawY * scale);
        program.setVec2("rectSize", size * scale, size * scale);
        program.setFloat("radius", radius * scale);
        program.setColor("color", color);
        BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(drawX, drawY, size, size));
        program.unbind();
    }

    public void drawArc(float centerX, float centerY, float radius, float startDegrees, float sweepDegrees,
                        float thickness, Color color, MatrixStack matrices) {
        if (sweepDegrees <= 0.0F || color.getAlpha() <= 0) {
            return;
        }

        int segments = Math.max(12, (int) Math.ceil(
                (float) Math.toRadians(sweepDegrees) * radius / Math.max(0.35F, thickness * 0.55F)));
        for (int segment = 0; segment <= segments; segment++) {
            float angle = (float) Math.toRadians(startDegrees + sweepDegrees * segment / segments);
            drawCircle(centerX + (float) Math.cos(angle) * radius,
                    centerY + (float) Math.sin(angle) * radius,
                    thickness / 2.0F, color, matrices);
        }
    }

    public void drawMinecraftRectangle(DrawContext context, float x, float y, float width, float height, int color) {
        int left = Math.round(x);
        int top = Math.round(y);
        int right = Math.round(x + width);
        int bottom = Math.round(y + height);
        context.fill(left, top, right, bottom, color);
    }


    public void drawBlurredRoundedRect(float x, float y, float width, float height, float radius, Color tint,
                                       float alpha, MatrixStack matrices) {
        drawBlurredRoundedRect(x, y, width, height, radius, tint, alpha, matrices, 10.0F);
    }

    public void drawBlurredRoundedRect(float x, float y, float width, float height, float radius, Color tint,
                                       float alpha, MatrixStack matrices, float blurStrength) {
        int blurTexture = resolveHudBlurTexture();
        boolean kawase = BlurManager.BLUR.isKawaseApplied();
        BlurDebugLogger.logf("DrawBlur",
                "drawBlurredRoundedRect rect=(%.1f,%.1f,%.1fx%.1f) r=%.1f alpha=%.2f tint=%s tex=%d kawase=%s strength=%.1f",
                x, y, width, height, radius, alpha, tint, blurTexture, kawase, blurStrength);

        if (blurTexture <= 0) {
            BlurDebugLogger.stateChange("DrawBlur", "FALLBACK_NO_TEXTURE");
            BlurDebugLogger.log("DrawBlur", "FALLBACK no blur texture -> solid rounded rect");
            drawRoundedRect(x, y, width, height, radius, ColorUtil.withAlpha(tint, alpha), matrices);
            return;
        }

        ShaderLibrary.loadBlurShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("blurred_round_rect");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        BlurDebugLogger.log("DrawBlur", "blurred_round_rect -> " + BlurDebugLogger.describeRegistryShader("blurred_round_rect"));
        if (program == null) {
            BlurDebugLogger.stateChange("DrawBlur", "FALLBACK_NO_SHADER");
            BlurDebugLogger.log("DrawBlur", "FALLBACK blurred_round_rect missing/unlinked -> solid rounded rect");
            drawRoundedRect(x, y, width, height, radius, ColorUtil.withAlpha(tint, alpha), matrices);
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        int widthFb = client.getWindow().getFramebufferWidth();
        int heightFb = client.getWindow().getFramebufferHeight();
        float scale = HudScaleUtil.getScale();
        float effectiveRadius = Math.min(radius, Math.min(width, height) * 0.5F);

        BlurDebugLogger.dumpGl("DrawBlur-before-bind");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "blurredTexture");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "resolution");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "size");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "alpha");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "color");
        BlurDebugLogger.dumpUniform("DrawBlur", program.getProgramId(), "blurStrength");
        BlurDebugLogger.logf("DrawBlur", "tint rgba=(%d,%d,%d,%d) alphaFade=%.3f",
                tint.getRed(), tint.getGreen(), tint.getBlue(), tint.getAlpha(), alpha);

        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        TextureFilterUtil.drawWithTexture(blurTexture, false, () -> {
            BlurDebugLogger.log("DrawBlur", "inside drawWithTexture bound tex=" + blurTexture);
            BlurDebugLogger.dumpGl("DrawBlur-inside-texture");

            program.bind(matrices.peek().getPositionMatrix());
            program.setInt("blurredTexture", 0);
            program.setVec2("resolution", widthFb, heightFb);
            program.setVec2("size", width * scale, height * scale);
            program.setVec4("round", effectiveRadius, effectiveRadius, effectiveRadius, effectiveRadius);
            program.setFloat("alpha", alpha);
            program.setFloat("blurStrength", blurStrength);

            float tintMix = Math.min(1.0F, Math.max(0.0F, tint.getAlpha() / 255.0F));
            program.setVec4("color", tint.getRed() / 255.0F, tint.getGreen() / 255.0F, tint.getBlue() / 255.0F, tintMix);
            program.setFloat("roundType", 0.0F);
            BlurDebugLogger.logf("DrawBlur", "shader uniforms res=%dx%d size=(%.1f,%.1f) tintMix=%.3f blurStrength=%.1f",
                    widthFb, heightFb, width * scale, height * scale, tintMix, blurStrength);

            BlendStateUtil.runBlended(() -> {
                BlurDebugLogger.log("DrawBlur", "drawQuad begin");
                ManagedShader.drawQuad(x, y, width, height);
                BlurDebugLogger.log("DrawBlur", "drawQuad end");
            });
            program.unbind();
            BlurDebugLogger.stateChange("DrawBlur", "GLSL_OK");
        });
        BlurDebugLogger.dumpGl("DrawBlur-after");
    }

    public void drawBlurredSquircleRect(float x, float y, float width, float height, float radius, Color tint,
                                        float alpha, MatrixStack matrices) {
        drawBlurredHudPanel(x, y, width, height, CornerRadii.all(radius), tint, alpha, matrices,
                BlurManager.BLUR.isKawaseApplied() ? 1.5F : 0.75F);
    }

    public void drawBlurredHudPanel(float x, float y, float width, float height, CornerRadii radii, Color tint,
                                    float alpha, MatrixStack matrices, float blurStrength) {
        int blurTexture = resolveHudBlurTexture();
        if (blurTexture <= 0) {
            drawRoundedRect(x, y, width, height, radii, ColorUtil.withAlpha(tint, alpha), matrices);
            return;
        }

        ShaderLibrary.loadBlurShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("blurred_round_rect");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null) {
            drawRoundedRect(x, y, width, height, radii, ColorUtil.withAlpha(tint, alpha), matrices);
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        int widthFb = client.getWindow().getFramebufferWidth();
        int heightFb = client.getWindow().getFramebufferHeight();
        float scaleX = hudShaderScaleX();
        float scaleY = hudShaderScaleY();
        float pixelWidth = hudPixelWidth(width);
        float pixelHeight = hudPixelHeight(height);
        float maxRadius = Math.min(pixelWidth, pixelHeight) * 0.5F;
        float topLeft = Math.min(radii.topLeft() * scaleX, maxRadius);
        float topRight = Math.min(radii.topRight() * scaleX, maxRadius);
        float bottomRight = Math.min(radii.bottomRight() * scaleY, maxRadius);
        float bottomLeft = Math.min(radii.bottomLeft() * scaleY, maxRadius);

        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        TextureFilterUtil.drawWithTexture(blurTexture, false, () -> {
            program.bind(matrices.peek().getPositionMatrix());
            program.setInt("blurredTexture", 0);
            program.setVec2("resolution", widthFb, heightFb);
            program.setVec2("size", pixelWidth, pixelHeight);
            program.setVec4("round", topLeft, topRight, bottomRight, bottomLeft);
            program.setFloat("alpha", alpha);
            program.setFloat("blurStrength", blurStrength);

            float tintMix = Math.min(1.0F, Math.max(0.0F, tint.getAlpha() / 255.0F));
            program.setVec4("color", tint.getRed() / 255.0F, tint.getGreen() / 255.0F, tint.getBlue() / 255.0F, tintMix);
            program.setFloat("roundType", 0.0F);

            BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
            program.unbind();
        });
    }

    public void drawLiquidGlassRect(float x, float y, float width, float height, float radius, float alpha,
                                    Color fresnelColor, MatrixStack matrices) {
        ShaderLibrary.loadLiquidGlassShaders();
        Optional<ManagedShader> found = ShaderLibrary.getRegistry().find("liquid_glass");
        ManagedShader program = found.isPresent() && found.get().isLinked() ? found.get() : null;
        if (program == null || MinecraftClient.getInstance().getFramebuffer() == null) {
            drawRoundedRect(x, y, width, height, radius,
                    new Color(255, 255, 255, Math.round(alpha * 70.0F)), matrices);
            return;
        }

        int colorAttachment = MinecraftClient.getInstance().getFramebuffer().getColorAttachment();
        matrices.push();
        matrices.translate(x, y, 0.0F);
        program.bind(matrices.peek().getPositionMatrix());
        float scale = HudScaleUtil.getScale();

        program.setInt("Sampler0", 0);
        program.setVec2("Size", width * scale, height * scale);
        program.setVec4("Radius", radius * scale, radius * scale, radius * scale, radius * scale);
        program.setFloat("Smoothness", 1.35F);
        program.setFloat("CornerSmoothness", 2.0F);
        program.setFloat("GlobalAlpha", alpha);
        program.setFloat("FresnelPower", 1.75F);
        program.setVec3("FresnelColor", fresnelColor.getRed() / 255.0F, fresnelColor.getGreen() / 255.0F,
                fresnelColor.getBlue() / 255.0F);
        program.setFloat("FresnelAlpha", 0.75F);
        program.setFloat("BaseAlpha", 0.36F);
        program.setInt("FresnelInvert", 0);
        program.setFloat("FresnelMix", 0.64F);
        program.setFloat("DistortStrength", 0.018F);

        RenderSystem.setShaderTexture(0, colorAttachment);
        BlendStateUtil.runBlended(() -> drawPreparedLegacyTexturedQuad(width, height));
        program.unbind();
        matrices.pop();
    }


    public void drawDefaultHudThemedPanel(MatrixStack matrices, float x, float y, float width, float height,
                                          float radius, Color topColor, Color bottomColor) {
        drawVerticalGradientRoundedRect(x, y, width, height, radius, topColor, bottomColor, matrices);
    }

    public void drawDefaultHudElementRects(MatrixStack matrices, float x, float y, float width, float height,
                                           float radius, Color topColor, Color bottomColor) {
        drawVerticalGradientRoundedRect(x, y, width, height, radius, topColor, bottomColor, matrices);
    }

    public void drawMainMenuButton(float x, float y, float width, float height, float radius, float hover,
                                   Color accentColor, Color accentColor2, MatrixStack matrices) {
        ShaderLibrary.loadMainMenuShaders();
        ManagedShader program = resolve("main_menu_button");
        if (program == null) {
            Color fallback = ColorUtil.lerp(new Color(24, 26, 31, 180), accentColor, hover);
            drawRoundedRect(x, y, width, height, radius, fallback, matrices);
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        program.bind(matrices.peek().getPositionMatrix());
        float scaleX = hudShaderScaleX();
        float scaleY = hudShaderScaleY();
        program.setVec2("location", x * scaleX, window.getScaledHeight() - height * scaleY - y * scaleY);
        program.setVec2("rectSize", width * scaleX, height * scaleY);
        program.setFloat("radius", radius * scaleX);
        program.setFloat("hover", hover);
        program.setColor("accentColor", accentColor);
        program.setColor("accentColor2", accentColor2);
        BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
        program.unbind();
    }


    public void drawTexture(Identifier texture, float x, float y, float width, float height, Color color,
                            MatrixStack matrices) {
        float drawX = snapHud(x);
        float drawY = snapHud(y);
        float drawWidth = snapHud(width);
        float drawHeight = snapHud(height);

        int glId = MinecraftClient.getInstance().getTextureManager().getTexture(texture).getGlId();
        int[] size = TextureSizeCache.getSize(texture);
        boolean crisp = shouldUseCrispFilter(drawWidth, drawHeight, size[0], size[1]);

        TextureFilterUtil.drawWithTexture(glId, crisp, () -> {
            RenderSystem.setShaderTexture(0, glId);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

            Matrix4f matrix = matrices.peek().getPositionMatrix();
            BufferBuilder buffer = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            int red = color.getRed();
            int green = color.getGreen();
            int blue = color.getBlue();
            int alpha = color.getAlpha();

            buffer.vertex(matrix, drawX, drawY + drawHeight, 0.0F).texture(0.0F, 1.0F).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX + drawWidth, drawY + drawHeight, 0.0F).texture(1.0F, 1.0F).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX + drawWidth, drawY, 0.0F).texture(1.0F, 0.0F).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX, drawY, 0.0F).texture(0.0F, 0.0F).color(red, green, blue, alpha);
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        });
    }

    public void drawTextureRegion(Identifier texture, float x, float y, float width, float height, float u0, float v0,
                                  float u1, float v1, Color color, MatrixStack matrices) {
        float drawX = snapHud(x);
        float drawY = snapHud(y);
        float drawWidth = snapHud(width);
        float drawHeight = snapHud(height);

        int glId = MinecraftClient.getInstance().getTextureManager().getTexture(texture).getGlId();
        int[] size = TextureSizeCache.getSize(texture);
        boolean crisp = shouldUseCrispFilter(drawWidth, drawHeight, size[0], size[1]);

        TextureFilterUtil.drawWithTexture(glId, crisp, () -> {
            RenderSystem.setShaderTexture(0, glId);
            RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);

            Matrix4f matrix = matrices.peek().getPositionMatrix();
            BufferBuilder buffer = Tessellator.getInstance()
                    .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
            int red = color.getRed();
            int green = color.getGreen();
            int blue = color.getBlue();
            int alpha = color.getAlpha();

            buffer.vertex(matrix, drawX, drawY + drawHeight, 0.0F).texture(u0, v1).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX + drawWidth, drawY + drawHeight, 0.0F).texture(u1, v1).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX + drawWidth, drawY, 0.0F).texture(u1, v0).color(red, green, blue, alpha);
            buffer.vertex(matrix, drawX, drawY, 0.0F).texture(u0, v0).color(red, green, blue, alpha);
            BufferRenderer.drawWithGlobalProgram(buffer.end());
        });
    }

    public void drawTextureNative(Identifier texture, float centerX, float centerY, Color color, MatrixStack matrices) {
        float width = TextureSizeCache.nativeHudWidth(texture);
        float height = TextureSizeCache.nativeHudHeight(texture);
        drawTexture(texture, centerX - width / 2.0F, centerY - height / 2.0F, width, height, color, matrices);
    }

    public void drawRoundedTexture(Identifier texture, float x, float y, float width, float height, float radius,
                                   Color color, MatrixStack matrices) {
        drawRoundedTexture(texture, x, y, width, height, radius, 0.0F, 0.0F, 1.0F, 1.0F, color, matrices);
    }

    public void drawRoundedTexture(Identifier texture, float x, float y, float width, float height, float radius,
                                   float u, float v, float regionWidth, float regionHeight, Color color,
                                   MatrixStack matrices) {
        ShaderLibrary.loadDefaultShaders();
        ManagedShader program = resolve("round_texture");
        if (program == null) {
            drawTexture(texture, x, y, width, height, color, matrices);
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        int glId = MinecraftClient.getInstance().getTextureManager().getTexture(texture).getGlId();
        RenderSystem.activeTexture(GL13.GL_TEXTURE0);
        TextureFilterUtil.drawWithTexture(glId, true, () -> {
            program.bind(matrices.peek().getPositionMatrix());
            float scale = HudScaleUtil.getScale();
            program.setVec2("location", x * scale, window.getHeight() - height * scale - y * scale);
            program.setVec2("rectSize", width * scale, height * scale);
            program.setFloat("radius", radius);
            program.setInt("tex", 0);
            program.setFloat("u", u);
            program.setFloat("v", v);
            program.setFloat("w", regionWidth);
            program.setFloat("h", regionHeight);
            program.setColor("tintColor", color);
            BlendStateUtil.runBlended(() -> ManagedShader.drawQuad(x, y, width, height));
            program.unbind();
        });
    }

    public void drawStack(DrawContext context, MatrixStack matrices, ItemStack stack, float x, float y, float scale) {
        if (stack == null || stack.isEmpty()) {
            return;
        }

        matrices.push();
        try {
            matrices.translate(x, y, 0.0F);
            matrices.scale(scale, scale, 1.0F);
            context.drawItem(stack, 0, 0);
            context.drawStackOverlay(MinecraftClient.getInstance().textRenderer, stack, 0, 0);
        } finally {
            matrices.pop();
        }
    }

    private boolean shouldUseCrispFilter(float drawWidth, float drawHeight, int texWidth, int texHeight) {
        if (texWidth <= 64 && texHeight <= 64) {
            return true;
        }
        float scale = HudScaleUtil.getScale();
        return Math.abs(drawWidth * scale - texWidth) < 0.01F
                && Math.abs(drawHeight * scale - texHeight) < 0.01F;
    }


    public static void runOverlay(Runnable draw) {
        ensureMainFramebuffer();
        HudProjectionManager.begin(HudProjectionManager.HUD_SCALE);
        try {
            draw.run();
        } finally {
            HudProjectionManager.end();
            ensureMainFramebuffer();
        }
    }

    public static void renderHudElement(Runnable render) {
        beginHudLiquidGlass();
        try {
            prepareGuiOverlayDraw();
            render.run();
        } finally {
            endHudLiquidGlass();
        }
    }

    public static void beginHudRenderBatch() {
        beginHudLiquidGlass();
        prepareGuiOverlayDraw();
    }

    public static void endHudRenderBatch() {
        endHudLiquidGlass();
        restoreVanillaGuiState();
    }

    public static void beginHudLiquidGlass() {
        hudLiquidGlassScopeDepth++;
    }

    public static void endHudLiquidGlass() {
        hudLiquidGlassScopeDepth = Math.max(0, hudLiquidGlassScopeDepth - 1);
    }

    public static void prepareGuiOverlayDraw() {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void finishGuiOverlayDraw() {
        HudProjectionManager.forceEnd();
        restoreVanillaGuiState();
    }

    public static void restoreVanillaGuiState() {
        ScissorStack.reset();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableDepthTest();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
    }

    public static void resetRenderState() {
        HudProjectionManager.forceEnd();
    }

    public static void ensureMainFramebuffer() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.getFramebuffer() == null) {
            return;
        }

        client.getFramebuffer().beginWrite(false);
        Window window = client.getWindow();
        if (window != null) {
            GL11.glViewport(0, 0, Math.max(1, window.getFramebufferWidth()), Math.max(1, window.getFramebufferHeight()));
        }
    }

    public static boolean areCoreShadersReady() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return false;
        }
        try {
            return client.getShaderLoader().getOrCreateProgram(ShaderProgramKeys.POSITION_TEX_COLOR) != null;
        } catch (RuntimeException exception) {
            return false;
        }
    }

    public static void scaleStart(MatrixStack matrices, float x, float y, float scale) {
        matrices.push();
        matrices.translate(x, y, 0.0F);
        matrices.scale(scale, scale, 1.0F);
        matrices.translate(-x, -y, 0.0F);
    }

    public static void scaleEnd(MatrixStack matrices) {
        matrices.pop();
    }


    public static void drawPreparedLegacyTexturedQuad(float width, float height) {
        RenderSystem.assertOnRenderThread();
        ensureLegacyQuadBuffers();
        LEGACY_QUAD_BUFFER.clear();

        float[] vertices = {
                0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
                0.0F, height, 0.0F, 0.0F, 1.0F,
                width, height, 0.0F, 1.0F, 1.0F,
                0.0F, 0.0F, 0.0F, 0.0F, 0.0F,
                width, height, 0.0F, 1.0F, 1.0F,
                width, 0.0F, 0.0F, 1.0F, 0.0F
        };
        LEGACY_QUAD_BUFFER.put(vertices);
        LEGACY_QUAD_BUFFER.flip();

        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, legacyQuadVbo);
        GL15.glBufferData(GL15.GL_ARRAY_BUFFER, LEGACY_QUAD_BUFFER, GL15.GL_STREAM_DRAW);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);

        int previousVertexArray = GL30.glGetInteger(GL30.GL_VERTEX_ARRAY_BINDING);
        int previousBuffer = GL15.glGetInteger(GL15.GL_ARRAY_BUFFER_BINDING);

        RenderSystem.disableDepthTest();
        GL30.glBindVertexArray(legacyQuadVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, legacyQuadVbo);
        GL11.glDrawArrays(GL11.GL_TRIANGLES, 0, 6);
        GL30.glBindVertexArray(previousVertexArray);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, previousBuffer);
        RenderSystem.enableDepthTest();
    }

    private static void ensureLegacyQuadBuffers() {
        if (legacyQuadVao != 0) {
            return;
        }

        legacyQuadVao = GL30.glGenVertexArrays();
        legacyQuadVbo = GL15.glGenBuffers();
        GL30.glBindVertexArray(legacyQuadVao);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, legacyQuadVbo);
        GL20.glEnableVertexAttribArray(0);
        GL20.glVertexAttribPointer(0, 3, GL11.GL_FLOAT, false, 20, 0L);
        GL20.glEnableVertexAttribArray(1);
        GL20.glVertexAttribPointer(1, 2, GL11.GL_FLOAT, false, 20, 12L);
        GL30.glBindVertexArray(0);
        GL15.glBindBuffer(GL15.GL_ARRAY_BUFFER, 0);
    }


    private static ManagedShader resolve(String name) {
        Optional<ManagedShader> program = ShaderLibrary.getRegistry().find(name);
        return program.isPresent() && program.get().isLinked() ? program.get() : null;
    }

    private static int resolveHudBlurTexture() {
        if (BlurManager.BLUR.hasCapturedFrame()) {
            return BlurManager.BLUR.getSampleTexture();
        }
        return 0;
    }

    private static float snapHud(float value) {
        float scale = HudScaleUtil.getScale();
        return Math.round(value * scale) / scale;
    }

    private static float hudShaderScaleX() {
        Window window = MinecraftClient.getInstance().getWindow();
        if (!HudProjectionManager.isActive()) {
            return HudScaleUtil.getScale();
        }
        float renderWidth = HudScaleUtil.getRenderWidth();
        if (renderWidth <= 0.0F) {
            return 1.0F;
        }
        return window.getScaledWidth() / renderWidth;
    }

    private static float hudShaderScaleY() {
        Window window = MinecraftClient.getInstance().getWindow();
        if (!HudProjectionManager.isActive()) {
            return HudScaleUtil.getScale();
        }
        float renderHeight = HudScaleUtil.getRenderHeight();
        if (renderHeight <= 0.0F) {
            return 1.0F;
        }
        return window.getScaledHeight() / renderHeight;
    }

    private static float hudPixelWidth(float width) {
        Window window = MinecraftClient.getInstance().getWindow();
        float shaderScale = hudShaderScaleX();
        float framebufferRatio = window.getScaledWidth() > 0.0F
                ? (float) window.getFramebufferWidth() / window.getScaledWidth()
                : 1.0F;
        return width * shaderScale * framebufferRatio;
    }

    private static float hudPixelHeight(float height) {
        Window window = MinecraftClient.getInstance().getWindow();
        float shaderScale = hudShaderScaleY();
        float framebufferRatio = window.getScaledHeight() > 0.0F
                ? (float) window.getFramebufferHeight() / window.getScaledHeight()
                : 1.0F;
        return height * shaderScale * framebufferRatio;
    }
}
