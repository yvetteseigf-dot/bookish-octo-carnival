package sky.render;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.PlayerEntityModel;

public interface CapeRenderer {
    void render(AbstractClientPlayerEntity player, int light, PlayerEntityModel model,
                VertexConsumerProvider vertexConsumers, int overlay);

    boolean vanillaUvValues();
}
