package sky.render.framebuffer;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.SimpleFramebuffer;
import org.lwjgl.opengl.GL11;
import sky.render.shader.ManagedShader;

public final class FramebufferTarget {
    private SimpleFramebuffer framebuffer;
    private boolean linear;

    public FramebufferTarget setLinear() {
        linear = true;
        return this;
    }

    public void beginWrite(boolean setViewport) {
        MinecraftClient client = MinecraftClient.getInstance();
        int width = Math.max(1, client.getWindow().getFramebufferWidth());
        int height = Math.max(1, client.getWindow().getFramebufferHeight());
        ensureFramebuffer(width, height);
        framebuffer.beginWrite(setViewport);
    }

    public void endWrite() {
        if (framebuffer != null) {
            framebuffer.endWrite();
        }
    }

    public void drawFullscreen() {
        if (framebuffer == null) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        RenderSystem.bindTexture(framebuffer.getColorAttachment());
        ManagedShader.drawQuad(0.0F, 0.0F, client.getWindow().getScaledWidth(), client.getWindow().getScaledHeight());
    }

    public int getColorAttachment() {
        return framebuffer == null ? 0 : framebuffer.getColorAttachment();
    }

    private void ensureFramebuffer(int width, int height) {
        if (framebuffer != null && framebuffer.textureWidth == width && framebuffer.textureHeight == height) {
            return;
        }

        if (framebuffer != null) {
            framebuffer.delete();
        }

        framebuffer = new SimpleFramebuffer(width, height, false);
        if (linear) {
            RenderSystem.bindTexture(framebuffer.getColorAttachment());
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
            GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        }
    }
}
