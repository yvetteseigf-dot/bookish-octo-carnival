package sky.render;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import sky.event.render.HudRenderEvent;
import sky.event.render.OverlayRenderEvent;

public final class HudOverlayRenderer {
    private HudOverlayRenderer() {
    }

    public static void renderOverlay(DrawContext context, float partialTicks) {
        MatrixStack matrices = context.getMatrices();
        Window window = MinecraftClient.getInstance().getWindow();
        float referenceWidth = (float) (window.getFramebufferWidth() / 2.0);
        float referenceHeight = (float) (window.getFramebufferHeight() / 2.0);
        float scaleX = referenceWidth <= 0.0F ? 1.0F : window.getScaledWidth() / referenceWidth;
        float scaleY = referenceHeight <= 0.0F ? 1.0F : window.getScaledHeight() / referenceHeight;

        matrices.push();
        matrices.scale(scaleX, scaleY, 1.0F);
        HudProjectionManager.beginHud();
        try {
            EventManager.call(new OverlayRenderEvent(matrices, partialTicks, context));
            EventManager.call(new OverlayRenderEvent.Pre(matrices, partialTicks, context));
            EventManager.call(new HudRenderEvent(context, partialTicks));
            EventManager.call(new OverlayRenderEvent.Post(matrices, partialTicks, context));
            EventManager.call(new OverlayRenderEvent.Send(matrices, partialTicks, context));
        } finally {
            DrawHelper.finishGuiOverlayDraw();
            matrices.pop();
        }
    }
}
