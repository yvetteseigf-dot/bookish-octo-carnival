package sky.render;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.resource.Resource;
import net.minecraft.util.Identifier;
import sky.util.render.HudScaleUtil;

public final class TextureSizeCache {
    private static final Map<Identifier, int[]> sizeCache = new HashMap<>();

    private TextureSizeCache() {
    }

    public static float nativeHudWidth(Identifier texture) {
        return getSize(texture)[0] / HudScaleUtil.getScale();
    }

    public static float nativeHudHeight(Identifier texture) {
        return getSize(texture)[1] / HudScaleUtil.getScale();
    }

    public static int[] getSize(Identifier texture) {
        return sizeCache.computeIfAbsent(texture, TextureSizeCache::loadSize);
    }

    private static int[] loadSize(Identifier texture) {
        MinecraftClient client = MinecraftClient.getInstance();

        try {
            Optional<Resource> resource = client.getResourceManager().getResource(texture);
            if (resource.isPresent()) {
                try (NativeImage image = NativeImage.read(resource.get().getInputStream())) {
                    return new int[]{image.getWidth(), image.getHeight()};
                }
            }
        } catch (IOException | RuntimeException ignored) {
        }

        return new int[]{256, 256};
    }
}
