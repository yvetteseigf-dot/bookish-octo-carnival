package sky.render.font;

public final class QueuedGlyph {
    private final float x;
    private final float y;
    private final int color;
    private final Glyph glyph;

    public QueuedGlyph(float x, float y, int color, Glyph glyph) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.glyph = glyph;
    }

    public float x() {
        return x;
    }

    public float y() {
        return y;
    }

    public int color() {
        return color;
    }

    public Glyph glyph() {
        return glyph;
    }
}
