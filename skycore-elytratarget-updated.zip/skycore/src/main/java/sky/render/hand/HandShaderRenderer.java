package sky.render.hand;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.SimpleFramebuffer;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL13;
import org.lwjgl.opengl.GL14;
import org.lwjgl.opengl.GL20;
import org.lwjgl.opengl.GL30;
import sky.theme.GuiTheme;
import sky.access.MinecraftAccess;
import sky.module.visuals.Hands;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import sky.render.DrawHelper;

public final class HandShaderRenderer implements MinecraftAccess {
    private static final String HAND_VERTEX_SHADER = "#version 120\n"
            + "void main() {\n"
            + "    gl_TexCoord[0] = gl_MultiTexCoord0;\n"
            + "    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;\n"
            + "}";
    private static final String FULLSCREEN_VERTEX_SHADER = "#version 150\n"
            + "uniform mat4 Transform;\n"
            + "in vec3 Position;\n"
            + "in vec2 UV0;\n"
            + "out vec2 vTexCoord;\n"
            + "void main() {\n"
            + "    vTexCoord = vec2(UV0.x, 1.0 - UV0.y);\n"
            + "    gl_Position = Transform * vec4(Position, 1.0);\n"
            + "}";
    private static final float OPTIMIZED_SCALE = 0.55F;
    private static final int MAX_BLOOM_PASSES_OPTIMIZED = 4;

    private static HandShaderRenderer instance;

    private final List<SimpleFramebuffer> bloomBuffers = new ArrayList<>();
    private int downProg = -1;
    private int upProg = -1;
    private int glowProg = -1;
    private int maskProg = -1;
    private int fillProg = -1;
    private int mirrorPostProg = -1;
    private int transparentPostProg = -1;
    private int shaderPostProg = -1;
    private int outlineProg = -1;
    private int flameFadeProg = -1;
    private int flameOuterProg = -1;
    private int flameBlitProg = -1;
    private float smoothDt = 0.016666668F;
    private long lastSwingMs = -10000L;
    private int lastBloomTex = -1;
    private final long shaderSessionStart = System.currentTimeMillis();
    private final Map<Long, Integer> uniformCache = new HashMap<>();
    private int captureWidth = -1;
    private int captureHeight = -1;
    private int processWidth = -1;
    private int processHeight = -1;
    private int configuredBeforeDepthTex = -1;
    private int configuredAfterDepthTex = -1;

    private SimpleFramebuffer beforeBuffer;
    private SimpleFramebuffer afterBuffer;
    private SimpleFramebuffer maskBuffer;
    private SimpleFramebuffer processCompositeBuffer;
    private SimpleFramebuffer flameRead;
    private SimpleFramebuffer flameWrite;
    private Matrix4f processTransform;
    private Matrix4f screenTransform;
    private int[] savedViewport;
    private long lastFlameTime;
    private float smoothFlameRise;
    private float smoothFlameSway;
    private float smoothBurst;
    private boolean wasSwinging;
    private int autoTick;

    public static HandShaderRenderer getInstance() {
        if (instance == null) {
            instance = new HandShaderRenderer();
        }
        return instance;
    }

    public void onHandsPre() {
        if (fillProg == -1) {
            initShaders();
        }
        if (!needsCapture()) {
            return;
        }
        ensureCaptureBuffers();
        if (beforeBuffer != null) {
            if (needsColorCapture()) {
                copyColorAndDepthToBuffer(beforeBuffer);
            } else {
                copyDepthToBuffer(beforeBuffer);
            }
        }
    }

    public void onHandsPost() {
        if (!needsCapture()) {
            GL20.glUseProgram(0);
            return;
        }
        ensureCaptureBuffers();
        if (beforeBuffer == null || afterBuffer == null || maskBuffer == null) {
            return;
        }
        if (needsColorCapture()) {
            copyColorAndDepthToBuffer(afterBuffer);
        } else {
            copyDepthToBuffer(afterBuffer);
        }
        mc.getFramebuffer().beginWrite(true);
        renderEffects();
    }

    public void invalidateState() {
        lastBloomTex = -1;
        configuredBeforeDepthTex = -1;
        configuredAfterDepthTex = -1;
        captureWidth = -1;
        captureHeight = -1;
        processWidth = -1;
        processHeight = -1;
    }

    public void onDisable() {
        invalidateState();
        if (beforeBuffer != null) {
            beforeBuffer.delete();
            beforeBuffer = null;
        }
        if (afterBuffer != null) {
            afterBuffer.delete();
            afterBuffer = null;
        }
        if (maskBuffer != null) {
            maskBuffer.delete();
            maskBuffer = null;
        }
        if (processCompositeBuffer != null) {
            processCompositeBuffer.delete();
            processCompositeBuffer = null;
        }
        if (flameRead != null) {
            flameRead.delete();
            flameRead = null;
        }
        if (flameWrite != null) {
            flameWrite.delete();
            flameWrite = null;
        }
        for (Framebuffer buffer : bloomBuffers) {
            buffer.delete();
        }
        bloomBuffers.clear();
        lastFlameTime = 0L;
        smoothDt = 0.016666668F;
        smoothFlameRise = 0.0F;
        smoothFlameSway = 0.0F;
        smoothBurst = 0.0F;
        if (downProg != -1) {
            GL20.glDeleteProgram(downProg);
            GL20.glDeleteProgram(upProg);
            GL20.glDeleteProgram(glowProg);
            GL20.glDeleteProgram(maskProg);
            GL20.glDeleteProgram(fillProg);
            GL20.glDeleteProgram(flameFadeProg);
            GL20.glDeleteProgram(flameOuterProg);
            GL20.glDeleteProgram(flameBlitProg);
            if (outlineProg != -1) {
                GL20.glDeleteProgram(outlineProg);
            }
            if (mirrorPostProg != -1) {
                GL20.glDeleteProgram(mirrorPostProg);
            }
            if (transparentPostProg != -1) {
                GL20.glDeleteProgram(transparentPostProg);
            }
            if (shaderPostProg != -1) {
                GL20.glDeleteProgram(shaderPostProg);
            }
            downProg = upProg = glowProg = maskProg = fillProg = mirrorPostProg = transparentPostProg
                    = shaderPostProg = outlineProg = flameFadeProg = flameOuterProg = flameBlitProg = -1;
            uniformCache.clear();
        }
    }

    private void initShaders() {
        downProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D inTexture;\n"
                + "uniform vec2 uOffset, uHalfPixel, uSize;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 u = vTexCoord, h = uHalfPixel * uOffset;\n"
                + "  fragColor = (texture(inTexture, u) * 4.0 + texture(inTexture, u - h) + texture(inTexture, u + h)"
                + " + texture(inTexture, u + vec2(h.x, -h.y)) + texture(inTexture, u - vec2(h.x, -h.y))) / 8.0;\n"
                + "}");
        upProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D inTexture;\n"
                + "uniform vec2 uOffset, uHalfPixel, uSize;\n"
                + "uniform vec3 color;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 u = vTexCoord, h = uHalfPixel * uOffset;\n"
                + "  vec4 s = texture(inTexture, u + vec2(-h.x * 2.0, 0.0)) + texture(inTexture, u + vec2(-h.x, h.y)) * 2.0"
                + " + texture(inTexture, u + vec2(0.0, h.y * 2.0)) + texture(inTexture, u + vec2(h.x, h.y)) * 2.0"
                + " + texture(inTexture, u + vec2(h.x * 2.0, 0.0)) + texture(inTexture, u + vec2(h.x, -h.y)) * 2.0"
                + " + texture(inTexture, u + vec2(0.0, -h.y * 2.0)) + texture(inTexture, u + vec2(-h.x, -h.y)) * 2.0;\n"
                + "  vec4 r = s / 12.0;\n"
                + "  fragColor = vec4(r.rgb * color, r.a);\n"
                + "}");
        glowProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, buildGlowFragment());
        maskProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D beforeTexture;\n"
                + "uniform sampler2D afterTexture;\n"
                + "uniform sampler2D beforeDepthTexture;\n"
                + "uniform sampler2D afterDepthTexture;\n"
                + "uniform int useColorMask;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  float depthBefore = texture(beforeDepthTexture, uv).r;\n"
                + "  float depthAfter = texture(afterDepthTexture, uv).r;\n"
                + "  float depthMask = step(0.0001, depthBefore - depthAfter);\n"
                + "  float mask = depthMask;\n"
                + "  if (useColorMask == 1) {\n"
                + "    vec3 beforeColor = texture(beforeTexture, uv).rgb;\n"
                + "    vec3 afterColor = texture(afterTexture, uv).rgb;\n"
                + "    float colorMask = smoothstep(0.018, 0.10, length(afterColor - beforeColor));\n"
                + "    mask = max(depthMask, colorMask);\n"
                + "  }\n"
                + "  fragColor = vec4(mask);\n"
                + "}");
        outlineProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D inTex;\n"
                + "uniform sampler2D bloomTex;\n"
                + "uniform vec2 texelSize;\n"
                + "uniform float width, alpha, rainbowTime, rainbowSpeed, rainbowScale, screenH, saturation;\n"
                + "uniform int colorMode;\n"
                + "uniform vec3 solidColor;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "vec3 hue2rgb(float h) {\n"
                + "  vec3 p = abs(fract(vec3(h) + vec3(0.0, 2.0/3.0, 1.0/3.0)) * 6.0 - 3.0);\n"
                + "  return clamp(p - 1.0, 0.0, 1.0);\n"
                + "}\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  vec4 c = texture(inTex, uv);\n"
                + "  if (c.a > 0.01) discard;\n"
                + "  float maxA = 0.0;\n"
                + "  for (int x = -2; x <= 2; x++) {\n"
                + "    for (int y = -2; y <= 2; y++) {\n"
                + "      if (x == 0 && y == 0) continue;\n"
                + "      vec2 d = vec2(float(x), float(y)) * texelSize * width;\n"
                + "      maxA = max(maxA, texture(inTex, uv + d).a);\n"
                + "    }\n"
                + "  }\n"
                + "  if (maxA < 0.01) discard;\n"
                + "  vec3 col;\n"
                + "  if (colorMode == 1) {\n"
                + "    float yN = gl_FragCoord.y / max(screenH, 1.0);\n"
                + "    float h = fract(yN * rainbowScale + rainbowTime * rainbowSpeed);\n"
                + "    col = hue2rgb(h);\n"
                + "  } else if (colorMode == 2) {\n"
                + "    vec4 b = texture(bloomTex, uv);\n"
                + "    vec3 cb = b.rgb / max(b.a, 0.001);\n"
                + "    float m = max(cb.r, max(cb.g, cb.b));\n"
                + "    if (m > 0.001) cb /= m;\n"
                + "    float l = dot(cb, vec3(0.299, 0.587, 0.114));\n"
                + "    col = clamp(mix(vec3(l), cb, saturation), 0.0, 1.0);\n"
                + "  } else {\n"
                + "    col = solidColor;\n"
                + "  }\n"
                + "  fragColor = vec4(col, maxA * alpha);\n"
                + "}");
        fillProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D originalTexture;\n"
                + "uniform sampler2D maskTexture;\n"
                + "uniform vec3 fillColor;\n"
                + "uniform float fillAlpha, shadingStrength;\n"
                + "uniform int keepShading;\n"
                + "uniform int rainbow;\n"
                + "uniform float rainbowTime, rainbowSpeed, rainbowScale, screenH;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "vec3 hue2rgb(float h) {\n"
                + "  vec3 p = abs(fract(vec3(h) + vec3(0.0, 2.0/3.0, 1.0/3.0)) * 6.0 - 3.0);\n"
                + "  return clamp(p - 1.0, 0.0, 1.0);\n"
                + "}\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  float mask = texture(maskTexture, uv).a;\n"
                + "  if (mask < 0.01) discard;\n"
                + "  vec4 s = texture(originalTexture, uv);\n"
                + "  vec3 f;\n"
                + "  if (rainbow == 1) {\n"
                + "    float yN = gl_FragCoord.y / max(screenH, 1.0);\n"
                + "    float h = fract(yN * rainbowScale + rainbowTime * rainbowSpeed);\n"
                + "    f = hue2rgb(h);\n"
                + "  } else {\n"
                + "    f = fillColor;\n"
                + "  }\n"
                + "  if (keepShading == 1) f *= mix(1.0, dot(s.rgb, vec3(0.299, 0.587, 0.114)), shadingStrength);\n"
                + "  fragColor = vec4(mix(s.rgb, f, fillAlpha), mask * fillAlpha);\n"
                + "}");
        mirrorPostProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D sceneTex;\n"
                + "uniform sampler2D blurTex;\n"
                + "uniform sampler2D maskTex;\n"
                + "uniform vec4 multiplier;\n"
                + "uniform vec2 resolution;\n"
                + "uniform float mixFactor;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  float inside = texture(maskTex, uv).a;\n"
                + "  if (inside < 0.01) discard;\n"
                + "  vec4 src = texture(sceneTex, uv);\n"
                + "  vec2 blurUV = vec2(gl_FragCoord.x / resolution.x, 1.0 - gl_FragCoord.y / resolution.y);\n"
                + "  vec4 blurred = texture(blurTex, blurUV);\n"
                + "  vec3 tinted = blurred.rgb * multiplier.rgb;\n"
                + "  fragColor = vec4(mix(tinted, src.rgb, mixFactor), inside);\n"
                + "}");
        transparentPostProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D sceneTex, blurTex, maskTex;\n"
                + "uniform vec4 multiplier;\n"
                + "uniform vec2 resolution;\n"
                + "uniform float mixFactor;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  float mask = texture(maskTex, uv).a;\n"
                + "  if (mask < 0.01) discard;\n"
                + "  vec4 src = texture(sceneTex, uv);\n"
                + "  vec2 blurUV = vec2(gl_FragCoord.x / resolution.x, 1.0 - gl_FragCoord.y / resolution.y);\n"
                + "  vec4 blurred = texture(blurTex, blurUV);\n"
                + "  vec3 tintedGlass = blurred.rgb * multiplier.rgb;\n"
                + "  vec3 finalRGB = mix(tintedGlass, src.rgb, mixFactor);\n"
                + "  fragColor = vec4(finalRGB, mask * multiplier.a);\n"
                + "}");
        shaderPostProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D sceneTex, maskTex;\n"
                + "uniform vec2 resolution;\n"
                + "uniform float time, alpha, speed;\n"
                + "uniform vec3 primaryColor, accentColor;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "float hash21(vec2 p){p=fract(p*vec2(443.897,397.297));p+=dot(p,p+23.317);return fract(p.x*p.y);}\n"
                + "float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);float a=hash21(i),b=hash21(i+vec2(1.0,0.0)),"
                + "c=hash21(i+vec2(0.0,1.0)),d=hash21(i+vec2(1.0,1.0));return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}\n"
                + "float fbm(vec2 p){float v=0.0,a=0.5;for(int i=0;i<4;i++){v+=noise(p)*a;p=mat2(1.62,-1.18,1.18,1.62)*p"
                + "+vec2(5.2,2.7);a*=0.5;}return v;}\n"
                + "vec3 sat(vec3 c,float k){float g=dot(c,vec3(0.299,0.587,0.114));return clamp(mix(vec3(g),c,k),0.0,1.0);}\n"
                + "vec3 cosmosColor(vec2 p,float t){vec2 q=p*4.6;float n=fbm(q+vec2(t*0.12,-t*0.08));"
                + "float r=fbm(q*1.8+vec2(-t*0.07,t*0.11)+8.0);float d=smoothstep(0.18,0.95,mix(n,r,0.45));"
                + "vec3 base=primaryColor/max(max(primaryColor.r,max(primaryColor.g,primaryColor.b)),0.001);"
                + "vec3 col=mix(base*0.05,base*0.9,d);col=mix(col,vec3(1.0),smoothstep(0.82,1.0,d)*0.55);"
                + "float stars=smoothstep(0.988,0.999,hash21(floor(p*vec2(95.0,70.0))))"
                + "*smoothstep(0.34,0.0,length(fract(p*vec2(95.0,70.0))-0.5));return sat(col+stars,1.35);}\n"
                + "void main(){vec2 uv=vTexCoord;float mask=texture(maskTex,uv).a;if(mask<0.01)discard;"
                + "vec4 src=texture(sceneTex,uv);vec2 p=gl_FragCoord.xy/max(resolution,vec2(1.0));"
                + "p.x*=resolution.x/max(resolution.y,1.0);float t=time*speed;vec3 col=cosmosColor(p,t);"
                + "float rim=mask*(1.0-smoothstep(0.01,0.62,texture(maskTex,uv+vec2(1.0/resolution.x,0.0)).a"
                + "*texture(maskTex,uv+vec2(-1.0/resolution.x,0.0)).a*texture(maskTex,uv+vec2(0.0,1.0/resolution.y)).a"
                + "*texture(maskTex,uv+vec2(0.0,-1.0/resolution.y)).a));col+=accentColor*rim*0.4;"
                + "vec3 finalRGB=mix(src.rgb,col,alpha);fragColor=vec4(clamp(finalRGB,0.0,1.0),mask*max(alpha,0.08));}");
        flameFadeProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D inTex;\n"
                + "uniform sampler2D anchorTex;\n"
                + "uniform vec2 offset;\n"
                + "uniform vec2 texSize;\n"
                + "uniform float fade;\n"
                + "uniform float t;\n"
                + "uniform float dt;\n"
                + "uniform float turb;\n"
                + "uniform float flickAmp;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "float wob(float y, float tt) {\n"
                + "  return sin(y * 11.0 + tt * 5.1) * 0.55 + sin(y * 19.0 - tt * 2.8) * 0.28"
                + " + sin(y * 5.0 + tt * 1.7) * 0.42 + sin(y * 31.0 + tt * 6.4) * 0.18;\n"
                + "}\n"
                + "vec4 blurSample(vec2 p) {\n"
                + "  vec2 px = 1.0 / max(texSize, vec2(1.0));\n"
                + "  vec4 c = texture(inTex, p) * 0.34;\n"
                + "  c += texture(inTex, p + vec2( px.x, 0.0)) * 0.165;\n"
                + "  c += texture(inTex, p + vec2(-px.x, 0.0)) * 0.165;\n"
                + "  c += texture(inTex, p + vec2(0.0,  px.y)) * 0.165;\n"
                + "  c += texture(inTex, p + vec2(0.0, -px.y)) * 0.165;\n"
                + "  return c;\n"
                + "}\n"
                + "void main() {\n"
                + "  vec2 uv = vTexCoord;\n"
                + "  vec2 px = 1.0 / max(texSize, vec2(1.0));\n"
                + "  float mirroredY = 1.0 - uv.y;\n"
                + "  float dxTurb = (wob(mirroredY, t) - wob(mirroredY, t - dt)) * turb;\n"
                + "  float yFactor = 0.85 + mirroredY * 1.05;\n"
                + "  vec2 disp = vec2(offset.x + dxTurb, offset.y * yFactor);\n"
                + "  vec4 c = blurSample(uv - disp);\n"
                + "  float anchor = texture(anchorTex, uv).a;\n"
                + "  anchor = max(anchor, texture(anchorTex, uv + vec2(px.x * 2.0, 0.0)).a);\n"
                + "  anchor = max(anchor, texture(anchorTex, uv + vec2(-px.x * 2.0, 0.0)).a);\n"
                + "  anchor = max(anchor, texture(anchorTex, uv + vec2(0.0, px.y * 2.0)).a);\n"
                + "  anchor = max(anchor, texture(anchorTex, uv + vec2(0.0, -px.y * 2.0)).a);\n"
                + "  anchor = clamp(anchor * 1.45, 0.0, 1.0);\n"
                + "  float flick = 1.0 - flickAmp + flickAmp * (0.5 + 0.5 * sin(t * 16.0) + 0.3 * sin(t * 10.7));\n"
                + "  float oldA = c.a;\n"
                + "  float retention = mix(0.22, 0.99, anchor) * flick;\n"
                + "  float fadeBoost = mix(3.6, 1.0, anchor);\n"
                + "  float newA = max(0.0, oldA * retention - fade * fadeBoost);\n"
                + "  float scale = oldA > 0.001 ? newA / oldA : 0.0;\n"
                + "  fragColor = vec4(c.rgb * scale, newA);\n"
                + "}");
        flameOuterProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, buildFlameOuterFragment());
        flameBlitProg = createFullscreenProgram(FULLSCREEN_VERTEX_SHADER, "#version 150\n"
                + "uniform sampler2D inTex;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  fragColor = texture(inTex, vTexCoord);\n"
                + "}");
    }

    private String buildGlowFragment() {
        return "#version 150\n"
                + "uniform sampler2D bloomTexture, maskTexture, sceneTexture;\n"
                + "uniform vec3 glowColor1, glowColor2;\n"
                + "uniform float exposure, saturation;\n"
                + "uniform int outerOnly, colorMode;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + "void main() {\n"
                + "  vec2 u = vTexCoord;\n"
                + "  vec4 b = texture(bloomTexture, u);\n"
                + "  float mask = texture(maskTexture, u).a;\n"
                + "  float outerMask = 1.0 - clamp(mask, 0.0, 1.0);\n"
                + "  float edge = outerOnly == 1 ? smoothstep(0.10, 0.92, outerMask) : 1.0;\n"
                + "  float i = b.a * edge * exposure;\n"
                + "  if (i <= 0.001) discard;\n"
                + "  vec3 themed;\n"
                + "  if (colorMode == 0) {\n"
                + "    themed = mix(glowColor1, glowColor2, clamp(u.y, 0.0, 1.0));\n"
                + "  } else if (colorMode == 2) {\n"
                + "    vec3 itemCol = texture(sceneTexture, u).rgb;\n"
                + "    float lum = dot(itemCol, vec3(0.299, 0.587, 0.114));\n"
                + "    itemCol = mix(vec3(lum), itemCol, 1.35);\n"
                + "    themed = mix(glowColor1, itemCol, 0.72);\n"
                + "  } else {\n"
                + "    themed = mix(glowColor1, glowColor2, clamp(u.y, 0.0, 1.0));\n"
                + "  }\n"
                + "  vec3 c = b.rgb / max(b.a, 0.001);\n"
                + "  float m = max(c.r, max(c.g, c.b));\n"
                + "  if (m > 0.001) c /= m;\n"
                + "  float l = dot(c, vec3(0.299, 0.587, 0.114));\n"
                + "  vec3 autoCol = clamp(mix(vec3(l), c, saturation), 0.0, 1.0);\n"
                + "  float themedWeight = colorMode == 0 ? 0.88 : (colorMode == 2 ? 0.82 : 0.72);\n"
                + "  vec3 col = clamp(autoCol * (1.0 - themedWeight) + themed * themedWeight, 0.0, 1.0);\n"
                + "  fragColor = vec4(col, i);\n"
                + "}\n";
    }

    private String buildFlameOuterFragment() {
        return "#version 150\n"
                + "uniform sampler2D bloomTexture;\n"
                + "uniform sampler2D maskTexture;\n"
                + "uniform sampler2D sceneTexture;\n"
                + "uniform vec3 glowColor1, glowColor2;\n"
                + "uniform vec2 resolution;\n"
                + "uniform float exposure, saturation, time;\n"
                + "uniform int colorMode;\n"
                + "in vec2 vTexCoord;\n"
                + "out vec4 fragColor;\n"
                + auroraCommonFragment()
                + buildFlameColorMix()
                + "void main(){\n"
                + "  vec2 uv=vTexCoord;\n"
                + "  vec2 fxUv=vec2(uv.x, 1.0-uv.y);\n"
                + "  vec4 b=texture(bloomTexture, uv);\n"
                + "  float mask=texture(maskTexture, uv).a;\n"
                + "  vec3 sceneCol=texture(sceneTexture, uv).rgb;\n"
                + "  float outerMask=1.0-clamp(mask,0.0,1.0);\n"
                + "  float edge=smoothstep(0.10,0.92,outerMask);\n"
                + "  float outer=b.a*edge;\n"
                + "  float rawAlpha=outer*exposure;\n"
                + "  if(rawAlpha<=0.001) discard;\n"
                + "  float aspect=resolution.x/max(resolution.y,1.0);\n"
                + "  vec2 p=fxUv*vec2(aspect,1.0)*3.8;\n"
                + "  float t=time*1.35;\n"
                + "  vec2 flow=p+vec2(sin(p.y*3.4+t*2.8)*0.30, -t*1.9);\n"
                + "  flow+=vec2(cos(p.x*5.1-t*1.6), sin(p.x*4.2+t*1.9))*0.16;\n"
                + "  float n1=fbm(flow*1.15+vec2(0.0,t*0.55));\n"
                + "  float n2=fbm(flow*0.92-vec2(t*0.42, t*0.68));\n"
                + "  float fire=clamp(n1*0.58+n2*0.42, 0.0, 1.0);\n"
                + "  float tongue=pow(max(0.0, sin((p.x*2.1-p.y*3.4)+fire*5.4+t*1.7)*0.5+0.5), 5.2);\n"
                + "  float aura=smoothstep(0.05,0.98,outerMask);\n"
                + "  fire=clamp(fire*aura+tongue*aura*0.38, 0.0, 1.0);\n"
                + "  vec3 hot=vec3(1.0, 0.99, 0.94);\n"
                + "  vec3 coreDefault=mix(glowColor2, vec3(0.55, 0.92, 1.0), colorMode == 0 ? 0.62 : 0.18);\n"
                + "  vec3 edgeDefault=mix(glowColor1, vec3(0.18, 0.48, 0.95), colorMode == 0 ? 0.45 : 0.12);\n"
                + "  vec3 baseCol=pickFlameColor(glowColor1, glowColor2, hot, coreDefault, edgeDefault, colorMode, sceneCol);\n"
                + "  vec3 core=mix(baseCol, hot, 0.35);\n"
                + "  vec3 edgeCol=baseCol*0.72;\n"
                + "  vec3 col=mix(edgeCol, core, smoothstep(0.18, 0.72, fire));\n"
                + "  col=mix(col, hot, smoothstep(0.58, 0.98, fire)*0.92);\n"
                + "  col+=hot*tongue*0.22*aura;\n"
                + "  col=softLimit(sat(col, 1.0+clamp(saturation,0.5,2.2)*0.14));\n"
                + "  float intensity=clamp(rawAlpha*(0.55+fire*0.62+tongue*0.16*aura), 0.0, 1.0);\n"
                + "  fragColor=vec4(col, intensity);\n"
                + "}\n";
    }

    private String auroraCommonFragment() {
        return "float hash21(vec2 p){p=fract(p*vec2(123.34,345.45));p+=dot(p,p+34.345);return fract(p.x*p.y);}\n"
                + "float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.0-2.0*f);float a=hash21(i),b=hash21(i+vec2(1.0,0.0)),"
                + "c=hash21(i+vec2(0.0,1.0)),d=hash21(i+vec2(1.0,1.0));return mix(mix(a,b,f.x),mix(c,d,f.x),f.y);}\n"
                + "float fbm(vec2 p){float v=0.0,a=0.52;for(int i=0;i<4;i++){v+=noise(p)*a;p=mat2(1.58,-1.16,1.16,1.58)*p"
                + "+vec2(5.2,2.7);a*=0.5;}return v;}\n"
                + "vec3 sat(vec3 c,float k){float g=dot(c,vec3(0.299,0.587,0.114));return clamp(mix(vec3(g),c,k),0.0,1.0);}\n"
                + "vec3 softLimit(vec3 c){c=max(c,vec3(0.0));return c/(1.0+c*0.35);}\n";
    }

    private String buildFlameColorMix() {
        return "vec3 pickFlameColor(vec3 glowColor1, vec3 glowColor2, vec3 hot, vec3 coreDefault, vec3 edgeDefault,"
                + " int colorMode, vec3 sceneCol){\n"
                + "  if (colorMode == 0) return mix(edgeDefault, coreDefault, 0.5);\n"
                + "  if (colorMode == 2) {\n"
                + "    float lum = dot(sceneCol, vec3(0.299, 0.587, 0.114));\n"
                + "    vec3 ic = mix(vec3(lum), sceneCol, 1.25);\n"
                + "    return mix(glowColor1, ic, 0.75);\n"
                + "  }\n"
                + "  return mix(glowColor1, glowColor2, 0.55);\n"
                + "}\n";
    }

    private int createFullscreenProgram(String vertexSource, String fragmentSource) {
        return createProgram(vertexSource, fragmentSource, true);
    }

    private int createHandProgram(String vertexSource, String fragmentSource) {
        return createProgram(vertexSource, fragmentSource, false);
    }

    private int createProgram(String vertexSource, String fragmentSource, boolean bindLegacyQuadAttribs) {
        int vertexShader = GL20.glCreateShader(GL20.GL_VERTEX_SHADER);
        int fragmentShader = GL20.glCreateShader(GL20.GL_FRAGMENT_SHADER);
        int program = GL20.glCreateProgram();

        GL20.glShaderSource(vertexShader, vertexSource);
        GL20.glCompileShader(vertexShader);
        if (GL20.glGetShaderi(vertexShader, GL20.GL_COMPILE_STATUS) == 0) {
            System.err.println("[Hands] VS error: " + GL20.glGetShaderInfoLog(vertexShader, 1024));
        }

        GL20.glShaderSource(fragmentShader, fragmentSource);
        GL20.glCompileShader(fragmentShader);
        if (GL20.glGetShaderi(fragmentShader, GL20.GL_COMPILE_STATUS) == 0) {
            System.err.println("[Hands] FS error: " + GL20.glGetShaderInfoLog(fragmentShader, 1024));
        }

        GL20.glAttachShader(program, vertexShader);
        GL20.glAttachShader(program, fragmentShader);
        if (bindLegacyQuadAttribs) {
            GL20.glBindAttribLocation(program, 0, "Position");
            GL20.glBindAttribLocation(program, 1, "UV0");
        }
        GL20.glLinkProgram(program);
        GL20.glDeleteShader(vertexShader);
        GL20.glDeleteShader(fragmentShader);
        return program;
    }

    private void renderEffects() {
        setup2D();
        if (!buildMask()) {
            restore3D();
            return;
        }
        lastBloomTex = -1;
        Hands hands = Hands.INSTANCE;
        if (hands.mode.is("Fill")) {
            renderFillOverlay();
        } else if (hands.mode.is("Shader")) {
            renderShaderOverlay();
        }
        if (hands.shouldRenderGlow() && hands.outerGlow.isEnabled()) {
            doBloomChain();
        } else if (hands.flameEnabled.isEnabled()) {
            doFlameChain();
        } else {
            clearFlameState();
        }
        if (hands.outlineEnabled.isEnabled() && !hands.shouldRenderGlow() && !hands.flameEnabled.isEnabled()) {
            doSmallBlurForAuto();
        }
        if (hands.outlineEnabled.isEnabled()) {
            renderOutline();
        }
        restore3D();
    }

    private boolean buildMask() {
        if (maskProg == -1) {
            return false;
        }
        int beforeDepth = beforeBuffer.getDepthAttachment();
        int afterDepth = afterBuffer.getDepthAttachment();
        if (beforeDepth != 0 && beforeDepth != configuredBeforeDepthTex) {
            configureDepthTexture(beforeDepth);
            configuredBeforeDepthTex = beforeDepth;
        }
        if (afterDepth != 0 && afterDepth != configuredAfterDepthTex) {
            configureDepthTexture(afterDepth);
            configuredAfterDepthTex = afterDepth;
        }

        maskBuffer.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
        maskBuffer.clear();
        maskBuffer.beginWrite(false);
        RenderSystem.disableDepthTest();
        RenderSystem.disableBlend();
        GL20.glUseProgram(maskProg);

        if (useColorMask()) {
            u1i(maskProg, "beforeTexture", 0);
            u1i(maskProg, "afterTexture", 1);
            u1i(maskProg, "beforeDepthTexture", 2);
            u1i(maskProg, "afterDepthTexture", 3);
            u1i(maskProg, "useColorMask", 1);
            bindTex(GL13.GL_TEXTURE0, beforeBuffer.getColorAttachment());
            bindTex(GL13.GL_TEXTURE1, afterBuffer.getColorAttachment());
            bindTex(GL13.GL_TEXTURE2, beforeDepth);
            bindTex(GL13.GL_TEXTURE3, afterDepth);
        } else {
            u1i(maskProg, "beforeDepthTexture", 0);
            u1i(maskProg, "afterDepthTexture", 1);
            u1i(maskProg, "useColorMask", 0);
            bindTex(GL13.GL_TEXTURE0, beforeDepth);
            bindTex(GL13.GL_TEXTURE1, afterDepth);
        }

        drawProcessQuad(maskProg);
        GL20.glUseProgram(0);

        if (useColorMask()) {
            bindTex(GL13.GL_TEXTURE3, 0);
            bindTex(GL13.GL_TEXTURE2, 0);
            bindTex(GL13.GL_TEXTURE1, 0);
            bindTex(GL13.GL_TEXTURE0, 0);
        } else {
            bindTex(GL13.GL_TEXTURE1, 0);
            bindTex(GL13.GL_TEXTURE0, 0);
        }

        RenderSystem.enableDepthTest();
        mc.getFramebuffer().beginWrite(true);
        return true;
    }

    private void renderFillOverlay() {
        Hands hands = Hands.INSTANCE;
        float fillAlpha = hands.fillAlpha.getCurrent();
        if (fillAlpha <= 0.001F) {
            return;
        }
        Color accent = GuiTheme.theme.getAccent();

        mc.getFramebuffer().beginWrite(true);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        GL20.glUseProgram(fillProg);
        u1i(fillProg, "originalTexture", 0);
        u1i(fillProg, "maskTexture", 1);
        u3f(fillProg, "fillColor", accent.getRed() / 255.0F, accent.getGreen() / 255.0F, accent.getBlue() / 255.0F);
        u1f(fillProg, "fillAlpha", fillAlpha);
        u1i(fillProg, "keepShading", hands.keepShading.isEnabled() ? 1 : 0);
        u1f(fillProg, "shadingStrength", hands.shadingStrength.getCurrent());
        u1i(fillProg, "rainbow", hands.fillRainbow.isEnabled() ? 1 : 0);
        u1f(fillProg, "rainbowTime", System.currentTimeMillis() % 100000L / 1000.0F);
        u1f(fillProg, "rainbowSpeed", hands.rainbowSpeed.getCurrent());
        u1f(fillProg, "rainbowScale", hands.rainbowScale.getCurrent());
        u1f(fillProg, "screenH", processHeight);
        bindTex(GL13.GL_TEXTURE0, afterBuffer.getColorAttachment());
        bindTex(GL13.GL_TEXTURE1, maskBuffer.getColorAttachment());
        drawProcessQuad(fillProg);
        GL20.glUseProgram(0);
        bindTex(GL13.GL_TEXTURE1, 0);
        bindTex(GL13.GL_TEXTURE0, 0);
    }

    private void renderShaderOverlay() {
        if (shaderPostProg == -1) {
            return;
        }
        Hands hands = Hands.INSTANCE;
        Color accent = GuiTheme.theme.getAccent();
        float[] color = {accent.getRed() / 255.0F, accent.getGreen() / 255.0F, accent.getBlue() / 255.0F};
        float time = (System.currentTimeMillis() - shaderSessionStart) / 1000.0F;

        mc.getFramebuffer().beginWrite(true);
        GL20.glUseProgram(shaderPostProg);
        u1i(shaderPostProg, "sceneTex", 0);
        u1i(shaderPostProg, "maskTex", 1);
        u2f(shaderPostProg, "resolution", captureWidth, captureHeight);
        u1f(shaderPostProg, "time", time);
        u1f(shaderPostProg, "alpha", hands.shaderAlpha.getCurrent());
        u1f(shaderPostProg, "speed", hands.shaderSpeed.getCurrent());
        u3f(shaderPostProg, "primaryColor", color[0], color[1], color[2]);
        u3f(shaderPostProg, "accentColor", color[0], color[1], color[2]);
        bindTex(GL13.GL_TEXTURE0, afterBuffer.getColorAttachment());
        bindTex(GL13.GL_TEXTURE1, maskBuffer.getColorAttachment());
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        drawProcessQuad(shaderPostProg);
        GL20.glUseProgram(0);
        bindTex(GL13.GL_TEXTURE1, 0);
        bindTex(GL13.GL_TEXTURE0, 0);
    }

    private void renderOutline() {
        Hands hands = Hands.INSTANCE;
        boolean rainbow = hands.fillRainbow.isEnabled() && hands.mode.is("Fill");
        boolean hasBloom = lastBloomTex != -1;
        int colorMode = rainbow ? 1 : (hasBloom ? 2 : 0);
        Color accent = GuiTheme.theme.getAccent();
        float alpha = accent.getAlpha() / 255.0F;

        GL20.glUseProgram(outlineProg);
        u1i(outlineProg, "inTex", 0);
        u1i(outlineProg, "bloomTex", 1);
        u1i(outlineProg, "colorMode", colorMode);
        u1f(outlineProg, "width", hands.outlineWidth.getCurrent());
        u2f(outlineProg, "texelSize", 1.0F / processWidth, 1.0F / processHeight);
        u1f(outlineProg, "alpha", alpha);
        u1f(outlineProg, "rainbowTime", System.currentTimeMillis() % 100000L / 1000.0F);
        u1f(outlineProg, "rainbowSpeed", hands.rainbowSpeed.getCurrent());
        u1f(outlineProg, "rainbowScale", hands.rainbowScale.getCurrent());
        u1f(outlineProg, "screenH", processHeight);
        u1f(outlineProg, "saturation", hands.saturation.getCurrent());
        u3f(outlineProg, "solidColor", accent.getRed() / 255.0F, accent.getGreen() / 255.0F, accent.getBlue() / 255.0F);

        if (hasBloom) {
            bindTex(GL13.GL_TEXTURE1, lastBloomTex);
        }
        bindTex(GL13.GL_TEXTURE0, maskBuffer.getColorAttachment());
        if (processWidth == captureWidth) {
            drawProcessQuad(outlineProg);
        } else {
            drawScreenQuad();
        }
        if (hasBloom) {
            bindTex(GL13.GL_TEXTURE1, 0);
        }
        bindTex(GL13.GL_TEXTURE0, 0);
        GL20.glUseProgram(0);
    }

    private void doBloomChain() {
        int passes = getMaxBloomPasses();
        int bloomTex = runBloomPasses(passes);
        float[] c1 = resolveGlowColor1();
        float[] c2 = resolveGlowColor2();
        clearFlameState();
        renderGlowComposite(bloomTex, c1, c2);
    }

    private void doFlameChain() {
        Hands hands = Hands.INSTANCE;
        int passes = hands.isFlameWeak()
                ? Math.min(5, Math.max(3, (int) hands.glowRadius.getCurrent() + 1))
                : Math.max(5, (int) hands.glowRadius.getCurrent() + 1);
        int bloomTex = runBloomPasses(passes);
        float[] c1 = resolveGlowColor1();
        float[] c2 = resolveGlowColor2();
        renderFlameComposite(bloomTex, c1, c2);
        if (hands.isFlameWeak()) {
            renderFlame(bloomTex, c1, c2);
        }
    }

    private void renderGlowComposite(int bloomTex, float[] c1, float[] c2) {
        Hands hands = Hands.INSTANCE;
        Runnable draw = () -> {
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
            GL20.glUseProgram(glowProg);
            u1i(glowProg, "bloomTexture", 0);
            u1i(glowProg, "maskTexture", 1);
            u1i(glowProg, "sceneTexture", 2);
            u1i(glowProg, "colorMode", hands.glowColorModeIndex());
            u3f(glowProg, "glowColor1", c1[0], c1[1], c1[2]);
            u3f(glowProg, "glowColor2", c2[0], c2[1], c2[2]);
            u1f(glowProg, "exposure", hands.glowExposure.getCurrent());
            u1f(glowProg, "saturation", hands.saturation.getCurrent());
            u1i(glowProg, "outerOnly", hands.outerGlow.isEnabled() ? 1 : 0);
            bindTex(GL13.GL_TEXTURE2, afterBuffer.getColorAttachment());
            bindTex(GL13.GL_TEXTURE1, maskBuffer.getColorAttachment());
            bindTex(GL13.GL_TEXTURE0, bloomTex);
            drawProcessQuad(glowProg);
            GL20.glUseProgram(0);
            bindTex(GL13.GL_TEXTURE2, 0);
            bindTex(GL13.GL_TEXTURE1, 0);
            bindTex(GL13.GL_TEXTURE0, 0);
        };
        if (usesOptimizedComposite()) {
            processCompositeBuffer.beginWrite(false);
            processCompositeBuffer.clear();
            draw.run();
            processCompositeBuffer.endWrite();
            blitProcessTextureToScreen(processCompositeBuffer.getColorAttachment(), true);
        } else {
            mc.getFramebuffer().beginWrite(true);
            draw.run();
            RenderSystem.defaultBlendFunc();
        }
    }

    private void renderFlameComposite(int bloomTex, float[] c1, float[] c2) {
        Runnable draw = () -> {
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
            bindFlameOuterUniforms(flameOuterProg, bloomTex, c1, c2);
            drawProcessQuad(flameOuterProg);
            GL20.glUseProgram(0);
            bindTex(GL13.GL_TEXTURE2, 0);
            bindTex(GL13.GL_TEXTURE1, 0);
            bindTex(GL13.GL_TEXTURE0, 0);
        };
        if (usesOptimizedComposite()) {
            processCompositeBuffer.beginWrite(false);
            processCompositeBuffer.clear();
            draw.run();
            processCompositeBuffer.endWrite();
            blitProcessTextureToScreen(processCompositeBuffer.getColorAttachment(), true);
        } else {
            mc.getFramebuffer().beginWrite(true);
            draw.run();
            RenderSystem.defaultBlendFunc();
        }
    }

    private void renderFlame(int bloomTex, float[] c1, float[] c2) {
        Hands hands = Hands.INSTANCE;
        int divisor = hands.isFlameWeak() ? Math.max(2, Math.round(1.0F / OPTIMIZED_SCALE)) : 1;
        flameRead = ensureBuffer(flameRead, false, divisor);
        flameWrite = ensureBuffer(flameWrite, false, divisor);

        long now = System.currentTimeMillis();
        float rawDelta = lastFlameTime > 0L ? (now - lastFlameTime) / 1000.0F : 0.016666668F;
        lastFlameTime = now;
        if (rawDelta <= 0.0F || rawDelta > 0.05F) {
            rawDelta = smoothDt;
        }
        rawDelta = Math.max(0.0069444445F, Math.min(0.016666668F, rawDelta));
        smoothDt += (rawDelta - smoothDt) * 0.08F;
        float dt = smoothDt;
        float time = now % 100000L / 1000.0F;

        float rise = hands.flameRise.getCurrent() * dt * 0.22F;
        float swayStrength = hands.flameSway.getCurrent();
        float sway = (float) (Math.sin(time * 4.8F) - Math.sin((time - dt) * 4.8F)) * swayStrength * 0.42F;
        float smoothing = 1.0F - (float) Math.exp(-dt * 9.0F);
        smoothFlameRise += (rise - smoothFlameRise) * smoothing;
        smoothFlameSway += (sway - smoothFlameSway) * smoothing;

        boolean swinging = mc.player != null && mc.player.handSwinging;
        if (hands.flameBurst.isEnabled() && swinging && !wasSwinging) {
            lastSwingMs = now;
        }
        wasSwinging = swinging;
        float sinceSwing = (now - lastSwingMs) / 1000.0F;
        float burst = Math.max(0.0F, 1.0F - sinceSwing / 0.45F);
        smoothBurst += (burst - smoothBurst) * (1.0F - (float) Math.exp(-dt * 6.0F));
        float burstFade = smoothBurst * hands.flameBurstPower.getCurrent() * 0.014F;

        flameWrite.beginWrite(true);
        GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
        RenderSystem.disableBlend();
        GL20.glUseProgram(flameFadeProg);
        u1i(flameFadeProg, "inTex", 0);
        u1i(flameFadeProg, "anchorTex", 1);
        u2f(flameFadeProg, "offset", smoothFlameSway, smoothFlameRise);
        u1f(flameFadeProg, "fade", hands.flameFade.getCurrent() + burstFade);
        u1f(flameFadeProg, "t", time);
        u1f(flameFadeProg, "dt", dt);
        u1f(flameFadeProg, "turb", hands.flameTurb.getCurrent());
        u1f(flameFadeProg, "flickAmp", hands.flameFlicker.getCurrent());
        u2f(flameFadeProg, "texSize", flameRead.textureWidth, flameRead.textureHeight);
        bindTex(GL13.GL_TEXTURE0, flameRead.getColorAttachment());
        bindTex(GL13.GL_TEXTURE1, bloomTex);
        drawSizedQuad(flameFadeProg, flameWrite.textureWidth, flameWrite.textureHeight);
        GL20.glUseProgram(0);
        bindTex(GL13.GL_TEXTURE1, 0);
        bindTex(GL13.GL_TEXTURE0, 0);

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        bindFlameOuterUniforms(flameOuterProg, bloomTex, c1, c2);
        drawSizedQuad(flameOuterProg, flameWrite.textureWidth, flameWrite.textureHeight);
        GL20.glUseProgram(0);
        bindTex(GL13.GL_TEXTURE2, 0);
        bindTex(GL13.GL_TEXTURE1, 0);
        bindTex(GL13.GL_TEXTURE0, 0);

        blitProcessTextureToScreen(flameWrite.getColorAttachment(), true);

        SimpleFramebuffer previous = flameRead;
        flameRead = flameWrite;
        flameWrite = previous;
    }

    private void bindFlameOuterUniforms(int program, int bloomTex, float[] c1, float[] c2) {
        Hands hands = Hands.INSTANCE;
        GL20.glUseProgram(program);
        u1i(program, "bloomTexture", 0);
        u1i(program, "maskTexture", 1);
        u1i(program, "sceneTexture", 2);
        u1i(program, "colorMode", hands.glowColorModeIndex());
        u3f(program, "glowColor1", c1[0], c1[1], c1[2]);
        u3f(program, "glowColor2", c2[0], c2[1], c2[2]);
        u1f(program, "exposure", hands.flameIntensity.getCurrent());
        u2f(program, "resolution", processWidth, processHeight);
        u1f(program, "time", (System.currentTimeMillis() - shaderSessionStart) / 1000.0F);
        u1f(program, "saturation", hands.saturation.getCurrent());
        bindTex(GL13.GL_TEXTURE2, afterBuffer.getColorAttachment());
        bindTex(GL13.GL_TEXTURE1, maskBuffer.getColorAttachment());
        bindTex(GL13.GL_TEXTURE0, bloomTex);
    }

    private void clearFlameState() {
        lastFlameTime = 0L;
        smoothFlameRise = 0.0F;
        smoothFlameSway = 0.0F;
        smoothBurst = 0.0F;
        if (flameRead != null) {
            flameRead.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            flameRead.clear();
        }
        if (flameWrite != null) {
            flameWrite.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            flameWrite.clear();
        }
    }

    private int runBloomPasses(int iter) {
        int texture = maskBuffer.getColorAttachment();
        setupBloomBuffers(iter);
        GL20.glUseProgram(downProg);
        u1i(downProg, "inTexture", 0);
        for (int i = 0; i < iter; i++) {
            SimpleFramebuffer buffer = bloomBuffers.get(i);
            buffer.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            buffer.clear();
            buffer.beginWrite(true);
            u2f(downProg, "uSize", buffer.textureWidth, buffer.textureHeight);
            u2f(downProg, "uOffset", 1.0F + i, 1.0F + i);
            u2f(downProg, "uHalfPixel", 0.5F / buffer.textureWidth, 0.5F / buffer.textureHeight);
            bindTex(GL13.GL_TEXTURE0, texture);
            drawSizedQuad(downProg, buffer.textureWidth, buffer.textureHeight);
            texture = buffer.getColorAttachment();
        }
        GL20.glUseProgram(upProg);
        u1i(upProg, "inTexture", 0);
        for (int i = iter - 1; i >= 1; i--) {
            SimpleFramebuffer buffer = bloomBuffers.get(i - 1);
            buffer.beginWrite(true);
            u2f(upProg, "uSize", buffer.textureWidth, buffer.textureHeight);
            u2f(upProg, "uOffset", 1.0F + i, 1.0F + i);
            u2f(upProg, "uHalfPixel", 0.5F / buffer.textureWidth, 0.5F / buffer.textureHeight);
            u3f(upProg, "color", 1.0F, 1.0F, 1.0F);
            bindTex(GL13.GL_TEXTURE0, texture);
            drawSizedQuad(upProg, buffer.textureWidth, buffer.textureHeight);
            texture = buffer.getColorAttachment();
        }
        GL20.glUseProgram(0);
        return texture;
    }

    private void doSmallBlurForAuto() {
        setupBloomBuffers(3);
        int texture = maskBuffer.getColorAttachment();
        GL20.glUseProgram(downProg);
        u1i(downProg, "inTexture", 0);
        for (int i = 0; i < 3; i++) {
            SimpleFramebuffer buffer = bloomBuffers.get(i);
            buffer.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            buffer.clear();
            buffer.beginWrite(true);
            u2f(downProg, "uSize", buffer.textureWidth, buffer.textureHeight);
            u2f(downProg, "uOffset", 1.0F + i, 1.0F + i);
            u2f(downProg, "uHalfPixel", 0.5F / buffer.textureWidth, 0.5F / buffer.textureHeight);
            bindTex(GL13.GL_TEXTURE0, texture);
            drawSizedQuad(downProg, buffer.textureWidth, buffer.textureHeight);
            texture = buffer.getColorAttachment();
        }
        GL20.glUseProgram(upProg);
        u1i(upProg, "inTexture", 0);
        for (int i = 2; i >= 1; i--) {
            SimpleFramebuffer buffer = bloomBuffers.get(i - 1);
            buffer.beginWrite(true);
            u2f(upProg, "uSize", buffer.textureWidth, buffer.textureHeight);
            u2f(upProg, "uOffset", 1.0F + i, 1.0F + i);
            u2f(upProg, "uHalfPixel", 0.5F / buffer.textureWidth, 0.5F / buffer.textureHeight);
            u3f(upProg, "color", 1.0F, 1.0F, 1.0F);
            bindTex(GL13.GL_TEXTURE0, texture);
            drawSizedQuad(upProg, buffer.textureWidth, buffer.textureHeight);
            texture = buffer.getColorAttachment();
        }
        GL20.glUseProgram(0);
        lastBloomTex = texture;
        mc.getFramebuffer().beginWrite(true);
    }

    private void setupBloomBuffers(int count) {
        int width = processWidth;
        int height = processHeight;
        if (bloomBuffers.size() < count) {
            for (Framebuffer buffer : bloomBuffers) {
                buffer.delete();
            }
            bloomBuffers.clear();
            for (int i = 0; i < count; i++) {
                SimpleFramebuffer buffer = new SimpleFramebuffer(Math.max(2, width >> (i + 1)),
                        Math.max(2, height >> (i + 1)), false);
                setLinearFiltering(buffer);
                buffer.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
                bloomBuffers.add(buffer);
            }
        }
        for (int i = 0; i < count; i++) {
            int targetWidth = Math.max(2, width >> (i + 1));
            int targetHeight = Math.max(2, height >> (i + 1));
            SimpleFramebuffer buffer = bloomBuffers.get(i);
            if (buffer.textureWidth != targetWidth || buffer.textureHeight != targetHeight) {
                buffer.resize(targetWidth, targetHeight);
                setLinearFiltering(buffer);
            }
        }
    }

    private int getMaxBloomPasses() {
        Hands hands = Hands.INSTANCE;
        int radius = (int) hands.glowRadius.getCurrent();
        if (usesOptimizedComposite()) {
            return Math.min(MAX_BLOOM_PASSES_OPTIMIZED, radius);
        }
        return radius;
    }

    private float[] resolveGlowColor1() {
        Hands hands = Hands.INSTANCE;
        if (hands.glowColor.is("Sky")) {
            return new float[]{0.18F, 0.48F, 0.95F};
        }
        return themeBaseColor();
    }

    private float[] resolveGlowColor2() {
        Hands hands = Hands.INSTANCE;
        if (hands.glowColor.is("Sky")) {
            return new float[]{0.55F, 0.92F, 1.0F};
        }
        return themeBaseColor();
    }

    private float[] themeBaseColor() {
        Color accent = GuiTheme.theme.getAccent();
        return new float[]{accent.getRed() / 255.0F, accent.getGreen() / 255.0F, accent.getBlue() / 255.0F};
    }

    private float[] argb(int color) {
        return new float[]{
                (color >> 16 & 255) / 255.0F,
                (color >> 8 & 255) / 255.0F,
                (color & 255) / 255.0F,
                (color >> 24 & 255) / 255.0F
        };
    }

    private void ensureCaptureBuffers() {
        int framebufferWidth = mc.getWindow().getFramebufferWidth();
        int framebufferHeight = mc.getWindow().getFramebufferHeight();
        float scale = getProcessScale();
        int targetWidth = Math.max(2, Math.round(framebufferWidth * scale));
        int targetHeight = Math.max(2, Math.round(framebufferHeight * scale));
        if (framebufferWidth == captureWidth && framebufferHeight == captureHeight
                && targetWidth == processWidth && targetHeight == processHeight
                && beforeBuffer != null && afterBuffer != null && maskBuffer != null) {
            return;
        }
        if (beforeBuffer != null) {
            beforeBuffer.delete();
        }
        if (afterBuffer != null) {
            afterBuffer.delete();
        }
        if (maskBuffer != null) {
            maskBuffer.delete();
        }
        if (processCompositeBuffer != null) {
            processCompositeBuffer.delete();
        }
        beforeBuffer = new SimpleFramebuffer(targetWidth, targetHeight, true);
        afterBuffer = new SimpleFramebuffer(targetWidth, targetHeight, true);
        maskBuffer = new SimpleFramebuffer(targetWidth, targetHeight, false);
        processCompositeBuffer = new SimpleFramebuffer(targetWidth, targetHeight, false);
        setLinearFiltering(processCompositeBuffer);
        captureWidth = framebufferWidth;
        captureHeight = framebufferHeight;
        processWidth = targetWidth;
        processHeight = targetHeight;
        configuredBeforeDepthTex = -1;
        configuredAfterDepthTex = -1;
    }

    private SimpleFramebuffer ensureBuffer(SimpleFramebuffer buffer, boolean depth, int divisor) {
        int framebufferWidth = mc.getWindow().getFramebufferWidth();
        int framebufferHeight = mc.getWindow().getFramebufferHeight();
        int width = Math.max(2, framebufferWidth / divisor);
        int height = Math.max(2, framebufferHeight / divisor);
        if (buffer == null) {
            buffer = new SimpleFramebuffer(width, height, depth);
            setLinearFiltering(buffer);
            buffer.setClearColor(0.0F, 0.0F, 0.0F, 0.0F);
            buffer.clear();
        } else if (buffer.textureWidth != width || buffer.textureHeight != height) {
            buffer.resize(width, height);
            setLinearFiltering(buffer);
            buffer.clear();
        }
        return buffer;
    }

    private void setLinearFiltering(Framebuffer framebuffer) {
        RenderSystem.bindTexture(framebuffer.getColorAttachment());
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_LINEAR);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_LINEAR);
        RenderSystem.bindTexture(0);
    }

    private void configureDepthTexture(int depthTex) {
        RenderSystem.bindTexture(depthTex);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL14.GL_TEXTURE_COMPARE_MODE, 0);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MIN_FILTER, GL11.GL_NEAREST);
        GL11.glTexParameteri(GL11.GL_TEXTURE_2D, GL11.GL_TEXTURE_MAG_FILTER, GL11.GL_NEAREST);
        RenderSystem.bindTexture(0);
    }

    private void copyDepthToBuffer(SimpleFramebuffer target) {
        blitMainToBuffer(target, GL11.GL_DEPTH_BUFFER_BIT);
    }

    private void copyColorAndDepthToBuffer(SimpleFramebuffer target) {
        blitMainToBuffer(target, GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);
    }

    private void blitMainToBuffer(SimpleFramebuffer target, int mask) {
        int previousRead = GL11.glGetInteger(GL30.GL_READ_FRAMEBUFFER_BINDING);
        int previousDraw = GL11.glGetInteger(GL30.GL_DRAW_FRAMEBUFFER_BINDING);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, mc.getFramebuffer().fbo);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, target.fbo);
        GL30.glBlitFramebuffer(0, 0, captureWidth, captureHeight, 0, 0, processWidth, processHeight,
                mask, GL11.GL_NEAREST);
        GL30.glBindFramebuffer(GL30.GL_READ_FRAMEBUFFER, previousRead);
        GL30.glBindFramebuffer(GL30.GL_DRAW_FRAMEBUFFER, previousDraw);
    }

    private void blitProcessTextureToScreen(int texture, boolean additive) {
        mc.getFramebuffer().beginWrite(true);
        RenderSystem.enableBlend();
        if (additive) {
            RenderSystem.blendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE);
        } else {
            RenderSystem.defaultBlendFunc();
        }
        GL20.glUseProgram(flameBlitProg != -1 ? flameBlitProg : 0);
        if (flameBlitProg != -1) {
            u1i(flameBlitProg, "inTex", 0);
        }
        bindTex(GL13.GL_TEXTURE0, texture);
        drawScreenQuad();
        GL20.glUseProgram(0);
        bindTex(GL13.GL_TEXTURE0, 0);
        RenderSystem.defaultBlendFunc();
    }

    private void setup2D() {
        savedViewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, savedViewport);
        float processW = Math.max(1, processWidth);
        float processH = Math.max(1, processHeight);
        float captureW = Math.max(1, captureWidth);
        float captureH = Math.max(1, captureHeight);
        Matrix4f processProjection = new Matrix4f().setOrtho(0.0F, processW, processH, 0.0F, 1000.0F, 3000.0F);
        Matrix4f processView = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
        processTransform = processProjection.mul(processView);
        Matrix4f screenProjection = new Matrix4f().setOrtho(0.0F, captureW, captureH, 0.0F, 1000.0F, 3000.0F);
        Matrix4f screenView = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
        screenTransform = screenProjection.mul(screenView);
        RenderSystem.disableDepthTest();
    }

    private void restore3D() {
        RenderSystem.enableDepthTest();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.bindTexture(0);
        GL20.glUseProgram(0);
        if (savedViewport != null) {
            GL11.glViewport(savedViewport[0], savedViewport[1], savedViewport[2], savedViewport[3]);
            savedViewport = null;
        }
        mc.getFramebuffer().beginWrite(true);
    }

    private void drawProcessQuad() {
        drawProcessQuad(GL20.glGetInteger(GL20.GL_CURRENT_PROGRAM));
    }

    private void drawProcessQuad(int program) {
        float width = Math.max(1, processWidth);
        float height = Math.max(1, processHeight);
        setTransformUniform(program, processTransform);
        DrawHelper.drawPreparedLegacyTexturedQuad(width, height);
    }

    private void drawScreenQuad() {
        float width = Math.max(1, captureWidth);
        float height = Math.max(1, captureHeight);
        setTransformUniform(GL20.glGetInteger(GL20.GL_CURRENT_PROGRAM), screenTransform);
        DrawHelper.drawPreparedLegacyTexturedQuad(width, height);
    }

    private void drawSizedQuad(int program, int width, int height) {
        Matrix4f projection = new Matrix4f().setOrtho(0.0F, width, height, 0.0F, 1000.0F, 3000.0F);
        Matrix4f view = new Matrix4f().translation(0.0F, 0.0F, -2000.0F);
        setTransformUniform(program, projection.mul(view));
        DrawHelper.drawPreparedLegacyTexturedQuad(Math.max(1, width), Math.max(1, height));
    }

    private void drawShaderQuad() {
        float width = Math.max(1, mc.getWindow().getFramebufferWidth());
        float height = Math.max(1, mc.getWindow().getFramebufferHeight());
        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE);
        buffer.vertex(0.0F, height, 0.0F).texture(0.0F, 0.0F);
        buffer.vertex(width, height, 0.0F).texture(1.0F, 0.0F);
        buffer.vertex(width, 0.0F, 0.0F).texture(1.0F, 1.0F);
        buffer.vertex(0.0F, 0.0F, 0.0F).texture(0.0F, 1.0F);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private void drawFullscreenTexturedQuad() {
        float width = Math.max(mc.getWindow().getScaledWidth(), 1);
        float height = Math.max(mc.getWindow().getScaledHeight(), 1);
        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        buffer.vertex(0.0F, 0.0F, 0.0F).texture(0.0F, 1.0F).color(255, 255, 255, 255);
        buffer.vertex(0.0F, height, 0.0F).texture(0.0F, 0.0F).color(255, 255, 255, 255);
        buffer.vertex(width, height, 0.0F).texture(1.0F, 0.0F).color(255, 255, 255, 255);
        buffer.vertex(width, 0.0F, 0.0F).texture(1.0F, 1.0F).color(255, 255, 255, 255);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }

    private void setTransformUniform(int program, Matrix4f transform) {
        if (program <= 0 || transform == null) {
            return;
        }
        int location = uloc(program, "Transform");
        if (location >= 0) {
            float[] values = new float[16];
            transform.get(values);
            GL20.glUniformMatrix4fv(location, false, values);
        }
    }

    private boolean needsCapture() {
        Hands hands = Hands.INSTANCE;
        return hands.shouldRenderGlow()
                || hands.flameEnabled.isEnabled()
                || hands.outlineEnabled.isEnabled()
                || hands.mode.is("Fill")
                || hands.mode.is("Shader");
    }

    private boolean needsColorCapture() {
        Hands hands = Hands.INSTANCE;
        if (hands.mode.is("Fill") || hands.mode.is("Shader")) {
            return true;
        }
        if (hands.glowColor.is("Item Color")) {
            return true;
        }
        return hands.shouldRenderGlow() || hands.flameEnabled.isEnabled();
    }

    private boolean useColorMask() {
        return needsColorCapture();
    }

    private boolean usesOptimizedComposite() {
        return getProcessScale() < 1.0F;
    }

    private float getProcessScale() {
        Hands hands = Hands.INSTANCE;
        if (hands.mode.is("Fill") || hands.mode.is("Shader")) {
            return 1.0F;
        }
        if (hands.flameEnabled.isEnabled() && !hands.isFlameWeak()) {
            return 1.0F;
        }
        return OPTIMIZED_SCALE;
    }

    private void bindTex(int unit, int tex) {
        GlStateManager._activeTexture(unit);
        GlStateManager._bindTexture(tex);
    }

    private int uloc(int program, String name) {
        long key = (long) program << 32 | name.hashCode() & 4294967295L;
        Integer cached = uniformCache.get(key);
        if (cached != null) {
            return cached;
        }
        int location = GL20.glGetUniformLocation(program, name);
        uniformCache.put(key, location);
        return location;
    }

    private void u1i(int program, String name, int value) {
        int location = uloc(program, name);
        if (location >= 0) {
            GL20.glUniform1i(location, value);
        }
    }

    private void u1f(int program, String name, float value) {
        int location = uloc(program, name);
        if (location >= 0) {
            GL20.glUniform1f(location, value);
        }
    }

    private void u2f(int program, String name, float a, float b) {
        int location = uloc(program, name);
        if (location >= 0) {
            GL20.glUniform2f(location, a, b);
        }
    }

    private void u3f(int program, String name, float a, float b, float c) {
        int location = uloc(program, name);
        if (location >= 0) {
            GL20.glUniform3f(location, a, b, c);
        }
    }

    private void u4f(int program, String name, float a, float b, float c, float d) {
        int location = uloc(program, name);
        if (location >= 0) {
            GL20.glUniform4f(location, a, b, c, d);
        }
    }
}
