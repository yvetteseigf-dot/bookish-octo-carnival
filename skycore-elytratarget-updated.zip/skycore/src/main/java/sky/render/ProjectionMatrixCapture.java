package sky.render;

import net.minecraft.client.MinecraftClient;
import org.joml.Matrix4f;

public final class ProjectionMatrixCapture {
    private static final int[] VIEWPORT = new int[4];
    private static Matrix4f projection = new Matrix4f();
    private static Matrix4f worldSpace = new Matrix4f();
    private static boolean captured;

    private ProjectionMatrixCapture() {
    }

    public static void capture(Matrix4f projectionMatrix, Matrix4f worldSpaceMatrix) {
        projection.set(projectionMatrix);
        worldSpace.set(worldSpaceMatrix);

        MinecraftClient client = MinecraftClient.getInstance();
        VIEWPORT[0] = 0;
        VIEWPORT[1] = 0;
        VIEWPORT[2] = client.getWindow().getFramebufferWidth();
        VIEWPORT[3] = client.getWindow().getFramebufferHeight();
        captured = true;
    }

    public static boolean isCaptured() {
        return captured;
    }

    public static Matrix4f getProjection() {
        return projection;
    }

    public static Matrix4f getWorldSpace() {
        return worldSpace;
    }

    public static int[] getViewport() {
        return VIEWPORT;
    }
}
