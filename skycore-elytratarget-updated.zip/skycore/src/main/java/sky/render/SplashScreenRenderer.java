package sky.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import sky.theme.GuiTheme;
import sky.util.render.ColorUtil;
import sky.util.render.HudScaleUtil;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;

public final class SplashScreenRenderer {
    private static final Identifier BACKGROUND = Identifier.of("skycore", "mainmenu/background.png");
    private static final long OUTLINE_CYCLE_MS = 1650L;

    private SplashScreenRenderer() {
    }

    public static void render(DrawContext context, float alpha) {
        if (alpha <= 0.01F) {
            return;
        }

        alpha = Math.clamp(alpha, 0.0F, 1.0F);
        float width = HudScaleUtil.getRenderWidth();
        float height = HudScaleUtil.getRenderHeight();

        drawSplashBackground(context, width, height, alpha);
        drawSplashDim(context, width, height, alpha);

        if (!DrawHelper.areCoreShadersReady()) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        MatrixStack matrices = context.getMatrices();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        renderLogo(renderer, matrices, width, height, alpha);
    }

    private static void drawSplashBackground(DrawContext context, float width, float height, float alpha) {
        GuiTheme theme = GuiTheme.theme;
        int scaledWidth = Math.round(width);
        int scaledHeight = Math.round(height);

        int[] size = TextureSizeCache.getSize(BACKGROUND);
        int textureWidth = size[0] > 0 ? size[0] : scaledWidth;
        int textureHeight = size[1] > 0 ? size[1] : scaledHeight;

        context.drawTexture(RenderLayer::getGuiTextured, BACKGROUND, 0, 0, 0.0F, 0.0F, scaledWidth, scaledHeight,
                textureWidth, textureHeight, ColorUtil.rgba(255, 255, 255, Math.round(255.0F * alpha)));

        Color accent = theme.getAccent();
        context.fill(0, 0, scaledWidth, scaledHeight,
                ColorUtil.rgba(accent.getRed(), accent.getGreen(), accent.getBlue(), Math.round(52.0F * alpha)));
    }

    private static void drawSplashDim(DrawContext context, float width, float height, float alpha) {
        context.fill(0, 0, Math.round(width), Math.round(height), ColorUtil.rgba(0, 0, 0, Math.round(142.0F * alpha)));
    }

    private static void renderLogo(DrawHelper renderer, MatrixStack matrices, float screenWidth, float screenHeight,
                                   float alpha) {
        int fontSize = Math.round(Math.min(230.0F, Math.max(150.0F, Math.min(screenWidth, screenHeight) * 0.32F)));
        FontRenderer font = FontRegistry.getSkycore(fontSize);
        if (font == null) {
            return;
        }

        String logo = "a";
        float logoWidth = font.getWidth(logo);
        float logoHeight = font.getLineHeight(logo);
        float logoX = (screenWidth - logoWidth) / 2.0F;
        float logoY = (screenHeight - logoHeight) / 2.0F - Math.min(20.0F, screenHeight * 0.035F);

        Color base = Color.WHITE;
        Color fill = ColorUtil.withAlpha(base, 0.92F * alpha);

        drawLogo(font, matrices, logo, logoX, logoY, ColorUtil.withAlpha(base, 0.2F * alpha), 0.0F, 5.0F);
        drawLogoOutline(font, matrices, logo, logoX, logoY, ColorUtil.withAlpha(base, 0.22F * alpha), 1.15F);
        drawLogo(font, matrices, logo, logoX, logoY, fill, 0.0F, 0.0F);
        drawLogo(font, matrices, logo, logoX, logoY - 1.2F, ColorUtil.withAlpha(base, 0.34F * alpha), 0.0F, 0.0F);
        renderTravellingOutline(font, matrices, logo, logoX, logoY, logoWidth, logoHeight, base, alpha);
    }

    private static void renderTravellingOutline(FontRenderer font, MatrixStack matrices, String logo, float logoX,
                                                float logoY, float logoWidth, float logoHeight, Color accent,
                                                float alpha) {
        float progress = (System.currentTimeMillis() % OUTLINE_CYCLE_MS) / 1650.0F;
        float eased = progress < 0.5F
                ? 2.0F * progress * progress
                : 1.0F - (float) Math.pow(-2.0F * progress + 2.0F, 2.0D) / 2.0F;

        float bandWidth = Math.max(18.0F, logoWidth * 0.22F);
        float bandX = logoX - bandWidth + (logoWidth + bandWidth * 2.0F) * eased;

        ScissorStack.enable(bandX, logoY - 8.0F, bandWidth, logoHeight + 16.0F);
        drawLogoOutline(font, matrices, logo, logoX, logoY, ColorUtil.withAlpha(Color.WHITE, 0.92F * alpha), 1.55F);
        drawLogoOutline(font, matrices, logo, logoX, logoY, ColorUtil.withAlpha(accent, 0.76F * alpha), 2.25F);
        drawLogo(font, matrices, logo, logoX, logoY, ColorUtil.withAlpha(Color.WHITE, 0.52F * alpha), 0.0F, 0.0F);
        ScissorStack.disable();
    }

    private static void drawLogoOutline(FontRenderer font, MatrixStack matrices, String logo, float x, float y,
                                        Color color, float offset) {
        drawLogo(font, matrices, logo, x, y, color, -offset, 0.0F);
        drawLogo(font, matrices, logo, x, y, color, offset, 0.0F);
        drawLogo(font, matrices, logo, x, y, color, 0.0F, -offset);
        drawLogo(font, matrices, logo, x, y, color, 0.0F, offset);

        Color diagonal = ColorUtil.withAlpha(color, color.getAlpha() / 510.0F);
        drawLogo(font, matrices, logo, x, y, diagonal, -offset, -offset);
        drawLogo(font, matrices, logo, x, y, diagonal, offset, offset);
    }

    private static void drawLogo(FontRenderer font, MatrixStack matrices, String logo, float x, float y, Color color,
                                 float offsetX, float offsetY) {
        font.draw(logo, x + offsetX, y + offsetY, color, matrices);
    }
}
