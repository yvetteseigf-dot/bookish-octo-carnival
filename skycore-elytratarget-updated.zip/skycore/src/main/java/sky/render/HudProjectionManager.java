package sky.render;

import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.joml.Matrix4f;
import sky.util.render.HudScaleUtil;

public final class HudProjectionManager {
    public static final double HUD_SCALE = 2.0D;

    private static boolean active;
    private static boolean projectionSwapped;
    private static Matrix4f savedProjection;

    private HudProjectionManager() {
    }

    public static void begin(double scale) {
        if (active) {
            end();
        }
        DrawHelper.ensureMainFramebuffer();
        savedProjection = new Matrix4f(RenderSystem.getProjectionMatrix());

        Window window = MinecraftClient.getInstance().getWindow();
        float width = (float) (window.getFramebufferWidth() / scale);
        float height = (float) (window.getFramebufferHeight() / scale);
        RenderSystem.setProjectionMatrix(
                new Matrix4f().setOrtho(0.0F, width, height, 0.0F, 1000.0F, 21000.0F),
                ProjectionType.ORTHOGRAPHIC);
        RenderSystem.disableDepthTest();
        HudScaleUtil.markActive(scale);
        projectionSwapped = true;
        active = true;
    }

    public static void beginHud() {
        if (active) {
            end();
        }
        RenderSystem.disableDepthTest();
        HudScaleUtil.markActive(HUD_SCALE);
        projectionSwapped = false;
        active = true;
    }

    public static void end() {
        if (!active) {
            return;
        }
        RenderSystem.disableDepthTest();
        if (projectionSwapped) {
            applyVanillaProjection();
        }
        HudScaleUtil.markInactive();
        projectionSwapped = false;
        active = false;
    }

    public static void forceEnd() {
        if (active) {
            end();
        }
    }

    public static boolean isActive() {
        return active;
    }

    private static void applyVanillaProjection() {
        if (savedProjection != null) {
            RenderSystem.setProjectionMatrix(new Matrix4f(savedProjection), ProjectionType.ORTHOGRAPHIC);
            savedProjection = null;
            return;
        }

        Window window = MinecraftClient.getInstance().getWindow();
        RenderSystem.setProjectionMatrix(
                new Matrix4f().setOrtho(0.0F, window.getScaledWidth(), window.getScaledHeight(), 0.0F, 1000.0F, 21000.0F),
                ProjectionType.ORTHOGRAPHIC);
    }
}
