package sky.render;

import net.minecraft.client.util.math.MatrixStack;
import sky.theme.GuiTheme;
import sky.clickgui.GuiStyle;
import sky.util.render.ColorUtil;

import java.awt.Color;

public final class HudPanelRenderer {
    public static final float PADDING_X = 10.0F;
    public static final float MIN_WIDTH = 70.0F;
    public static final int ICON_FONT = 13;
    public static final float ROW_HEIGHT = 14.0F;
    public static final float RADIUS = 14.0F;
    public static final int HEADER_FONT = 14;
    public static final float HEADER_ICON_GAP = 6.0F;
    public static final float HEADER_HEIGHT = 22.0F;
    public static final int ROW_FONT = 13;
    public static final float ROW_ICON_GAP = 5.0F;
    public static final float COLUMN_GAP = 8.0F;
    public static final long FADE_DURATION_MS = 250L;
    public static final float SEPARATOR_THICKNESS = 1.0F;

    private HudPanelRenderer() {
    }

    public static void drawBackground(DrawHelper renderer, float x, float y, float width, float height, float radius,
                                      Color topColor, Color bottomColor, MatrixStack matrices) {
        drawBackground(renderer, x, y, width, height, radius, topColor, bottomColor,
                resolveFade(topColor, bottomColor), matrices);
    }

    public static void drawBackground(DrawHelper renderer, float x, float y, float width, float height, float radius,
                                      Color topColor, Color bottomColor, float panelAlpha, MatrixStack matrices) {
        GuiSurfaceRenderer.drawHudSurface(renderer, x, y, width, height, radius, panelAlpha, matrices);
        DrawHelper.prepareGuiOverlayDraw();
    }

    public static void drawWatermarkBackground(DrawHelper renderer, float x, float y, float width, float height, float radius,
                                               Color topColor, Color bottomColor, float panelAlpha, MatrixStack matrices) {
        drawBackground(renderer, x, y, width, height, radius, topColor, bottomColor, panelAlpha, matrices);
    }

    public static void drawHeaderSeparator(DrawHelper renderer, MatrixStack matrices, float x, float y, float width,
                                           float alpha, GuiTheme theme) {
        float half = width / 2.0F;
        Color faint = ColorUtil.withAlpha(theme.getText(), 0.02F * alpha);
        Color bright = ColorUtil.withAlpha(theme.getText(), 0.05F * alpha);
        renderer.drawGradientRoundedRect(x, y, half, SEPARATOR_THICKNESS, 0.0F, faint, bright, faint, bright, matrices);
        renderer.drawGradientRoundedRect(x + half, y, half, SEPARATOR_THICKNESS, 0.0F, bright, faint, bright, faint, matrices);
    }

    private static float resolveFade(Color topColor, Color bottomColor) {
        if (GuiTheme.theme.getGuiStyle() == GuiStyle.KAWASE) {
            return 1.0F;
        }
        return Math.max(topColor.getAlpha(), bottomColor.getAlpha()) / 255.0F;
    }
}
