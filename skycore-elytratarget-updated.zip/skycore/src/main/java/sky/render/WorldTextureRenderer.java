package sky.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;

public final class WorldTextureRenderer {
    private WorldTextureRenderer() {
    }

    public static void drawTexture(MatrixStack matrices, Identifier texture, float x, float y, float width,
                                   float height, Color color) {
        Matrix4f matrix = matrices.peek().getPositionMatrix();

        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, texture);

        BufferBuilder buffer = Tessellator.getInstance()
                .begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);

        int argb = color.getAlpha() << 24 | color.getRed() << 16 | color.getGreen() << 8 | color.getBlue();

        buffer.vertex(matrix, x, y, 0.0F).texture(0.0F, 0.0F).color(argb);
        buffer.vertex(matrix, x, y + height, 0.0F).texture(0.0F, 1.0F).color(argb);
        buffer.vertex(matrix, x + width, y + height, 0.0F).texture(1.0F, 1.0F).color(argb);
        buffer.vertex(matrix, x + width, y, 0.0F).texture(1.0F, 0.0F).color(argb);

        BufferRenderer.drawWithGlobalProgram(buffer.end());
    }
}
