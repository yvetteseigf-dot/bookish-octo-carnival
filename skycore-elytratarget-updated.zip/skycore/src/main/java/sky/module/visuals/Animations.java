package sky.module.visuals;

import sky.config.BooleanSetting;
import sky.config.MultiBooleanSetting;
import sky.module.Category;
import sky.module.Module;
import sky.ui.animation.ChatInputSlideAnimation;
import sky.ui.animation.GhostRecipeAnimation;
import sky.ui.animation.HotbarSelectAnimation;
import sky.ui.animation.InventoryCloseAnimation;
import sky.ui.animation.TooltipAnimation;

public final class Animations extends Module {
    public static final String CHAT_SLIDE = "Chat slide";
    public static final String CHAT_STACK = "Chat stack";
    public static final String INV_OPEN = "Inv. open";
    public static final String INV_CLOSE = "Inv. close";
    public static final String INV_SLOTS = "Slot cascade";
    public static final String TOOLTIP = "Tooltips";
    public static final String ESC_HOVER = "Button hover";
    public static final String ESC_PRESS = "Button press";
    public static final String ESC_PANEL = "ESC panel";
    public static final String HOTBAR = "Hotbar";
    public static final String CHAT_FIELD = "Chat field";
    public static final String BOSSBAR = "Boss bar";

    public static final Animations INSTANCE = new Animations();

    public final MultiBooleanSetting effects;

    private final ChatInputSlideAnimation chatInputAnimator;
    private final HotbarSelectAnimation hotbarSelectAnimator;

    private Animations() {
        super("Animations", "Interface animations for chat, inventory, tooltips, ESC, hotbar, and boss bar",
                Category.VISUALS);
        this.effects = new MultiBooleanSetting("Effects",
                new BooleanSetting(CHAT_SLIDE, true),
                new BooleanSetting(CHAT_STACK, true),
                new BooleanSetting(INV_OPEN, true),
                new BooleanSetting(INV_CLOSE, true),
                new BooleanSetting(INV_SLOTS, true),
                new BooleanSetting(TOOLTIP, true),
                new BooleanSetting(ESC_HOVER, true),
                new BooleanSetting(ESC_PRESS, true),
                new BooleanSetting(ESC_PANEL, true),
                new BooleanSetting(HOTBAR, true),
                new BooleanSetting(CHAT_FIELD, false),
                new BooleanSetting(BOSSBAR, true));
        this.chatInputAnimator = new ChatInputSlideAnimation();
        this.hotbarSelectAnimator = new HotbarSelectAnimation();
        addSettings(this.effects);
        setEnabled(true);
    }

    @Override
    protected void onDisable() {
        super.onDisable();
        chatInputAnimator.reset();
        hotbarSelectAnimator.reset();
        InventoryCloseAnimation.cancel();
        TooltipAnimation.reset();
        GhostRecipeAnimation.reset();
    }

    public static HotbarSelectAnimation hotbar() {
        return INSTANCE.hotbarSelectAnimator;
    }

    public static ChatInputSlideAnimation chatInput() {
        return INSTANCE.chatInputAnimator;
    }

    public static boolean effect(String name) {
        return active() && INSTANCE.effects.is(name);
    }

    public static boolean active() {
        return INSTANCE.isEnabled();
    }
}
