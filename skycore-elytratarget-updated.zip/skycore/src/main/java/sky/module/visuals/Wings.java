package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import sky.config.BooleanSetting;
import sky.theme.GuiTheme;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;

public final class Wings extends Module {
    public static final Wings INSTANCE = new Wings();

    private static final Identifier BLOOM_TEXTURE = Identifier.of("skycore", "icons/world_render/bloom.png");
    private static final Identifier ANGEL_WINGS = Identifier.of("skycore", "textures/wings/angel_wings.png");
    private static final Identifier BAT_WINGS = Identifier.of("skycore", "textures/wings/bat_wings.png");
    private static final Identifier BLUE_BUTTERFLY_WINGS = Identifier.of("skycore", "textures/wings/blue_butterfly_wings.png");
    private static final Identifier NECROZMA_WINGS = Identifier.of("skycore", "textures/wings/dawn_wings_necrozma_wings.png");
    private static final Identifier DRAGON_WINGS = Identifier.of("skycore", "textures/wings/dragon_wings.png");
    private static final Identifier EVIL_WINGS = Identifier.of("skycore", "textures/wings/evil_wings.png");
    private static final Identifier FAIRY_WINGS = Identifier.of("skycore", "textures/wings/fairy_wings.png");
    private static final Identifier FIRE_WINGS = Identifier.of("skycore", "textures/wings/fire_wings.png");
    private static final Identifier GOD_WINGS = Identifier.of("skycore", "textures/wings/god_wings.png");
    private static final Identifier METALLIC_WINGS = Identifier.of("skycore", "textures/wings/metallic_wings.png");
    private static final Identifier MONARCH_WINGS = Identifier.of("skycore", "textures/wings/monarch_butterfly_wings.png");
    private static final Identifier PARROT_WINGS = Identifier.of("skycore", "textures/wings/parrot_wings.png");
    private static final Identifier SLIME_WINGS = Identifier.of("skycore", "textures/wings/slime_wings.png");
    private static final String MODE_NEW = "New";
    private static final float DEFAULT_SPREAD = 8.0f;
    private static final float BACK_Z = 0.16f;
    private static final float TORSO_Y = 1.20f;
    private static final float TORSO_Y_SNEAK = 0.98f;
    private static final float[][] VECTOR_SHAPE = {
            {0.08f, 0.1f, 0.88f},
            {0.28f, 0.34f, 0.78f},
            {0.56f, 0.82f, 0.62f},
            {0.86f, 0.3f, 0.52f},
            {1.14f, 0.46f, 0.4f},
            {1.24f, 0.04f, 0.3f},
            {1.02f, -0.18f, 0.28f},
            {1.18f, -0.64f, 0.22f},
            {0.86f, -0.46f, 0.2f},
            {0.8f, -0.98f, 0.14f},
            {0.54f, -0.74f, 0.16f},
            {0.3f, -1.16f, 0.12f},
            {0.1f, -0.54f, 0.18f}
    };

    private final ModeSetting mode;
    private final BooleanSetting self;
    private final BooleanSetting players;
    private final BooleanSetting fill;
    private final NumberSetting opacity;
    private final NumberSetting size;

    private boolean selfBodyYawInitialized;
    private float selfBodyYaw;

    private Wings() {
        super("Wings", "Translucent wings behind your back", Category.VISUALS);
        this.mode = new ModeSetting("Style", "Default",
                "Default", MODE_NEW, "Angel", "Bat", "Butterfly", "Necrozma", "Dragon",
                "Demon", "Fairy", "Fire", "God", "Metal", "Monarch", "Parrot", "Slime");
        this.self = new BooleanSetting("Self", true);
        this.players = new BooleanSetting("Players", false);
        this.fill = new BooleanSetting("Fill", true);
        this.opacity = new NumberSetting("Opacity", 220.0f, 10.0f, 255.0f, 5.0f);
        this.size = new NumberSetting("Size", 1.0f, 0.5f, 2.0f, 0.05f);
        addSettings(mode, self, players, fill, opacity, size);
    }

    @Override
    public void onDisable() {
        selfBodyYawInitialized = false;
        super.onDisable();
    }

    @EventTarget
    public void onRender3D(RenderWorldEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        float partialTicks = event.getPartialTicks();
        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        MatrixStack stack = event.getMatrixStack();

        Identifier wingTexture = resolveWingTexture();
        if (self.isEnabled()
                && !mc.options.getPerspective().isFirstPerson()
                && mc.player.isAlive()
                && !hasElytra(mc.player)) {
            renderPlayerWings(stack, mc.player, partialTicks, cameraPos, wingTexture);
        }

        if (players.isEnabled()) {
            for (PlayerEntity player : mc.world.getPlayers()) {
                if (player == mc.player || !player.isAlive() || hasElytra(player)) {
                    continue;
                }
                renderPlayerWings(stack, player, partialTicks, cameraPos, wingTexture);
            }
        }
    }

    private void renderPlayerWings(MatrixStack stack, PlayerEntity player, float partialTicks, Vec3d cameraPos,
                                   Identifier wingTexture) {
        if (wingTexture != null) {
            renderTexturedWings(stack, player, partialTicks, cameraPos, wingTexture);
        } else {
            renderVectorWings(stack, player, partialTicks, cameraPos);
        }
    }

    private boolean hasElytra(PlayerEntity player) {
        return player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
    }

    private Identifier resolveWingTexture() {
        if (mode.is("Angel")) {
            return ANGEL_WINGS;
        }
        if (mode.is("Bat")) {
            return BAT_WINGS;
        }
        if (mode.is("Butterfly")) {
            return BLUE_BUTTERFLY_WINGS;
        }
        if (mode.is("Necrozma")) {
            return NECROZMA_WINGS;
        }
        if (mode.is("Dragon")) {
            return DRAGON_WINGS;
        }
        if (mode.is("Demon")) {
            return EVIL_WINGS;
        }
        if (mode.is("Fairy")) {
            return FAIRY_WINGS;
        }
        if (mode.is("Fire")) {
            return FIRE_WINGS;
        }
        if (mode.is("God")) {
            return GOD_WINGS;
        }
        if (mode.is("Metal")) {
            return METALLIC_WINGS;
        }
        if (mode.is("Monarch")) {
            return MONARCH_WINGS;
        }
        if (mode.is("Parrot")) {
            return PARROT_WINGS;
        }
        if (mode.is("Slime")) {
            return SLIME_WINGS;
        }
        return null;
    }

    private void renderTexturedWings(MatrixStack stack, PlayerEntity player, float partialTicks, Vec3d cameraPos,
                                     Identifier texture) {
        if (player.isGliding() || player.isSwimming()) {
            return;
        }

        float time = player.age + partialTicks;
        float flap = (float) Math.sin(time * 0.22f) * 10.0f;
        float scale = size.get() * (player.isSneaking() ? 0.92f : 1.0f);
        int tint = setAlpha(0xFFFFFFFF, opacity.get().intValue());

        stack.push();
        orientToBack(stack, player, partialTicks, cameraPos);
        stack.translate(0.0f, player.isSneaking() ? TORSO_Y_SNEAK : TORSO_Y, BACK_Z);
        stack.scale(scale, scale, scale);
        drawTexturedWingSide(stack, -1.0f, 16.0f + flap, texture, tint);
        drawTexturedWingSide(stack, 1.0f, 16.0f + flap, texture, tint);
        stack.pop();
    }

    private void drawTexturedWingSide(MatrixStack stack, float side, float spread, Identifier texture, int tint) {
        stack.push();
        stack.translate(side * 0.06f, 0.0f, 0.0f);
        stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * spread));
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, texture);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        Matrix4f matrix = stack.peek().getPositionMatrix();
        float width = 1.05f;
        float height = 1.15f;
        float u0 = side < 0.0f ? 1.0f : 0.0f;
        float u1 = side < 0.0f ? 0.0f : 1.0f;
        buffer.vertex(matrix, 0.0f, -height * 0.85f, 0.0f).texture(u0, 1.0f).color(tint);
        buffer.vertex(matrix, side * width, -height * 0.85f, 0.0f).texture(u1, 1.0f).color(tint);
        buffer.vertex(matrix, side * width, height * 0.25f, 0.0f).texture(u1, 0.0f).color(tint);
        buffer.vertex(matrix, 0.0f, height * 0.25f, 0.0f).texture(u0, 0.0f).color(tint);
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        stack.pop();
    }

    private int resolveBaseColor() {
        return GuiTheme.theme.getAccent().getRGB() | 0xFF000000;
    }

    private int resolveCoreColor(int base) {
        int red = Math.min(255, ((base >> 16) & 255) + (int) ((255 - ((base >> 16) & 255)) * 0.55f));
        int green = Math.min(255, ((base >> 8) & 255) + (int) ((255 - ((base >> 8) & 255)) * 0.55f));
        int blue = Math.min(255, (base & 255) + (int) ((255 - (base & 255)) * 0.55f));
        return (base & 0xFF000000) | (red << 16) | (green << 8) | blue;
    }

    private int resolveGlowColor(int base) {
        int red = Math.min(255, ((base >> 16) & 255) + (int) ((255 - ((base >> 16) & 255)) * 0.28f));
        int green = Math.min(255, ((base >> 8) & 255) + (int) ((255 - ((base >> 8) & 255)) * 0.28f));
        int blue = Math.min(255, (base & 255) + (int) ((255 - (base & 255)) * 0.28f));
        return (base & 0xFF000000) | (red << 16) | (green << 8) | blue;
    }

    private float resolveBodyYaw(PlayerEntity player, float partialTicks) {
        float interpolated = MathHelper.lerpAngleDegrees(partialTicks, player.prevBodyYaw, player.bodyYaw);
        if (player != mc.player) {
            return interpolated;
        }
        if (!selfBodyYawInitialized || player.age < 2) {
            selfBodyYaw = interpolated;
            selfBodyYawInitialized = true;
            return selfBodyYaw;
        }
        selfBodyYaw = approachDegrees(selfBodyYaw, interpolated, 14.0f);
        return selfBodyYaw;
    }

    private void orientToBack(MatrixStack stack, PlayerEntity player, float partialTicks, Vec3d cameraPos) {
        double x = MathHelper.lerp(partialTicks, player.lastRenderX, player.getX()) - cameraPos.x;
        double y = MathHelper.lerp(partialTicks, player.lastRenderY, player.getY()) - cameraPos.y;
        double z = MathHelper.lerp(partialTicks, player.lastRenderZ, player.getZ()) - cameraPos.z;
        stack.translate(x, y, z);
        stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - resolveBodyYaw(player, partialTicks)));
    }

    private void renderVectorWings(MatrixStack stack, PlayerEntity player, float partialTicks, Vec3d cameraPos) {
        float motion = (float) MathHelper.clamp(player.getVelocity().horizontalLength(), 0.0, 1.0);
        boolean newMode = mode.is(MODE_NEW);
        WingPose pose = resolveVectorPose(player, newMode);
        if (pose == null) {
            return;
        }

        float time = player.age + partialTicks;
        float flap = (float) Math.sin(time * pose.flapSpeed()) * pose.flapAmplitude();
        float spread = (DEFAULT_SPREAD + flap + motion * pose.motionSpreadBoost()) * pose.openMultiplier();
        float scale = size.get() * pose.scaleMultiplier();
        int baseColor = resolveBaseColor();
        int glowColor = resolveGlowColor(baseColor);
        int coreColor = resolveCoreColor(baseColor);

        stack.push();
        orientToBack(stack, player, partialTicks, cameraPos);
        stack.translate(0.0f, pose.preTranslateY(), Math.abs(pose.preTranslateZ()));
        if (pose.pitchRotation() != 0.0f) {
            stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pose.pitchRotation()));
        }
        if (pose.rollRotation() != 0.0f) {
            stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(pose.rollRotation()));
        }
        stack.translate(0.0f, pose.anchorY(), Math.abs(pose.anchorZ()));
        stack.scale(scale, scale, scale);
        renderVectorWingSide(stack, -1.0f, spread, baseColor, glowColor, coreColor, pose, newMode, time);
        renderVectorWingSide(stack, 1.0f, spread, baseColor, glowColor, coreColor, pose, newMode, time);
        stack.pop();
    }

    private WingPose resolveVectorPose(PlayerEntity player, boolean newMode) {
        if (player.isGliding() || player.isSwimming()) {
            return null;
        }
        if (player.isSneaking()) {
            if (newMode) {
                return new WingPose(0.0f, 0.12f, 0.72f, 0.14f, 20.0f, 0.0f, 1.1f, 1.08f,
                        0.24f, 5.8f, 0.075f, 0.035f, -14.0f, -6.0f, 0.15f);
            }
            return new WingPose(0.0f, 0.12f, 0.68f, 0.12f, 18.0f, 0.0f, 1.0f, 1.0f,
                    0.18f, 4.5f, 0.06f, 0.02f, -11.0f, -4.0f, 0.12f);
        }
        if (newMode) {
            return new WingPose(0.0f, 0.14f, 0.88f, 0.14f, -2.0f, 0.0f, 1.12f, 1.1f,
                    0.25f, 5.8f, 0.075f, 0.035f, -14.0f, -6.0f, 0.15f);
        }
        return new WingPose(0.0f, 0.12f, 0.86f, 0.12f, 0.0f, 0.0f, 1.0f, 1.0f,
                0.18f, 4.5f, 0.06f, 0.02f, -11.0f, -4.0f, 0.12f);
    }

    private void renderVectorWingSide(MatrixStack stack, float side, float spread, int baseColor, int glowColor,
                                      int coreColor, WingPose pose, boolean newMode, float time) {
        stack.push();
        stack.translate(side * pose.sideOffset(), 0.0f, Math.abs(pose.sideZOffset()));
        stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * spread));
        stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * pose.sideRoll()));
        stack.multiply(RotationAxis.POSITIVE_X.rotationDegrees(pose.sidePitch()));
        if (newMode) {
            drawWingLayer(stack, side, 1.58f, setAlpha(glowColor, 34), setAlpha(glowColor, 0));
            drawWingLayer(stack, side, 1.36f, setAlpha(glowColor, 52), setAlpha(glowColor, 0));
        }
        if (fill.isEnabled()) {
            int alpha = opacity.get().intValue();
            drawWingLayer(stack, side, 1.0f, setAlpha(baseColor, alpha),
                    setAlpha(baseColor, Math.max(20, alpha / 4)));
        }
        drawWingLayer(stack, side, 1.22f, setAlpha(glowColor, 48), setAlpha(glowColor, 0));
        drawWingLayer(stack, side, 0.84f, setAlpha(coreColor, 57), setAlpha(coreColor, 0));
        if (newMode) {
            drawBloomEdge(stack, side, glowColor, coreColor, time);
        }
        stack.pop();
    }

    private void drawWingLayer(MatrixStack stack, float side, float scale, int rootColor, int edgeColor) {
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLES, VertexFormats.POSITION_COLOR);
        MatrixStack.Entry entry = stack.peek();
        for (int index = 0; index < VECTOR_SHAPE.length; index++) {
            float[] current = VECTOR_SHAPE[index];
            float[] next = VECTOR_SHAPE[(index + 1) % VECTOR_SHAPE.length];
            buffer.vertex(entry, 0.0f, 0.0f, 0.0f).color(rootColor);
            buffer.vertex(entry, side * current[0] * scale, current[1] * scale, 0.0f).color(edgeColor);
            buffer.vertex(entry, side * next[0] * scale, next[1] * scale, 0.0f).color(edgeColor);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
    }

    private void drawBloomEdge(MatrixStack stack, float side, int glowColor, int coreColor, float time) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_TEX_COLOR);
        RenderSystem.setShaderTexture(0, BLOOM_TEXTURE);
        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_TEXTURE_COLOR);
        Matrix4f matrix = stack.peek().getPositionMatrix();
        float pulse = 0.88f + 0.12f * (float) Math.sin(time * 0.22f + side);
        emitBloomQuad(buffer, matrix, 0.0f, 0.02f, -0.006f, 0.42f * pulse, setAlpha(coreColor, 58));
        for (int index = 1; index < VECTOR_SHAPE.length - 1; index += 2) {
            float[] point = VECTOR_SHAPE[index];
            float weight = MathHelper.clamp(point[2], 0.12f, 0.88f);
            float quadSize = (0.28f + weight * 0.22f) * pulse;
            int tint = index % 4 == 1 ? coreColor : glowColor;
            int color = setAlpha(tint, (int) (48.0f + weight * 40.0f));
            emitBloomQuad(buffer, matrix, side * point[0], point[1], -0.008f, quadSize, color);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.enableCull();
    }

    private void emitBloomQuad(BufferBuilder buffer, Matrix4f matrix, float x, float y, float z, float size, int color) {
        float half = size * 0.5f;
        buffer.vertex(matrix, x - half, y - half, z).texture(0.0f, 1.0f).color(color);
        buffer.vertex(matrix, x + half, y - half, z).texture(1.0f, 1.0f).color(color);
        buffer.vertex(matrix, x + half, y + half, z).texture(1.0f, 0.0f).color(color);
        buffer.vertex(matrix, x - half, y + half, z).texture(0.0f, 0.0f).color(color);
    }

    private static int setAlpha(int color, int alpha) {
        return (MathHelper.clamp(alpha, 0, 255) << 24) | (color & 0xFFFFFF);
    }

    private static float approachDegrees(float current, float target, float maxDelta) {
        float delta = MathHelper.wrapDegrees(target - current);
        delta = MathHelper.clamp(delta, -maxDelta, maxDelta);
        return current + delta;
    }

    record WingPose(
            float preTranslateY,
            float preTranslateZ,
            float anchorY,
            float anchorZ,
            float pitchRotation,
            float rollRotation,
            float openMultiplier,
            float scaleMultiplier,
            float motionSpreadBoost,
            float flapAmplitude,
            float sideOffset,
            float sideZOffset,
            float sideRoll,
            float sidePitch,
            float flapSpeed
    ) {
    }
}
