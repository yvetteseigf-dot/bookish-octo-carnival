package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.theme.GuiTheme;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.event.network.PacketSendEvent;
import sky.event.combat.AttackEntityEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.render.WorldDrawHelper;
import sky.render.WorldTextureRenderer;
import sky.util.render.ColorUtil;

public final class GhostHit extends Module {
    public static final GhostHit INSTANCE = new GhostHit();

    private static final float MODEL_SCALE = 0.9375f;
    private static final float VERTICAL_OFFSET = -1.501f;
    private static final int TOTEM_POP_STATUS = 35;
    private static final Identifier GLOW = Identifier.of("skycore", "icons/glow.png");

    private final NumberSetting lifetime;
    private final NumberSetting riseHeight;
    private final NumberSetting ghostAlpha;
    private final NumberSetting glowPower;
    private final NumberSetting maxGhosts;
    private final NumberSetting particles;
    private final BooleanSetting onHit;
    private final BooleanSetting onTotem;
    private final MultiBooleanSetting triggers;
    private final BooleanSetting rainbow;
    private final List<GhostEntry> ghosts;

    private PlayerEntityModel wideModel;
    private PlayerEntityModel slimModel;

    private GhostHit() {
        super("GhostHit", "Player skin ghost on hit", Category.VISUALS);
        this.lifetime = new NumberSetting("Lifetime", 1450.0f, 550.0f, 3000.0f, 50.0f);
        this.riseHeight = new NumberSetting("Rise", 1.85f, 0.45f, 4.0f, 0.05f);
        this.ghostAlpha = new NumberSetting("Opacity", 0.58f, 0.15f, 1.0f, 0.01f);
        this.glowPower = new NumberSetting("Glow", 1.0f, 0.2f, 2.2f, 0.05f);
        this.maxGhosts = new NumberSetting("Max Ghosts", 7.0f, 1.0f, 16.0f, 1.0f);
        this.particles = new NumberSetting("Particles", 7.0f, 0.0f, 24.0f, 1.0f);
        this.onHit = new BooleanSetting("Hit", true);
        this.onTotem = new BooleanSetting("Totem", true);
        this.triggers = new MultiBooleanSetting("Spawn", onHit, onTotem);
        this.rainbow = new BooleanSetting("Rainbow", false);
        this.ghosts = new ArrayList<>();
        addSettings(lifetime, riseHeight, ghostAlpha, glowPower, maxGhosts, particles, triggers, rainbow);
    }

    @Override
    public void onDisable() {
        ghosts.clear();
        super.onDisable();
    }

    @EventTarget
    private void onRender3D(RenderWorldEvent event) {
        if (ghosts.isEmpty() || mc.player == null || mc.world == null) {
            return;
        }

        ensureModels();
        long now = System.currentTimeMillis();
        ghosts.removeIf(ghost -> ghost.rawProgress(now, lifetime.getCurrent()) >= 1.0f);
        if (ghosts.isEmpty()) {
            return;
        }

        MatrixStack matrices = event.getMatrixStack();
        Vec3d cameraPos = mc.gameRenderer.getCamera().getPos();
        VertexConsumerProvider.Immediate consumers = mc.getBufferBuilders().getEntityVertexConsumers();

        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE_MINUS_SRC_ALPHA);
        RenderSystem.depthMask(false);
        try {
            for (GhostEntry ghost : ghosts) {
                float raw = ghost.rawProgress(now, lifetime.getCurrent());
                float eased = ghost.easedProgress(raw);
                if (eased < 0.01f) {
                    continue;
                }

                float rise = computeRiseHeight(raw);
                float alpha = eased * ghostAlpha.getCurrent();
                int color = ghostColor(ghost, raw, 255);
                renderGhostModel(matrices, consumers, cameraPos, ghost, rise, alpha, color, false);
            }
            consumers.draw();
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.defaultBlendFunc();
        }

        renderParticles(matrices, cameraPos, now);
        renderTrails(cameraPos, now);
    }

    @EventTarget
    private void onPacket(PacketSendEvent event) {
        if (!event.isReceive() || mc.world == null || mc.player == null || !onTotem.isEnabled()) {
            return;
        }

        if (event.getPacket() instanceof EntityStatusS2CPacket statusPacket
                && statusPacket.getStatus() == TOTEM_POP_STATUS) {
            Entity entity = statusPacket.getEntity(mc.world);
            if (entity instanceof AbstractClientPlayerEntity player && player != mc.player) {
                spawnGhost(player);
            }
        }
    }

    @EventTarget
    private void onAttack(AttackEntityEvent event) {
        if (!onHit.isEnabled()) {
            return;
        }
        if (mc.player == null || mc.world == null) {
            return;
        }

        Entity target = event.getTarget();
        if (!(target instanceof AbstractClientPlayerEntity player) || player == mc.player) {
            return;
        }
        spawnGhost(player);
    }

    private void spawnGhost(AbstractClientPlayerEntity player) {
        float tickDelta = mc.getRenderTickCounter().getTickDelta(false);
        SkinTextures skin = player.getSkinTextures();
        Vec3d pos = new Vec3d(
                MathHelper.lerp(tickDelta, player.lastRenderX, player.getX()),
                MathHelper.lerp(tickDelta, player.lastRenderY, player.getY()),
                MathHelper.lerp(tickDelta, player.lastRenderZ, player.getZ()));
        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, player.prevBodyYaw, player.bodyYaw);
        float headYaw = MathHelper.lerpAngleDegrees(tickDelta, player.prevHeadYaw, player.headYaw);
        float pitch = MathHelper.lerp(tickDelta, player.prevPitch, player.getPitch());
        float limbPos = player.limbAnimator.getPos(tickDelta);
        float limbSpeed = Math.min(player.limbAnimator.getSpeed(tickDelta), 1.0f);
        float swing = player.getHandSwingProgress(tickDelta);
        boolean slim = skin.model() == SkinTextures.Model.SLIM;
        boolean sneaking = player.isInSneakingPose();
        boolean baby = player.isBaby();
        float height = player.getHeight();

        ghosts.add(new GhostEntry(
                pos,
                skin.texture(),
                slim,
                bodyYaw,
                headYaw - bodyYaw,
                pitch,
                limbPos,
                limbSpeed,
                swing,
                sneaking,
                baby,
                height,
                System.currentTimeMillis(),
                (float) Math.random()));

        while (ghosts.size() > Math.round(maxGhosts.getCurrent())) {
            ghosts.remove(0);
        }
    }

    private void ensureModels() {
        if (wideModel != null) {
            return;
        }
        wideModel = createPlayerModel(false, Dilation.NONE);
        slimModel = createPlayerModel(true, Dilation.NONE);
    }

    private static PlayerEntityModel createPlayerModel(boolean slim, Dilation dilation) {
        ModelPart root = TexturedModelData.of(PlayerEntityModel.getTexturedModelData(dilation, slim), 64, 64)
                .createModel();
        return new PlayerEntityModel(root, slim);
    }

    private PlayerEntityModel pickModel(boolean slim, boolean emissive) {
        return slim ? slimModel : wideModel;
    }

    private float computeRiseHeight(float progress) {
        return riseHeight.getCurrent() * (1.0f - (float) Math.pow(1.0f - progress, 2.4d));
    }

    private float computeRiseCurve(float progress) {
        progress = MathHelper.clamp(progress, 0.0f, 1.0f);
        return progress * progress * (3.0f - 2.0f * progress);
    }

    private int ghostColor(GhostEntry ghost, float progress, int alpha) {
        alpha = MathHelper.clamp(alpha, 0, 255);
        if (rainbow.isEnabled()) {
            float hue = (ghost.seed + progress * 0.35f
                    + (System.currentTimeMillis() % 4000L) / 4000.0f) % 1.0f;
            int rgb = Color.HSBtoRGB(hue, 0.85f, 1.0f);
            return (alpha << 24) | (rgb & 0xFFFFFF);
        }

        Color accent = GuiTheme.theme.getAccent();
        float mul = 0.65f + 0.35f * MathHelper.sin(progress * 3.1415927f * 2.0f + ghost.seed * 6.0f);
        return ColorUtil.rgba(
                MathHelper.clamp((int) (accent.getRed() * mul), 0, 255),
                MathHelper.clamp((int) (accent.getGreen() * mul), 0, 255),
                MathHelper.clamp((int) (accent.getBlue() * mul), 0, 255),
                alpha);
    }

    private PlayerEntityRenderState buildState(GhostEntry ghost, float alpha) {
        PlayerEntityRenderState state = new PlayerEntityRenderState();
        float raw = ghost.rawProgress(System.currentTimeMillis(), lifetime.getCurrent());
        float limbSpeed = MathHelper.clamp(ghost.limbSpeed * (1.0f - raw * 0.65f), 0.0f, 1.0f);
        if (limbSpeed < 1.0E-4f) {
            limbSpeed = 0.0f;
        }

        state.bodyYaw = ghost.bodyYaw;
        state.yawDegrees = ghost.headYaw;
        state.pitch = ghost.pitch - computeRiseCurve(raw) * 14.0f;
        state.limbFrequency = ghost.limbPos + raw * 2.0f;
        state.limbAmplitudeMultiplier = limbSpeed;
        state.limbAmplitudeInverse = limbSpeed > 1.0E-4f ? 1.0f / limbSpeed : 1.0f;
        state.handSwingProgress = MathHelper.clamp(
                ghost.swing * (1.0f - raw) + MathHelper.sin(raw * 3.1415927f) * 0.32f,
                0.0f,
                1.0f);
        state.isInSneakingPose = false;
        state.sneaking = false;
        state.baby = ghost.baby;
        state.pose = EntityPose.STANDING;
        state.leaningPitch = 0.0f;
        state.age = raw * 20.0f;
        state.baseScale = 1.0f;
        state.ageScale = ghost.baby ? 0.5f : 1.0f;
        state.preferredArm = Arm.RIGHT;
        state.mainArm = Arm.RIGHT;
        state.activeHand = Hand.MAIN_HAND;
        state.leftArmPose = BipedEntityModel.ArmPose.EMPTY;
        state.rightArmPose = BipedEntityModel.ArmPose.EMPTY;
        state.equippedHeadStack = ItemStack.EMPTY;
        state.equippedChestStack = ItemStack.EMPTY;
        state.equippedLegsStack = ItemStack.EMPTY;
        state.equippedFeetStack = ItemStack.EMPTY;
        state.hatVisible = false;
        state.jacketVisible = false;
        state.leftSleeveVisible = false;
        state.rightSleeveVisible = false;
        state.leftPantsLegVisible = false;
        state.rightPantsLegVisible = false;
        state.handSwinging = state.handSwingProgress > 0.0f;
        return state;
    }

    private void renderGhostModel(
            MatrixStack matrices,
            VertexConsumerProvider consumers,
            Vec3d cameraPos,
            GhostEntry ghost,
            float rise,
            float alpha,
            int color,
            boolean emissive) {
        PlayerEntityModel model = pickModel(ghost.slim, emissive);
        PlayerEntityRenderState state = buildState(ghost, alpha);
        model.getRootPart().traverse().forEach(ModelPart::resetTransform);
        model.setVisible(true);
        model.setAngles(state);
        applyGhostMotion(model, ghost, ghost.rawProgress(System.currentTimeMillis(), lifetime.getCurrent()));
        sanitizePart(model.head);
        sanitizePart(model.body);
        sanitizePart(model.leftArm);
        sanitizePart(model.rightArm);
        sanitizePart(model.leftLeg);
        sanitizePart(model.rightLeg);
        sanitizeLimbs(model);

        model.head.visible = true;
        model.body.visible = true;
        model.leftArm.visible = true;
        model.rightArm.visible = true;
        model.leftLeg.visible = true;
        model.rightLeg.visible = true;
        model.hat.visible = false;
        model.jacket.visible = false;
        model.leftSleeve.visible = false;
        model.rightSleeve.visible = false;
        model.leftPants.visible = false;
        model.rightPants.visible = false;

        float scale = MODEL_SCALE * (ghost.baby ? 0.5f : 1.0f);
        float raw = ghost.rawProgress(System.currentTimeMillis(), lifetime.getCurrent());
        float yawWobble = MathHelper.sin(raw * 3.1415927f) * 7.0f + raw * 18.0f;
        int tint = ColorUtil.rgba(255, 255, 255, MathHelper.clamp((int) (alpha * 255.0f), 0, 255));

        matrices.push();
        matrices.translate(
                ghost.pos.x - cameraPos.x,
                ghost.pos.y + rise - cameraPos.y,
                ghost.pos.z - cameraPos.z);
        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(180.0f - ghost.bodyYaw + yawWobble));
        matrices.scale(-scale, -scale, scale);
        matrices.translate(0.0f, VERTICAL_OFFSET, 0.0f);

        RenderLayer layer = emissive
                ? RenderLayer.getEntityTranslucentEmissive(ghost.skin)
                : RenderLayer.getEntityTranslucent(ghost.skin);
        VertexConsumer vertices = consumers.getBuffer(layer);
        try {
            model.render(matrices, vertices, 15728880, OverlayTexture.DEFAULT_UV, tint);
        } catch (Throwable ignored) {
        }
        matrices.pop();
    }

    private void applyGhostMotion(PlayerEntityModel model, GhostEntry ghost, float progress) {
        ModelPart root = model.getRootPart();
        if (root.hasChild("ear")) {
            root.getChild("ear").visible = false;
        }
        if (root.hasChild("cloak")) {
            root.getChild("cloak").visible = false;
        }
    }

    private void sanitizePart(ModelPart part) {
        if (part == null) {
            return;
        }
        if (Float.isNaN(part.pitch) || Float.isInfinite(part.pitch)) {
            part.pitch = 0.0f;
        }
        if (Float.isNaN(part.yaw) || Float.isInfinite(part.yaw)) {
            part.yaw = 0.0f;
        }
        if (Float.isNaN(part.roll) || Float.isInfinite(part.roll)) {
            part.roll = 0.0f;
        }
        if (Float.isNaN(part.pivotX) || Float.isInfinite(part.pivotX)) {
            part.pivotX = 0.0f;
        }
        if (Float.isNaN(part.pivotY) || Float.isInfinite(part.pivotY)) {
            part.pivotY = 0.0f;
        }
        if (Float.isNaN(part.pivotZ) || Float.isInfinite(part.pivotZ)) {
            part.pivotZ = 0.0f;
        }
    }

    private void sanitizeLimbs(PlayerEntityModel model) {
        boolean broken = Float.isNaN(model.leftArm.pitch)
                || Float.isNaN(model.rightArm.pitch)
                || Float.isNaN(model.leftLeg.pitch)
                || Float.isNaN(model.rightLeg.pitch);
        if (!broken) {
            return;
        }

        model.leftArm.pitch = 0.0f;
        model.rightArm.pitch = 0.0f;
        model.leftLeg.pitch = 0.0f;
        model.rightLeg.pitch = 0.0f;
        model.leftArm.yaw = 0.0f;
        model.rightArm.yaw = 0.0f;
        model.leftLeg.yaw = 0.0f;
        model.rightLeg.yaw = 0.0f;
        model.leftArm.roll = -0.1f;
        model.rightArm.roll = 0.1f;
        model.leftLeg.roll = 0.0f;
        model.rightLeg.roll = 0.0f;
        model.rightArm.pivotX = -5.0f;
        model.rightArm.pivotY = 2.0f;
        model.rightArm.pivotZ = 0.0f;
        model.leftArm.pivotX = 5.0f;
        model.leftArm.pivotY = 2.0f;
        model.leftArm.pivotZ = 0.0f;
        model.rightLeg.pivotX = -1.9f;
        model.rightLeg.pivotY = 12.0f;
        model.rightLeg.pivotZ = 0.0f;
        model.leftLeg.pivotX = 1.9f;
        model.leftLeg.pivotY = 12.0f;
        model.leftLeg.pivotZ = 0.0f;
    }

    private void renderParticles(MatrixStack matrices, Vec3d cameraPos, long now) {
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        try {
            for (GhostEntry ghost : ghosts) {
                float raw = ghost.rawProgress(now, lifetime.getCurrent());
                float eased = ghost.easedProgress(raw);
                if (eased < 0.01f) {
                    continue;
                }

                float rise = computeRiseHeight(raw);
                float glow = glowPower.getCurrent();
                float pulse = 0.86f + MathHelper.sin(raw * 6.2831855f * 2.0f + ghost.seed * 6.2831855f) * 0.14f;
                Vec3d risen = ghost.pos.add(0.0d, rise, 0.0d);

                drawBillboard(
                        matrices,
                        cameraPos,
                        risen.add(0.0d, ghost.height * 0.56d, 0.0d),
                        2.55f * pulse,
                        ghostColor(ghost, raw, (int) (158.0f * eased * glow)));
                drawBillboard(
                        matrices,
                        cameraPos,
                        risen.add(0.0d, ghost.height * 0.95d, 0.0d),
                        1.35f * pulse,
                        ghostColor(ghost, raw + 0.05f, (int) (138.0f * eased * glow)));
                drawBillboard(
                        matrices,
                        cameraPos,
                        risen.add(0.0d, 0.18d, 0.0d),
                        1.85f * (1.0f + raw * 0.35f),
                        ghostColor(ghost, raw + 0.12f, (int) (120.0f * eased * glow)));

                int count = Math.round(particles.getCurrent());
                if (count <= 0) {
                    continue;
                }
                for (int index = 0; index < count; index++) {
                    float angle = ghost.seed * 6.2831855f
                            + raw * 6.2831855f * 2.25f
                            + index * 6.2831855f / count;
                    float radius = 0.48f + 0.12f * MathHelper.sin(raw * 6.2831855f + index);
                    float yOff = 0.25f
                            + ghost.height * (index / (float) count)
                            + MathHelper.sin(raw * 6.2831855f * 1.5f + index) * 0.12f;
                    Vec3d point = risen.add(
                            MathHelper.cos(angle) * radius,
                            yOff,
                            MathHelper.sin(angle) * radius);
                    float size = 0.32f + 0.12f * MathHelper.sin(angle + raw * 6.2831855f);
                    drawBillboard(
                            matrices,
                            cameraPos,
                            point,
                            size,
                            ghostColor(ghost, raw + index * 0.03f, (int) (112.0f * eased * glow)));
                }
            }
        } finally {
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
        }
    }

    private void renderTrails(Vec3d cameraPos, long now) {
        int particleCount = Math.round(particles.getCurrent());
        int trailCount = Math.max(0, Math.min(6, Math.round(particleCount / 2.5f)));
        if (trailCount <= 0) {
            return;
        }

        for (GhostEntry ghost : ghosts) {
            float raw = ghost.rawProgress(now, lifetime.getCurrent());
            float eased = ghost.easedProgress(raw);
            if (eased < 0.01f) {
                continue;
            }

            float rise = computeRiseHeight(raw);
            Vec3d risen = ghost.pos.add(0.0d, rise, 0.0d);
            for (int trail = 0; trail < trailCount; trail++) {
                Vec3d previous = null;
                for (int step = 0; step <= 48; step++) {
                    float t = step / 48.0f;
                    float angle = ghost.seed * 6.2831855f
                            + raw * 6.2831855f * 2.8f
                            + t * 6.2831855f * 1.28f
                            + trail * 6.2831855f / Math.max(1, trailCount);
                    float radius = (0.34f + 0.16f * MathHelper.sin(t * 3.1415927f)) * (1.0f + raw * 0.42f);
                    Vec3d point = risen.add(
                            MathHelper.cos(angle) * radius,
                            0.2d + ghost.height * t + raw * 0.36d,
                            MathHelper.sin(angle) * radius);
                    if (previous != null) {
                        int color = ghostColor(
                                ghost,
                                raw + t * 0.08f,
                                (int) ((1.0f - t * 0.35f) * eased * 160.0f * glowPower.getCurrent()));
                        WorldDrawHelper.drawLine(previous, point, color, 2.0f, false);
                    }
                    previous = point;
                }
            }
        }
    }

    private void drawBillboard(MatrixStack matrices, Vec3d cameraPos, Vec3d pos, float size, int color) {
        int alpha = color >>> 24 & 255;
        if (alpha <= 0) {
            return;
        }

        matrices.push();
        matrices.translate(pos.x - cameraPos.x, pos.y - cameraPos.y, pos.z - cameraPos.z);
        matrices.multiply(mc.gameRenderer.getCamera().getRotation());
        Color tint = new Color(color >> 16 & 255, color >> 8 & 255, color & 255, alpha);
        WorldTextureRenderer.drawTexture(matrices, GLOW, -size / 2.0f, -size / 2.0f, size, size, tint);
        matrices.pop();
    }

    private static final class GhostEntry {
        private static final float EASE_IN = 0.16f;
        private static final float EASE_MID = 0.22f;
        private static final float EASE_OUT = 0.78f;

        private final Vec3d pos;
        private final Identifier skin;
        private final boolean slim;
        private final float bodyYaw;
        private final float headYaw;
        private final float pitch;
        private final float limbPos;
        private final float limbSpeed;
        private final float swing;
        private final boolean sneaking;
        private final boolean baby;
        private final float height;
        private final long startMs;
        private final float seed;

        private GhostEntry(
                Vec3d pos,
                Identifier skin,
                boolean slim,
                float bodyYaw,
                float headYaw,
                float pitch,
                float limbPos,
                float limbSpeed,
                float swing,
                boolean sneaking,
                boolean baby,
                float height,
                long startMs,
                float seed) {
            this.pos = pos;
            this.skin = skin;
            this.slim = slim;
            this.bodyYaw = bodyYaw;
            this.headYaw = headYaw;
            this.pitch = pitch;
            this.limbPos = limbPos;
            this.limbSpeed = limbSpeed;
            this.swing = swing;
            this.sneaking = sneaking;
            this.baby = baby;
            this.height = Math.max(1.0f, height);
            this.startMs = startMs;
            this.seed = seed;
        }

        private float rawProgress(long nowMs, float lifetimeMs) {
            return MathHelper.clamp((nowMs - startMs) / Math.max(1.0f, lifetimeMs), 0.0f, 1.0f);
        }

        private float easedProgress(float progress) {
            float fadeIn = smoothstep(MathHelper.clamp(progress / EASE_IN, 0.0f, 1.0f));
            float fadeOut = 1.0f - smoothstep(MathHelper.clamp((progress - EASE_MID) / EASE_OUT, 0.0f, 1.0f));
            return fadeIn * fadeOut;
        }

        private static float smoothstep(float value) {
            return value * value * (3.0f - 2.0f * value);
        }
    }
}
