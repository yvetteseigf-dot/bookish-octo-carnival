package sky.module.visuals;

import sky.module.Category;
import sky.module.Module;

public final class MediaPlayer extends Module {
    public static final MediaPlayer INSTANCE = new MediaPlayer();

    private MediaPlayer() {
        super("MediaPlayer", "Shows the current track", Category.VISUALS);
    }
}
