package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.LightType;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;

public final class FullBright extends Module {
    public static final FullBright INSTANCE = new FullBright();

    public final ModeSetting mode;
    public final BooleanSetting adaptiveBrightness;
    public final NumberSetting gammaValue;

    private double savedGamma = 1.0;
    private float renderGamma = 1.0f;

    private FullBright() {
        super("Full Bright", "Lights up dark areas in the world", Category.VISUALS);
        this.mode = new ModeSetting("Mode", "Gamma", "Gamma", "Potion");
        this.adaptiveBrightness = new BooleanSetting("Adaptive Brightness", false, () -> mode.is("Gamma"));
        this.gammaValue = new NumberSetting("Brightness", 8.0f, 0.5f, 20.0f, 0.1f,
                () -> !adaptiveBrightness.get() && (mode.is("Gamma") || mode.is("Potion")));
        addSettings(mode, adaptiveBrightness, gammaValue);
    }

    public static float getGammaForRendering(float vanillaGamma) {
        if (!INSTANCE.isEnabled()) {
            return vanillaGamma;
        }

        if (INSTANCE.mode.is("Gamma")) {
            return INSTANCE.renderGamma;
        }

        if (INSTANCE.mode.is("Potion")) {
            return Math.max(vanillaGamma, INSTANCE.renderGamma);
        }

        return vanillaGamma;
    }

    @Override
    protected void onEnable() {
        super.onEnable();

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options != null) {
            savedGamma = client.options.getGamma().getValue();
            renderGamma = (float) savedGamma;
        }
    }

    @Override
    protected void onDisable() {
        if (mc.options != null) {
            mc.options.getGamma().setValue(savedGamma);
        }

        renderGamma = 0.0f;
        if (mc.player != null) {
            mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
        }

        super.onDisable();
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null || mc.options == null) {
            return;
        }

        if (mode.is("Gamma")) {
            if (adaptiveBrightness.get()) {
                BlockPos pos = mc.player.getBlockPos();
                int light = Math.max(
                        mc.world.getLightLevel(LightType.BLOCK, pos),
                        mc.world.getLightLevel(LightType.SKY, pos));
                double target = 1.2 + Math.pow(1.0 - light / 15.0, 2.0) * 10.8;
                float wanted = MathHelper.clamp((float) target, 1.2f, 12.0f);
                renderGamma += (wanted - renderGamma) * 0.3f;
            } else {
                renderGamma = gammaValue.get() / 5.0f;
            }
        } else if (mode.is("Potion")) {
            renderGamma = gammaValue.get() / 5.0f;
        }

        RegistryEntry<StatusEffect> nightVision = StatusEffects.NIGHT_VISION;
        if (mode.is("Potion")) {
            StatusEffectInstance active = mc.player.getStatusEffect(nightVision);
            if (active == null || active.getDuration() < 220) {
                mc.player.addStatusEffect(new StatusEffectInstance(nightVision, 1337, 1, false, false, false));
            }
        } else {
            mc.player.removeStatusEffect(nightVision);
        }
    }
}
