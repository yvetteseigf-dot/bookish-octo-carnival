package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import sky.config.NumberSetting;
import sky.event.render.ViewModelEvent;
import sky.module.Category;
import sky.module.Module;

public final class ViewModel extends Module {
    public static final ViewModel INSTANCE = new ViewModel();

    public final NumberSetting leftX;
    public final NumberSetting leftY;
    public final NumberSetting leftZ;
    public final NumberSetting rightX;
    public final NumberSetting rightY;
    public final NumberSetting rightZ;

    private ViewModel() {
        super("ViewModel", "Hand position settings", Category.VISUALS);
        this.leftX = new NumberSetting("Left Hand X", 0.0f, -2.0f, 2.0f, 0.1f);
        this.leftY = new NumberSetting("Left Hand Y", 0.0f, -2.0f, 2.0f, 0.1f);
        this.leftZ = new NumberSetting("Left Hand Z", 0.0f, -2.0f, 2.0f, 0.1f);
        this.rightX = new NumberSetting("Right Hand X", 0.0f, -2.0f, 2.0f, 0.1f);
        this.rightY = new NumberSetting("Right Hand Y", 0.0f, -2.0f, 2.0f, 0.1f);
        this.rightZ = new NumberSetting("Right Hand Z", 0.0f, -2.0f, 2.0f, 0.1f);
        addSettings(leftX, leftY, leftZ, rightX, rightY, rightZ);
    }

    @EventTarget
    public void onViewModel(ViewModelEvent event) {
        applyHandPosition(event.getMatrixStack(), event.getArm());
    }

    public void applyHandPosition(MatrixStack stack, Arm arm) {
        if (!isEnabled() || stack == null || SwingAnimation.INSTANCE.hasCustomViewModel()) {
            return;
        }
        if (arm == Arm.RIGHT) {
            stack.translate(rightX.getCurrent(), rightY.getCurrent(), rightZ.getCurrent());
        } else {
            stack.translate(leftX.getCurrent(), leftY.getCurrent(), leftZ.getCurrent());
        }
    }
}
