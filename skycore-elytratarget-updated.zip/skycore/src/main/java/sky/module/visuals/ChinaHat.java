package sky.module.visuals;

import com.darkmagician6.eventapi.EventTarget;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.ModelWithHead;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.opengl.GL11;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.theme.GuiTheme;
import sky.event.render.ArmorLayerEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.render.ArgbUtil;
import sky.util.render.ColorUtil;

public final class ChinaHat extends Module {
    public static final ChinaHat INSTANCE = new ChinaHat();

    private static final float PI = 0.034906585f;

    private final BooleanSetting viewOnFriends;

    private ChinaHat() {
        super("China Hat", "Adds a china hat", Category.VISUALS);
        this.viewOnFriends = new BooleanSetting("Show on friends", true);
        addSettings(viewOnFriends);
    }

    @EventTarget
    public void onLayerHead(ArmorLayerEvent event) {
        if (mc.world == null || mc.player == null) {
            return;
        }

        EntityModel<?> model = event.getModel();
        if (!(model instanceof ModelWithHead headModel)) {
            return;
        }
        LivingEntity living = event.getEntity();
        if (!(living instanceof PlayerEntity player)) {
            return;
        }

        boolean self = player == mc.player;
        boolean friend = SkyInit.getInstance().getFriendManager().isFriend(player.getGameProfile().getName());
        if (!self && (!viewOnFriends.isEnabled() || !friend)) {
            return;
        }
        if (self && mc.options.getPerspective().isFirstPerson()) {
            return;
        }

        double width = player.getBoundingBox().getLengthX();
        float headOffset = player.getEquippedStack(EquipmentSlot.HEAD).isEmpty() ? 0.42f : 0.5f;
        int accent = GuiTheme.theme.getAccent().getRGB() | 0xFF000000;
        int darkened = ColorUtil.darken(GuiTheme.theme.getAccent(), 0.5f).getRGB() | 0xFF000000;

        MatrixStack stack = event.getMatrix();
        stack.push();
        headModel.getHead().rotate(stack);
        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.defaultBlendFunc();
        RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        GL11.glEnable(GL11.GL_LINE_SMOOTH);
        GL11.glHint(GL11.GL_LINE_SMOOTH_HINT, GL11.GL_NICEST);
        RenderSystem.lineWidth(2.0f);
        stack.translate(0.0f, -headOffset, 0.0f);
        stack.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(180.0f));
        stack.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(90.0f));
        MatrixStack.Entry entry = stack.peek();

        BufferBuilder buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.TRIANGLE_STRIP, VertexFormats.POSITION_COLOR);
        for (int index = 0; index <= 180; index++) {
            float angle = index * PI;
            int phase = index * 8;
            float x = MathHelper.sin(angle) * (float) width;
            float z = MathHelper.cos(angle) * (float) width;
            int faded = fade(accent, darkened, phase);
            int rim = ArgbUtil.multAlpha(faded, 0.5f);
            buffer.vertex(entry, x, 0.0f, z).color(rim);
            buffer.vertex(entry, 0.0f, 0.3f, 0.0f).color(accent);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());

        RenderSystem.depthMask(false);
        buffer = Tessellator.getInstance().begin(VertexFormat.DrawMode.DEBUG_LINE_STRIP, VertexFormats.POSITION_COLOR);
        for (int index = 0; index <= 180; index++) {
            float angle = index * PI;
            int phase = index * 8;
            float x = MathHelper.sin(angle) * (float) width;
            float z = MathHelper.cos(angle) * (float) width;
            int faded = fade(accent, darkened, phase);
            buffer.vertex(entry, x, 0.0f, z).color(faded);
        }
        BufferRenderer.drawWithGlobalProgram(buffer.end());
        RenderSystem.depthMask(true);
        GL11.glDisable(GL11.GL_LINE_SMOOTH);
        RenderSystem.enableCull();
        RenderSystem.defaultBlendFunc();
        stack.pop();
    }

    private static int fade(int from, int to, int phase) {
        float t = (MathHelper.sin(phase * 0.05f) + 1.0f) * 0.5f;
        int a = (int) (((from >> 24) & 255) + (((to >> 24) & 255) - ((from >> 24) & 255)) * t);
        int r = (int) (((from >> 16) & 255) + (((to >> 16) & 255) - ((from >> 16) & 255)) * t);
        int g = (int) (((from >> 8) & 255) + (((to >> 8) & 255) - ((from >> 8) & 255)) * t);
        int b = (int) ((from & 255) + ((to & 255) - (from & 255)) * t);
        return (a << 24) | (r << 16) | (g << 8) | b;
    }
}
