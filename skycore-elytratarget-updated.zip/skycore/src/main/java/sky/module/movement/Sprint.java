package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.event.player.PlayerTickEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AttackAura;
import sky.util.entity.MovementUtil;
import sky.module.combat.Criticals;

public final class Sprint extends Module {
    public static final Sprint INSTANCE = new Sprint();

    private final BooleanSetting water;
    private final ModeSetting mode;

    private int hwStartDelay;
    private int hwStopDelay;
    private boolean hwSprinting;

    private Sprint() {
        super("Sprint", "Automatically enables sprint when the player starts moving", Category.MOVEMENT);
        this.mode = new ModeSetting("Mode", "Normal", "Normal", "Packet", "Holyworld");
        this.water = new BooleanSetting("Sprint in water", false, () -> !mode.is("Holyworld"));
        addSettings(mode, water);
    }

    @EventTarget
    public void onUpdate(PlayerTickEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (mode.is("Holyworld")) {
            updateHolyworldSprint();
            return;
        }

        if (!mode.is("Normal") && !mode.is("Packet")) {
            return;
        }

        boolean inWater = mc.player.isTouchingWater() || mc.player.isSubmergedInWater();
        boolean shouldSprint = MovementUtil.hasPlayerMovement()
                && !mc.player.horizontalCollision
                && !mc.player.isSneaking()
                && !mc.player.isUsingItem()
                && (water.isEnabled() || !inWater);
        boolean holdingForCriticals = AttackAura.INSTANCE.isEnabled()
                && AttackAura.INSTANCE.getTarget() != null
                && AttackAura.INSTANCE.onlyCriticals.isEnabled();

        if (mode.is("Packet")) {
            boolean wantSprint = holdingForCriticals
                    ? canStopSprintForCrits() && shouldSprint
                    : shouldSprint;
            if (wantSprint) {
                if (!mc.player.isSprinting()) {
                    mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                            ClientCommandC2SPacket.Mode.START_SPRINTING));
                }
                mc.player.setSprinting(true);
                mc.options.sprintKey.setPressed(true);
            } else {
                mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                        ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                mc.player.setSprinting(false);
                mc.options.sprintKey.setPressed(false);
            }
            return;
        }

        if (holdingForCriticals) {
            if (canStopSprintForCrits() && shouldSprint) {
                mc.options.sprintKey.setPressed(true);
            } else {
                mc.options.sprintKey.setPressed(false);
                mc.player.setSprinting(false);
            }
        } else if (shouldSprint) {
            mc.options.sprintKey.setPressed(true);
        } else {
            mc.options.sprintKey.setPressed(false);
            mc.player.setSprinting(false);
        }
    }

    private void updateHolyworldSprint() {
        if (mc.player.isTouchingWater() && !mc.player.isSubmergedInWater()) {
            return;
        }

        boolean inWater = mc.player.isTouchingWater() || mc.player.isSubmergedInWater();
        boolean shouldSprint = mc.player.input.hasForwardMovement()
                && !mc.player.isUsingItem()
                && !mc.player.isGliding()
                && !isBlind()
                && !mc.player.isSneaking()
                && !mc.player.horizontalCollision
                && canSprint()
                && isWalking()
                && (inWater || !mc.player.shouldSlowDown());

        if (shouldSprint) {
            if (hwStartDelay > 0) {
                hwStartDelay--;
                return;
            }
            mc.player.setSprinting(true);
            hwSprinting = true;
        } else {
            if (hwSprinting) {
                mc.player.setSprinting(false);
                hwSprinting = false;
            }
            hwStartDelay = 1;
        }
    }

    private boolean canStopSprintForCrits() {
        boolean inWater = mc.player.isTouchingWater() || mc.player.isSubmergedInWater();
        boolean inCobweb = mc.player.getBlockStateAtPos().isOf(Blocks.COBWEB);

        if (mc.player.isGliding()) {
            return false;
        }

        return inCobweb
                || mc.player.getAbilities().flying
                || inWater
                || mc.player.hasVehicle()
                || (mc.player.fallDistance <= 0.0F && mc.player.isOnGround());
    }

    private boolean canSprint() {
        return mc.player.getAbilities().allowFlying
                || mc.player.getHungerManager().getFoodLevel() > 6.0F
                || mc.player.isSubmergedInWater();
    }

    private boolean isWalking() {
        return mc.player.isSubmergedInWater()
                ? mc.player.input.hasForwardMovement()
                : mc.player.input.movementForward >= 0.8D;
    }

    private boolean isBlind() {
        return mc.player.hasStatusEffect(StatusEffects.BLINDNESS);
    }

    @Override
    public void onDisable() {
        if (mc.player != null) {
            mc.player.setSprinting(false);
        }
        if (mc.options != null) {
            mc.options.sprintKey.setPressed(false);
        }
        hwSprinting = false;
        hwStartDelay = 0;
        hwStopDelay = 0;
        super.onDisable();
    }
}
