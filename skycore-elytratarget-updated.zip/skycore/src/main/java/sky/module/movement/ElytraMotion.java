package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerMoveEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AttackAura;
import sky.module.combat.ElytraTarget;
import sky.util.inventory.ItemSwapUtil;
import sky.util.MsTimer;

public final class ElytraMotion extends Module {
    public static final ElytraMotion INSTANCE = new ElytraMotion();

    public final NumberSetting attackDistance;

    private final BooleanSetting autoFireworks;
    private final MsTimer fireworkTimer;

    public boolean freeze;

    private ElytraMotion() {
        super("ElytraMotion", "Hovers on elytra in front of the opponent", Category.MOVEMENT);
        attackDistance = new NumberSetting("Distance", 2.5F, 1.0F, 3.0F, 0.1F);
        autoFireworks = new BooleanSetting("AutoFireworks", false);
        fireworkTimer = new MsTimer();
        addSettings(attackDistance, autoFireworks);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || !mc.player.isGliding()) {
            freeze = false;
            return;
        }

        AttackAura aura = AttackAura.INSTANCE;
        ElytraTarget elytraTarget = ElytraTarget.INSTANCE;

        if (check(aura, elytraTarget)) {
            mc.options.forwardKey.setPressed(false);
            freeze = true;
        } else {
            mc.options.forwardKey.setPressed(true);
            freeze = false;
        }

        if (autoFireworks.isEnabled()
                && aura.getTarget() != null
                && !elytraTarget.slowdownActive
                && !GrimGlide.isGlideFlyActive()
                && fireworkTimer.finished(500L)) {
            ItemSwapUtil.inventorySwapClick(Items.FIREWORK_ROCKET);
            fireworkTimer.reset();
        }
    }

    @EventTarget
    public void onMove(PlayerMoveEvent event) {
        if (freeze && !GrimGlide.isGlideFlyActive()) {
            event.setMovePos(Vec3d.ZERO);
        }
    }

    public boolean check(AttackAura aura, ElytraTarget elytraTarget) {
        LivingEntity target = aura.getTarget();
        if (target == null || mc.player == null || !mc.player.isGliding()) {
            return false;
        }
        if (elytraTarget != null && elytraTarget.isEnabled() && elytraTarget.shouldTarget(target)) {
            return false;
        }

        double deltaX = target.getX() - target.lastRenderX;
        double deltaY = target.getY() - target.lastRenderY;
        double deltaZ = target.getZ() - target.lastRenderZ;
        double blocksPerSecond = Math.sqrt(deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ) * 20.0D;
        if (blocksPerSecond >= 25.0D) {
            return false;
        }

        float range = attackDistance.getCurrent() + (target.isGliding() ? 0.5F : 0.0F);
        return target.distanceTo(mc.player) < range;
    }

    @Override
    public void onEnable() {
        freeze = false;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        freeze = false;
        if (mc.options != null) {
            mc.options.forwardKey.setPressed(false);
        }
        super.onDisable();
    }
}
