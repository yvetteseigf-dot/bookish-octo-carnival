package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.util.PlayerInput;
import sky.session.SilentPacketUtil;
import sky.scheduler.TimerSpeedController;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerTickEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.render.RenderWorldEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class ChargeBoost extends Module {
    public static final ChargeBoost INSTANCE = new ChargeBoost();

    private static final long CHARGE_DURATION_NANOS = 1250000000L;
    private static final long MAX_BOOST_DURATION_NANOS = 2400000000L;
    private static final float CHARGE_TIMER = 0.05F;
    private static final float BOOST_TIMER = 1.7F;
    private static final int FULL_BOOST_JUMPS = 4;

    private final Queue<CommonPongC2SPacket> delayedTransactions;

    private Phase phase;
    private boolean cycleActive;
    private boolean airborne;
    private long phaseStartedAt;
    private int completedJumps;
    private int groundTicks;

    private ChargeBoost() {
        super("Charge Boost", "Speed boosts for ReallyWorld", Category.MOVEMENT);
        this.phase = Phase.CHARGING;
        this.delayedTransactions = new ConcurrentLinkedQueue<>();
    }

    @Override
    public void onEnable() {
        stopCycle();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        stopCycle();
        super.onDisable();
    }

    public static boolean shouldBlockAutoJump() {
        return INSTANCE.isEnabled();
    }

    @EventTarget
    public void onWorldRender(RenderWorldEvent event) {
        if (mc.player == null || !isMoving(mc.player.input.playerInput)) {
            stopCycle();
            return;
        }

        long now = System.nanoTime();
        if (!cycleActive) {
            cycleActive = true;
            beginCharging();
            return;
        }

        if (phase == Phase.CHARGING) {
            if (now - phaseStartedAt >= CHARGE_DURATION_NANOS) {
                beginBoosting();
            }
        } else if (phase == Phase.BOOSTING) {
            if (now - phaseStartedAt >= MAX_BOOST_DURATION_NANOS) {
                beginCharging();
            }
        }
    }

    @EventTarget
    public void onTick(PlayerTickEvent event) {
        if (mc.player == null || !cycleActive || phase != Phase.BOOSTING) {
            return;
        }

        if (mc.player.verticalCollision) {
            if (airborne) {
                airborne = false;
                completedJumps++;
            }
        } else {
            airborne = true;
            if (completedJumps >= FULL_BOOST_JUMPS && mc.player.getVelocity().y <= 0.0D) {
                beginCharging();
            }
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            stopCycle();
        }
    }

    @EventTarget
    public void onMoveInput(StrafeInputEvent event) {
        PlayerInput input = event.getInput();
        if (mc.player == null || phase != Phase.BOOSTING || input == null || !isMoving(input)) {
            groundTicks = 0;
            return;
        }

        groundTicks = mc.player.verticalCollision ? groundTicks + 1 : 0;
        boolean jump = groundTicks > 0 || input.jump();
        event.setInput(new PlayerInput(
                input.forward(),
                input.backward(),
                input.left(),
                input.right(),
                jump,
                input.sneak(),
                true));
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (event.isSend() && cycleActive) {
            Packet<?> packet = event.getPacket();
            if (packet instanceof CommonPongC2SPacket pong) {
                delayedTransactions.add(pong);
                event.setCancelled(true);
                return;
            }
        }

        if (event.isReceive() && cycleActive
                && event.getPacket() instanceof PlayerPositionLookS2CPacket) {
            beginCharging();
        }
    }

    public boolean isBoosting() {
        return phase == Phase.BOOSTING;
    }

    public boolean isCharging() {
        return phase == Phase.CHARGING;
    }

    public boolean isCycleActive() {
        return cycleActive;
    }

    public float getHudProgress() {
        if (!isEnabled() || !cycleActive || phaseStartedAt == 0L) {
            return 1.0F;
        }

        long elapsed = System.nanoTime() - phaseStartedAt;
        if (phase == Phase.CHARGING) {
            return Math.min(1.0F, elapsed / (float) CHARGE_DURATION_NANOS);
        }
        return Math.max(0.0F, 1.0F - elapsed / (float) MAX_BOOST_DURATION_NANOS);
    }

    private void beginCharging() {
        flushTransactions();
        phase = Phase.CHARGING;
        airborne = false;
        completedJumps = 0;
        groundTicks = 0;
        phaseStartedAt = System.nanoTime();
        TimerSpeedController.setSpeed(CHARGE_TIMER);
    }

    private void beginBoosting() {
        phase = Phase.BOOSTING;
        airborne = false;
        completedJumps = 0;
        groundTicks = 0;
        phaseStartedAt = System.nanoTime();
        TimerSpeedController.setSpeed(BOOST_TIMER);
    }

    private void stopCycle() {
        flushTransactions();
        cycleActive = false;
        phase = Phase.CHARGING;
        airborne = false;
        completedJumps = 0;
        groundTicks = 0;
        phaseStartedAt = 0L;
        TimerSpeedController.resetSpeed();
    }

    private void flushTransactions() {
        CommonPongC2SPacket pong;
        while ((pong = delayedTransactions.poll()) != null) {
            SilentPacketUtil.sendSilentPacket(pong);
        }
    }

    private boolean isMoving(PlayerInput input) {
        return input != null
                && (input.forward() || input.backward() || input.left() || input.right());
    }

    private enum Phase {
        CHARGING,
        BOOSTING
    }
}
