package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import sky.event.world.BlockCollideShapeEvent;
import sky.module.Category;
import sky.module.Module;

public final class WebIgnore extends Module {
    public static final WebIgnore INSTANCE = new WebIgnore();

    private WebIgnore() {
        super("Web Ignore", "Lets you break blocks through cobwebs", Category.MOVEMENT);
    }

    @EventTarget
    public void onBlockCollide(BlockCollideShapeEvent event) {
        if (mc.world == null || event.getPos() == null) {
            return;
        }

        if (mc.world.getBlockState(event.getPos()).isOf(Blocks.COBWEB)) {
            event.setCancelled(true);
        }
    }
}
