package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.session.SilentPacketUtil;
import sky.event.network.PacketSendEvent;
import sky.event.network.GameJoinEvent;
import sky.event.player.PlayerMoveEvent;
import sky.event.player.MotionEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.entity.TravelEvent;
import sky.module.Category;
import sky.module.Module;

public final class AirStuck extends Module {
    public static final AirStuck INSTANCE = new AirStuck();

    private final BooleanSetting changeAuraDistance;
    private final NumberSetting auraDistance;
    private final BooleanSetting catchMoment;

    private boolean frozen;
    private double peakY;
    private Vec3d frozenPos;

    private AirStuck() {
        super("Air Stuck", "Lets you freeze in the air", Category.MOVEMENT);
        this.changeAuraDistance = new BooleanSetting("Change kill aura distance", false);
        this.auraDistance = new NumberSetting("Kill aura distance", 3.5f, 2.0f, 6.0f, 0.1f,
                changeAuraDistance::isEnabled);
        this.catchMoment = new BooleanSetting("Catch the moment", true);
        this.peakY = Double.NaN;
        addSettings(this.changeAuraDistance, this.auraDistance, this.catchMoment);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null) {
            return;
        }

        if (frozen) {
            if (frozenPos == null) {
                freezeAtCurrentPosition();
            } else {
                mc.player.setVelocity(Vec3d.ZERO);
                mc.player.fallDistance = 0.0f;
                mc.player.setPosition(frozenPos);
            }
        }

        if (!catchMoment.isEnabled()) {
            return;
        }

        double currentY = mc.player.getY();
        if (mc.player.isOnGround()) {
            peakY = Double.NaN;
            frozen = false;
            frozenPos = null;
        } else if (!frozen) {
            if (Double.isNaN(peakY)) {
                peakY = currentY;
            } else if (currentY > peakY) {
                peakY = currentY;
            } else if (currentY < peakY) {
                frozen = true;
                freezeAtCurrentPosition();
            }
        }
    }

    @EventTarget
    public void onMotion(MotionEvent event) {
        if (!frozen || mc.player == null || frozenPos == null) {
            return;
        }

        event.setCancelled(true);
        SilentPacketUtil.sendSilentPacket(new PlayerMoveC2SPacket.Full(frozenPos.x, frozenPos.y, frozenPos.z,
                mc.player.getYaw(), mc.player.getPitch(), false, false));
    }

    @EventTarget
    public void onMove(PlayerMoveEvent event) {
        if (frozen) {
            event.setMovePos(Vec3d.ZERO);
        }
    }

    @EventTarget
    public void onTravel(TravelEvent event) {
        if (frozen && event.getEntity() == mc.player) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (mc.player == null || !frozen) {
            return;
        }

        if (event.isSend() && event.getPacket() instanceof PlayerMoveC2SPacket) {
            event.setCancelled(true);
        }
    }

    @EventTarget
    public void onSwapWorld(GameJoinEvent event) {
        toggle();
    }

    public boolean isFrozen() {
        return isEnabled() && frozen;
    }

    public float getKillAuraDistance() {
        if (isEnabled() && changeAuraDistance.isEnabled()) {
            return auraDistance.getCurrent();
        }

        return -1.0f;
    }

    private void freezeAtCurrentPosition() {
        if (mc.player == null) {
            return;
        }

        frozenPos = mc.player.getPos();
        mc.player.setVelocity(Vec3d.ZERO);
        mc.player.fallDistance = 0.0f;
    }

    @Override
    public void onEnable() {
        super.onEnable();
        frozenPos = null;

        if (catchMoment.isEnabled()) {
            peakY = mc.player != null && !mc.player.isOnGround() ? mc.player.getY() : Double.NaN;
            frozen = false;
        } else {
            frozen = true;
            freezeAtCurrentPosition();
        }
    }

    @Override
    public void onDisable() {
        frozen = false;
        frozenPos = null;
        super.onDisable();
    }
}
