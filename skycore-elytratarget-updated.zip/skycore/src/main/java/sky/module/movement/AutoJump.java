package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.combat.AttackAura;

public final class AutoJump extends Module {
    public static final AutoJump INSTANCE = new AutoJump();

    private AutoJump() {
        super("AutoJump", "Automatically jumps when Aura finds a target", Category.MOVEMENT);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (ChargeBoost.shouldBlockAutoJump()) {
            return;
        }

        AttackAura aura = AttackAura.INSTANCE;
        if (!aura.isEnabled() || aura.getTarget() == null) {
            return;
        }

        if (mc.player.isOnGround()) {
            mc.player.jump();
        }
    }
}
