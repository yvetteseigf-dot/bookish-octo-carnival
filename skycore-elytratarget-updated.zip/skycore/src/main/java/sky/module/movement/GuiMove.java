package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.CraftingScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.util.PlayerInput;
import org.lwjgl.glfw.GLFW;
import sky.config.ModeSetting;
import sky.event.player.CloseScreenEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.ClickSlotEvent;
import sky.event.input.InputTickEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementUtil;
import sky.util.entity.PlayerUtil;

import java.util.ArrayList;
import java.util.List;

public final class GuiMove extends Module {
    public static final GuiMove INSTANCE = new GuiMove();

    public final ModeSetting mode;

    private final List<ClickSlotC2SPacket> queuedClicks;

    public boolean slow;
    public boolean bypassInventorySwap;

    private int reallyworldStopTicks;

    private GuiMove() {
        super("Gui Move", "Lets you walk with the inventory open", Category.MOVEMENT);
        mode = new ModeSetting("Bypass", "Vanilla", "Vanilla", "Reallyworld");
        queuedClicks = new ArrayList<>();
        addSettings(mode);
    }

    public boolean isBypassMode() {
        return mode.is("Reallyworld");
    }

    public boolean isReallyworldMode() {
        return isEnabled() && mode.is("Reallyworld");
    }

    @Override
    public void onDisable() {
        queuedClicks.clear();
        reallyworldStopTicks = 0;
        slow = false;
        bypassInventorySwap = false;
        super.onDisable();
    }

    @EventTarget
    private void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null) {
            return;
        }

        if (reallyworldStopTicks > 0) {
            reallyworldStopTicks--;
        }

        if (mode.is("Reallyworld") && reallyworldStopTicks > 0) {
            return;
        }

        if (isBlockedScreen()) {
            return;
        }

        updateKeyBindingState(movementKeys());

        if (mode.is("Reallyworld") && slow) {
            flushQueuedClicks(false);
            slow = false;
        }
    }

    @EventTarget
    public void onKeyboard(InputTickEvent event) {
        if (mc.currentScreen == null || isBlockedScreen()) {
            return;
        }

        event.setSneak(false);
    }

    @EventTarget
    public void onInput(StrafeInputEvent event) {
        if (mode.is("Reallyworld") && reallyworldStopTicks > 0) {
            event.setForward(0.0F);
            event.setStrafe(0.0F);
            event.setInput(new PlayerInput(false, false, false, false, false, false, false));
            return;
        }

        if (mc.currentScreen == null || isBlockedScreen() || mc.options == null) {
            return;
        }

        boolean forward = mc.options.forwardKey.isPressed();
        boolean back = mc.options.backKey.isPressed();
        boolean left = mc.options.leftKey.isPressed();
        boolean right = mc.options.rightKey.isPressed();
        boolean jump = mc.options.jumpKey.isPressed();
        boolean sprint = mc.options.sprintKey.isPressed();

        event.setForward((forward ? 1.0F : 0.0F) - (back ? 1.0F : 0.0F));
        event.setStrafe((left ? 1.0F : 0.0F) - (right ? 1.0F : 0.0F));
        event.setInput(new PlayerInput(forward, back, left, right, jump, false, sprint));
    }

    @EventTarget
    public void onWindowClick(ClickSlotEvent event) {
        if (!isReallyworldMode()
                || bypassInventorySwap
                || !(mc.currentScreen instanceof InventoryScreen)
                || !MovementUtil.hasPlayerMovement()) {
            return;
        }

        ClickSlotC2SPacket packet = PlayerUtil.createClickSlotPacket(
                event.getWindowId(),
                event.getSlotId(),
                event.getButton(),
                event.getActionType(),
                mc.player);
        if (packet != null) {
            queuedClicks.add(packet);
        }
        event.setCancelled(true);
    }

    @EventTarget
    public void onInventoryClose(CloseScreenEvent event) {
        if (!isReallyworldMode()
                || !(mc.currentScreen instanceof InventoryScreen)
                || !MovementUtil.hasPlayerMovement()
                || queuedClicks.isEmpty()) {
            return;
        }

        slow = true;
        reallyworldStopTicks = 3;
        event.setCancelled(true);
    }

    private boolean isBlockedScreen() {
        return mc.currentScreen instanceof ChatScreen
                || mc.currentScreen instanceof AbstractSignEditScreen
                || mc.currentScreen instanceof GenericContainerScreen
                || mc.currentScreen instanceof CraftingScreen
                || (mc.player != null && mc.player.isGliding());
    }

    private KeyBinding[] movementKeys() {
        return new KeyBinding[] {
                mc.options.forwardKey,
                mc.options.backKey,
                mc.options.leftKey,
                mc.options.rightKey,
                mc.options.jumpKey,
                mc.options.sprintKey
        };
    }

    private void updateKeyBindingState(KeyBinding[] keyBindings) {
        long windowHandle = mc.getWindow().getHandle();
        for (KeyBinding keyBinding : keyBindings) {
            keyBinding.setPressed(isKeyBindingDown(windowHandle, keyBinding));
        }
    }

    private boolean isKeyBindingDown(long windowHandle, KeyBinding keyBinding) {
        InputUtil.Key bound = InputUtil.fromTranslationKey(keyBinding.getBoundKeyTranslationKey());
        if (bound == null || bound.getCode() == -1) {
            return false;
        }
        if (bound.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(windowHandle, bound.getCode()) == GLFW.GLFW_PRESS;
        }
        if (bound.getCategory() == InputUtil.Type.KEYSYM) {
            return InputUtil.isKeyPressed(windowHandle, bound.getCode());
        }
        return false;
    }

    private void flushQueuedClicks(boolean closeScreen) {
        if (mc.player == null || mc.getNetworkHandler() == null) {
            queuedClicks.clear();
            return;
        }

        if (queuedClicks.isEmpty()) {
            if (closeScreen && mc.currentScreen != null) {
                mc.setScreen(null);
            }
            return;
        }

        bypassInventorySwap = true;
        try {
            for (ClickSlotC2SPacket packet : queuedClicks) {
                mc.getNetworkHandler().sendPacket(packet);
            }
            mc.getNetworkHandler().sendPacket(
                    new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
        } finally {
            bypassInventorySwap = false;
        }

        queuedClicks.clear();
        if (closeScreen && mc.currentScreen != null) {
            mc.setScreen(null);
        }
    }
}
