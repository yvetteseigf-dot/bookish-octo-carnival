package sky.module.movement;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import sky.config.NumberSetting;
import sky.event.camera.ThirdPersonDistanceEvent;
import sky.event.camera.CameraUpdateEvent;
import sky.event.network.WorldSwapEvent;
import sky.event.player.MotionPostEvent;
import sky.event.render.RenderHandEvent;
import sky.event.input.InputTickEvent;
import sky.event.input.HandleInputEvent;
import sky.module.Category;
import sky.module.Module;

public final class FreeCamera extends Module {
    public static final FreeCamera INSTANCE = new FreeCamera();

    private static final double DETACH_DISTANCE_SQ = 0.0625D;

    private final NumberSetting speedXZ;
    private final NumberSetting speedY;

    private Vec3d cameraPosition;
    private Vec3d prevCameraPosition;
    private Perspective prevPerspective;

    private float rotationYaw;
    private float rotationPitch;
    private float inputForward;
    private float inputStrafe;
    private boolean inputJump;
    private boolean inputSneak;
    private boolean detached;

    private FreeCamera() {
        super("Free Camera", "Lets you move in a free camera", Category.MOVEMENT);
        speedXZ = new NumberSetting("XZ Speed", 1.5F, 0.1F, 5.0F, 0.1F);
        speedY = new NumberSetting("Y Speed", 1.0F, 0.1F, 5.0F, 0.1F);
        prevPerspective = Perspective.FIRST_PERSON;
        addSettings(speedXZ, speedY);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        if (mc.player == null) {
            return;
        }

        cameraPosition = mc.player.getEyePos();
        prevCameraPosition = cameraPosition;
        rotationYaw = mc.player.getYaw();
        rotationPitch = mc.player.getPitch();
        prevPerspective = mc.options.getPerspective();
        detached = false;
        mc.options.setPerspective(Perspective.FIRST_PERSON);
    }

    @Override
    public void onDisable() {
        super.onDisable();
        cameraPosition = null;
        prevCameraPosition = null;
        inputForward = 0.0F;
        inputStrafe = 0.0F;
        inputJump = false;
        inputSneak = false;
        detached = false;
        mc.options.setPerspective(prevPerspective);
    }

    @EventTarget
    public void onEvent(MotionPostEvent event) {
        if (cameraPosition == null) {
            return;
        }

        prevCameraPosition = cameraPosition;
        updateInputFromKeys();
        if (!detached) {
            cameraPosition = mc.player.getEyePos();
        }
        applyCameraMovement();
        updateDetachedState();
    }

    @EventTarget
    public void onEvent(CameraUpdateEvent eventRotation) {
        rotationYaw = eventRotation.getYaw();
        rotationPitch = eventRotation.getPitch();

        Vec3d position = prevCameraPosition == null
                ? cameraPosition
                : prevCameraPosition.lerp(cameraPosition, eventRotation.getPartialTicks());
        eventRotation.setPosition(position);
        eventRotation.setCancelled(true);
    }

    @EventTarget
    public void onEvent(ThirdPersonDistanceEvent eventThirdPersonDistance) {
        if (detached) {
            eventThirdPersonDistance.setDistance(0.0D);
        }
    }

    @EventTarget
    public void onEvent(RenderHandEvent eventThirdPersonRender) {
        if (detached) {
            eventThirdPersonRender.setThirdperson(true);
        }
    }

    @EventTarget
    public void onEvent(HandleInputEvent eventCancelThirdPerson) {
        eventCancelThirdPerson.setCancelled(true);
    }

    @EventTarget
    public void onEvent(WorldSwapEvent eventSwapWorld) {
        toggle();
    }

    @EventTarget
    public void onEvent(InputTickEvent eventInput) {
        if (cameraPosition == null) {
            return;
        }

        inputForward = eventInput.getForward();
        inputStrafe = eventInput.getStrafe();
        inputJump = eventInput.isJump();
        inputSneak = eventInput.isSneak();

        long windowHandle = mc.getWindow().getHandle();
        boolean upArrow = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_UP) == GLFW.GLFW_PRESS;
        boolean downArrow = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_DOWN) == GLFW.GLFW_PRESS;
        boolean leftArrow = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_LEFT) == GLFW.GLFW_PRESS;
        boolean rightArrow = GLFW.glfwGetKey(windowHandle, GLFW.GLFW_KEY_RIGHT) == GLFW.GLFW_PRESS;

        float forward = 0.0F;
        if (upArrow) {
            forward += 1.0F;
        }
        if (downArrow) {
            forward -= 1.0F;
        }

        float strafe = 0.0F;
        if (leftArrow) {
            strafe += 1.0F;
        }
        if (rightArrow) {
            strafe -= 1.0F;
        }

        eventInput.setForward(forward);
        eventInput.setStrafe(strafe);
        eventInput.setJump(false);
        eventInput.setSneak(false);
    }

    public Vec3d getInterpolatedCameraPosition(float partialTicks) {
        if (cameraPosition == null) {
            return null;
        }
        if (prevCameraPosition == null) {
            return cameraPosition;
        }

        double x = prevCameraPosition.x + (cameraPosition.x - prevCameraPosition.x) * partialTicks;
        double y = prevCameraPosition.y + (cameraPosition.y - prevCameraPosition.y) * partialTicks;
        double z = prevCameraPosition.z + (cameraPosition.z - prevCameraPosition.z) * partialTicks;
        return new Vec3d(x, y, z);
    }

    public boolean isDetached() {
        return detached;
    }

    private void updateInputFromKeys() {
        if (mc.options == null) {
            return;
        }

        float forward = 0.0F;
        if (mc.options.forwardKey.isPressed()) {
            forward += 1.0F;
        }
        if (mc.options.backKey.isPressed()) {
            forward -= 1.0F;
        }

        float strafe = 0.0F;
        if (mc.options.leftKey.isPressed()) {
            strafe += 1.0F;
        }
        if (mc.options.rightKey.isPressed()) {
            strafe -= 1.0F;
        }

        inputForward = forward;
        inputStrafe = strafe;
        inputJump = mc.options.jumpKey.isPressed();
        inputSneak = mc.options.sneakKey.isPressed();
    }

    private void applyCameraMovement() {
        if (inputForward == 0.0F && inputStrafe == 0.0F && !inputJump && !inputSneak) {
            return;
        }

        double horizontalSpeed = speedXZ.getCurrent();
        double verticalSpeed = speedY.getCurrent();
        double yawRadians = Math.toRadians(rotationYaw);
        double sinYaw = Math.sin(yawRadians);
        double cosYaw = Math.cos(yawRadians);

        double deltaX = (inputForward * -sinYaw + inputStrafe * cosYaw) * horizontalSpeed;
        double deltaZ = (inputForward * cosYaw + inputStrafe * sinYaw) * horizontalSpeed;
        double deltaY = (inputJump ? verticalSpeed : 0.0D) - (inputSneak ? verticalSpeed : 0.0D);

        cameraPosition = cameraPosition.add(deltaX, deltaY, deltaZ);
    }

    private void updateDetachedState() {
        if (detached || mc.player == null || cameraPosition == null) {
            return;
        }

        if (cameraPosition.squaredDistanceTo(mc.player.getEyePos()) > DETACH_DISTANCE_SQ) {
            detached = true;
            mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        }
    }
}
