package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import sky.SkyInit;
import sky.event.combat.AttackEntityEvent;
import sky.module.Category;
import sky.module.Module;

public final class NoFriendDamage extends Module {
    public static final NoFriendDamage INSTANCE = new NoFriendDamage();

    private NoFriendDamage() {
        super("NoFriendDamage", "Removes damage to friends", Category.COMBAT);
    }

    @EventTarget
    public void onAttack(AttackEntityEvent event) {
        Entity target = event.getTarget();
        if (target instanceof PlayerEntity player) {
            String name = player.getName().getString();
            if (SkyInit.getInstance().getFriendManager().isFriend(name)) {
                event.setCancelled(true);
            }
        }
    }
}
