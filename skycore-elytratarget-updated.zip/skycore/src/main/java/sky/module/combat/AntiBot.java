package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.MsTimer;

public final class AntiBot extends Module {
    public static final AntiBot INSTANCE = new AntiBot();
    public static final List<PlayerEntity> bots = new ArrayList<>();

    private final ModeSetting mode;
    private final BooleanSetting cakeAirborneOnly;
    private final MsTimer timer;

    private AntiBot() {
        super("AntiBot", "Removes bots", Category.COMBAT);
        this.mode = new ModeSetting("Bypass", "ReallyWorld", "ReallyWorld", "Matrix", "CakeWorld");
        this.cakeAirborneOnly = new BooleanSetting("Airborne only", true, () -> mode.is("CakeWorld"));
        this.timer = new MsTimer();
        addSettings(mode, cakeAirborneOnly);
    }

    @EventTarget
    public void onTick(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (timer.finished(10000L)) {
            bots.clear();
            timer.reset();
        }

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == null || player == mc.player) {
                continue;
            }

            boolean bot = false;
            if (mode.is("ReallyWorld")) {
                bot = reallyWorldCheck(player);
            } else if (mode.is("Matrix")) {
                bot = matrixCheck(player);
            } else if (mode.is("CakeWorld")) {
                bot = cakeWorldCheck(player);
            }

            if (bot) {
                if (!bots.contains(player)) {
                    bots.add(player);
                }
            } else {
                bots.remove(player);
            }
        }
    }

    private boolean reallyWorldCheck(PlayerEntity player) {
        boolean hasBasicArmor = false;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = getArmor(player, slot);
            if (stack.isEmpty()) {
                continue;
            }

            boolean leather = stack.getItem() == Items.LEATHER_HELMET
                    || stack.getItem() == Items.LEATHER_CHESTPLATE
                    || stack.getItem() == Items.LEATHER_LEGGINGS
                    || stack.getItem() == Items.LEATHER_BOOTS;
            boolean iron = stack.getItem() == Items.IRON_HELMET
                    || stack.getItem() == Items.IRON_CHESTPLATE
                    || stack.getItem() == Items.IRON_LEGGINGS
                    || stack.getItem() == Items.IRON_BOOTS;
            if (leather || iron) {
                hasBasicArmor = true;
            }
        }

        boolean noEnchantments = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = getArmor(player, slot);
            if (!stack.isEmpty() && stack.hasEnchantments()) {
                noEnchantments = false;
                break;
            }
        }

        boolean noDamage = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = getArmor(player, slot);
            if (!stack.isEmpty() && stack.isDamaged()) {
                noDamage = false;
                break;
            }
        }

        boolean noDyedLeather = true;
        for (int slot = 0; slot < 4; slot++) {
            ItemStack stack = getArmor(player, slot);
            if (!stack.isEmpty() && isLeatherArmor(stack) && stack.contains(DataComponentTypes.DYED_COLOR)) {
                noDyedLeather = false;
                break;
            }
        }

        boolean emptyOffHand = player.getOffHandStack().isEmpty();
        boolean fullFood = player.getHungerManager().getFoodLevel() == 20;

        return hasBasicArmor && noEnchantments && noDamage && noDyedLeather && emptyOffHand && fullFood;
    }

    private boolean cakeWorldCheck(PlayerEntity player) {
        if (!isNaked(player) || !isInvisible(player)) {
            return false;
        }

        if (!cakeAirborneOnly.get()) {
            return true;
        }

        return !player.isOnGround()
                && !player.isTouchingWater()
                && !player.isClimbing()
                && !player.hasVehicle()
                && !player.isGliding();
    }

    private boolean matrixCheck(PlayerEntity player) {
        if (player.getUuid().version() == 2) {
            return true;
        }

        if (mc.getNetworkHandler() == null || player.age < 20) {
            return false;
        }

        PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
        if (entry == null) {
            return true;
        }

        if (mc.player == null) {
            return false;
        }

        String localName = mc.player.getName().getString();
        UUID localOffline = UUID.nameUUIDFromBytes(("OfflinePlayer:" + localName).getBytes(StandardCharsets.UTF_8));
        if (!mc.player.getUuid().equals(localOffline)) {
            return false;
        }

        String name = player.getName().getString();
        UUID offlineUuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
        return !player.getUuid().equals(offlineUuid);
    }

    private boolean isNaked(PlayerEntity player) {
        return player.getArmor() == 0;
    }

    private boolean isInvisible(PlayerEntity player) {
        return player.isInvisible() || player.hasStatusEffect(StatusEffects.INVISIBILITY);
    }

    private boolean isLeatherArmor(ItemStack stack) {
        return stack.getItem() == Items.LEATHER_HELMET
                || stack.getItem() == Items.LEATHER_CHESTPLATE
                || stack.getItem() == Items.LEATHER_LEGGINGS
                || stack.getItem() == Items.LEATHER_BOOTS;
    }

    private ItemStack getArmor(PlayerEntity entity, int slot) {
        return entity.getInventory().getArmorStack(slot);
    }

    public static boolean isBot(PlayerEntity player) {
        return INSTANCE.isEnabled() && bots.contains(player);
    }

    @Override
    public void onEnable() {
        super.onEnable();
        bots.clear();
    }

    @Override
    public void onDisable() {
        bots.clear();
        super.onDisable();
    }
}
