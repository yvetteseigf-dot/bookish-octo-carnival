package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import sky.config.BooleanSetting;
import sky.camera.FreeLookCamera;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.FreeLookUtil;
import sky.util.entity.PlayerUtil;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class AutoPotion extends Module {
    private static final int THROW_COOLDOWN_TICKS = 15;
    private static final int BUSY_TICKS = 4;

    public static final AutoPotion INSTANCE = new AutoPotion();

    private final BooleanSetting strength;
    private final BooleanSetting speed;
    private final BooleanSetting fireResistance;
    private final BooleanSetting healing;
    private final NumberSetting healHealth;

    private int throwCooldown;
    private int busyTicks;

    private AutoPotion() {
        super("AutoPotion", "Throws selected potions under you after a buff expires / at low HP", Category.COMBAT);
        this.strength = new BooleanSetting("Strength potion", true);
        this.speed = new BooleanSetting("Speed potion", true);
        this.fireResistance = new BooleanSetting("Fire resistance potion", true);
        this.healing = new BooleanSetting("Healing potion", true);
        this.healHealth = new NumberSetting("Heal until", 14.0F, 1.0F, 20.0F, 0.5F, this.healing::isEnabled);
        addSettings(this.strength, this.speed, this.fireResistance, this.healing, this.healHealth);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            return;
        }

        if (mc.currentScreen != null || mc.player.isSpectator() || !mc.player.isAlive()) {
            return;
        }

        if (busyTicks > 0) {
            busyTicks--;
        }

        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
            busyTicks = 0;
            return;
        }

        if (throwCooldown > 0) {
            throwCooldown--;
            return;
        }

        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.isBusy()) {
            return;
        }

        List<RegistryEntry<StatusEffect>> needed = collectNeededPotions();
        if (needed.isEmpty()) {
            return;
        }

        throwAllUnderSelf(needed);
        busyTicks = BUSY_TICKS;
        throwCooldown = THROW_COOLDOWN_TICKS;
    }

    @Override
    protected void onDisable() {
        throwCooldown = 0;
        busyTicks = 0;
        super.onDisable();
    }

    public boolean isBusy() {
        if (!isEnabled() || busyTicks <= 0) {
            return false;
        }
        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
            return false;
        }
        return true;
    }

    private void throwAllUnderSelf(List<RegistryEntry<StatusEffect>> effects) {
        boolean auraTargeting = AttackAura.INSTANCE.isEnabled() && AttackAura.INSTANCE.getTarget() != null;
        boolean freeLook = FreeLookCamera.isActive() || auraTargeting;

        float restoreYaw;
        float restorePitch;
        if (freeLook) {
            restoreYaw = FreeLookCamera.getFreeYaw();
            restorePitch = FreeLookCamera.getFreePitch();
        } else {
            restoreYaw = mc.player.getYaw();
            restorePitch = mc.player.getPitch();
        }

        float yaw = mc.player.getYaw();
        boolean onGround = mc.player.isOnGround();
        boolean horizontalCollision = mc.player.horizontalCollision;

        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                mc.player.getX(), mc.player.getY(), mc.player.getZ(), yaw, 90.0F, onGround, horizontalCollision));

        Set<Integer> usedSlots = new HashSet<>();
        for (RegistryEntry<StatusEffect> effect : effects) {
            if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
                break;
            }

            int hotbarSlot = findSplashPotion(effect, true, usedSlots);
            int invSlot = hotbarSlot == -1 ? findSplashPotion(effect, false, usedSlots) : -1;
            if (hotbarSlot == -1 && invSlot == -1) {
                continue;
            }

            findAndThrowPotion(hotbarSlot, invSlot);
            if (hotbarSlot != -1) {
                usedSlots.add(hotbarSlot);
            } else {
                usedSlots.add(invSlot);
            }
        }

        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                mc.player.getX(), mc.player.getY(), mc.player.getZ(), yaw, restorePitch, onGround,
                horizontalCollision));

        if (auraTargeting || freeLook) {
            RotationManager.instance.stopRotation();
            FreeLookCamera.setActive(true);
            FreeLookCamera.setFreeYaw(restoreYaw);
            FreeLookCamera.setFreePitch(restorePitch);
            FreeLookUtil.snapToFreeLook();
        }
    }

    private void findAndThrowPotion(int hotbarSlot, int invSlot) {
        int selectedSlot = mc.player.getInventory().selectedSlot;

        if (hotbarSlot != -1) {
            if (hotbarSlot != selectedSlot) {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
            }
            useItem(Hand.MAIN_HAND);
            if (hotbarSlot != selectedSlot) {
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(selectedSlot));
            }
            return;
        }

        if (invSlot == -1) {
            return;
        }

        int syncId = mc.player.currentScreenHandler.syncId;
        int screenSlot = invSlot < 9 ? invSlot + 36 : invSlot;
        mc.interactionManager.clickSlot(syncId, screenSlot, selectedSlot, SlotActionType.SWAP, mc.player);
        useItem(Hand.MAIN_HAND);
        mc.interactionManager.clickSlot(syncId, screenSlot, selectedSlot, SlotActionType.SWAP, mc.player);
    }

    private List<RegistryEntry<StatusEffect>> collectNeededPotions() {
        List<RegistryEntry<StatusEffect>> needed = new ArrayList<>();

        if (strength.isEnabled() && !mc.player.hasStatusEffect(StatusEffects.STRENGTH)
                && hasSplashPotion(StatusEffects.STRENGTH)) {
            needed.add(StatusEffects.STRENGTH);
        }

        if (speed.isEnabled() && !mc.player.hasStatusEffect(StatusEffects.SPEED)
                && hasSplashPotion(StatusEffects.SPEED)) {
            needed.add(StatusEffects.SPEED);
        }

        if (fireResistance.isEnabled() && !mc.player.hasStatusEffect(StatusEffects.FIRE_RESISTANCE)
                && hasSplashPotion(StatusEffects.FIRE_RESISTANCE)) {
            needed.add(StatusEffects.FIRE_RESISTANCE);
        }

        if (healing.isEnabled() && needsHealing() && hasSplashPotion(StatusEffects.INSTANT_HEALTH)) {
            needed.add(StatusEffects.INSTANT_HEALTH);
        }

        return needed;
    }

    private boolean hasSplashPotion(RegistryEntry<StatusEffect> effect) {
        return findSplashPotion(effect, true, null) != -1 || findSplashPotion(effect, false, null) != -1;
    }

    private int findSplashPotion(RegistryEntry<StatusEffect> effect, boolean hotbarOnly, Set<Integer> usedSlots) {
        int from = hotbarOnly ? 0 : 9;
        int to = hotbarOnly ? 9 : 36;

        for (int slot = from; slot < to; slot++) {
            if (usedSlots != null && usedSlots.contains(slot)) {
                continue;
            }
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (isSplashWithEffect(stack, effect)) {
                return slot;
            }
        }

        return -1;
    }

    private boolean isSplashWithEffect(ItemStack stack, RegistryEntry<StatusEffect> effect) {
        if (stack.isEmpty() || !stack.isOf(Items.SPLASH_POTION)) {
            return false;
        }

        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) {
            return false;
        }

        for (StatusEffectInstance instance : contents.getEffects()) {
            if (instance.getEffectType().equals(effect)) {
                return true;
            }
        }

        return false;
    }

    private boolean needsHealing() {
        float health = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        return health <= healHealth.getCurrent();
    }

    private void useItem(Hand hand) {
        PlayerUtil.sendSequencedPacket(
                sequence -> new PlayerInteractItemC2SPacket(hand, sequence, mc.player.getYaw(), 90.0F));
    }
}
