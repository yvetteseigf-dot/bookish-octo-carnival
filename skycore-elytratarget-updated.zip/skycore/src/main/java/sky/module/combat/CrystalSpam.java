package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;
import sky.config.BooleanSetting;
import sky.config.KeybindSetting;
import sky.session.SilentPacketUtil;
import sky.event.player.PlayerUpdateEvent;
import sky.event.combat.AttackEntityEvent;
import sky.module.Category;
import sky.module.Module;
import sky.config.Bind;

public final class CrystalSpam extends Module {
    public static final CrystalSpam INSTANCE = new CrystalSpam();
    public static boolean Rabotaet;

    private final KeybindSetting bind;
    private final BooleanSetting test;

    private boolean wasPressed;
    private int previousSlot;

    private CrystalSpam() {
        super("CrystalSpam", "Spams crystals", Category.COMBAT);
        this.bind = new KeybindSetting("Bind");
        this.test = new BooleanSetting("Remove delay", false);
        this.previousSlot = -1;
        addSettings(bind, test);
    }

    @Override
    public void onDisable() {
        Rabotaet = false;
        restoreSlot();
        super.onDisable();
    }

    @EventTarget
    private void update(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            Rabotaet = false;
            return;
        }

        int keyCode = bind.getKeyCode();
        if (keyCode == -1) {
            Rabotaet = false;
            return;
        }

        long handle = mc.getWindow().getHandle();
        boolean pressed = keyCode <= GLFW.GLFW_MOUSE_BUTTON_LAST
                ? GLFW.glfwGetMouseButton(handle, keyCode) == GLFW.GLFW_PRESS
                : GLFW.glfwGetKey(handle, keyCode) == GLFW.GLFW_PRESS;
        Rabotaet = pressed;

        if (!pressed) {
            if (wasPressed) {
                restoreSlot();
                wasPressed = false;
            }
            return;
        }

        if (!wasPressed) {
            previousSlot = mc.player.getInventory().selectedSlot;
            wasPressed = true;
        }

        if (mc.currentScreen != null) {
            return;
        }

        handleCrystalLogic();
    }

    @EventTarget
    private void onAttack(AttackEntityEvent event) {
        if (test.get()) {
            Entity target = event.getTarget();
            if (target instanceof EndCrystalEntity crystal) {
                crystal.discard();
            }
        }
    }

    private void handleCrystalLogic() {
        HitResult crosshair = mc.crosshairTarget;
        if (crosshair instanceof EntityHitResult entityHit) {
            Entity entity = entityHit.getEntity();
            if (entity instanceof EndCrystalEntity crystal) {
                attackCrystal(crystal);
                return;
            }
        }

        HitResult blockTarget = mc.crosshairTarget;
        if (blockTarget instanceof BlockHitResult blockHit) {
            BlockPos pos = blockHit.getBlockPos();
            if (mc.world.getBlockState(pos).getBlock() == Blocks.OBSIDIAN) {
                int crystalSlot = getHotbarSlotWithCrystal();
                if (crystalSlot != -1) {
                    switchToSlot(crystalSlot);
                    placeCrystalOn(obsidianTopPos(pos));
                    explodeCrystalsNear(obsidianTopPos(pos));
                }
            }
        }
    }

    private int getHotbarSlotWithCrystal() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() == Items.END_CRYSTAL) {
                return slot;
            }
        }
        return -1;
    }

    private void placeCrystalOn(BlockPos placePos) {
        BlockPos obsidianPos = placePos.down();
        if (!mc.world.getBlockState(placePos).isAir()) {
            return;
        }

        Box crystalBox = new Box(
                placePos.getX(),
                placePos.getY(),
                placePos.getZ(),
                placePos.getX() + 1.0,
                placePos.getY() + 2.0,
                placePos.getZ() + 1.0);
        if (!mc.world.getOtherEntities(null, crystalBox).isEmpty()) {
            return;
        }

        Vec3d hitPos = new Vec3d(
                obsidianPos.getX() + 0.5,
                obsidianPos.getY() + 0.5,
                obsidianPos.getZ() + 0.5);
        BlockHitResult hit = new BlockHitResult(hitPos, Direction.UP, obsidianPos, false);
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        if (result == ActionResult.SUCCESS || result.isAccepted()) {
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void explodeCrystalsNear(BlockPos placePos) {
        Box searchBox = new Box(
                placePos.getX() - 4.5,
                placePos.getY() - 2.0,
                placePos.getZ() - 4.5,
                placePos.getX() + 1.0 + 4.5,
                placePos.getY() + 2.0 + 4.5,
                placePos.getZ() + 1.0 + 4.5);
        for (Entity entity : mc.world.getOtherEntities(null, searchBox)) {
            if (!(entity instanceof EndCrystalEntity crystal)) {
                continue;
            }
            if (mc.player.distanceTo(crystal) > 4.5F) {
                continue;
            }
            if (mc.getNetworkHandler() != null) {
                SilentPacketUtil.sendPacket(PlayerInteractEntityC2SPacket.attack(crystal, mc.player.isSneaking()));
            } else {
                mc.interactionManager.attackEntity(mc.player, crystal);
            }
            mc.player.swingHand(Hand.MAIN_HAND);
        }
    }

    private void switchToSlot(int hotbarSlot) {
        if (hotbarSlot < 0 || hotbarSlot > 8) {
            return;
        }
        if (mc.player.getInventory().selectedSlot == hotbarSlot) {
            return;
        }
        mc.player.getInventory().selectedSlot = hotbarSlot;
        if (mc.getNetworkHandler() != null) {
            SilentPacketUtil.sendPacket(new UpdateSelectedSlotC2SPacket(hotbarSlot));
        }
    }

    private void attackCrystal(Entity entity) {
        if (mc.getNetworkHandler() != null) {
            SilentPacketUtil.sendPacket(PlayerInteractEntityC2SPacket.attack(entity, mc.player.isSneaking()));
        } else {
            mc.interactionManager.attackEntity(mc.player, entity);
        }
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private void restoreSlot() {
        if (previousSlot < 0 || previousSlot > 8) {
            previousSlot = -1;
            return;
        }
        switchToSlot(previousSlot);
        previousSlot = -1;
    }

    private BlockPos obsidianTopPos(BlockPos obsidianPos) {
        return obsidianPos.up();
    }
}
