package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import sky.session.SilentPacketUtil;
import sky.event.network.PacketSendEvent;
import sky.mixin.network.PlayerInteractEntityC2SPacketMixin;
import sky.module.Category;
import sky.module.Module;
import sky.util.math.MathUtil;
import sky.util.entity.PlayerUtil;

public final class Criticals extends Module {
    public static final Criticals INSTANCE = new Criticals();

    private Criticals() {
        super("Criticals", "Deals a critical hit to the opponent in cobweb", Category.COMBAT);
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (!isEnabled() || !event.isSend() || mc.player == null || mc.world == null) {
            return;
        }

        if (!(event.getPacket() instanceof PlayerInteractEntityC2SPacket packet)) {
            return;
        }

        PlayerInteractEntityC2SPacketMixin mixin = (PlayerInteractEntityC2SPacketMixin) packet;
        if (mixin.skycore$getTypeHandler()
                != ((PlayerInteractEntityC2SPacketMixin) PlayerInteractEntityC2SPacket.attack(mc.player, false))
                        .skycore$getTypeHandler()) {
            return;
        }

        if (mc.player.isGliding()) {
            return;
        }

        Entity entity = mc.world.getEntityById(mixin.skycore$getEntityId());
        if (entity == null || entity instanceof EndCrystalEntity) {
            return;
        }

        AttackAura aura = AttackAura.INSTANCE;
        Entity auraTarget = aura.getTarget();
        if (!aura.isEnabled() || entity != auraTarget) {
            return;
        }

        if (!PlayerUtil.isPlayerInWeb()) {
            return;
        }

        float offset = MathUtil.randomizeFloat(1.0E-7F, 1.0E-6F);
        mc.player.fallDistance = offset;
        SilentPacketUtil.sendSilentPacket(new PlayerMoveC2SPacket.Full(
                mc.player.getX(),
                mc.player.getY() - offset,
                mc.player.getZ(),
                AttackAura.INSTANCE.lastYaw,
                AttackAura.INSTANCE.lastPitch,
                false,
                mc.player.horizontalCollision));
    }
}
