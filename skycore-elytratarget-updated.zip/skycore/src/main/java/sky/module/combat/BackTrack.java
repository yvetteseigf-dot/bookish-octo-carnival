package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionSyncS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.HealthUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldEventS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.NumberSetting;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.combat.AttackEntityEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.render.WorldDrawHelper;

import java.util.concurrent.ConcurrentLinkedQueue;

public final class BackTrack extends Module {
    public static final BackTrack INSTANCE = new BackTrack();

    private final NumberSetting distance;
    private final NumberSetting delay;
    private final NumberSetting holdTime;
    private final NumberSetting afterAttack;
    private final BooleanSetting renderBox;
    private final ConcurrentLinkedQueue<DelayedPacket> inboundQueue;
    private final ConcurrentLinkedQueue<Packet<?>> releaseQueue;

    private Entity target;
    private Vec3d trackedPos;
    private long lastTargetSeen;
    private long lastAttackTime;
    private int releaseDelayMs;

    private BackTrack() {
        super("BackTrack", "Delays the target's position packets to increase hit range", Category.COMBAT);
        this.distance = new NumberSetting("Target distance", 3.0F, 1.0F, 10.0F, 1.0F);
        this.delay = new NumberSetting("Packet delay (ms)", 150.0F, 10.0F, 1000.0F, 10.0F);
        this.holdTime = new NumberSetting("Remember target (ms)", 500.0F, 0.0F, 2000.0F, 50.0F);
        this.afterAttack = new NumberSetting("Work after hit (ms)", 1000.0F, 0.0F, 5000.0F, 50.0F);
        this.renderBox = new BooleanSetting("Show position", true);
        this.inboundQueue = new ConcurrentLinkedQueue<>();
        this.releaseQueue = new ConcurrentLinkedQueue<>();
        addSettings(this.distance, this.delay, this.holdTime, this.afterAttack, this.renderBox);
    }

    @EventTarget
    public void onAttack(AttackEntityEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        Entity attacked = event.getTarget();
        if (isValidTarget(attacked)) {
            lastAttackTime = System.currentTimeMillis();
            if (attacked != target) {
                reset(false);
                trackedPos = attacked.getPos();
            }
            target = attacked;
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (mc.player == null || mc.world == null || !event.isReceive() || event.isCancelled()) {
            return;
        }

        if (inboundQueue.isEmpty() && !isActive()) {
            return;
        }

        Packet<?> packet = event.getPacket();

        if (packet instanceof PlaySoundS2CPacket soundPacket
                && soundPacket.getSound().value() == SoundEvents.ENTITY_PLAYER_HURT) {
            return;
        }

        if (packet instanceof WorldEventS2CPacket || packet instanceof HealthUpdateS2CPacket) {
            return;
        }

        if (target != null && packetEntityId(packet) == target.getId()) {
            if (packet instanceof EntityPositionS2CPacket
                    || packet instanceof EntityPositionSyncS2CPacket
                    || packet instanceof EntityS2CPacket
                    || packet instanceof EntityVelocityUpdateS2CPacket) {
                updateTrackedPos(target.getPos());
            } else if (packet instanceof EntityDamageS2CPacket) {
                release(true);
                return;
            }
        }

        if (shouldDelay(packet)) {
            event.setCancelled(true);
            inboundQueue.add(new DelayedPacket(packet, System.currentTimeMillis()));
        }
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null) {
            reset(true);
            return;
        }

        if (isActive()) {
            releaseExpired(false);
        } else {
            reset(false);
        }

        Packet<?> packet;
        while ((packet = releaseQueue.poll()) != null) {
            applyPacket(packet);
        }

        if (inboundQueue.isEmpty() && releaseQueue.isEmpty()) {
            releaseDelayMs = delay.get().intValue();
        }
    }

    @EventTarget
    public void onRender3D(RenderWorldEvent event) {
        if (!renderBox.isEnabled() || target == null || trackedPos == null || mc.player == null) {
            return;
        }

        double halfWidth = target.getWidth() / 2.0D;
        Box box = new Box(
                trackedPos.x - halfWidth,
                trackedPos.y,
                trackedPos.z - halfWidth,
                trackedPos.x + halfWidth,
                trackedPos.y + target.getHeight(),
                trackedPos.z + halfWidth);
        WorldDrawHelper.drawBox(box, 0x5A78B4FF, 2.0F, true, true, false);
    }

    @Override
    public void onDisable() {
        reset(true);
        super.onDisable();
    }

    private boolean isActive() {
        if (target == null || !target.isAlive()) {
            return false;
        }

        double distanceToTarget = target.distanceTo(mc.player);
        boolean inRange = distanceToTarget <= distance.get();
        if (inRange) {
            lastTargetSeen = System.currentTimeMillis();
        }

        boolean stillRemembered = System.currentTimeMillis() - lastTargetSeen < holdTime.get().longValue();
        boolean recentlyAttacked = System.currentTimeMillis() - lastAttackTime < afterAttack.get().longValue();
        return (inRange || stillRemembered) && target.age > 10 && recentlyAttacked;
    }

    private boolean isValidTarget(Entity entity) {
        if (entity == null || entity == mc.player || !(entity instanceof LivingEntity living)) {
            return false;
        }
        return living.isAlive() && entity.distanceTo(mc.player) <= distance.get();
    }

    private boolean shouldDelay(Packet<?> packet) {
        if (!isMovementPacket(packet) || !isActive() || target == null) {
            return false;
        }
        return packetEntityId(packet) == target.getId();
    }

    private boolean isMovementPacket(Packet<?> packet) {
        return packet instanceof EntityPositionS2CPacket
                || packet instanceof EntityPositionSyncS2CPacket
                || packet instanceof EntityS2CPacket
                || packet instanceof EntityVelocityUpdateS2CPacket;
    }

    private int packetEntityId(Packet<?> packet) {
        if (packet instanceof EntityPositionS2CPacket positionPacket) {
            return positionPacket.entityId();
        }
        if (packet instanceof EntityPositionSyncS2CPacket syncPacket) {
            return syncPacket.id();
        }
        if (packet instanceof EntityVelocityUpdateS2CPacket velocityPacket) {
            return velocityPacket.getEntityId();
        }
        if (packet instanceof EntityDamageS2CPacket damagePacket) {
            return damagePacket.entityId();
        }
        if (packet instanceof EntityS2CPacket entityPacket && mc.world != null) {
            Entity entity = entityPacket.getEntity(mc.world);
            return entity != null ? entity.getId() : Integer.MIN_VALUE;
        }
        return Integer.MIN_VALUE;
    }

    private void updateTrackedPos(Vec3d pos) {
        if (pos != null) {
            trackedPos = pos;
        }
    }

    private void releaseExpired(boolean force) {
        inboundQueue.removeIf(entry -> {
            if (!force && System.currentTimeMillis() - entry.time() < releaseDelayMs) {
                return false;
            }
            releaseQueue.add(entry.packet());
            return true;
        });
    }

    private void release(boolean force) {
        releaseExpired(force);
        if (force) {
            target = null;
            trackedPos = null;
        }
    }

    private void reset(boolean forceRelease) {
        releaseExpired(true);
        if (forceRelease) {
            Packet<?> packet;
            while ((packet = releaseQueue.poll()) != null) {
                applyPacket(packet);
            }
        }
        target = null;
        trackedPos = null;
    }

    private void applyPacket(Packet<?> packet) {
        if (mc.player == null || mc.player.networkHandler == null || packet == null) {
            return;
        }
        try {
            @SuppressWarnings("unchecked")
            Packet<ClientPlayPacketListener> clientPacket = (Packet<ClientPlayPacketListener>) packet;
            clientPacket.apply(mc.player.networkHandler);
        } catch (Exception ignored) {
        }
    }

    private record DelayedPacket(Packet<?> packet, long time) {
    }
}
