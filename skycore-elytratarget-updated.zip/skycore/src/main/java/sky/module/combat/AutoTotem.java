package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.screen.slot.Slot;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.misc.MovementBlocker;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.prediction.SimulatedPlayer;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.Sprint;
import sky.util.inventory.InventoryUtil;
import sky.util.inventory.ItemSwapUtil;
import sky.util.entity.MovementUtil;

public final class AutoTotem extends Module {
    private static final double ANCHOR_RANGE = 6.0D;
    private static final String CHECK_ELYTRA = "Elytra";
    private static final String CHECK_FALL = "Fall";
    private static final String CHECK_CRYSTALS = "Crystals";
    private static final String CHECK_ANCHOR = "Anchor";

    public static final AutoTotem INSTANCE = new AutoTotem();

    private final NumberSetting health;
    private final MultiBooleanSetting mode;
    private final NumberSetting elytraHealth;
    private final NumberSetting fallDistance;
    private final NumberSetting healthWithBall;
    private final BooleanSetting ignoreDragonidTotem;

    private int cooldownTicks;
    private ItemStack previousStack;

    private AutoTotem() {
        super("AutoTotem", "Takes a totem into the hand when conditions are met", Category.COMBAT);
        this.health = new NumberSetting("Health", 4.0F, 0.0F, 20.0F, 0.5F);
        this.mode = new MultiBooleanSetting("Checks",
                new BooleanSetting(CHECK_ELYTRA, true),
                new BooleanSetting(CHECK_FALL, true),
                new BooleanSetting(CHECK_CRYSTALS, true),
                new BooleanSetting(CHECK_ANCHOR, true));
        this.ignoreDragonidTotem = new BooleanSetting("Don't take Dragonid totem", true);

        BooleanSetting elytraOption = this.mode.getOptions().get(0);
        BooleanSetting fallOption = this.mode.getOptions().get(1);
        BooleanSetting crystalOption = this.mode.getOptions().get(2);

        this.elytraHealth = new NumberSetting("Elytra health", 10.0F, 0.0F, 20.0F, 0.5F,
                elytraOption::isEnabled);
        this.fallDistance = new NumberSetting("Block count", 20.0F, 10.0F, 50.0F, 0.1F,
                fallOption::isEnabled);
        this.healthWithBall = new NumberSetting("Health with head", 10.0F, 0.0F, 20.0F, 0.5F,
                crystalOption::isEnabled);

        this.cooldownTicks = 0;
        this.previousStack = null;
        addSettings(this.health, this.mode, this.elytraHealth, this.fallDistance, this.healthWithBall,
                this.ignoreDragonidTotem);
    }

    @EventTarget
    public void onPlayerTick(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }

        if (cooldownTicks > 0) {
            cooldownTicks--;
        }

        ItemStack offHandStack = mc.player.getOffHandStack().isEmpty() ? null : mc.player.getOffHandStack();

        if (shouldUseTotem()) {
            if (offHandStack == null || !isUsableTotem(offHandStack)) {
                Slot slot = findTotemSlot();
                if (slot != null && !InventoryUtil.isServerScreen()) {
                    if (previousStack == null || previousStack.isEmpty()) {
                        previousStack = offHandStack == null ? null : offHandStack.copy();
                    }

                    boolean stoppedSprinting = false;
                    if (mc.player.isSprinting()) {
                        mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(
                                new PlayerInput(false, false, false, false, false, false, false)));
                        mc.player.setSprinting(false);
                        mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                                ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                        if (!Sprint.INSTANCE.isEnabled()) {
                            mc.options.sprintKey.setPressed(false);
                        }
                        stoppedSprinting = true;
                    }

                    swapToOffhand(slot);

                    if (stoppedSprinting) {
                        mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
                    }

                    cooldownTicks = 3;
                }
            }
        } else if (previousStack != null && cooldownTicks == 0 && !previousStack.isEmpty()) {
            Slot slot = findRestoreSlot();
            if (slot != null) {
                boolean stoppedSprinting = false;
                if (mc.player.isSprinting()) {
                    mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(
                            new PlayerInput(false, false, false, false, false, false, false)));
                    mc.player.setSprinting(false);
                    mc.getNetworkHandler().sendPacket(new ClientCommandC2SPacket(mc.player,
                            ClientCommandC2SPacket.Mode.STOP_SPRINTING));
                    if (!Sprint.INSTANCE.isEnabled()) {
                        mc.options.sprintKey.setPressed(false);
                    }
                    stoppedSprinting = true;
                }

                swapToOffhand(slot);

                if (stoppedSprinting) {
                    mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
                }

                cooldownTicks = 3;
                previousStack = null;
            }
        }
    }

    @EventTarget
    private void onPacket(PacketSendEvent e) {
        if (e.isSent()) {
            return;
        }

        Packet<?> packet = e.getPacket();
        if (packet instanceof EntityStatusS2CPacket statusPacket && statusPacket.getStatus() == 35) {
            if (mc.world == null || mc.player == null) {
                return;
            }
            if (statusPacket.getEntity(mc.world) != mc.player) {
                return;
            }
            cooldownTicks = 5;
        }
    }

    public boolean needsTotem() {
        if (!isEnabled() || mc.player == null) {
            return false;
        }

        if (!shouldUseTotem()) {
            return false;
        }

        ItemStack offHandStack = mc.player.getOffHandStack();
        return !isUsableTotem(offHandStack);
    }

    public boolean isBusy() {
        return isEnabled() && (cooldownTicks > 0 || needsTotem());
    }

    private boolean shouldUseTotem() {
        if (mc.player.isInCreativeMode() || mc.player.isSpectator()) {
            return false;
        }

        float effectiveHealth = mc.player.getHealth() + mc.player.getAbsorptionAmount();
        if (effectiveHealth <= health.getCurrent()) {
            return true;
        }

        if (mode.is(CHECK_FALL) && mc.player.fallDistance >= fallDistance.getCurrent() && !mc.player.isGliding()) {
            return true;
        }

        if (mode.is(CHECK_ELYTRA) && isWearingElytra() && mc.player.getHealth() <= elytraHealth.getCurrent()) {
            return true;
        }

        if (mode.is(CHECK_CRYSTALS) && hasNearbyCrystalThreat()) {
            return true;
        }

        return mode.is(CHECK_ANCHOR) && hasNearbyChargedAnchor();
    }

    private boolean hasNearbyCrystalThreat() {
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof EndCrystalEntity crystal)) {
                continue;
            }

            if (mc.player.getEyePos().distanceTo(crystal.getBoundingBox().getCenter()) > 5.0D) {
                continue;
            }

            if (mc.player.getY() < crystal.getY()
                    && SimulatedPlayer.simulateLocalPlayer(1).pos.getY() < crystal.getY()) {
                continue;
            }

            if (isEnchantedBallInOffhand() && mc.player.getHealth() > healthWithBall.getCurrent()) {
                continue;
            }

            return true;
        }

        return false;
    }

    private boolean hasNearbyChargedAnchor() {
        BlockPos origin = mc.player.getBlockPos();
        int radius = (int) Math.ceil(ANCHOR_RANGE);
        Vec3d eyePos = mc.player.getEyePos();

        for (int offsetX = -radius; offsetX <= radius; offsetX++) {
            for (int offsetY = -radius; offsetY <= radius; offsetY++) {
                for (int offsetZ = -radius; offsetZ <= radius; offsetZ++) {
                    BlockPos pos = origin.add(offsetX, offsetY, offsetZ);
                    BlockState state = mc.world.getBlockState(pos);
                    if (!state.isOf(Blocks.RESPAWN_ANCHOR)) {
                        continue;
                    }
                    if (state.get(RespawnAnchorBlock.CHARGES) <= 0) {
                        continue;
                    }
                    if (eyePos.squaredDistanceTo(Vec3d.ofCenter(pos)) <= ANCHOR_RANGE * ANCHOR_RANGE) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private boolean isWearingElytra() {
        return mc.player.getInventory().getArmorStack(2).getItem() == Items.ELYTRA;
    }

    private boolean isEnchantedBallInOffhand() {
        return ItemSwapUtil.isBall(mc.player.getOffHandStack());
    }

    private boolean isUsableTotem(ItemStack stack) {
        return !stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING) && !isDragonidTotem(stack);
    }

    private boolean isDragonidTotem(ItemStack stack) {
        if (!ignoreDragonidTotem.isEnabled() || stack.isEmpty() || !stack.isOf(Items.TOTEM_OF_UNDYING)) {
            return false;
        }
        return stack.getName().getString().contains("Тотем Драконида");
    }

    private Slot findTotemSlot() {
        return InventoryUtil.getSlot(Items.TOTEM_OF_UNDYING, slot ->
                slot.id != 45
                        && slot.inventory == mc.player.getInventory()
                        && isUsableTotem(slot.getStack()));
    }

    private Slot findRestoreSlot() {
        if (previousStack == null || previousStack.isEmpty()) {
            return null;
        }

        if (ItemSwapUtil.isBall(previousStack)) {
            Slot slot = InventoryUtil.getSlot(previousStack, candidate -> candidate.id != 45);
            if (slot != null && slot.id != 45) {
                return slot;
            }
            return ItemSwapUtil.findBallSlot();
        }

        return InventoryUtil.getSlot(previousStack, slot -> slot.id != 45);
    }

    private void swapToOffhand(Slot slot) {
        if (MovementUtil.hasPlayerMovement()) {
            MovementBlocker.stopTicks = 3;
        }
        ItemSwapUtil.swapToOffHand(slot);
        InventoryUtil.closeScreen(true);
    }
}
