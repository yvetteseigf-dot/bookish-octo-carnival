package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.SkyInit;
import sky.config.BooleanSetting;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.event.network.PacketSendEvent;
import sky.event.network.EntitySpawnEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.render.WorldDrawHelper;
import sky.util.combat.AttackPacketUtil;
import sky.util.entity.EntityVectorUtil;
import sky.util.inventory.ItemSwapUtil;
import sky.util.MsTimer;
import sky.util.combat.Rotation;

public final class CrystalAura extends Module {
    private static final String TARGET_NAKED = "Naked";
    private static final String TARGET_PLAYERS = "Players";
    private static final float ROTATE_ANGLE = 5.0F;

    public static final CrystalAura INSTANCE = new CrystalAura();

    private final NumberSetting targetRange;
    private final NumberSetting placeRange;
    private final NumberSetting minSelfDistance;
    private final NumberSetting scanRadius;
    private final NumberSetting placeDelay;
    private final BooleanSetting fast;
    private final BooleanSetting autoObsidian;
    private final BooleanSetting autoMine;
    private final BooleanSetting render;
    private final BooleanSetting noExplodeResources;
    private final MultiBooleanSetting targets;
    private final MsTimer placeTimer;
    private final ConcurrentLinkedQueue<RenderBlock> renderBlocks;

    private BlockPos currentTarget;
    private int pendingCrystalId;
    private Box crystalArea;
    private BlockPos pendingObsidianPos;
    private CrystalTarget pendingTarget;
    private int pendingObsidianTicks;
    private int pendingCrystalTicks;
    private Vec3d pendingCrystalPos;

    private CrystalAura() {
        super("CrystalAura", "Automatically places and explodes crystals on targets", Category.COMBAT);
        this.targetRange = new NumberSetting("Target distance", 6.0F, 3.0F, 12.0F, 0.5F);
        this.placeRange = new NumberSetting("Place distance", 6.0F, 2.0F, 6.0F, 0.1F);
        this.minSelfDistance = new NumberSetting("Min self distance", 4.5F, 1.0F, 6.0F, 0.1F);
        this.scanRadius = new NumberSetting("Search radius", 5.0F, 2.0F, 8.0F, 0.5F);
        this.placeDelay = new NumberSetting("Delay", 0.0F, 0.0F, 500.0F, 10.0F);
        this.fast = new BooleanSetting("Fast explode", true);
        this.autoObsidian = new BooleanSetting("Place obsidian", true);
        this.autoMine = new BooleanSetting("Mine under", true);
        this.render = new BooleanSetting("Render", true);
        this.noExplodeResources = new BooleanSetting("Don't explode resources", false);
        this.targets = MultiBooleanSetting.create("Targets", List.of(TARGET_PLAYERS, TARGET_NAKED));
        this.placeTimer = new MsTimer();
        this.renderBlocks = new ConcurrentLinkedQueue<>();
        this.pendingCrystalId = -1;
        addSettings(targetRange, placeRange, minSelfDistance, scanRadius, placeDelay, fast, autoObsidian,
                autoMine, render, noExplodeResources, targets);
    }

    @Override
    public void onDisable() {
        clearState();
        renderBlocks.clear();
        super.onDisable();
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            return;
        }

        if (mc.player.isSpectator() || CrystalSpam.Rabotaet) {
            return;
        }

        tryAttackPendingCrystal();
        if (crystalArea != null) {
            attackCrystalInArea();
        }
        attackSafeCrystalsNearTarget();

        if (pendingObsidianPos != null) {
            LivingEntity target = findTarget();
            if (target != null && canPlaceCrystalOnObsidian(pendingObsidianPos, target)) {
                pendingTarget = checkPosition(pendingObsidianPos, target);
                pendingObsidianPos = null;
                pendingObsidianTicks = 0;
            } else if (--pendingObsidianTicks <= 0) {
                pendingObsidianPos = null;
            }
            return;
        }

        if (!placeTimer.finished((long) placeDelay.getCurrent())) {
            return;
        }

        int crystalSlot = findHotbarSlot(Items.END_CRYSTAL);
        if (crystalSlot == -1) {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            pendingTarget = null;
            currentTarget = null;
            return;
        }

        CrystalTarget placement = pendingTarget;
        if (placement == null || !isValidCrystalPos(placement.obsidianPos(), target)) {
            placement = findCrystalPosition(target);
            pendingTarget = placement;
        }

        if (placement == null) {
            tryMineUnderTarget(target);
            return;
        }

        if (!rotateTo(placement.hitVec())) {
            return;
        }

        int previousSlot = mc.player.getInventory().selectedSlot;
        ItemSwapUtil.switchToHotbarSlot(crystalSlot);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, placement.hitResult());
        mc.player.swingHand(Hand.MAIN_HAND);
        ItemSwapUtil.switchToHotbarSlot(previousSlot);

        scheduleCrystalExplosion(placement.obsidianPos());
        currentTarget = placement.obsidianPos();
        addRenderBlock(placement.obsidianPos());
        placeTimer.reset();
        pendingTarget = null;
    }

    @EventTarget
    private void onPacket(PacketSendEvent event) {
        if (!event.isReceive() || !(event.getPacket() instanceof EntitySpawnS2CPacket spawn)) {
            return;
        }

        if (spawn.getEntityType() != EntityType.END_CRYSTAL || crystalArea == null || mc.world == null) {
            return;
        }

        double x = spawn.getX();
        double y = spawn.getY();
        double z = spawn.getZ();
        if (!crystalArea.expand(0.5).contains(x, y, z)) {
            return;
        }

        if (fast.get()) {
            pendingCrystalId = spawn.getEntityId();
            pendingCrystalPos = new Vec3d(x, y, z);
            pendingCrystalTicks = 8;
            tryAttackPendingCrystal();

            Entity spawned = mc.world.getEntityById(spawn.getEntityId());
            if (spawned instanceof EndCrystalEntity crystal && !shouldNotExplodeBecauseOfResources(crystal)) {
                rotateToCrystal(crystal);
                attackCrystal(crystal);
                clearExplosionState();
            }
        } else {
            attackCrystalInArea();
        }
    }

    @EventTarget
    private void onSpawnEntity(EntitySpawnEvent event) {
        if (!fast.get() || crystalArea == null || mc.world == null) {
            return;
        }

        Entity spawned = event.getEntity();
        if (!(spawned instanceof EndCrystalEntity crystal)) {
            return;
        }

        if (!crystalArea.expand(0.5).contains(crystal.getX(), crystal.getY(), crystal.getZ())) {
            return;
        }

        if (shouldNotExplodeBecauseOfResources(crystal)) {
            clearExplosionState();
            return;
        }

        pendingCrystalId = crystal.getId();
        pendingCrystalPos = crystal.getPos();
        pendingCrystalTicks = 8;
        rotateToCrystal(crystal);
        attackCrystal(crystal);
        clearExplosionState();
    }

    @EventTarget
    public void onRender3D(RenderWorldEvent event) {
        if (!render.get() || mc.player == null || mc.world == null) {
            return;
        }

        for (RenderBlock block : renderBlocks) {
            if (System.currentTimeMillis() - block.time() > 2000L) {
                renderBlocks.remove(block);
                continue;
            }

            Box box = new Box(block.pos());
            WorldDrawHelper.drawBox(box, 0x78FF5078, 1.5F, true, true, false);
        }

        if (currentTarget != null) {
            Box box = new Box(currentTarget);
            WorldDrawHelper.drawBox(box, 0xB4FF2850, 2.0F, true, true, false);
        }
    }

    private void clearState() {
        clearExplosionState();
        currentTarget = null;
        pendingTarget = null;
        pendingObsidianPos = null;
        pendingObsidianTicks = 0;
    }

    private void clearExplosionState() {
        crystalArea = null;
        pendingCrystalId = -1;
        pendingCrystalPos = null;
        pendingCrystalTicks = 0;
    }

    private void scheduleCrystalExplosion(BlockPos obsidianPos) {
        BlockPos up = obsidianPos.up();
        crystalArea = new Box(up).expand(fast.get() ? 0.5 : 0.1);
        pendingCrystalId = -1;
        pendingCrystalPos = Vec3d.ofCenter(up);
        pendingCrystalTicks = fast.get() ? 8 : 6;
        attackCrystalInArea();
    }

    private void tryAttackPendingCrystal() {
        if (pendingCrystalTicks <= 0 || mc.world == null) {
            return;
        }

        pendingCrystalTicks--;
        Entity entity = pendingCrystalId == -1 ? null : mc.world.getEntityById(pendingCrystalId);
        if (entity instanceof EndCrystalEntity crystal
                && !shouldNotExplodeBecauseOfResources(crystal)
                && isSafeToExplode(crystal)) {
            rotateToCrystal(crystal);
            attackCrystal(crystal);
            clearExplosionState();
            return;
        }

        if (pendingCrystalPos != null) {
            Box searchBox = new Box(
                    pendingCrystalPos.x - 0.8,
                    pendingCrystalPos.y - 0.8,
                    pendingCrystalPos.z - 0.8,
                    pendingCrystalPos.x + 0.8,
                    pendingCrystalPos.y + 1.8,
                    pendingCrystalPos.z + 0.8);
            for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(
                    EndCrystalEntity.class, searchBox, ignored -> true)) {
                if (shouldNotExplodeBecauseOfResources(crystal) || !isSafeToExplode(crystal)) {
                    continue;
                }

                rotateToCrystal(crystal);
                attackCrystal(crystal);
                clearExplosionState();
                return;
            }
        }
    }

    private void attackCrystalInArea() {
        if (crystalArea == null || mc.player == null || mc.world == null) {
            return;
        }

        for (EndCrystalEntity crystal : mc.world.getEntitiesByClass(
                EndCrystalEntity.class, crystalArea.expand(0.25), entity -> true)) {
            if (shouldNotExplodeBecauseOfResources(crystal) || !isSafeToExplode(crystal)) {
                continue;
            }

            rotateToCrystal(crystal);
            attackCrystal(crystal);
            clearExplosionState();
            return;
        }
    }

    private void attackSafeCrystalsNearTarget() {
        if (mc.world == null || mc.player == null) {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            return;
        }

        mc.world.getEntitiesByClass(EndCrystalEntity.class, target.getBoundingBox().expand(4.0), this::isSafeToExplode)
                .stream()
                .min(Comparator.comparingDouble(target::squaredDistanceTo))
                .ifPresent(this::attackCrystal);
    }

    private void attackCrystal(Entity entity) {
        if (entity == null || mc.player == null || !isSafeToExplode(entity)) {
            return;
        }

        AttackPacketUtil.sendFixedAttack(mc.player, entity);
    }

    private void rotateToCrystal(Entity entity) {
        if (entity == null || mc.player == null || !fast.get()) {
            return;
        }

        if (!entity.getBoundingBox().contains(mc.player.getEyePos())) {
            Vec3d vector = EntityVectorUtil.getVector(entity);
            float yaw = (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vector.z, vector.x)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(vector.y, Math.hypot(vector.x, vector.z)));
            RotationManager.update(new Rotation(yaw, pitch), 180.0F, 1, 6);
        }
    }

    private boolean rotateTo(Vec3d target) {
        Rotation rotation = Rotation.lookingAt(target, mc.player.getEyePos());
        RotationManager.update(rotation, 18.0F, 14.0F, 35.0F, 35.0F, 3, 2, false);
        Rotation current = new Rotation(mc.player.getYaw(), mc.player.getPitch());
        return current.getDelta(rotation) <= ROTATE_ANGLE;
    }

    private LivingEntity findTarget() {
        double range = targetRange.getCurrent();
        return mc.world.getEntitiesByClass(LivingEntity.class,
                        mc.player.getBoundingBox().expand(range), this::isValidTarget)
                .stream()
                .min(Comparator.comparingDouble(entity -> entity.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity instanceof ArmorStandEntity) {
            return false;
        }

        if (mc.player.squaredDistanceTo(entity) > targetRange.getCurrent() * targetRange.getCurrent()) {
            return false;
        }

        if (!(entity instanceof PlayerEntity player)) {
            return false;
        }

        if (SkyInit.getInstance().getFriendManager().isFriend(player.getName().getString())) {
            return false;
        }

        if (AntiBot.isBot(player)) {
            return false;
        }

        boolean naked = player.getInventory().armor.stream()
                .allMatch(stack -> stack == null || stack.isEmpty());
        return targets.is(TARGET_PLAYERS) || (naked && targets.is(TARGET_NAKED));
    }

    private CrystalTarget findCrystalPosition(LivingEntity target) {
        BlockPos base = target.getBlockPos();
        int radius = (int) scanRadius.getCurrent();
        CrystalTarget best = null;
        double bestDistance = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -1; dy <= 1; dy++) {
                    BlockPos pos = base.add(dx, dy, dz);
                    CrystalTarget candidate = checkPosition(pos, target);
                    double distance = target.squaredDistanceTo(Vec3d.ofCenter(pos));
                    if (candidate != null && distance < bestDistance) {
                        bestDistance = distance;
                        best = candidate;
                    }
                }
            }
        }

        if (best != null) {
            return best;
        }

        if (autoObsidian.get()) {
            return findObsidianPlacement(target);
        }

        return null;
    }

    private CrystalTarget findObsidianPlacement(LivingEntity target) {
        int obsidianSlot = findHotbarSlot(Items.OBSIDIAN);
        if (obsidianSlot == -1) {
            return null;
        }

        BlockPos base = target.getBlockPos();
        int radius = (int) scanRadius.getCurrent();
        BlockPos bestPos = null;
        Placement bestPlacement = null;
        double bestDistance = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                BlockPos pos = base.add(dx, -1, dz);
                if (!mc.world.getBlockState(pos).isReplaceable()) {
                    continue;
                }
                if (!mc.world.getBlockState(pos.up()).isAir()) {
                    continue;
                }

                double playerDistance = mc.player.getEyePos().distanceTo(Vec3d.ofCenter(pos));
                if (playerDistance > placeRange.getCurrent()) {
                    continue;
                }

                double targetDistance = target.getPos().distanceTo(Vec3d.ofCenter(pos));
                if (!isSafeForPlayer(playerDistance, targetDistance)) {
                    continue;
                }

                Placement placement = getObsidianPlacement(pos);
                if (placement == null) {
                    continue;
                }

                double distance = target.squaredDistanceTo(Vec3d.ofCenter(pos));
                if (distance < bestDistance) {
                    bestDistance = distance;
                    bestPos = pos;
                    bestPlacement = placement;
                }
            }
        }

        if (bestPos == null || bestPlacement == null || !rotateTo(bestPlacement.hit())) {
            return null;
        }

        int previousSlot = mc.player.getInventory().selectedSlot;
        ItemSwapUtil.switchToHotbarSlot(obsidianSlot);
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, bestPlacement.hitResult());
        mc.player.swingHand(Hand.MAIN_HAND);
        ItemSwapUtil.switchToHotbarSlot(previousSlot);

        pendingObsidianPos = bestPos;
        pendingObsidianTicks = 8;
        currentTarget = bestPos;
        addRenderBlock(bestPos);
        return null;
    }

    private CrystalTarget checkPosition(BlockPos obsidianPos, LivingEntity target) {
        if (!isValidCrystalPos(obsidianPos, target)) {
            return null;
        }

        Vec3d hitVec = Vec3d.ofCenter(obsidianPos).add(0.0, 0.5, 0.0);
        BlockHitResult hitResult = new BlockHitResult(hitVec, Direction.UP, obsidianPos, false);
        double distance = mc.player.getEyePos().distanceTo(hitVec);
        return new CrystalTarget(obsidianPos, hitResult, hitVec, distance);
    }

    private boolean isValidCrystalPos(BlockPos obsidianPos, LivingEntity target) {
        if (mc.world == null || mc.player == null) {
            return false;
        }

        if (!canPlaceCrystalOnObsidian(obsidianPos, target)) {
            return false;
        }

        Vec3d center = Vec3d.ofCenter(obsidianPos);
        double playerDistance = mc.player.getEyePos().distanceTo(center);
        if (playerDistance > placeRange.getCurrent()) {
            return false;
        }

        double targetDistance = target.getPos().distanceTo(center);
        if (!isSafeForPlayer(playerDistance, targetDistance)) {
            return false;
        }

        BlockPos up = obsidianPos.up();
        Box box = new Box(
                up.getX(),
                up.getY(),
                up.getZ(),
                up.getX() + 1.0,
                up.getY() + 2.0,
                up.getZ() + 1.0);
        return mc.world.getOtherEntities(target, box, entity -> !(entity instanceof ItemEntity)).isEmpty();
    }

    private boolean canPlaceCrystalOnObsidian(BlockPos obsidianPos, Entity ignoredEntity) {
        BlockState state = mc.world.getBlockState(obsidianPos);
        if (state.getBlock() != Blocks.OBSIDIAN && state.getBlock() != Blocks.BEDROCK) {
            return false;
        }

        BlockPos up = obsidianPos.up();
        BlockState above = mc.world.getBlockState(up);
        if (!above.isAir() && !above.isReplaceable()) {
            return false;
        }

        Box box = new Box(
                up.getX(),
                up.getY(),
                up.getZ(),
                up.getX() + 1.0,
                up.getY() + 2.0,
                up.getZ() + 1.0);
        return mc.world.getOtherEntities(ignoredEntity, box, entity -> !(entity instanceof ItemEntity)).isEmpty();
    }

    private Placement getObsidianPlacement(BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockPos neighbour = pos.offset(direction.getOpposite());
            if (!canClickNeighbor(neighbour)) {
                continue;
            }

            Vec3d hit = Vec3d.ofCenter(neighbour).add(Vec3d.of(direction.getVector()).multiply(0.5));
            return new Placement(new BlockHitResult(hit, direction, neighbour, false), hit);
        }

        return null;
    }

    private boolean canClickNeighbor(BlockPos pos) {
        return mc.world.isInBuildLimit(pos)
                && !mc.world.getBlockState(pos).isAir()
                && !mc.world.getBlockState(pos).isReplaceable();
    }

    private boolean isSafeToExplode(Entity crystal) {
        if (mc.player == null) {
            return false;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            return false;
        }

        Vec3d center = crystal.getBoundingBox().getCenter();
        return isSafeForPlayer(
                mc.player.getEyePos().distanceTo(center),
                target.getPos().distanceTo(center));
    }

    private boolean isSafeForPlayer(double playerDistance, double targetDistance) {
        double min = Math.max(4.5, minSelfDistance.getCurrent());
        return playerDistance >= min && targetDistance + 1.25 < playerDistance;
    }

    private boolean shouldNotExplodeBecauseOfResources(Entity crystalEntity) {
        if (!noExplodeResources.get() || mc.world == null) {
            return false;
        }

        return mc.world.getEntitiesByClass(ItemEntity.class, crystalEntity.getBoundingBox().expand(6.0), itemEntity -> true)
                .stream()
                .map(itemEntity -> itemEntity.getStack().getItem())
                .anyMatch(item -> item == Items.TOTEM_OF_UNDYING
                        || item == Items.END_CRYSTAL
                        || item == Items.ENCHANTED_GOLDEN_APPLE
                        || item == Items.NETHERITE_HELMET
                        || item == Items.NETHERITE_CHESTPLATE
                        || item == Items.NETHERITE_LEGGINGS
                        || item == Items.NETHERITE_BOOTS
                        || item == Items.NETHERITE_SWORD
                        || item == Items.DIAMOND_SWORD
                        || item == Items.ELYTRA
                        || item == Items.TRIDENT);
    }

    private void tryMineUnderTarget(LivingEntity target) {
        if (!autoMine.get() || mc.player == null || mc.world == null || mc.interactionManager == null) {
            return;
        }

        BlockPos down = target.getBlockPos().down();
        BlockState state = mc.world.getBlockState(down);
        if (state.isAir() || state.isOf(Blocks.OBSIDIAN) || state.isOf(Blocks.BEDROCK)) {
            return;
        }

        if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(down)) > placeRange.getCurrent()) {
            return;
        }

        mc.interactionManager.updateBlockBreakingProgress(down, Direction.UP);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private void addRenderBlock(BlockPos pos) {
        if (!render.get()) {
            return;
        }

        renderBlocks.add(new RenderBlock(pos, System.currentTimeMillis()));
        while (renderBlocks.size() > 32) {
            renderBlocks.poll();
        }
    }

    private int findHotbarSlot(Item item) {
        for (int slot = 0; slot < 9; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty() && stack.getItem() == item) {
                return slot;
            }
        }
        return -1;
    }

    record CrystalTarget(BlockPos obsidianPos, BlockHitResult hitResult, Vec3d hitVec, double distance) {
        public double getDistance() {
            return distance;
        }
    }

    record Placement(BlockHitResult hitResult, Vec3d hit) {
    }

    record RenderBlock(BlockPos pos, long time) {
    }
}
