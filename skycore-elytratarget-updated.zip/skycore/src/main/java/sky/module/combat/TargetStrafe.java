package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import com.darkmagician6.eventapi.Priority;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.entity.MovementFixUtil;

public final class TargetStrafe extends Module {
    private static final String MODE_COLLISION = "Collision";
    private static final String MODE_CIRCLE = "Circle";

    public static final TargetStrafe INSTANCE = new TargetStrafe();

    private final ModeSetting mode;
    private final BooleanSetting predict;
    private final NumberSetting predictStrength;
    private final NumberSetting radius;
    private final NumberSetting strength;

    private Vec3d predictedPos;

    private TargetStrafe() {
        super("TargetStrafe", "Automatically circles the Aura target for better hits", Category.COMBAT);
        this.mode = new ModeSetting("Mode", MODE_CIRCLE, MODE_COLLISION, MODE_CIRCLE);
        this.predict = new BooleanSetting("Target predict", true, () -> mode.is(MODE_CIRCLE));
        this.predictStrength = new NumberSetting("Predict strength", 5.0f, 0.0f, 10.0f, 0.1f,
                () -> mode.is(MODE_CIRCLE) && predict.isEnabled());
        this.radius = new NumberSetting("Radius", 2.0f, 0.5f, 5.0f, 0.1f,
                () -> mode.is(MODE_CIRCLE));
        this.strength = new NumberSetting("Push strength", 0.03f, 0.01f, 0.1f, 0.01f,
                () -> mode.is(MODE_COLLISION));
        addSettings(mode, predict, predictStrength, radius, strength);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null || !mode.is(MODE_COLLISION)) {
            return;
        }

        LivingEntity target = getTarget();
        if (target == null || mc.player.distanceTo(target) > 1.5f) {
            return;
        }

        Vec3d direction = target.getPos().subtract(mc.player.getPos()).normalize();
        double push = strength.get().floatValue();
        mc.player.setVelocity(
                mc.player.getVelocity().x + direction.x * push,
                mc.player.getVelocity().y,
                mc.player.getVelocity().z + direction.z * push);
    }

    @EventTarget(Priority.LOWEST)
    public void onMoveInput(StrafeInputEvent event) {
        if (mc.player == null || mc.world == null || !mode.is(MODE_CIRCLE)) {
            return;
        }

        LivingEntity target = getTarget();
        if (target == null) {
            predictedPos = null;
            return;
        }

        Vec3d targetPos = target.getPos();
        if (predict.isEnabled()) {
            targetPos = predictPosition(target, targetPos);
        } else {
            predictedPos = null;
        }

        double deltaX = mc.player.getX() - targetPos.x;
        double deltaZ = mc.player.getZ() - targetPos.z;
        double dist = Math.hypot(deltaX, deltaZ);
        double orbit = radius.get().floatValue();
        double angle = Math.atan2(deltaZ, deltaX);

        double velocityX = mc.player.getVelocity().x;
        double velocityZ = mc.player.getVelocity().z;
        double tangentSign = Math.signum(-deltaZ * velocityX + deltaX * velocityZ);
        if (tangentSign == 0.0) {
            tangentSign = 1.0;
        }

        double nextAngle = angle + tangentSign * Math.toRadians(50.0);
        double desiredDist = orbit;
        if (dist > orbit + 0.45) {
            desiredDist = Math.max(orbit * 0.85, dist - 0.75);
        } else if (dist < Math.max(0.6, orbit - 0.45)) {
            desiredDist = Math.min(orbit, dist + 0.75);
        }

        Vec3d desired = new Vec3d(
                targetPos.x + Math.cos(nextAngle) * desiredDist,
                mc.player.getY(),
                targetPos.z + Math.sin(nextAngle) * desiredDist);
        MovementFixUtil.moveToPosition(event, desired, mc.player.getYaw());
    }

    @Override
    public void onDisable() {
        predictedPos = null;
        super.onDisable();
    }

    private LivingEntity getTarget() {
        AttackAura attackAura = AttackAura.INSTANCE;
        if (!attackAura.isEnabled()) {
            return null;
        }
        if (TriggerBot.INSTANCE.isEnabled() && TriggerBot.INSTANCE.getTarget() != null) {
            return null;
        }
        return attackAura.getTarget();
    }

    private Vec3d predictPosition(LivingEntity target, Vec3d basePosition) {
        double speed = Math.hypot(target.getX() - target.lastRenderX, target.getZ() - target.lastRenderZ) * 20.0;
        if (speed < 0.15) {
            return basePosition;
        }

        double deltaX = target.getX() - target.lastRenderX;
        double deltaZ = target.getZ() - target.lastRenderZ;
        double length = Math.hypot(deltaX, deltaZ);
        if (length <= 0.001) {
            predictedPos = basePosition;
            return basePosition;
        }

        double factor = predictStrength.get().floatValue() / 10.0;
        predictedPos = basePosition.add(deltaX / length * factor, 0.0, deltaZ / length * factor);
        return predictedPos;
    }
}
