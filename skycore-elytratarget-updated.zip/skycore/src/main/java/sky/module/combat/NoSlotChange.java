package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.component.type.ProfileComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.MathHelper;
import sky.config.MultiBooleanSetting;
import sky.event.network.PacketSendEvent;
import sky.event.player.PlayerUpdateEvent;
import sky.event.player.ClickSlotEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.inventory.ItemSwapUtil;

import java.util.List;

public final class NoSlotChange extends Module {
    private static final String BLOCK_SLOT_SWAP = "Block slot change";
    private static final String KEEP_ELYTRA = "Don't drop elytra";
    private static final String KEEP_CHESTPLATE = "Don't drop chestplate";
    private static final String KEEP_HEAD = "Don't drop head";
    private static final String KEEP_FRAGMENTS = "Don't drop fragments";

    public static final NoSlotChange INSTANCE = new NoSlotChange();

    private final MultiBooleanSetting options;

    private NoSlotChange() {
        super("NoSlotChange", "Protects important items from accidental drops and slot changes", Category.COMBAT);
        this.options = MultiBooleanSetting.create("Item protection",
                List.of(BLOCK_SLOT_SWAP, KEEP_ELYTRA, KEEP_CHESTPLATE, KEEP_HEAD, KEEP_FRAGMENTS));
        addSettings(this.options);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.interactionManager == null || isContainerScreenOpen()) {
            return;
        }

        ItemStack cursorStack = mc.player.currentScreenHandler.getCursorStack();
        if (cursorStack.isEmpty()) {
            return;
        }

        int emptySlot = ItemSwapUtil.findEmptyInventorySlot();
        if (emptySlot == -1) {
            return;
        }

        if (options.is(KEEP_ELYTRA) && cursorStack.isOf(Items.ELYTRA) && ItemSwapUtil.getSlot(Items.ELYTRA) == -1) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, emptySlot, 0,
                    SlotActionType.PICKUP, mc.player);
        }

        if (options.is(KEEP_CHESTPLATE) && isChestplate(cursorStack) && ItemSwapUtil.getChestPlateSlot() == -1) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, emptySlot, 0,
                    SlotActionType.PICKUP, mc.player);
        }

        if (options.is(KEEP_HEAD) && cursorStack.isOf(Items.PLAYER_HEAD) && ItemSwapUtil.getSlot(Items.PLAYER_HEAD) == -1) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, emptySlot, 0,
                    SlotActionType.PICKUP, mc.player);
        }

        if (options.is(KEEP_FRAGMENTS) && isFragment(cursorStack)) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, emptySlot, 0,
                    SlotActionType.PICKUP, mc.player);
        }
    }

    @EventTarget
    public void onClickSlot(ClickSlotEvent event) {
        if (mc.player == null || isContainerScreenOpen()) {
            return;
        }

        if (event.getActionType() == SlotActionType.SWAP && event.getButton() == 40) {
            return;
        }

        int slotId = event.getSlotId();
        if (slotId < 0 || slotId >= mc.player.currentScreenHandler.slots.size()) {
            return;
        }

        if (event.getActionType() == SlotActionType.SWAP || event.getActionType() == SlotActionType.PICKUP) {
            ItemStack stack = mc.player.currentScreenHandler.getSlot(event.getSlotId()).getStack();
            if (shouldBlockStack(stack)) {
                event.setCancelled(true);
            }
        }
    }

    @EventTarget
    public void onPacket(PacketSendEvent event) {
        if (mc.player == null) {
            return;
        }

        if (!options.is(BLOCK_SLOT_SWAP)) {
            return;
        }

        if (event.isReceive()) {
            Packet<?> packet = event.getPacket();
            if (packet instanceof UpdateSelectedSlotS2CPacket slotPacket) {
                int requestedSlot = slotPacket.slot();
                int currentSlot = mc.player.getInventory().selectedSlot;
                if (requestedSlot != currentSlot) {
                    int neighbourSlot = MathHelper.clamp(currentSlot >= 8 ? currentSlot - 1 : currentSlot + 1, 0, 8);
                    if (mc.getNetworkHandler() != null) {
                        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(neighbourSlot));
                        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(currentSlot));
                    }
                    event.setCancelled(true);
                }
            }
        }
    }

    private boolean shouldBlockStack(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        if (options.is(KEEP_ELYTRA) && stack.isOf(Items.ELYTRA)) {
            return true;
        }
        if (options.is(KEEP_CHESTPLATE) && isChestplate(stack)) {
            return true;
        }
        if (options.is(KEEP_HEAD) && stack.isOf(Items.PLAYER_HEAD)) {
            return true;
        }
        return options.is(KEEP_FRAGMENTS) && isFragment(stack);
    }

    private boolean isChestplate(ItemStack stack) {
        if (stack.isEmpty() || stack.isOf(Items.ELYTRA)) {
            return false;
        }
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && equippable.slot() == EquipmentSlot.CHEST;
    }

    private boolean isFragment(ItemStack stack) {
        ProfileComponent profile = stack.get(DataComponentTypes.PROFILE);
        return profile != null && stack.contains(DataComponentTypes.CUSTOM_NAME);
    }

    private boolean isContainerScreenOpen() {
        return mc.currentScreen instanceof GenericContainerScreen
                || mc.currentScreen instanceof InventoryScreen
                || mc.currentScreen instanceof CreativeInventoryScreen;
    }
}
