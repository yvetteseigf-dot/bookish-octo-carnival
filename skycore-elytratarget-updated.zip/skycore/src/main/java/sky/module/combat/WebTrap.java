package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.PassiveEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import sky.SkyInit;
import sky.config.ModeSetting;
import sky.config.MultiBooleanSetting;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.event.player.PlayerUpdateEvent;
import sky.module.Category;
import sky.module.Module;
import sky.util.inventory.ItemSwapUtil;
import sky.util.MsTimer;
import sky.util.combat.Rotation;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class WebTrap extends Module {
    private static final String MODE_SINGLE = "Single";
    private static final String MODE_MULTI = "Multi";
    private static final String TARGET_PLAYERS = "Players";
    private static final String TARGET_NAKED = "Naked";
    private static final String TARGET_MOBS = "Mobs";
    private static final String TARGET_ANIMALS = "Animals";

    private static final double RANGE = 4.0D;
    private static final float PLACE_ANGLE = 4.0F;
    private static final long PLACE_DELAY_MS = 60L;

    public static final WebTrap INSTANCE = new WebTrap();

    private final ModeSetting mode;
    private final MultiBooleanSetting targets;
    private final NumberSetting predict;
    private final MsTimer placeTimer;

    private Placement pendingPlacement;

    private WebTrap() {
        super("WebTrap", "Places cobweb on the target or ahead of it using predict", Category.COMBAT);
        this.mode = new ModeSetting("Place mode", MODE_SINGLE, MODE_SINGLE, MODE_MULTI);
        this.targets = MultiBooleanSetting.create("Targets",
                List.of(TARGET_PLAYERS, TARGET_NAKED, TARGET_MOBS, TARGET_ANIMALS));
        this.predict = new NumberSetting("Predict", 1.0F, 0.0F, 4.0F, 0.1F);
        this.placeTimer = new MsTimer();
        addSettings(this.mode, this.targets, this.predict);
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent ignored) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            return;
        }

        int webSlot = findWebSlot();
        if (webSlot == -1) {
            return;
        }

        LivingEntity target = findTarget();
        if (target == null) {
            pendingPlacement = null;
            return;
        }

        Placement placement = pendingPlacement;
        if (placement == null || !canReplace(placement.placePos())) {
            placement = findPlacement(target);
            pendingPlacement = placement;
        }

        if (placement == null) {
            return;
        }

        if (!rotateTo(placement.hit())) {
            return;
        }

        if (!placeTimer.finished(PLACE_DELAY_MS)) {
            return;
        }

        int previousSlot = mc.player.getInventory().selectedSlot;
        ItemSwapUtil.switchToHotbarSlot(webSlot);
        if (placeWeb(placement)) {
            mc.player.swingHand(Hand.MAIN_HAND);
            placeTimer.reset();
            pendingPlacement = null;
        }
        ItemSwapUtil.switchToHotbarSlot(previousSlot);
    }

    @Override
    protected void onDisable() {
        pendingPlacement = null;
        super.onDisable();
    }

    private LivingEntity findTarget() {
        return mc.world.getEntitiesByClass(LivingEntity.class,
                        mc.player.getBoundingBox().expand(RANGE), this::isValidTarget)
                .stream()
                .min(Comparator.comparingDouble(entity -> entity.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity instanceof ArmorStandEntity) {
            return false;
        }

        if (mc.player.squaredDistanceTo(entity) > 16.0D) {
            return false;
        }

        if (entity instanceof PlayerEntity player) {
            if (SkyInit.getInstance().getFriendManager().isFriend(player.getName().getString())) {
                return false;
            }
            if (AntiBot.isBot(player)) {
                return false;
            }
            boolean naked = isNaked(player);
            return targets.is(TARGET_PLAYERS) || (naked && targets.is(TARGET_NAKED));
        }

        if (entity instanceof PassiveEntity) {
            return targets.is(TARGET_ANIMALS);
        }

        if (entity instanceof HostileEntity) {
            return targets.is(TARGET_MOBS);
        }

        return false;
    }

    private boolean isNaked(PlayerEntity player) {
        return player.getInventory().armor.stream().allMatch(stack -> stack == null || stack.isEmpty());
    }

    private List<BlockPos> getTrapPositions(LivingEntity target) {
        Vec3d velocity = target.getVelocity();
        double speed = Math.sqrt(velocity.x * velocity.x + velocity.z * velocity.z);
        double lead = speed > 0.03D ? predict.getCurrent() : 0.0D;

        Vec3d predicted = target.getPos().add(velocity.x * lead, 0.0D, velocity.z * lead);
        BlockPos base = BlockPos.ofFloored(predicted.x, target.getY(), predicted.z);

        List<BlockPos> positions = new ArrayList<>();
        positions.add(base);
        if (mode.is(MODE_MULTI)) {
            positions.add(base.up());
            positions.add(base.east());
            positions.add(base.south());
            positions.add(base.west());
            positions.add(base.north());
        }
        return positions;
    }

    private Placement findPlacement(LivingEntity target) {
        for (BlockPos pos : getTrapPositions(target)) {
            Placement placement = getPlacement(pos);
            if (placement != null) {
                return placement;
            }
        }
        return null;
    }

    private Placement getPlacement(BlockPos pos) {
        if (!canReplace(pos)) {
            return null;
        }

        for (Direction direction : Direction.values()) {
            BlockPos neighbour = pos.offset(direction.getOpposite());
            if (!canClick(neighbour)) {
                continue;
            }

            Vec3d hit = Vec3d.ofCenter(neighbour).add(Vec3d.of(direction.getVector()).multiply(0.5D));
            return new Placement(pos, new BlockHitResult(hit, direction, neighbour, false), hit);
        }

        return null;
    }

    private boolean canReplace(BlockPos pos) {
        return mc.world.isInBuildLimit(pos)
                && mc.world.getBlockState(pos).isReplaceable()
                && !mc.world.getBlockState(pos).isOf(Blocks.COBWEB);
    }

    private boolean canClick(BlockPos pos) {
        return mc.world.isInBuildLimit(pos)
                && !mc.world.getBlockState(pos).isAir()
                && !mc.world.getBlockState(pos).isReplaceable();
    }

    private boolean placeWeb(Placement placement) {
        mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, placement.hitResult());
        return true;
    }

    private boolean rotateTo(Vec3d hit) {
        Rotation rotation = Rotation.lookingAt(hit, mc.player.getEyePos());
        RotationManager.update(rotation, 18.0F, 14.0F, 35.0F, 35.0F, 3, 2, false);
        return new Rotation(mc.player.getYaw(), mc.player.getPitch()).getDelta(rotation) <= PLACE_ANGLE;
    }

    private int findWebSlot() {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(Items.COBWEB)) {
                return slot;
            }
        }
        return -1;
    }

    private static Direction getForwardDirection(Vec3d velocity, float yaw) {
        if (velocity.horizontalLengthSquared() > 0.003D) {
            return Direction.getFacing(velocity.x, 0.0D, velocity.z);
        }

        double yawRadians = Math.toRadians(yaw);
        return Direction.getFacing(-Math.sin(yawRadians), 0.0D, Math.cos(yawRadians));
    }

    private record Placement(BlockPos placePos, BlockHitResult hitResult, Vec3d hit) {
    }
}
