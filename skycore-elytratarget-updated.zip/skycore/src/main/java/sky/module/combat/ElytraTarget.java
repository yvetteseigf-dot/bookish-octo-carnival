package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.prediction.ElytraTargetPredictor;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.access.SwingTimerAccess;
import sky.event.player.PlayerUpdateEvent;
import sky.event.entity.FireworkRocketEntityTickEvent;
import sky.event.render.RenderWorldEvent;
import sky.event.entity.MoveEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.GrimGlide;
import sky.util.MsTimer;
import sky.util.inventory.ItemSwapUtil;

public final class ElytraTarget extends Module {
    private static final String BOX_NORMAL = "Normal";
    private static final String BOX_DASHED = "Dashed";
    private static final String BOX_DIAGONALS = "Diagonals";

    public static final ElytraTarget INSTANCE = new ElytraTarget();
    public static NumberSetting pursuitdistance = new NumberSetting("Chase distance", 30.0F, 10.0F, 100.0F, 5.0F);

    public final BooleanSetting target;
    public final ModeSetting predictMode;
    public final BooleanSetting predictCube;
    public final NumberSetting predictFillAlpha;
    public final BooleanSetting predictFromTheme;
    public final ModeSetting predictBoxMode;
    public final BooleanSetting visualReverse;
    public final NumberSetting distance;
    public final BooleanSetting autoFirework;
    public final NumberSetting fireworkSpeed;

    public boolean status;
    public boolean disableForward;
    public boolean slowdownActive;
    boolean non;
    int lastslot;
    private final MsTimer hurtTimer;
    private final MsTimer fireworkTimer;
    private boolean visualReverseWasActive;

    private ElytraTarget() {
        super("ElytraTarget", "Chases the target on elytra", Category.COMBAT);
        this.target = new BooleanSetting("Overtake", false);
        this.predictMode = new ModeSetting("Predict mode", "ReallyWorld", target::isEnabled,
                "ReallyWorld", "ReallyWorld - 2", "Test", "Smart");
        this.predictCube = new BooleanSetting("Draw predict", true,
                () -> target.isEnabled() && supportsPredictCube());
        this.predictFillAlpha = new NumberSetting("Opacity", 40.0F, 0.0F, 255.0F, 1.0F,
                () -> target.isEnabled() && predictCube.isEnabled() && supportsPredictCube());
        this.predictFromTheme = new BooleanSetting("From theme", true,
                () -> target.isEnabled() && predictCube.isEnabled() && supportsPredictCube());
        this.predictBoxMode = new ModeSetting("Box style", BOX_NORMAL,
                () -> target.isEnabled() && predictCube.isEnabled() && supportsPredictCube(),
                BOX_NORMAL, BOX_DASHED, BOX_DIAGONALS);
        this.visualReverse = new BooleanSetting("180 turn", false, target::isEnabled);
        this.distance = new NumberSetting("Predict strength", 2.7F, 1.0F, 5.0F, 0.1F, target::isEnabled);
        this.autoFirework = new BooleanSetting("Auto firework", false);
        // value = delay between rockets in ms: 100 = strongest (fastest), 1500 = weakest (slowest)
        this.fireworkSpeed = new NumberSetting("Firework speed", 500.0F, 100.0F, 1500.0F, 50.0F,
                autoFirework::isEnabled);
        this.status = true;
        this.disableForward = false;
        this.slowdownActive = false;
        this.non = false;
        this.lastslot = 0;
        this.hurtTimer = new MsTimer();
        this.fireworkTimer = new MsTimer();
        this.visualReverseWasActive = false;
        addSettings(predictMode, predictCube, predictFillAlpha, predictFromTheme, predictBoxMode,
                visualReverse, target, distance, pursuitdistance, autoFirework, fireworkSpeed);
    }

    @Override
    public void onDisable() {
        slowdownActive = false;
        fireworkTimer.reset();
        ElytraTargetPredictor.resetState();
        disableForward = false;
        visualReverseWasActive = false;
        super.onDisable();
    }

    public boolean shouldTarget(LivingEntity livingEntity) {
        if (!isEnabled() || livingEntity == null || disableForward) {
            return false;
        }

        boolean gliding = livingEntity.isGliding();
        return status && mc.player != null && mc.player.isGliding() && gliding;
    }

    @EventTarget
    public void onRender3D(RenderWorldEvent event) {
        ElytraTargetPredictor.renderPredictCube(event, this);
    }

    public float getPredictDistance() {
        return distance.getCurrent();
    }

    public boolean isPedikPredict() {
        return predictMode.is("ReallyWorld - 2");
    }

    public boolean isForwardPredict() {
        return predictMode.is("ReallyWorld");
    }

    public boolean supportsPredictCube() {
        return isForwardPredict() || isPedikPredict() || isTestPredict() || isSmartPredict();
    }

    public boolean usesVisualReverseLogic() {
        return isForwardPredict() || isPedikPredict() || isTestPredict() || isSmartPredict();
    }

    @EventTarget
    public void onFirework(FireworkRocketEntityTickEvent event) {
        if (slowdownActive) {
            event.setSpeed(0.01F);
            event.setYSpeed(0.01F);
        }
    }

    public boolean isReverseActive() {
        if (!usesVisualReverseLogic()
                || !isEnabled()
                || !target.isEnabled()
                || !visualReverse.isEnabled()
                || disableForward
                || mc.player == null) {
            visualReverseWasActive = false;
            return false;
        }

        AttackAura aura = AttackAura.INSTANCE;
        LivingEntity auraTarget = aura != null ? aura.getTarget() : null;
        if (auraTarget != null && shouldTarget(auraTarget)) {
            float dist = mc.player.distanceTo(auraTarget);
            float inner = Math.max(2.5F, distance.getCurrent());
            float outer = inner + 3.0F;
            if (!visualReverseWasActive && dist <= 2.5F) {
                visualReverseWasActive = true;
            }
            if (visualReverseWasActive && dist >= outer) {
                visualReverseWasActive = false;
            }
            return visualReverseWasActive;
        }

        visualReverseWasActive = false;
        return false;
    }

    public float getPursuitDistance() {
        return pursuitdistance.getCurrent();
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null) {
            slowdownActive = false;
            return;
        }

        if (!non) {
            lastslot = mc.player.getInventory().selectedSlot;
        }

        AttackAura aura = AttackAura.INSTANCE;
        status = target.isEnabled();
        if (aura != null && aura.getTarget() != null) {
            LivingEntity auraTarget = aura.getTarget();
            if (mc.player.hurtTime > 0
                    && auraTarget instanceof SwingTimerAccess swingAccess
                    && !swingAccess.skycore$getLastSwing().finished(500L)) {
                disableForward = true;
                hurtTimer.reset();
            }
            if (hurtTimer.finished(500L)) {
                disableForward = false;
            }
        } else {
            disableForward = false;
        }

        if (!mc.player.isGliding()) {
            slowdownActive = false;
        } else {
            LivingEntity auraTarget = aura != null ? aura.getTarget() : null;
            slowdownActive = auraTarget != null
                    && shouldTarget(auraTarget)
                    && mc.player.isGliding()
                    && mc.player.distanceTo(auraTarget) <= Math.max(2.5F, distance.getCurrent());
        }

        handleAutoFirework();
    }

    @EventTarget
    public void onMoving(MoveEvent event) {
        if (slowdownActive && !GrimGlide.isGlideFlyActive()) {
            event.setMotion(Vec3d.ZERO);
        }
    }

    public boolean isTestPredict() {
        return predictMode.is("Test");
    }

    public boolean isSmartPredict() {
        return predictMode.is("Smart");
    }

    private void handleAutoFirework() {
        if (!autoFirework.isEnabled() || mc.player == null || mc.interactionManager == null) {
            return;
        }
        if (!mc.player.isGliding() || slowdownActive || mc.currentScreen != null) {
            return;
        }
        if (!fireworkTimer.finished(fireworkSpeed.getCurrent())) {
            return;
        }
        boolean hasRocket = mc.player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)
                || mc.player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)
                || ItemSwapUtil.getSlot(Items.FIREWORK_ROCKET) != -1;
        if (!hasRocket) {
            return;
        }
        fireworkTimer.reset();
        ItemSwapUtil.inventorySwapClick(Items.FIREWORK_ROCKET);
    }

    public boolean isOvertakeEnabled() {
        return isEnabled() && target.isEnabled();
    }
}
