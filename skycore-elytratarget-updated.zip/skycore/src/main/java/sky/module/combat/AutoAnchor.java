package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.lwjgl.glfw.GLFW;
import sky.SkyInit;
import sky.config.BindCapture;
import sky.config.BooleanSetting;
import sky.config.KeybindSetting;
import sky.config.ModeSetting;
import sky.config.NumberSetting;
import sky.rotation.RotationManager;
import sky.event.player.PlayerUpdateEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.Category;
import sky.module.Module;
import sky.render.WorldDrawHelper;
import sky.util.combat.AnchorAimUtil;
import sky.util.inventory.ItemSwapUtil;
import sky.util.combat.Rotation;

public final class AutoAnchor extends Module {
    private static final String MODE_HOLD = "Hold";
    private static final String MODE_CLICK = "Click";
    private static final String AIM_NORMAL = "Normal";
    private static final String AIM_SILENT = "Silent";

    private static final int VANILLA_PLACE_COOLDOWN_TICKS = 1;
    private static final int STEP_TIMEOUT_MS = 450;
    private static final int SEQUENCE_TIMEOUT_MS = 1200;
    private static final int MAX_STEP_STUCK_TICKS = 8;
    private static final int MAX_ANCHOR_CHARGES = 4;
    private static final double PLACE_FACE_CORNER = 0.49D;
    private static final double PLACE_RAY_EPSILON = 1.0E-4D;
    private static final float PLACE_ANGLE = 12.0F;
    private static final float ROTATION_SETTLE_THRESHOLD = 1.7F;

    public static final AutoAnchor INSTANCE = new AutoAnchor();

    private static final double[][] PLACE_FACE_SAMPLE_OFFSETS = {
            {0.0D, 0.0D},
            {PLACE_FACE_CORNER, PLACE_FACE_CORNER},
            {PLACE_FACE_CORNER, -PLACE_FACE_CORNER},
            {-PLACE_FACE_CORNER, PLACE_FACE_CORNER},
            {-PLACE_FACE_CORNER, -PLACE_FACE_CORNER}
    };

    private final ModeSetting mode;
    private final KeybindSetting activateKey;
    private final BooleanSetting repeat;
    private final BooleanSetting autoAim;
    private final ModeSetting aimType;
    private final NumberSetting aimSpeed;
    private final BooleanSetting renderPosition;
    private final BooleanSetting strictPlace;
    private final BooleanSetting safeAnchor;
    private final NumberSetting safetyTimeout;
    private final NumberSetting selfDamageGate;
    private final NumberSetting charges;
    private final NumberSetting chargeDelay;
    private final NumberSetting explodeSlot;
    private final NumberSetting explodeDelay;

    private boolean hasInteractionPitchDelta;
    private long sequenceStartMillis;
    private int stepStuckTicks;
    private boolean rotationPrimed;
    private long stepStartMillis;
    private boolean keyWasDown;
    private boolean clickQueued;
    private int cachedPlacementAge;
    private float lastInteractionPitchDelta;
    private int placeStuckTicks;
    private int savedSlot;
    private float prevYaw;
    private AnchorStep anchorStep;
    private float prevPitch;
    private int placeCooldown;
    private int nextAnchorActionTick;
    private float lastDeltaPitch;
    private Vec3d cachedAnchorAim;
    private long safetyStepStartMillis;
    private LivingEntity cachedPlacementTarget;
    private PlacementHit cachedPlacement;
    private boolean holdCycleCompleted;
    private BlockPos activeAnchorPos;
    private int remainingCharges;

    private AutoAnchor() {
        super("Auto Anchor", "Places an anchor at the target, charges and explodes it", Category.COMBAT);
        this.mode = new ModeSetting("Mode", MODE_HOLD, MODE_HOLD, MODE_CLICK);
        this.activateKey = new KeybindSetting("Bind");
        this.repeat = new BooleanSetting("Repeat", true, () -> mode.is(MODE_HOLD));
        this.autoAim = new BooleanSetting("Auto search", true);
        this.aimType = new ModeSetting("Aim", AIM_SILENT, () -> autoAim.isEnabled(), AIM_NORMAL, AIM_SILENT);
        this.aimSpeed = new NumberSetting("Aim speed", 360.0F, 20.0F, 360.0F, 5.0F, autoAim::isEnabled);
        this.renderPosition = new BooleanSetting("Show position", true);
        this.strictPlace = new BooleanSetting("Strict place", false);
        this.safeAnchor = new BooleanSetting("Safety block", true);
        this.safetyTimeout = new NumberSetting("Safety timeout", 250.0F, 100.0F, 3000.0F, 50.0F, safeAnchor::isEnabled);
        this.selfDamageGate = new NumberSetting("Safety damage", 0.0F, 0.0F, 20.0F, 0.5F, safeAnchor::isEnabled);
        this.charges = new NumberSetting("Charges", 1.0F, 1.0F, 4.0F, 1.0F);
        this.chargeDelay = new NumberSetting("Charge delay", 0.0F, 0.0F, 20.0F, 1.0F);
        this.explodeSlot = new NumberSetting("Explode slot", 1.0F, 1.0F, 9.0F, 1.0F);
        this.explodeDelay = new NumberSetting("Explode delay", 0.0F, 0.0F, 20.0F, 1.0F);
        this.savedSlot = -1;
        this.cachedPlacementAge = -1;
        addSettings(this.mode, this.activateKey, this.repeat, this.autoAim, this.aimType, this.aimSpeed,
                this.renderPosition, this.strictPlace, this.safeAnchor, this.safetyTimeout, this.selfDamageGate,
                this.charges, this.chargeDelay, this.explodeSlot, this.explodeDelay);
    }

    @Override
    public void onEnable() {
        resetAll();
        super.onEnable();
    }

    @Override
    public void onDisable() {
        restoreSlot();
        resetAll();
        super.onDisable();
    }

    @EventTarget
    private void onUpdate(PlayerUpdateEvent ignored) {
        updateRotationTracker();
        if (placeCooldown > 0) {
            placeCooldown--;
        }

        if (mc.player == null || mc.world == null || mc.interactionManager == null
                || mc.currentScreen != null || BindCapture.isActive(activateKey)) {
            clickQueued = false;
            resetAnchorSequence();
            keyWasDown = false;
            return;
        }

        boolean bindDown = isBindDown(activateKey.getKeyCode());
        boolean holdMode = mode.is(MODE_HOLD);
        if (holdMode && !bindDown) {
            holdCycleCompleted = false;
        }
        if (!holdMode && bindDown && !keyWasDown) {
            clickQueued = true;
            if (!isAnchorSequenceActive()) {
                placeCooldown = 0;
            }
        }

        boolean active = holdMode ? bindDown : clickQueued || isAnchorSequenceActive();
        if (!active) {
            resetAnchorSequence();
            handleInactive();
            keyWasDown = bindDown;
            return;
        }

        if (holdMode && !repeat.isEnabled() && holdCycleCompleted && !isAnchorSequenceActive()) {
            handleInactive();
            keyWasDown = bindDown;
            return;
        }

        if (isAnchorSequenceActive()) {
            continueAnchorSequence();
            keyWasDown = bindDown;
            return;
        }

        BlockHitResult crosshair = currentBlockHit();
        if (crosshair != null && isRespawnAnchor(crosshair.getBlockPos())) {
            BlockPos anchorPos = crosshair.getBlockPos();
            if (!isAnchorWithinRange(anchorPos)) {
                if (!holdMode) {
                    clickQueued = false;
                }
                handleInactive();
                keyWasDown = bindDown;
                return;
            }
            beginAnchorSequence(anchorPos, rollChargeCount());
            keyWasDown = bindDown;
            return;
        }

        keyWasDown = bindDown;
        runFreshAnchorPlacement(holdMode);
    }

    @EventTarget
    private void onRender3D(RenderWorldEvent event) {
        if (!renderPosition.isEnabled() || mc.player == null || mc.world == null) {
            return;
        }
        if (!isBindDown(activateKey.getKeyCode()) || BindCapture.isActive(activateKey)) {
            return;
        }

        PlacementHit placement = getCachedOrFindPlacement(event.getPartialTicks());
        if (placement == null) {
            return;
        }
        WorldDrawHelper.drawBox(new Box(placement.placementPos()), 0x64FF6A00, 1.5F, true, true, false);
    }

    private void runFreshAnchorPlacement(boolean holdMode) {
        float tickDelta = 1.0F;
        boolean aiming = autoAim.isEnabled();
        PlacementHit autoPlacement = null;
        BlockHitResult manualHit = null;
        boolean usedAutoPlacement = false;

        if (aiming) {
            autoPlacement = getCachedOrFindPlacement(tickDelta);
            if (autoPlacement != null) {
                usedAutoPlacement = true;
            } else {
                manualHit = currentBlockHit();
            }
            if (manualHit == null && !usedAutoPlacement) {
                if (!holdMode) {
                    clickQueued = false;
                }
                handleInactive();
                return;
            }
        } else {
            manualHit = currentBlockHit();
            if (manualHit == null) {
                if (!holdMode) {
                    clickQueued = false;
                }
                handleInactive();
                return;
            }
        }

        int hotbarSlot = findHotbar(Items.RESPAWN_ANCHOR);
        if (hotbarSlot == -1) {
            clickQueued = false;
            handleInactive();
            return;
        }
        if (placeCooldown > 0) {
            return;
        }
        if (!swapTo(hotbarSlot)) {
            return;
        }
        if (!mc.player.getMainHandStack().isOf(Items.RESPAWN_ANCHOR)) {
            return;
        }

        BlockHitResult hit;
        BlockPos placementPos;
        if (usedAutoPlacement) {
            if (autoPlacement == null) {
                return;
            }
            hit = autoPlacement.hitResult();
            placementPos = autoPlacement.placementPos();
            if (!rotateTo(hit.getPos())) {
                placeStuckTicks++;
                if (placeStuckTicks < 3) {
                    return;
                }
            } else {
                placeStuckTicks = 0;
            }
            if (strictPlace.isEnabled() && !isReadyToPlace(autoPlacement, tickDelta)) {
                placeStuckTicks++;
                if (placeStuckTicks < 5) {
                    return;
                }
            }
        } else {
            hit = manualHit;
            placementPos = hit.getBlockPos().offset(hit.getSide());
            if (!isManualPlacementValid(placementPos)) {
                if (!holdMode) {
                    clickQueued = false;
                }
                handleInactive();
                return;
            }
            if (autoAim.isEnabled() && !rotateTo(hit.getPos())) {
                return;
            }
        }

        ActionResult result = interact(hit);
        placeCooldown = VANILLA_PLACE_COOLDOWN_TICKS;
        if (result.isAccepted()) {
            markInteraction();
            placeStuckTicks = 0;
            if (placementPos != null) {
                beginAnchorSequence(placementPos, rollChargeCount());
            }
        } else if (!holdMode) {
            placeStuckTicks++;
            if (placeStuckTicks >= 8) {
                finishAnchorSequence();
            }
        } else {
            placeStuckTicks++;
            if (placeStuckTicks >= 12) {
                invalidatePlacementCache();
                placeStuckTicks = 0;
            }
        }
    }

    private void continueAnchorSequence() {
        if (!isRespawnAnchor(activeAnchorPos) || !isAnchorWithinRange(activeAnchorPos)) {
            finishAnchorSequence();
            return;
        }
        if (System.currentTimeMillis() - sequenceStartMillis >= SEQUENCE_TIMEOUT_MS) {
            finishAnchorSequence();
            return;
        }
        if (mc.player.age < nextAnchorActionTick) {
            return;
        }
        switch (anchorStep) {
            case PLACE_SAFETY -> placeSafetyBlock();
            case CHARGE -> chargeActiveAnchor();
            case EXPLODE -> explodeActiveAnchor();
        }
    }

    private void beginAnchorSequence(BlockPos anchorPos, int chargeCount) {
        this.activeAnchorPos = anchorPos;
        this.remainingCharges = Math.max(0, chargeCount - getAnchorCharge(anchorPos));
        this.anchorStep = safeAnchor.isEnabled() ? AnchorStep.PLACE_SAFETY : AnchorStep.CHARGE;
        this.nextAnchorActionTick = mc.player.age;
        this.cachedAnchorAim = Vec3d.ofCenter(anchorPos);
        long now = System.currentTimeMillis();
        this.safetyStepStartMillis = now;
        this.sequenceStartMillis = now;
        enterStep();
        invalidatePlacementCache();
    }

    private void placeSafetyBlock() {
        if (!safeAnchor.isEnabled()) {
            advanceToChargeStep();
            return;
        }

        float gate = selfDamageGate.getCurrent();
        if (gate > 0.0F && getAnchorDamageTo(mc.player, activeAnchorPos) < gate) {
            advanceToChargeStep();
            return;
        }

        int timeoutMs = Math.min(Math.round(safetyTimeout.getCurrent()), STEP_TIMEOUT_MS);
        long now = System.currentTimeMillis();
        if (timeoutMs > 0 && now - safetyStepStartMillis >= timeoutMs) {
            advanceToChargeStep();
            return;
        }
        if (now - stepStartMillis >= STEP_TIMEOUT_MS || stepStuckTicks >= MAX_STEP_STUCK_TICKS) {
            advanceToChargeStep();
            return;
        }

        int safetySlot = findSafetyBlockSlot();
        if (safetySlot == -1) {
            advanceToChargeStep();
            return;
        }

        List<BlockPos> ranked = rankedSafetyCandidates();
        if (ranked.isEmpty()) {
            advanceToChargeStep();
            return;
        }
        if (hasExistingSafetyBlock(ranked.get(0))) {
            advanceToChargeStep();
            return;
        }

        PlacementHit placement = pickSafetyPlacement(ranked);
        if (placement == null) {
            advanceToChargeStep();
            return;
        }

        boolean aimed = !autoAim.isEnabled() || rotateTo(placement.hitResult().getPos());
        if (!aimed) {
            stepStuckTicks++;
            return;
        }
        if (strictPlace.isEnabled() && !isReadyToPlace(placement, 1.0F)) {
            stepStuckTicks++;
            return;
        }
        if (placeCooldown > 0) {
            stepStuckTicks++;
            return;
        }
        if (!swapTo(safetySlot)) {
            stepStuckTicks++;
            return;
        }

        ItemStack stack = mc.player.getMainHandStack();
        if (!(stack.getItem() instanceof BlockItem) || stack.isOf(Items.RESPAWN_ANCHOR)) {
            stepStuckTicks++;
            return;
        }

        ActionResult result = interact(placement.hitResult());
        placeCooldown = VANILLA_PLACE_COOLDOWN_TICKS;
        if (result.isAccepted()) {
            markInteraction();
            cachedAnchorAim = null;
            advanceToChargeStep();
            return;
        }
        stepStuckTicks++;
    }

    private void chargeActiveAnchor() {
        int charge = getAnchorCharge(activeAnchorPos);
        if (remainingCharges <= 0 || charge >= MAX_ANCHOR_CHARGES) {
            beginExplodeOrFinish();
            return;
        }

        long elapsed = System.currentTimeMillis() - stepStartMillis;
        if (elapsed >= STEP_TIMEOUT_MS || stepStuckTicks >= MAX_STEP_STUCK_TICKS) {
            if (charge > 0) {
                beginExplodeOrFinish();
            } else {
                finishAnchorSequence();
            }
            return;
        }

        int glowstoneSlot = findHotbar(Items.GLOWSTONE);
        if (glowstoneSlot == -1) {
            remainingCharges = 0;
            beginExplodeOrFinish();
            return;
        }
        if (!swapTo(glowstoneSlot) || !mc.player.getMainHandStack().isOf(Items.GLOWSTONE)) {
            stepStuckTicks++;
            return;
        }

        Vec3d aim = getAnchorAimPoint(activeAnchorPos);
        boolean aimed = !autoAim.isEnabled() || rotateTo(aim);
        if (!aimed && stepStuckTicks < 2) {
            stepStuckTicks++;
            return;
        }

        BlockHitResult hit = getReadyAnchorHit(activeAnchorPos);
        if (hit == null) {
            cachedAnchorAim = AnchorAimUtil.findClearAimPoint(activeAnchorPos, 1.0F);
            hit = new BlockHitResult(getAnchorAimPoint(activeAnchorPos), Direction.UP, activeAnchorPos, false);
        }

        ActionResult result = interact(hit);
        if (!result.isAccepted()) {
            stepStuckTicks++;
            cachedAnchorAim = AnchorAimUtil.findClearAimPoint(activeAnchorPos, 1.0F);
            return;
        }

        markInteraction();
        remainingCharges--;
        enterStep();
        if (remainingCharges <= 0) {
            anchorStep = AnchorStep.EXPLODE;
            nextAnchorActionTick = mc.player.age + rollDelay(explodeDelay);
            return;
        }
        nextAnchorActionTick = mc.player.age + rollDelay(chargeDelay);
    }

    private void explodeActiveAnchor() {
        int charge = getAnchorCharge(activeAnchorPos);
        if (charge <= 0) {
            finishAnchorSequence();
            return;
        }

        long elapsed = System.currentTimeMillis() - stepStartMillis;
        if (elapsed >= STEP_TIMEOUT_MS || stepStuckTicks >= MAX_STEP_STUCK_TICKS) {
            finishAnchorSequence();
            return;
        }

        int slot = Math.round(explodeSlot.getCurrent()) - 1;
        if (!swapTo(slot)) {
            stepStuckTicks++;
            return;
        }

        ItemStack stack = mc.player.getInventory().getStack(slot);
        if (stack.isOf(Items.GLOWSTONE) && charge < MAX_ANCHOR_CHARGES) {
            finishAnchorSequence();
            return;
        }

        Vec3d aim = getAnchorAimPoint(activeAnchorPos);
        boolean aimed = !autoAim.isEnabled() || rotateTo(aim);
        if (!aimed && stepStuckTicks < 2) {
            stepStuckTicks++;
            return;
        }

        BlockHitResult hit = getReadyAnchorHit(activeAnchorPos);
        if (hit == null) {
            hit = new BlockHitResult(getAnchorAimPoint(activeAnchorPos), Direction.UP, activeAnchorPos, false);
        }

        ActionResult result = interact(hit);
        if (!result.isAccepted()) {
            stepStuckTicks++;
            cachedAnchorAim = AnchorAimUtil.findClearAimPoint(activeAnchorPos, 1.0F);
            return;
        }

        markInteraction();
        placeCooldown = VANILLA_PLACE_COOLDOWN_TICKS;
        finishAnchorSequence();
    }

    private void beginExplodeOrFinish() {
        if (getAnchorCharge(activeAnchorPos) <= 0) {
            finishAnchorSequence();
            return;
        }
        anchorStep = AnchorStep.EXPLODE;
        nextAnchorActionTick = mc.player.age + rollDelay(explodeDelay);
        enterStep();
    }

    private void advanceToChargeStep() {
        anchorStep = AnchorStep.CHARGE;
        nextAnchorActionTick = mc.player.age + rollDelay(chargeDelay);
        enterStep();
        placeCooldown = 0;
    }

    private void finishAnchorSequence() {
        resetAnchorSequence();
        if (mode.is(MODE_HOLD) && isBindDown(activateKey.getKeyCode())) {
            if (!repeat.isEnabled()) {
                holdCycleCompleted = true;
                restoreSlot();
            }
            return;
        }
        holdCycleCompleted = false;
        clickQueued = false;
        restoreSlot();
    }

    private void handleInactive() {
        resetAnchorSequence();
        restoreSlot();
    }

    private void resetAll() {
        clickQueued = false;
        keyWasDown = false;
        holdCycleCompleted = false;
        placeCooldown = 0;
        placeStuckTicks = 0;
        rotationPrimed = false;
        hasInteractionPitchDelta = false;
        resetAnchorSequence();
    }

    private void resetAnchorSequence() {
        anchorStep = null;
        activeAnchorPos = null;
        remainingCharges = 0;
        nextAnchorActionTick = 0;
        cachedAnchorAim = null;
        stepStuckTicks = 0;
        sequenceStartMillis = 0L;
        stepStartMillis = 0L;
    }

    private void enterStep() {
        stepStartMillis = System.currentTimeMillis();
        stepStuckTicks = 0;
    }

    private boolean isAnchorSequenceActive() {
        return anchorStep != null && activeAnchorPos != null;
    }

    private BlockHitResult currentBlockHit() {
        HitResult hit = mc.crosshairTarget;
        if (!(hit instanceof BlockHitResult blockHit)) {
            return null;
        }
        if (blockHit.getType() != HitResult.Type.BLOCK) {
            return null;
        }
        return blockHit;
    }

    private int findHotbar(Item item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return -1;
    }

    private int findSafetyBlockSlot() {
        return findHotbar(Items.GLOWSTONE);
    }

    private boolean swapTo(int hotbarSlot) {
        if (hotbarSlot < 0 || hotbarSlot > 8 || mc.player == null) {
            return false;
        }
        if (savedSlot == -1) {
            savedSlot = mc.player.getInventory().selectedSlot;
        }
        ItemSwapUtil.switchToHotbarSlot(hotbarSlot);
        return mc.player.getInventory().selectedSlot == hotbarSlot;
    }

    private void restoreSlot() {
        if (savedSlot != -1 && mc.player != null) {
            ItemSwapUtil.switchToHotbarSlot(savedSlot);
            savedSlot = -1;
        }
    }

    private boolean rotateTo(Vec3d point) {
        if (!autoAim.isEnabled() || point == null) {
            return true;
        }
        Rotation target = Rotation.lookingAt(point, mc.player.getEyePos());
        float speed = Math.max(20.0F, aimSpeed.getCurrent());
        boolean silent = !aimType.is(AIM_SILENT);
        if (speed >= 300.0F) {
            RotationManager.updateExact(target, speed, speed, 40.0F, 40.0F, 2, 1, silent);
        } else {
            RotationManager.update(target, speed, speed, 40.0F, 40.0F, 2, 1, silent);
        }
        Rotation current = new Rotation(mc.player.getYaw(), mc.player.getPitch());
        return current.getDelta(target) <= PLACE_ANGLE;
    }

    private void updateRotationTracker() {
        if (mc.player == null) {
            rotationPrimed = false;
            return;
        }
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        if (rotationPrimed) {
            lastDeltaPitch = Math.abs(pitch - prevPitch);
        } else {
            lastDeltaPitch = Float.MAX_VALUE;
        }
        prevYaw = yaw;
        prevPitch = pitch;
        rotationPrimed = true;
    }

    private void markInteraction() {
        if (!rotationPrimed) {
            return;
        }
        lastInteractionPitchDelta = lastDeltaPitch;
        hasInteractionPitchDelta = true;
    }

    private boolean isDuplicateRotPlaceSafe() {
        if (!rotationPrimed) {
            return false;
        }
        if (lastDeltaPitch < ROTATION_SETTLE_THRESHOLD) {
            return true;
        }
        return !hasInteractionPitchDelta || Math.abs(lastDeltaPitch - lastInteractionPitchDelta) >= 0.001F;
    }

    private boolean isReadyToPlace(PlacementHit placementHit, float tickDelta) {
        if (strictPlace.isEnabled() && !isDuplicateRotPlaceSafe()) {
            return false;
        }
        if (!strictPlace.isEnabled()) {
            return true;
        }
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        BlockPos expected = placementHit.hitResult().getBlockPos();
        BlockHitResult hit = raycastFromRotation(yaw, pitch, tickDelta);
        if (hit == null || hit.getType() != HitResult.Type.BLOCK) {
            return false;
        }
        if (!hit.getBlockPos().equals(expected)) {
            return false;
        }
        return hit.getSide() == placementHit.hitResult().getSide();
    }

    private ActionResult interact(BlockHitResult hit) {
        ActionResult result = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hit);
        if (result.isAccepted()) {
            mc.player.swingHand(Hand.MAIN_HAND);
        }
        return result;
    }

    private LivingEntity findTarget() {
        LivingEntity auraTarget = AttackAura.INSTANCE.isEnabled() ? AttackAura.INSTANCE.getTarget() : null;
        if (auraTarget != null && auraTarget.isAlive()) {
            return auraTarget;
        }
        return mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        mc.player.getBoundingBox().expand(6.0D),
                        this::isValidTarget)
                .stream()
                .min(Comparator.comparingDouble(entity -> entity.squaredDistanceTo(mc.player)))
                .orElse(null);
    }

    private boolean isValidTarget(LivingEntity entity) {
        if (entity == null || entity == mc.player || !entity.isAlive() || entity instanceof ArmorStandEntity) {
            return false;
        }
        if (!(entity instanceof PlayerEntity player)) {
            return false;
        }
        return !SkyInit.getInstance().getFriendManager().isFriend(player.getName().getString())
                && !AntiBot.isBot(player);
    }

    private PlacementHit getCachedOrFindPlacement(float tickDelta) {
        LivingEntity target = findTarget();
        if (target == null) {
            invalidatePlacementCache();
            return null;
        }
        if (cachedPlacement != null
                && cachedPlacementTarget == target
                && mc.player.age - cachedPlacementAge <= 2
                && isValidPlacement(cachedPlacement.placementPos())
                && !target.getBoundingBox().intersects(new Box(cachedPlacement.placementPos()))) {
            return cachedPlacement;
        }
        PlacementHit hit = findBestPlacementHit(tickDelta, target);
        cachedPlacement = hit;
        cachedPlacementAge = mc.player.age;
        cachedPlacementTarget = target;
        return hit;
    }

    private void invalidatePlacementCache() {
        cachedPlacement = null;
        cachedPlacementAge = -1;
        cachedPlacementTarget = null;
    }

    private PlacementHit findBestPlacementHit(float tickDelta, LivingEntity target) {
        if (mc.player == null || mc.world == null || target == null) {
            return null;
        }

        Vec3d eyePos = mc.player.getCameraPosVec(tickDelta);
        double range = mc.player.getBlockInteractionRange();
        double rangeSq = range * range;
        Vec3d lerpedPos = target.getLerpedPos(tickDelta);
        Box targetBox = target.getBoundingBox().offset(lerpedPos.subtract(target.getPos()));
        Vec3d feet = new Vec3d(lerpedPos.x, targetBox.minY, lerpedPos.z);
        int baseX = MathHelper.floor(feet.x);
        int baseY = MathHelper.floor(feet.y);
        int baseZ = MathHelper.floor(feet.z);

        PlacementHit best = null;
        double bestScore = Double.MAX_VALUE;
        for (int offsetX = -2; offsetX <= 2; offsetX++) {
            for (int offsetZ = -2; offsetZ <= 2; offsetZ++) {
                for (int offsetY = -1; offsetY <= 1; offsetY++) {
                    if (offsetX == 0 && offsetZ == 0 && offsetY >= 0 && offsetY <= 1) {
                        continue;
                    }
                    BlockPos pos = new BlockPos(baseX + offsetX, baseY + offsetY, baseZ + offsetZ);
                    if (!isValidPlacement(pos) || !hasSupportingFace(pos)) {
                        continue;
                    }
                    Box placementBox = new Box(pos);
                    if (targetBox.intersects(placementBox) || collidesWithPlayer(pos) || hasBlockingEntity(placementBox)) {
                        continue;
                    }
                    PlacementHit hit = findPlacementHit(pos, false);
                    if (hit == null) {
                        continue;
                    }
                    if (eyePos.squaredDistanceTo(hit.hitResult().getPos()) > rangeSq) {
                        continue;
                    }
                    Vec3d center = Vec3d.ofCenter(pos);
                    double feetDistSq = feet.squaredDistanceTo(center);
                    double hitDistSq = eyePos.squaredDistanceTo(hit.hitResult().getPos());
                    double score = feetDistSq + hitDistSq * 0.05D + Math.abs(offsetY) * 0.35D;
                    if (score < bestScore) {
                        bestScore = score;
                        best = hit;
                    }
                }
            }
        }
        return best;
    }

    private PlacementHit findPlacementHit(BlockPos placementPos, boolean requireRaycast) {
        Vec3d eyePos = mc.player.getEyePos();
        PlacementHit best = null;
        double bestDist = Double.MAX_VALUE;
        for (Direction direction : Direction.values()) {
            BlockPos adjacent = placementPos.offset(direction);
            Direction face = direction.getOpposite();
            if (!mc.world.getBlockState(adjacent).isSideSolidFullSquare(mc.world, adjacent, face)) {
                continue;
            }
            PlacementHit hit = findPlacementHitOnFace(eyePos, placementPos, adjacent, direction, face, requireRaycast);
            if (hit == null) {
                continue;
            }
            double dist = eyePos.squaredDistanceTo(hit.hitResult().getPos());
            if (dist < bestDist) {
                bestDist = dist;
                best = hit;
            }
        }
        return best;
    }

    private PlacementHit findPlacementHitOnFace(
            Vec3d eyePos,
            BlockPos placementPos,
            BlockPos adjacent,
            Direction direction,
            Direction face,
            boolean requireRaycast) {
        for (double[] offset : PLACE_FACE_SAMPLE_OFFSETS) {
            Vec3d sample = getFaceSamplePoint(adjacent, face, offset[0], offset[1]);
            BlockHitResult hitResult = new BlockHitResult(sample, face, adjacent, false);
            if (requireRaycast && !canRaycastPlacementFace(eyePos, hitResult, direction)) {
                continue;
            }
            return new PlacementHit(placementPos, hitResult);
        }
        return null;
    }

    private boolean canRaycastPlacementFace(Vec3d eyePos, BlockHitResult placementHit, Direction direction) {
        Vec3d hitPos = placementHit.getPos();
        Vec3d nudged = hitPos.add(
                direction.getOffsetX() * PLACE_RAY_EPSILON,
                direction.getOffsetY() * PLACE_RAY_EPSILON,
                direction.getOffsetZ() * PLACE_RAY_EPSILON);
        BlockHitResult hit = mc.world.raycast(new RaycastContext(
                eyePos,
                nudged,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                mc.player));
        if (hit.getType() != HitResult.Type.BLOCK) {
            return false;
        }
        if (!hit.getBlockPos().equals(placementHit.getBlockPos())) {
            return false;
        }
        return hit.getSide() == placementHit.getSide();
    }

    private Vec3d getFaceSamplePoint(BlockPos pos, Direction direction, double offsetA, double offsetB) {
        Vec3d face = Vec3d.ofCenter(pos).add(
                direction.getOffsetX() * 0.5D,
                direction.getOffsetY() * 0.5D,
                direction.getOffsetZ() * 0.5D);
        return switch (direction.getAxis()) {
            case X -> face.add(0.0D, offsetA, offsetB);
            case Y -> face.add(offsetA, 0.0D, offsetB);
            case Z -> face.add(offsetA, offsetB, 0.0D);
        };
    }

    private boolean isValidPlacement(BlockPos pos) {
        if (pos == null || mc.world == null || !mc.world.isInBuildLimit(pos)) {
            return false;
        }
        BlockState state = mc.world.getBlockState(pos);
        return state.isAir() || state.isReplaceable();
    }

    private boolean isManualPlacementValid(BlockPos pos) {
        return isValidPlacement(pos) && !collidesWithPlayer(pos) && !hasBlockingEntity(new Box(pos));
    }

    private boolean hasSupportingFace(BlockPos pos) {
        for (Direction direction : Direction.values()) {
            BlockPos adjacent = pos.offset(direction);
            if (mc.world.getBlockState(adjacent).isSideSolidFullSquare(mc.world, adjacent, direction.getOpposite())) {
                return true;
            }
        }
        return false;
    }

    private boolean collidesWithPlayer(BlockPos pos) {
        return mc.player != null && mc.player.getBoundingBox().intersects(new Box(pos));
    }

    private boolean hasBlockingEntity(Box box) {
        for (Entity entity : mc.world.getOtherEntities(mc.player, box)) {
            if (entity.isRemoved()) {
                continue;
            }
            if (entity instanceof LivingEntity || entity.isCollidable()) {
                return true;
            }
        }
        return false;
    }

    private boolean isRespawnAnchor(BlockPos pos) {
        return pos != null && mc.world != null && mc.world.getBlockState(pos).isOf(Blocks.RESPAWN_ANCHOR);
    }

    private boolean isAnchorWithinRange(BlockPos pos) {
        if (mc.player == null || pos == null) {
            return false;
        }
        double range = mc.player.getBlockInteractionRange() + 1.0D;
        return mc.player.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= range * range;
    }

    private int getAnchorCharge(BlockPos pos) {
        if (!isRespawnAnchor(pos)) {
            return 0;
        }
        return mc.world.getBlockState(pos).get(RespawnAnchorBlock.CHARGES);
    }

    private Vec3d getAnchorAimPoint(BlockPos pos) {
        if (pos == null) {
            return null;
        }
        if (mc.player == null) {
            return Vec3d.ofCenter(pos);
        }
        if (cachedAnchorAim != null && pos.equals(activeAnchorPos)) {
            Vec3d eyePos = mc.player.getEyePos();
            if (AnchorAimUtil.canHitAnchor(eyePos, cachedAnchorAim, pos)) {
                return cachedAnchorAim;
            }
            cachedAnchorAim = AnchorAimUtil.findClearAimPoint(pos, 1.0F);
            return cachedAnchorAim != null ? cachedAnchorAim : Vec3d.ofCenter(pos);
        }
        Vec3d point = AnchorAimUtil.findClearAimPoint(pos, 1.0F);
        return point != null ? point : Vec3d.ofCenter(pos);
    }

    private BlockHitResult getReadyAnchorHit(BlockPos pos) {
        if (!isAnchorWithinRange(pos)) {
            return null;
        }
        if (strictPlace.isEnabled() && !isDuplicateRotPlaceSafe()) {
            return null;
        }
        if (!strictPlace.isEnabled()) {
            return new BlockHitResult(getAnchorAimPoint(pos), Direction.UP, pos, false);
        }
        BlockHitResult crosshair = currentBlockHit();
        if (crosshair != null && crosshair.getBlockPos().equals(pos)) {
            return crosshair;
        }
        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        BlockHitResult hit = raycastFromRotation(yaw, pitch, 1.0F);
        if (hit == null || hit.getType() != HitResult.Type.BLOCK) {
            return null;
        }
        if (!hit.getBlockPos().equals(pos)) {
            return null;
        }
        return hit;
    }

    private BlockHitResult raycastFromRotation(float yaw, float pitch, float tickDelta) {
        Vec3d start = mc.player.getCameraPosVec(tickDelta);
        Vec3d look = Vec3d.fromPolar(pitch, yaw);
        double range = mc.player.getBlockInteractionRange();
        Vec3d end = start.add(look.multiply(range));
        return mc.world.raycast(new RaycastContext(
                start,
                end,
                RaycastContext.ShapeType.OUTLINE,
                RaycastContext.FluidHandling.NONE,
                mc.player));
    }

    private boolean rayIntersectsBlock(float yaw, float pitch, BlockPos pos, float tickDelta) {
        BlockHitResult hit = raycastFromRotation(yaw, pitch, tickDelta);
        return hit != null && hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos);
    }

    private PlacementHit trySafetyPlacementAt(BlockPos pos) {
        if (pos == null || pos.equals(activeAnchorPos) || mc.world == null || mc.player == null) {
            return null;
        }
        if (!isValidPlacement(pos)) {
            return null;
        }
        Box box = new Box(pos);
        if (mc.player.getBoundingBox().intersects(box) || hasBlockingEntity(box)) {
            return null;
        }
        PlacementHit hit = findPlacementHit(pos, false);
        if (hit == null) {
            BlockPos below = pos.down();
            BlockState belowState = mc.world.getBlockState(below);
            if (belowState.isAir() || belowState.isReplaceable()) {
                return null;
            }
            Vec3d sample = Vec3d.ofCenter(below).add(0.0D, 0.5D, 0.0D);
            hit = new PlacementHit(pos, new BlockHitResult(sample, Direction.UP, below, false));
        }
        Vec3d eyePos = mc.player.getEyePos();
        double range = mc.player.getBlockInteractionRange();
        if (eyePos.squaredDistanceTo(hit.hitResult().getPos()) > range * range) {
            return null;
        }
        return hit;
    }

    private PlacementHit pickSafetyPlacement(List<BlockPos> ranked) {
        for (BlockPos pos : ranked) {
            PlacementHit hit = trySafetyPlacementAt(pos);
            if (hit != null) {
                return hit;
            }
        }
        return null;
    }

    private List<BlockPos> rankedSafetyCandidates() {
        List<BlockPos> ranked = new ArrayList<>();
        if (mc.player == null || activeAnchorPos == null) {
            return ranked;
        }

        BlockPos playerPos = BlockPos.ofFloored(mc.player.getX(), mc.player.getY(), mc.player.getZ());
        Vec3d playerCenter = Vec3d.ofCenter(playerPos);
        Vec3d anchorCenter = Vec3d.ofCenter(activeAnchorPos);
        double deltaX = anchorCenter.x - playerCenter.x;
        double deltaZ = anchorCenter.z - playerCenter.z;
        int signX = (int) Math.signum(deltaX);
        int signZ = (int) Math.signum(deltaZ);

        for (int dist = 1; dist <= 2; dist++) {
            if (signX != 0 || signZ != 0) {
                ranked.add(playerPos.add(signX * dist, 0, signZ * dist));
            }
            if (signX != 0) {
                ranked.add(playerPos.add(signX * dist, 0, 0));
            }
            if (signZ != 0) {
                ranked.add(playerPos.add(0, 0, signZ * dist));
            }
        }

        for (int offsetX = -2; offsetX <= 2; offsetX++) {
            for (int offsetZ = -2; offsetZ <= 2; offsetZ++) {
                if (offsetX == 0 && offsetZ == 0) {
                    continue;
                }
                BlockPos candidate = playerPos.add(offsetX, 0, offsetZ);
                Vec3d offset = Vec3d.ofCenter(candidate).subtract(playerCenter);
                if (offset.x * deltaX + offset.z * deltaZ <= 0.0D) {
                    continue;
                }
                ranked.add(candidate);
            }
        }

        List<BlockPos> unique = new ArrayList<>();
        for (BlockPos pos : ranked) {
            if (!unique.contains(pos) && !pos.equals(activeAnchorPos)) {
                unique.add(pos);
            }
        }
        unique.sort(Comparator.comparingDouble(pos -> Vec3d.ofCenter(pos).squaredDistanceTo(anchorCenter)));
        return unique;
    }

    private boolean hasExistingSafetyBlock(BlockPos pos) {
        if (pos == null || mc.world == null) {
            return false;
        }
        BlockState state = mc.world.getBlockState(pos);
        return !state.isAir() && !state.isReplaceable();
    }

    private int rollDelay(NumberSetting delaySetting) {
        return Math.max(0, Math.round(delaySetting.getCurrent()));
    }

    private int rollChargeCount() {
        return MathHelper.clamp(Math.round(charges.getCurrent()), 1, MAX_ANCHOR_CHARGES);
    }

    private boolean isBindDown(int key) {
        if (key == -1 || mc.getWindow() == null) {
            return false;
        }
        long handle = mc.getWindow().getHandle();
        if (key <= GLFW.GLFW_MOUSE_BUTTON_LAST) {
            return GLFW.glfwGetMouseButton(handle, key) == GLFW.GLFW_PRESS;
        }
        return GLFW.glfwGetKey(handle, key) == GLFW.GLFW_PRESS;
    }

    private float getSeenPercent(Vec3d explosionCenter, Box targetBox, Entity entity) {
        double stepX = 1.0D / (targetBox.getLengthX() * 2.0D + 1.0D);
        double stepY = 1.0D / (targetBox.getLengthY() * 2.0D + 1.0D);
        double stepZ = 1.0D / (targetBox.getLengthZ() * 2.0D + 1.0D);
        if (stepX <= 0.0D || stepY <= 0.0D || stepZ <= 0.0D) {
            return 0.0F;
        }
        double offsetX = (1.0D - Math.floor(1.0D / stepX) * stepX) / 2.0D;
        double offsetZ = (1.0D - Math.floor(1.0D / stepZ) * stepZ) / 2.0D;
        int misses = 0;
        int samples = 0;
        for (double x = 0.0D; x <= 1.0D; x += stepX) {
            for (double y = 0.0D; y <= 1.0D; y += stepY) {
                for (double z = 0.0D; z <= 1.0D; z += stepZ) {
                    Vec3d sample = new Vec3d(
                            MathHelper.lerp(x, targetBox.minX, targetBox.maxX) + offsetX,
                            MathHelper.lerp(y, targetBox.minY, targetBox.maxY),
                            MathHelper.lerp(z, targetBox.minZ, targetBox.maxZ) + offsetZ);
                    BlockHitResult hit = mc.world.raycast(new RaycastContext(
                            sample,
                            explosionCenter,
                            RaycastContext.ShapeType.COLLIDER,
                            RaycastContext.FluidHandling.NONE,
                            entity));
                    if (hit.getType() == HitResult.Type.MISS) {
                        misses++;
                    }
                    samples++;
                }
            }
        }
        return samples == 0 ? 0.0F : (float) misses / (float) samples;
    }

    private float getAnchorDamageTo(LivingEntity victim, BlockPos pos) {
        Vec3d center = Vec3d.ofCenter(pos);
        float diameter = 5.0F * 2.0F;
        double distanceFactor = Math.sqrt(victim.squaredDistanceTo(center)) / (double) diameter;
        if (distanceFactor > 1.0D) {
            return 0.0F;
        }
        float exposure = getSeenPercent(center, victim.getBoundingBox(), victim);
        double impact = (1.0D - distanceFactor) * (double) exposure;
        float damage = (float) ((impact * impact + impact) / 2.0D * 7.0D * (double) diameter + 1.0D);
        float armor = victim.getArmor();
        float toughness = (float) victim.getAttributeValue(EntityAttributes.ARMOR_TOUGHNESS);
        float toughnessDivisor = 2.0F + toughness / 4.0F;
        float reduction = MathHelper.clamp(armor - damage / toughnessDivisor, armor * 0.2F, 20.0F);
        return damage * (1.0F - reduction / 25.0F);
    }

    enum AnchorStep {
        PLACE_SAFETY,
        CHARGE,
        EXPLODE
    }

    record PlacementHit(BlockPos placementPos, BlockHitResult hitResult) {
    }
}
