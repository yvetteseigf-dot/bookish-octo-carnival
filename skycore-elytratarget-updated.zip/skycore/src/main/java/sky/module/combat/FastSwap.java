package sky.module.combat;

import com.darkmagician6.eventapi.EventTarget;
import java.util.EnumMap;
import java.util.Map;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;
import sky.config.BooleanSetting;
import sky.camera.FreeLookCamera;
import sky.config.KeybindSetting;
import sky.misc.MovementBlocker;
import sky.rotation.RotationManager;
import sky.event.player.PlayerUpdateEvent;
import sky.event.input.StrafeInputEvent;
import sky.event.input.KeyInputEvent;
import sky.module.Category;
import sky.module.Module;
import sky.module.movement.Sprint;
import sky.util.FreeLookUtil;
import sky.util.entity.MovementUtil;
import sky.util.entity.PlayerUtil;
import sky.util.combat.Rotation;

public final class FastSwap extends Module {
    private static final int STOP_TICKS = 3;
    private static final int BUSY_TICKS = 4;

    public static final FastSwap INSTANCE = new FastSwap();

    private final BooleanSetting healing;
    private final KeybindSetting healingKey;
    private final BooleanSetting slowFalling;
    private final KeybindSetting slowFallingKey;
    private final BooleanSetting weakness;
    private final KeybindSetting weaknessKey;
    private final BooleanSetting jumpBoost;
    private final KeybindSetting jumpBoostKey;
    private final BooleanSetting chorus;
    private final KeybindSetting chorusKey;

    private final Map<BindType, SwapMemory> memories;
    private Pending pending;
    private int movementStopTicks;
    private int busyTicks;

    private FastSwap() {
        super("FastSwap", "Fast swap on bind", Category.COMBAT);
        this.healing = new BooleanSetting("Healing potion", true);
        this.healingKey = new KeybindSetting("Healing bind", -98, healing::isEnabled);
        this.slowFalling = new BooleanSetting("Slow falling", true);
        this.slowFallingKey = new KeybindSetting("Slow falling bind", -98, slowFalling::isEnabled);
        this.weakness = new BooleanSetting("Weakness", true);
        this.weaknessKey = new KeybindSetting("Weakness bind", -98, weakness::isEnabled);
        this.jumpBoost = new BooleanSetting("Jump boost", true);
        this.jumpBoostKey = new KeybindSetting("Jump boost bind", -98, jumpBoost::isEnabled);
        this.chorus = new BooleanSetting("Chorus fruit", true);
        this.chorusKey = new KeybindSetting("Chorus bind", -98, chorus::isEnabled);
        this.memories = new EnumMap<>(BindType.class);
        addSettings(healing, healingKey, slowFalling, slowFallingKey, weakness, weaknessKey,
                jumpBoost, jumpBoostKey, chorus, chorusKey);
        for (BindType type : BindType.values()) {
            memories.put(type, new SwapMemory());
        }
    }

    @Override
    protected void onDisable() {
        pending = null;
        movementStopTicks = 0;
        busyTicks = 0;
        for (SwapMemory memory : memories.values()) {
            memory.clear();
        }
        super.onDisable();
    }

    public boolean isBusy() {
        if (!isEnabled() || busyTicks <= 0) {
            return false;
        }
        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
            return false;
        }
        return true;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null || mc.interactionManager == null || mc.getNetworkHandler() == null) {
            return;
        }

        if (busyTicks > 0) {
            busyTicks--;
        }
        if (movementStopTicks > 0) {
            movementStopTicks--;
        }

        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
            pending = null;
            busyTicks = 0;
            return;
        }

        if (pending == null || movementStopTicks > 0 || MovementUtil.hasPlayerMovement()) {
            return;
        }

        Pending queued = pending;
        pending = null;
        if (queued.restore()) {
            restoreSwap(queued.type());
        } else {
            executeUse(queued.type());
        }
    }

    @EventTarget
    private void onKey(KeyInputEvent event) {
        if (mc.player == null || mc.world == null || mc.currentScreen != null || !event.isHold()) {
            return;
        }

        if (pending != null || busyTicks > 0) {
            return;
        }

        if (AutoTotem.INSTANCE.isEnabled() && AutoTotem.INSTANCE.needsTotem()) {
            return;
        }

        BindType type = typeForKey(event.getKey());
        if (type == null) {
            return;
        }

        SwapMemory memory = memories.get(type);
        if (memory.active) {
            pending = Pending.restore(type);
            movementStopTicks = STOP_TICKS;
            return;
        }

        if (findItemSlot(type.action(), -1) == -1) {
            return;
        }

        pending = Pending.use(type);
        movementStopTicks = STOP_TICKS;
    }

    @EventTarget
    private void onMoveInput(StrafeInputEvent event) {
        if (movementStopTicks <= 0) {
            return;
        }

        event.setForward(0.0F);
        event.setStrafe(0.0F);
        if (event.getInput() != null) {
            event.setInput(new PlayerInput(false, false, false, false, false, false, event.getInput().sprint()));
        }
    }

    private BindType typeForKey(int key) {
        if (healing.isEnabled() && key == healingKey.getKeyCode()) {
            return BindType.HEALING;
        }
        if (slowFalling.isEnabled() && key == slowFallingKey.getKeyCode()) {
            return BindType.SLOW_FALLING;
        }
        if (weakness.isEnabled() && key == weaknessKey.getKeyCode()) {
            return BindType.WEAKNESS;
        }
        if (jumpBoost.isEnabled() && key == jumpBoostKey.getKeyCode()) {
            return BindType.JUMP_BOOST;
        }
        if (chorus.isEnabled() && key == chorusKey.getKeyCode()) {
            return BindType.CHORUS;
        }
        return null;
    }

    private void executeUse(BindType type) {
        if (AutoTotem.INSTANCE.isEnabled() && (AutoTotem.INSTANCE.needsTotem() || AutoTotem.INSTANCE.isBusy())) {
            return;
        }

        SwapAction action = type.action();
        int selected = mc.player.getInventory().selectedSlot;
        int itemSlot = findItemSlot(action, -1);
        if (itemSlot == -1) {
            return;
        }

        busyTicks = BUSY_TICKS;
        boolean auraTargeting = AttackAura.INSTANCE.isEnabled() && AttackAura.INSTANCE.getTarget() != null;
        boolean freeLook = FreeLookCamera.isActive() || auraTargeting;

        float restoreYaw;
        float restorePitch;
        if (freeLook) {
            restoreYaw = FreeLookCamera.getFreeYaw();
            restorePitch = FreeLookCamera.getFreePitch();
        } else {
            restoreYaw = mc.player.getYaw();
            restorePitch = mc.player.getPitch();
        }

        float yaw = mc.player.getYaw();
        float pitch = mc.player.getPitch();
        if (action.throwable()) {
            LivingEntity target = AttackAura.INSTANCE.getTarget();
            if (target != null) {
                Rotation rotation = Rotation.lookingAt(
                        target.getPos().add(0.0, target.getHeight() * 0.5, 0.0),
                        mc.player.getEyePos());
                yaw = rotation.getYaw();
                pitch = rotation.getPitch();
            }
            sendLook(yaw, pitch);
        }

        SwapMemory memory = memories.get(type);
        if (itemSlot != selected) {
            swapSlots(itemSlot, selected);
            memory.active = true;
            memory.otherSlot = itemSlot;
            memory.selectedSlot = selected;
        } else {
            memory.clear();
        }

        useItem(yaw, pitch);
        if (action.throwable()) {
            sendLook(restoreYaw, restorePitch);
        }

        if (auraTargeting || freeLook) {
            RotationManager.instance.stopRotation();
            FreeLookCamera.setActive(true);
            FreeLookCamera.setFreeYaw(restoreYaw);
            FreeLookCamera.setFreePitch(restorePitch);
            FreeLookUtil.snapToFreeLook();
        }
    }

    private void restoreSwap(BindType type) {
        SwapMemory memory = memories.get(type);
        if (!memory.active) {
            return;
        }

        busyTicks = BUSY_TICKS;
        swapSlots(memory.otherSlot, memory.selectedSlot);
        memory.clear();
    }

    private void swapSlots(int selected, int otherSlot) {
        if (MovementUtil.hasPlayerMovement()) {
            MovementBlocker.stopTicks = 3;
        }

        boolean wasSprinting = false;
        if (mc.player.isSprinting()) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(
                    new PlayerInput(false, false, false, false, false, false, false)));
            mc.player.setSprinting(false);
            mc.getNetworkHandler().sendPacket(
                    new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (!Sprint.INSTANCE.isEnabled()) {
                mc.options.sprintKey.setPressed(false);
            }
            wasSprinting = true;
        }

        int syncId = mc.player.currentScreenHandler.syncId;
        int slot = selected < 9 ? selected + 36 : selected;
        mc.interactionManager.clickSlot(syncId, slot, otherSlot, SlotActionType.SWAP, mc.player);

        if (wasSprinting) {
            mc.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(mc.player.input.playerInput));
        }
    }

    private int findItemSlot(SwapAction action, int excludeSlot) {
        for (int slot = 0; slot < 36; slot++) {
            if (slot == excludeSlot) {
                continue;
            }
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (action.matches(stack)) {
                return slot;
            }
        }
        return -1;
    }

    private void sendLook(float yaw, float pitch) {
        mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.Full(
                mc.player.getX(),
                mc.player.getY(),
                mc.player.getZ(),
                yaw,
                pitch,
                mc.player.isOnGround(),
                mc.player.horizontalCollision));
    }

    private void useItem(float yaw, float pitch) {
        PlayerUtil.sendSequencedPacket(
                sequence -> new PlayerInteractItemC2SPacket(Hand.MAIN_HAND, sequence, yaw, pitch));
    }

    enum BindType {
        HEALING,
        SLOW_FALLING,
        WEAKNESS,
        JUMP_BOOST,
        CHORUS;

        SwapAction action() {
            return switch (this) {
                case HEALING -> SwapAction.drink(StatusEffects.INSTANT_HEALTH);
                case SLOW_FALLING -> SwapAction.splash(StatusEffects.SLOW_FALLING);
                case WEAKNESS -> SwapAction.splash(StatusEffects.WEAKNESS);
                case JUMP_BOOST -> SwapAction.splash(StatusEffects.JUMP_BOOST);
                case CHORUS -> SwapAction.item(Items.CHORUS_FRUIT);
            };
        }
    }

    record Pending(BindType type, boolean restore) {
        static Pending use(BindType type) {
            return new Pending(type, false);
        }

        static Pending restore(BindType type) {
            return new Pending(type, true);
        }
    }

    record SwapAction(Item item, RegistryEntry<StatusEffect> effect, boolean throwable) {
        static SwapAction item(Item item) {
            return new SwapAction(item, null, false);
        }

        static SwapAction splash(RegistryEntry<StatusEffect> effect) {
            return new SwapAction(Items.SPLASH_POTION, effect, true);
        }

        static SwapAction drink(RegistryEntry<StatusEffect> effect) {
            return new SwapAction(Items.POTION, effect, false);
        }

        boolean matches(ItemStack stack) {
            if (stack.isEmpty() || !stack.isOf(item)) {
                return false;
            }
            if (effect == null) {
                return true;
            }

            PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
            if (contents == null) {
                return false;
            }

            for (StatusEffectInstance instance : contents.getEffects()) {
                if (instance.getEffectType().equals(effect)) {
                    return true;
                }
            }
            return false;
        }
    }

    static final class SwapMemory {
        int selectedSlot;
        int otherSlot;
        boolean active;

        private SwapMemory() {
            this.otherSlot = -1;
            this.selectedSlot = -1;
        }

        void clear() {
            active = false;
            otherSlot = -1;
            selectedSlot = -1;
        }
    }
}
