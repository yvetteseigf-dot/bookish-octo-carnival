package sky.waypoint;

/** A named two-dimensional world waypoint. */
public final class Waypoint {
    private String name;
    private final double x;
    private final double z;

    public Waypoint(String name, double x, double z) {
        this.name = name;
        this.x = x;
        this.z = z;
    }

    public Waypoint(double x, double z) {
        this.x = x;
        this.z = z;
    }

    public String getName() {
        return name;
    }

    public double getX() {
        return x;
    }

    public double getZ() {
        return z;
    }
}
