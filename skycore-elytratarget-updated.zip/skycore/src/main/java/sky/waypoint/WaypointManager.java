package sky.waypoint;

/** Holds the regular and player-specific active waypoint. */
public final class WaypointManager {
    private Waypoint activePlayerWaypoint;
    private Waypoint activeWaypoint;

    public WaypointManager() {
        activeWaypoint = null;
        activePlayerWaypoint = null;
    }

    public boolean isEmptyPlayerWaypoint() {
        return activePlayerWaypoint == null;
    }

    public void clearPlayerWaypoint() {
        activePlayerWaypoint = null;
    }

    public void set(Waypoint waypoint) {
        activeWaypoint = waypoint;
    }

    public void setPlayerWaypoint(Waypoint waypoint) {
        activePlayerWaypoint = waypoint;
    }

    public Waypoint getActiveWaypoint() {
        return activeWaypoint;
    }

    public boolean isEmpty() {
        return activeWaypoint == null;
    }

    public Waypoint getActivePlayerWaypoint() {
        return activePlayerWaypoint;
    }

    public void clear() {
        activeWaypoint = null;
    }
}
