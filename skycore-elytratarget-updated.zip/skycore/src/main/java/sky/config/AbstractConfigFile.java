package sky.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import sky.util.EncryptionUtil;

import java.io.File;
import java.nio.file.Files;

public abstract class AbstractConfigFile<T> {
    protected static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    protected final File configFile;
    protected final boolean encrypt;
    protected T data;

    protected AbstractConfigFile(String relativePath) {
        this(relativePath, true);
    }

    protected AbstractConfigFile(String relativePath, boolean encrypt) {
        this.configFile = new File(ClientPaths.BASE_PATH + relativePath);
        this.encrypt = encrypt;
    }

    public void init() {
        createDirectoriesIfNeeded();
        initializeData();
        load();
    }

    protected abstract void initializeData();

    public T getData() {
        return data;
    }

    public void load() {
        if (!configFile.exists()) {
            return;
        }

        try {
            String serialized = Files.readString(configFile.toPath());
            String json = encrypt ? EncryptionUtil.decrypt(serialized) : serialized;
            deserializeData(JsonParser.parseString(json).getAsJsonObject());
        } catch (Exception exception) {
            System.err.println("Could not load " + configFile.getName() + ": " + exception.getMessage());
            handleLoadError(exception);
        }
    }

    public boolean exists() {
        return configFile.exists();
    }

    public boolean delete() {
        return configFile.exists() && configFile.delete();
    }

    public void save() {
        try {
            createDirectoriesIfNeeded();
            String json = GSON.toJson(serializeData());
            String serialized = encrypt ? EncryptionUtil.encrypt(json) : json;
            Files.writeString(configFile.toPath(), serialized);
        } catch (Exception exception) {
            System.err.println("Could not save " + configFile.getName() + ": " + exception.getMessage());
            handleSaveError(exception);
        }
    }

    protected void createDirectoriesIfNeeded() {
        File parent = configFile.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }
    }

    protected void handleSaveError(Exception exception) {
    }

    protected void handleLoadError(Exception exception) {
    }

    protected abstract JsonObject serializeData();

    protected abstract void deserializeData(JsonObject object);

    public String getConfigPath() {
        return configFile.getAbsolutePath();
    }
}
