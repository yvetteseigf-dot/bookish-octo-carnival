package sky.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public final class ModeSetting extends Setting<String> {
    private final List<String> modes = new ArrayList<>();

    public ModeSetting(String name, String defaultValue, String... modes) {
        super(name, defaultValue);
        if (modes.length > 0) {
            Collections.addAll(this.modes, modes);
        } else if (defaultValue != null && !defaultValue.isEmpty()) {
            this.modes.add(defaultValue);
        }
    }

    public ModeSetting(String name, String defaultValue, Supplier<Boolean> visibleSupplier, String... modes) {
        this(name, defaultValue, modes);
        visible(visibleSupplier);
    }

    public ModeSetting(String name, Supplier<Boolean> visibleSupplier, String... modes) {
        this(name, modes.length > 0 ? modes[0] : "", modes);
        visible(visibleSupplier);
    }

    public void cycle() {
        if (modes.isEmpty()) {
            return;
        }
        int currentIndex = 0;
        for (int index = 0; index < modes.size(); index++) {
            if (modes.get(index).equalsIgnoreCase(get())) {
                currentIndex = index;
                break;
            }
        }
        set(modes.get((currentIndex + 1) % modes.size()));
    }

    public void select(String mode) {
        for (String candidate : modes) {
            if (candidate.equalsIgnoreCase(mode)) {
                set(candidate);
                return;
            }
        }
    }

    public String[] getModes() {
        return modes.toArray(new String[0]);
    }

    public boolean is(String mode) {
        return get().equalsIgnoreCase(mode);
    }

    /** A single mode of a {@link ModeSetting}, registering itself with its parent on construction. */
    public static final class Value {
        private final String name;
        private final ModeSetting parent;

        public Value(ModeSetting parent, String name) {
            this.parent = parent;
            this.name = name;
            if (!parent.modes.contains(name)) {
                parent.modes.add(name);
            }
            if (parent.get().isEmpty()) {
                select();
            }
        }

        public String getName() {
            return name;
        }

        public Value select() {
            parent.select(name);
            return this;
        }

        public boolean isSelected() {
            return parent.is(name);
        }
    }
}
