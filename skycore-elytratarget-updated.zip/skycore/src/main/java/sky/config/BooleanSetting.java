package sky.config;

import java.util.function.Supplier;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String name, boolean defaultValue) {
        super(name, defaultValue);
    }

    public BooleanSetting(String name, boolean defaultValue, Supplier<Boolean> visibleSupplier) {
        super(name, defaultValue);
        visible(visibleSupplier);
    }

    public void setEnabled(boolean enabled) {
        set(enabled);
    }

    public boolean isEnabled() {
        return get();
    }
}
