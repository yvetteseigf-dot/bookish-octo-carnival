package sky.config;

import net.minecraft.util.math.MathHelper;

import java.util.function.Supplier;

public final class NumberSetting extends Setting<Float> {
    private final float step;
    private final float max;
    private final float min;

    public NumberSetting(String name, float defaultValue, float min, float max, float step) {
        super(name, defaultValue);
        this.min = min;
        this.max = max;
        this.step = step;
    }

    public NumberSetting(String name, float defaultValue, float min, float max, float step,
                         Supplier<Boolean> visibleSupplier) {
        this(name, defaultValue, min, max, step);
        visible(visibleSupplier);
    }

    public float getCurrent() {
        return get();
    }

    public float getStep() {
        return step;
    }

    public float getMin() {
        return min;
    }

    public float getMax() {
        return max;
    }

    public void setClamped(float value) {
        float clamped = MathHelper.clamp(value, min, max);
        if (step > 0.0F) {
            clamped = Math.round(clamped / step) * step;
        }
        set(clamped);
    }
}
