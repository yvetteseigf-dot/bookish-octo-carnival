package sky.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import sky.SkyInit;
import sky.render.GradientMode;
import sky.clickgui.GuiStyle;
import sky.hud.HudEditor;
import sky.util.EncryptionUtil;

import java.nio.file.Files;
import sky.hud.HudManager;
import sky.theme.GuiTheme;
import sky.theme.ThemeRegistry;

/** Client-wide persisted settings: module state, HUD layout, theme and GUI style. */
public final class ClientSettingsFile extends AbstractConfigFile<ClientSettingsFile.ClientConfigData> {
    public ClientSettingsFile() {
        super(ClientPaths.CLIENT_CONFIG_FILE_REL);
    }

    @Override
    protected void initializeData() {
        data = new ClientConfigData();
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        object.add("modules", ConfigSerializer.saveModules());

        if (data.getSelectedConfig() != null) {
            object.addProperty("selectedConfig", data.getSelectedConfig());
        }

        String selectedTheme = data.getSelectedTheme();
        if (selectedTheme == null || selectedTheme.isEmpty()) {
            selectedTheme = ThemeRegistry.getCurrent().getId();
        }
        object.addProperty("selectedTheme", selectedTheme);

        String selectedGradientMode = data.getSelectedGradientMode();
        if (selectedGradientMode == null || selectedGradientMode.isEmpty()) {
            selectedGradientMode = GuiTheme.theme.getGradientMode().getId();
        }
        object.addProperty("selectedGradientMode", selectedGradientMode);

        String selectedGuiStyle = data.getSelectedGuiStyle();
        if (selectedGuiStyle == null || selectedGuiStyle.isEmpty()) {
            selectedGuiStyle = GuiTheme.theme.getGuiStyle().getId();
        }
        object.addProperty("selectedGuiStyle", selectedGuiStyle);

        object.addProperty("gradientOpacity", GuiTheme.theme.getGradientOpacity());
        object.addProperty("watermarkCustomNameEnabled", data.isWatermarkCustomNameEnabled());

        String watermarkCustomName = data.getWatermarkCustomName();
        object.addProperty("watermarkCustomName", watermarkCustomName == null ? "" : watermarkCustomName);

        object.add("hud", HudEditor.getInstance().savePositions());
        return object;
    }

    @Override
    protected void deserializeData(JsonObject object) {
        ConfigSerializer.loadProperty(object, "selectedConfig",
                element -> data.setSelectedConfig(element.getAsString()));
        ConfigSerializer.loadProperty(object, "selectedTheme",
                element -> data.setSelectedTheme(element.getAsString()));
        ConfigSerializer.loadProperty(object, "selectedGradientMode",
                element -> data.setSelectedGradientMode(element.getAsString()));
        ConfigSerializer.loadProperty(object, "selectedGuiStyle",
                element -> data.setSelectedGuiStyle(element.getAsString()));
        ConfigSerializer.loadProperty(object, "gradientOpacity",
                element -> data.setGradientOpacity(element.getAsFloat()));
        ConfigSerializer.loadProperty(object, "watermarkCustomNameEnabled",
                element -> data.setWatermarkCustomNameEnabled(element.getAsBoolean()));
        ConfigSerializer.loadProperty(object, "watermarkCustomName",
                element -> data.setWatermarkCustomName(element.getAsString()));
    }

    public void saveCurrentSettings() {
        try {
            save();
        } catch (Exception exception) {
            System.err.println("Error saving client settings: " + exception.getMessage());
        }
    }

    /** Applies persisted client settings after every manager has been initialized. */
    public void applySettings() {
        if (!configFile.exists()) {
            applyFirstRunDefaults();
            try {
                save();
            } catch (Exception exception) {
                System.err.println("Failed to save first-run client settings: " + exception.getMessage());
            }
            loadSelectedConfig();
            return;
        }

        try {
            String serialized = Files.readString(configFile.toPath());
            String json = encrypt ? EncryptionUtil.decrypt(serialized) : serialized;
            JsonObject object = JsonParser.parseString(json).getAsJsonObject();

            if (object.has("modules") && object.get("modules").isJsonObject()) {
                ConfigSerializer.loadModules(object.getAsJsonObject("modules"));
            }
            if (object.has("hud") && object.get("hud").isJsonObject()) {
                HudEditor.getInstance().loadPositions(object.getAsJsonObject("hud"));
            }
            if (object.has("selectedTheme") && !object.get("selectedTheme").isJsonNull()) {
                ThemeRegistry.apply(object.get("selectedTheme").getAsString());
            } else {
                ThemeRegistry.init();
            }
            if (object.has("selectedGradientMode") && !object.get("selectedGradientMode").isJsonNull()) {
                GuiTheme.theme.setGradientMode(GradientMode.byId(object.get("selectedGradientMode").getAsString()));
            }
            if (object.has("selectedGuiStyle") && !object.get("selectedGuiStyle").isJsonNull()) {
                GuiTheme.theme.setGuiStyle(GuiStyle.byId(object.get("selectedGuiStyle").getAsString()));
            }
            if (object.has("gradientOpacity") && !object.get("gradientOpacity").isJsonNull()) {
                GuiTheme.theme.setGradientOpacity(object.get("gradientOpacity").getAsFloat());
            }

            ThemeRegistry.syncForStyle(GuiTheme.theme.getGuiStyle());
            ThemeRegistry.apply(ThemeRegistry.getCurrent());
            applyWatermarkCustomName();
            loadSelectedConfig();
        } catch (Exception exception) {
            System.err.println("Failed to apply client config settings: " + exception.getMessage());
            exception.printStackTrace();
            loadSelectedConfig();
        }
    }

    private void applyFirstRunDefaults() {
        GuiTheme.theme.setGuiStyle(GuiStyle.KAWASE);
        GuiTheme.theme.setGradientOpacity(85.0F);
        ThemeRegistry.apply("horizon");
        data.setSelectedGuiStyle(GuiStyle.KAWASE.getId());
        data.setSelectedTheme("horizon");
        data.setGradientOpacity(85.0F);
    }

    private void applyWatermarkCustomName() {
        HudManager.getInstance().watermark.loadCustomNameSettings(
                data.isWatermarkCustomNameEnabled(), data.getWatermarkCustomName());
    }

    public void loadSelectedConfig() {
        CustomMetaFile configManager = SkyInit.getInstance().getConfigManager();
        if (configManager == null) {
            return;
        }

        String name = data.getSelectedConfig();
        if (name == null || name.trim().isEmpty()) {
            name = configManager.getLastLoadedConfigName();
        }
        if (name == null || name.trim().isEmpty()) {
            return;
        }
        if (configManager.getConfigInfo(name) != null) {
            configManager.loadConfig(name.trim());
        }
    }

    public String getSelectedConfig() {
        return data.getSelectedConfig();
    }

    public void onConfigSelected(String name) {
        data.setSelectedConfig(name);
        try {
            save();
            String selectedTheme = data.getSelectedTheme();
            if (selectedTheme != null && !selectedTheme.isEmpty()) {
                ThemeRegistry.apply(selectedTheme);
            }
        } catch (Exception exception) {
            System.err.println("Error saving selected config: " + exception.getMessage());
        }
    }

    public void onThemeSelected(String themeId) {
        data.setSelectedTheme(themeId);
        save();
    }

    public void onGradientModeSelected(GradientMode mode) {
        GuiTheme.theme.setGradientMode(mode);
        data.setSelectedGradientMode(GuiTheme.theme.getGradientMode().getId());
        save();
    }

    public void onGuiStyleSelected(GuiStyle style) {
        GuiTheme.theme.setGuiStyle(style);
        data.setSelectedGuiStyle(style.getId());
        save();
    }

    public void onGradientOpacityChanged(float opacity) {
        GuiTheme.theme.setGradientOpacity(opacity);
        data.setGradientOpacity(opacity);
        save();
    }

    public void onWatermarkCustomNameChanged(boolean enabled, String name) {
        data.setWatermarkCustomNameEnabled(enabled);
        data.setWatermarkCustomName(name == null ? "" : name);
        save();
    }

    public static final class ClientConfigData {
        private String selectedConfig;
        private String selectedTheme;
        private String selectedGradientMode;
        private String selectedGuiStyle;
        private float gradientOpacity = 85.0F;
        private boolean watermarkCustomNameEnabled;
        private String watermarkCustomName;

        public String getSelectedConfig() {
            return selectedConfig;
        }

        public void setSelectedConfig(String selectedConfig) {
            this.selectedConfig = selectedConfig;
        }

        public String getSelectedTheme() {
            return selectedTheme;
        }

        public void setSelectedTheme(String selectedTheme) {
            this.selectedTheme = selectedTheme;
        }

        public String getSelectedGradientMode() {
            return selectedGradientMode;
        }

        public void setSelectedGradientMode(String selectedGradientMode) {
            this.selectedGradientMode = selectedGradientMode;
        }

        public String getSelectedGuiStyle() {
            return selectedGuiStyle;
        }

        public void setSelectedGuiStyle(String selectedGuiStyle) {
            this.selectedGuiStyle = selectedGuiStyle;
        }

        public float getGradientOpacity() {
            return gradientOpacity;
        }

        public void setGradientOpacity(float gradientOpacity) {
            this.gradientOpacity = gradientOpacity;
        }

        public boolean isWatermarkCustomNameEnabled() {
            return watermarkCustomNameEnabled;
        }

        public void setWatermarkCustomNameEnabled(boolean watermarkCustomNameEnabled) {
            this.watermarkCustomNameEnabled = watermarkCustomNameEnabled;
        }

        public String getWatermarkCustomName() {
            return watermarkCustomName;
        }

        public void setWatermarkCustomName(String watermarkCustomName) {
            this.watermarkCustomName = watermarkCustomName;
        }
    }
}
