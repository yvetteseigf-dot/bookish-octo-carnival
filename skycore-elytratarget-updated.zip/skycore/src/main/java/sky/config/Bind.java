package sky.config;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import sky.SkyInit;
import sky.module.Module;
import sky.util.input.KeyCode;
import sky.util.input.KeyNameUtil;
import sky.util.text.CommandFeedback;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;
import sky.command.Command;
import sky.module.ModuleManager;
import sky.module.combat.AttackAura;
import sky.module.movement.Sprint;

public class Bind extends Command {
    public Bind() {
        super("bind");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(ctx -> {
            CommandFeedback.displayInfo("Usage: .bind add <module> <key> | remove <module> | list | clear");
            return 1;
        });
        builder.then(literal("add")
                .then(arg("module", StringArgumentType.greedyString())
                        .suggests(this::suggestModules)
                        .executes(this::add)));
        builder.then(literal("remove")
                .then(arg("module", StringArgumentType.greedyString())
                        .suggests(this::suggestModules)
                        .executes(this::remove)));
        builder.then(literal("list").executes(this::list));
        builder.then(literal("clear").executes(this::clear));
    }

    private int add(CommandContext<CommandSource> ctx) {
        String argument = ctx.getArgument("module", String.class).trim();
        int lastSpace = argument.lastIndexOf(' ');
        if (lastSpace <= 0) {
            CommandFeedback.displayInfo("Example: .bind add Sprint R");
            return 0;
        }
        String moduleName = argument.substring(0, lastSpace).trim();
        String keyName = argument.substring(lastSpace + 1).trim().toUpperCase(Locale.ROOT);
        int keyCode = resolveKey(keyName);
        if (keyCode < 0) {
            CommandFeedback.displayInfo("Key " + keyName + " not found");
            return 0;
        }
        Module module = resolveModule(moduleName);
        if (module != null) {
            module.setKeyBind(keyCode);
            CommandFeedback.displayInfo("Bound " + keyName + " to " + module.getName());
            return 1;
        }
        CommandFeedback.displayInfo("Module " + moduleName + " not found");
        return 0;
    }

    private int remove(CommandContext<CommandSource> ctx) {
        String moduleName = ctx.getArgument("module", String.class);
        Module module = resolveModule(moduleName);
        if (module != null) {
            module.setKeyBind(-1);
            CommandFeedback.displayInfo("Unbound " + module.getName());
            return 1;
        }
        CommandFeedback.displayInfo("Module not found");
        return 0;
    }

    private int list(CommandContext<CommandSource> ctx) {
        boolean anyBound = false;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() >= 0) {
                anyBound = true;
                sendBindLine(module.getName(), module.getKeyBind());
            }
        }
        if (!anyBound) {
            CommandFeedback.displayInfo("Bind list is empty");
        }
        return 1;
    }

    private int clear(CommandContext<CommandSource> ctx) {
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            module.setKeyBind(-1);
        }
        CommandFeedback.displayInfo("All binds cleared");
        return 1;
    }

    private CompletableFuture<Suggestions> suggestModules(CommandContext<CommandSource> ctx, SuggestionsBuilder builder) {
        List<String> names = new ArrayList<>();
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            names.add(module.getName());
        }
        names.add("AttackAura");
        names.add("Aura");
        return CommandSource.suggestMatching(names, builder);
    }

    private Module resolveModule(String name) {
        String normalized = normalize(name);
        ModuleManager moduleManager = SkyInit.getInstance().getModuleManager();
        for (Module module : moduleManager.getModules()) {
            if (normalize(module.getName()).equalsIgnoreCase(normalized)) {
                return module;
            }
        }
        if ("AttackAura".equalsIgnoreCase(normalized) || "Aura".equalsIgnoreCase(normalized)) {
            return moduleManager.getModule("AttackAura");
        }
        if ("Sprint".equalsIgnoreCase(normalized)) {
            return moduleManager.getModule("Sprint");
        }
        return null;
    }

    private String normalize(String name) {
        return name.replaceAll("\\s+", "");
    }

    private int resolveKey(String keyName) {
        int named = KeyCode.getKeyCode(keyName);
        if (named >= 0) {
            return named;
        }
        for (int key = 32; key <= 348; key++) {
            String name = GLFW.glfwGetKeyName(key, 0);
            if (name != null && name.equalsIgnoreCase(keyName)) {
                return key;
            }
        }
        return -1;
    }

    private void sendBindLine(String name, int keyCode) {
        String keyName = KeyNameUtil.getKey(keyCode);
        CommandFeedback.send(Text.literal(name).formatted(Formatting.WHITE)
                .append(Text.literal(" — ").formatted(Formatting.GRAY))
                .append(Text.literal(keyName).formatted(Formatting.WHITE)));
    }
}
