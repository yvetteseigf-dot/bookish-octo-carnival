package sky.config;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import sky.SkyInit;
import sky.util.EncryptionUtil;

import java.io.File;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import sky.hud.HudManager;

/**
 * Index of the named configs under the custom config directory, and the reader/writer for them.
 * The index itself only tracks which config was loaded last; the config payloads live in
 * separate {@code .cfg} files.
 */
public final class CustomMetaFile extends AbstractConfigFile<CustomMetaFile.ConfigData> {
    private static final File CONFIG_DIR = new File(ClientPaths.BASE_PATH + ClientPaths.CUSTOM_DIR_REL);

    public CustomMetaFile() {
        super(ClientPaths.CUSTOM_META_FILE_REL);
    }

    @Override
    public void init() {
        CONFIG_DIR.mkdirs();
        super.init();
    }

    @Override
    protected void initializeData() {
        data = new ConfigData();
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        if (data.getLastLoadedConfig() != null) {
            object.addProperty("lastLoadedConfig", data.getLastLoadedConfig());
        }
        return object;
    }

    @Override
    protected void deserializeData(JsonObject jsonObject) {
        ConfigSerializer.loadProperty(jsonObject, "lastLoadedConfig",
                value -> data.setLastLoadedConfig(value.getAsString()));
    }

    public File getConfigDirectory() {
        return CONFIG_DIR;
    }

    public List<String> getConfigNames() {
        File[] files = CONFIG_DIR.listFiles((dir, name) -> name.endsWith(".cfg"));
        if (files == null) {
            return Collections.emptyList();
        }
        List<String> names = new ArrayList<>();
        for (File file : files) {
            names.add(file.getName().replace(".cfg", ""));
        }
        return names;
    }

    /** Returns the stored config name matching {@code name} case-insensitively, or {@code null}. */
    public String resolveConfigName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        String trimmed = name.trim();
        for (String existing : getConfigNames()) {
            if (existing.equalsIgnoreCase(trimmed)) {
                return existing;
            }
        }
        return null;
    }

    public boolean configExists(String name) {
        return resolveConfigName(name) != null;
    }

    public String getLastLoadedConfigName() {
        return data.getLastLoadedConfig();
    }

    public void saveActiveConfig() {
        String name = data.getLastLoadedConfig();
        if (name == null || name.trim().isEmpty()) {
            name = "default";
        }
        saveConfig(name.trim());
    }

    public void saveConfig(String name) {
        if (name == null || name.trim().isEmpty()) {
            return;
        }
        String configName = name.trim();
        CONFIG_DIR.mkdirs();
        File file = new File(CONFIG_DIR, configName + ".cfg");
        try {
            JsonObject root = new JsonObject();
            root.add("module", ConfigSerializer.saveModules());
            root.add("hud", ConfigSerializer.saveHud());
            root.addProperty("creationDate", System.currentTimeMillis());
            root.addProperty("creator", "NexusUser");

            String json = GSON.toJson(root);
            Files.writeString(file.toPath(), encrypt ? EncryptionUtil.encrypt(json) : json);

            data.setLastLoadedConfig(configName);
            save();

            ClientSettingsFile clientConfig = SkyInit.getInstance().getClientConfig();
            if (clientConfig != null) {
                clientConfig.onConfigSelected(configName);
            }
        } catch (Exception exception) {
            System.err.println("Failed to save config: " + configName + " - " + exception.getMessage());
        }
    }

    public boolean loadConfig(String name) {
        String configName = resolveConfigName(name);
        if (configName == null) {
            return false;
        }
        File file = new File(CONFIG_DIR, configName + ".cfg");
        if (!file.exists()) {
            return false;
        }
        try {
            String serialized = Files.readString(file.toPath());
            String json = encrypt ? EncryptionUtil.decrypt(serialized) : serialized;
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();

            if (root.has("module") && root.get("module").isJsonObject()) {
                ConfigSerializer.loadModules(root.getAsJsonObject("module"));
            } else if (root.has("modules") && root.get("modules").isJsonObject()) {
                ConfigSerializer.loadModules(root.getAsJsonObject("modules"));
            }
            if (root.has("hud") && root.get("hud").isJsonObject()) {
                ConfigSerializer.loadHud(root.getAsJsonObject("hud"));
            }

            data.setLastLoadedConfig(configName);
            save();

            ClientSettingsFile clientConfig = SkyInit.getInstance().getClientConfig();
            if (clientConfig != null) {
                clientConfig.onConfigSelected(configName);
            }
            HudManager.getInstance().notifications.pushConfigLoaded(configName);
            return true;
        } catch (Exception exception) {
            System.err.println("Failed to load config file: " + configName + " - " + exception.getMessage());
            exception.printStackTrace();
            return false;
        }
    }

    public boolean deleteConfig(String name) {
        String configName = resolveConfigName(name);
        if (configName == null) {
            return false;
        }
        boolean deleted = new File(CONFIG_DIR, configName + ".cfg").delete();
        if (deleted && configName.equals(data.getLastLoadedConfig())) {
            data.setLastLoadedConfig(null);
            save();
        }
        return deleted;
    }

    public Config getConfigInfo(String name) {
        String configName = resolveConfigName(name);
        if (configName == null) {
            return null;
        }
        File file = new File(CONFIG_DIR, configName + ".cfg");
        if (!file.exists()) {
            return null;
        }
        try {
            String serialized = Files.readString(file.toPath());
            String json = encrypt ? EncryptionUtil.decrypt(serialized) : serialized;
            JsonObject root = JsonParser.parseString(json).getAsJsonObject();

            long creationDate = root.has("creationDate") && !root.get("creationDate").isJsonNull()
                    ? root.get("creationDate").getAsLong()
                    : System.currentTimeMillis();
            String creator = root.has("creator") && !root.get("creator").isJsonNull()
                    ? root.get("creator").getAsString()
                    : "Unknown";
            return new Config(configName, creationDate, creator);
        } catch (Exception unreadable) {
            return new Config(configName);
        }
    }

    public void resetToDefaults() {
        ConfigSerializer.resetToDefaults();
        ClientSettingsFile clientConfig = SkyInit.getInstance().getClientConfig();
        if (clientConfig != null) {
            clientConfig.saveCurrentSettings();
        }
    }

    public static final class ConfigData {
        private String lastLoadedConfig;

        public String getLastLoadedConfig() {
            return lastLoadedConfig;
        }

        public void setLastLoadedConfig(String lastLoadedConfig) {
            this.lastLoadedConfig = lastLoadedConfig;
        }
    }

    /** Metadata read back from a stored {@code .cfg} file. */
    public static final class Config {
        private final String name;
        private final long creationDate;
        private final String creator;

        public Config(String name) {
            this(name, System.currentTimeMillis(), "NexusUser");
        }

        public Config(String name, long creationDate, String creator) {
            this.name = name;
            this.creationDate = creationDate;
            this.creator = creator != null ? creator : "Unknown";
        }

        public String getName() {
            return name;
        }

        public long getCreationDate() {
            return creationDate;
        }

        public String getCreator() {
            return creator;
        }
    }
}
