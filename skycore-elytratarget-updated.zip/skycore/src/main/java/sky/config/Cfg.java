package sky.config;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import sky.SkyInit;
import sky.util.text.CommandFeedback;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.List;
import sky.command.Command;

public class Cfg extends Command {
    public Cfg() {
        super("cfg");
    }

    @Override
    public void register(CommandDispatcher<CommandSource> dispatcher) {
        LiteralArgumentBuilder<CommandSource> primary = LiteralArgumentBuilder.literal(getCommand());
        execute(primary);
        dispatcher.register(primary);

        LiteralArgumentBuilder<CommandSource> alias = LiteralArgumentBuilder.literal("config");
        execute(alias);
        dispatcher.register(alias);
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("save").then(arg("name", StringArgumentType.word()).executes(context -> {
            String name = context.getArgument("name", String.class);
            SkyInit.getInstance().getConfigManager().saveConfig(name);
            CommandFeedback.displayInfo(Formatting.GRAY + "Config \"" + name + "\" saved!");
            return 1;
        })));
        builder.then(literal("load").then(arg("name", StringArgumentType.word()).executes(context -> {
            String name = context.getArgument("name", String.class);
            CustomMetaFile configManager = SkyInit.getInstance().getConfigManager();
            if (!configManager.configExists(name)) {
                CommandFeedback.displayInfo(Formatting.GRAY + "Config \"" + name + "\" not found.");
                return 0;
            }
            if (!configManager.loadConfig(name)) {
                CommandFeedback.displayInfo(Formatting.GRAY + "Failed to load config \"" + name + "\". Check the log.");
                return 0;
            }
            CommandFeedback.displayInfo(Formatting.GRAY + "Config \"" + name + "\" loaded!");
            return 1;
        })));
        builder.then(literal("remove").then(arg("name", StringArgumentType.word()).executes(context -> {
            String name = context.getArgument("name", String.class);
            if (SkyInit.getInstance().getConfigManager().getConfigInfo(name) == null) {
                CommandFeedback.displayInfo(Formatting.GRAY + "Config \"" + name + "\" not found.");
                return 0;
            }
            SkyInit.getInstance().getConfigManager().deleteConfig(name);
            CommandFeedback.displayInfo(Formatting.GRAY + "Config \"" + name + "\" deleted!");
            return 1;
        })));
        builder.then(literal("list").executes(context -> {
            List<String> names = SkyInit.getInstance().getConfigManager().getConfigNames();
            if (names.isEmpty()) {
                CommandFeedback.displayInfo(Formatting.GRAY + "Config list is empty!");
                return 1;
            }
            CommandFeedback.displayInfo(Formatting.GRAY + "Configs:");
            for (String name : names) {
                MutableText line = Text.literal(name).formatted(Formatting.WHITE);
                line.append(clickable(" [Load]", ".cfg load " + name, Formatting.GREEN, "Load " + name));
                line.append(clickable(" [Delete]", ".cfg remove " + name, Formatting.RED, "Delete " + name));
                CommandFeedback.send(line);
            }
            return 1;
        }));
        builder.then(literal("dir").executes(context -> {
            openConfigDirectory(SkyInit.getInstance().getConfigManager());
            return 1;
        }));
        builder.then(literal("clear").executes(context -> {
            for (String name : SkyInit.getInstance().getConfigManager().getConfigNames()) {
                SkyInit.getInstance().getConfigManager().deleteConfig(name);
            }
            CommandFeedback.displayInfo(Formatting.GRAY + "Config list cleared!");
            return 1;
        }));
        builder.then(literal("reset").executes(context -> {
            SkyInit.getInstance().getConfigManager().resetToDefaults();
            CommandFeedback.displayInfo(Formatting.GRAY + "Config reset!");
            return 1;
        }));
    }

    private static MutableText clickable(String label, String command, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY
                .withColor(color)
                .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

    private static void openConfigDirectory(CustomMetaFile configManager) {
        try {
            File directory = configManager.getConfigDirectory();
            if (!directory.exists()) {
                directory.mkdirs();
            }
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(directory);
            } else {
                Runtime.getRuntime().exec(new String[] {"explorer", directory.getAbsolutePath()});
            }
            CommandFeedback.displayInfo(Formatting.GRAY + "Folder: " + directory.getAbsolutePath());
        } catch (IOException exception) {
            CommandFeedback.displayInfo(Formatting.GRAY + "Failed to open folder: " + exception.getMessage());
        }
    }
}
