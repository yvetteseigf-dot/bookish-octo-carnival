package sky.config;

public final class ButtonSetting extends Setting<Void> {
    private final Runnable action;

    public ButtonSetting(String name, Runnable action) {
        super(name, null);
        this.action = action;
    }

    public void run() {
        action.run();
    }

    @Override
    public void reset() {
        // A button has no persistent value.
    }
}
