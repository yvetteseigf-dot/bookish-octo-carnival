package sky.config;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Maps names used by older released configs onto the names the client currently uses,
 * so previously saved configs keep loading after a module or setting is renamed.
 */
public final class ConfigAliasRegistry {
    private static final Map<String, String> MODULE_ALIASES = new HashMap<>();
    private static final Map<String, String> SETTING_ALIASES = new HashMap<>();
    private static final Map<String, String> OPTION_ALIASES = new HashMap<>();

    static {
        aliasModule("attack aura", "attackaura");
        aliasModule("super firework", "elytrabooster");
        aliasModule("elytra helper", "elytrahelper");
        aliasModule("auto totem", "auto totem");
        aliasModule("gui move", "gui move");
        aliasModule("free camera", "free camera");
        aliasModule("full bright", "full bright");
        aliasModule("no render", "norender");
        aliasModule("target esp", "targetesp");
        aliasModule("swing animation", "swinganimation");
        aliasModule("scoreboard health", "scoreboard health");
        aliasModule("name protect", "nameprotect");
        aliasModule("client sounds", "clientsounds");
        aliasModule("auto duel", "auto duel");
        aliasModule("glide fly", "glide fly");
        aliasModule("elytra whatsapp", "elytra whatsapp");
        aliasModule("air stuck", "air stuck");
        aliasModule("no slow", "no slow");
        aliasModule("no push", "no push");
        aliasModule("web ignore", "web ignore");
        aliasModule("click pearl", "clickpearl");
        aliasModule("auto tool", "autotool");
        aliasModule("target pearl", "targetpearl");
        aliasModule("no delay", "nodelay");
        aliasModule("auto swap", "autoswap");
        aliasModule("auto explosion", "autoexplosion");
        aliasModule("crystal aura", "crystalaura");
        aliasModule("packet criticals", "criticals");
        aliasModule("criticals", "criticals");
        aliasModule("charge boost", "charge boost");
        aliasModule("chargeboost", "charge boost");

        aliasSetting("rendering", "Show");
        aliasSetting("Отображать", "Show");
        aliasSetting("Show", "Show");
        aliasSetting("viewhead", "Show head");
        aliasSetting("Отображать голову", "Show head");
        aliasSetting("Show head", "Show head");
        aliasSetting("vieweffects", "Show effects");
        aliasSetting("Отображать эффекты", "Show effects");
        aliasSetting("Show effects", "Show effects");
        aliasSetting("Potions", "Show effects");
        aliasSetting("viewarmor", "Show armor");
        aliasSetting("Отображать броню", "Show armor");
        aliasSetting("Show armor", "Show armor");
        aliasSetting("Armor", "Show armor");
        aliasSetting("viewenchants", "Show enchantments");
        aliasSetting("Отображать зачарования", "Show enchantments");
        aliasSetting("Show enchantments", "Show enchantments");
        aliasSetting("Enchants", "Show enchantments");
        aliasSetting("viewitem", "Show offhand");
        aliasSetting("Отображать левую руку", "Show offhand");
        aliasSetting("Show offhand", "Show offhand");
        aliasSetting("viewdisplayname", "Show item display name");
        aliasSetting("Отображать визуальное имя предмета", "Show item display name");
        aliasSetting("Show item display name", "Show item display name");
        aliasSetting("Display name", "Show item display name");
        aliasSetting("viewitemicon", "Show item icon");
        aliasSetting("Отображать иконку предмета", "Show item icon");
        aliasSetting("Show item icon", "Show item icon");
        aliasSetting("hide original", "Hide original");

        aliasOption("Игроков", "Players");
        aliasOption("Players", "Players");
        aliasOption("Монстров", "Monsters");
        aliasOption("Monsters", "Monsters");
        aliasOption("Друзей", "Friends");
        aliasOption("Friends", "Friends");
        aliasOption("Животных", "Animals");
        aliasOption("Animals", "Animals");
        aliasOption("Себя", "Self");
        aliasOption("Self", "Self");
        aliasOption("Жителей", "Villagers");
        aliasOption("Villagers", "Villagers");
        aliasOption("Голых", "Naked");
        aliasOption("Naked", "Naked");
        aliasOption("Предметы", "Items");
        aliasOption("Items", "Items");
        aliasOption("Кругляш", "Circle");
        aliasOption("Round", "Circle");
        aliasOption("Circle", "Circle");
    }

    private ConfigAliasRegistry() {
    }

    public static String resolveModuleKey(String configKey) {
        String normalized = normalizeModuleKey(configKey);
        String compact = compactKey(configKey);

        String alias = MODULE_ALIASES.get(normalized);
        if (alias != null) {
            return compactKey(alias);
        }
        alias = MODULE_ALIASES.get(compact);
        if (alias != null) {
            return compactKey(alias);
        }
        return compact;
    }

    public static String resolveSettingName(String settingName) {
        if (settingName == null) {
            return null;
        }
        return SETTING_ALIASES.getOrDefault(settingName, settingName);
    }

    public static String resolveOptionName(String optionName) {
        if (optionName == null) {
            return null;
        }
        return OPTION_ALIASES.getOrDefault(optionName, optionName);
    }

    public static String normalizeModuleKey(String name) {
        return name.toLowerCase(Locale.ROOT);
    }

    public static String compactKey(String name) {
        return normalizeModuleKey(name).replace(" ", "");
    }

    private static void aliasModule(String releaseName, String currentKey) {
        MODULE_ALIASES.put(compactKey(releaseName), compactKey(currentKey));
        MODULE_ALIASES.put(normalizeModuleKey(releaseName), compactKey(currentKey));
    }

    private static void aliasSetting(String releaseName, String currentName) {
        SETTING_ALIASES.put(releaseName, currentName);
    }

    private static void aliasOption(String releaseName, String currentName) {
        OPTION_ALIASES.put(releaseName, currentName);
    }
}
