package sky.config;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.event.player.PlayerUpdateEvent;
import sky.event.combat.AttackEntityEvent;
import sky.util.entity.EntityVectorUtil;

import java.util.ArrayList;
import java.util.List;
import sky.access.MinecraftAccess;

public final class NeuroFile extends AbstractConfigFile<List<NeuroFile.NeuroFrame>> implements MinecraftAccess {
    private static final int AUTO_SAVE_INTERVAL = 600;
    public static final long MAX_RECORD_MS = 150_000L;

    private int recordTicks;
    private Entity recordTarget;
    private long recordStartMs;
    private boolean recording;
    private int ticksSinceSave;

    public NeuroFile() {
        super("temp\\neuro.file", false);
    }

    @Override
    protected void initializeData() {
        data = new ArrayList<>();
    }

    public boolean hasData() {
        return data != null && !data.isEmpty();
    }

    public boolean isRecording() {
        return recording;
    }

    public void persist() {
        if (hasData()) {
            save();
        }
    }

    public NeuroFrame getFrame(int index) {
        if (data == null || data.isEmpty()) {
            return NeuroFrame.ZERO;
        }
        return data.get(Math.floorMod(index, data.size()));
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        JsonArray frames = new JsonArray();
        for (NeuroFrame frame : data) {
            JsonObject serializedFrame = new JsonObject();
            serializedFrame.addProperty("yaw", frame.yawOffset());
            serializedFrame.addProperty("pitch", frame.pitchOffset());
            frames.add(serializedFrame);
        }
        object.add("frames", frames);
        object.addProperty("ticks", recordTicks);
        return object;
    }

    @Override
    protected void deserializeData(JsonObject object) {
        data.clear();
        if (!object.has("frames")) {
            return;
        }
        JsonArray frames = object.getAsJsonArray("frames");
        if (frames == null) {
            return;
        }
        for (JsonElement element : frames) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject frame = element.getAsJsonObject();
            if (!frame.has("yaw") || !frame.has("pitch")) {
                continue;
            }
            data.add(new NeuroFrame(frame.get("yaw").getAsFloat(), frame.get("pitch").getAsFloat()));
        }
        if (object.has("ticks")) {
            recordTicks = object.get("ticks").getAsInt();
        }
    }

    public int stopRecording() {
        if (!recording) {
            return 0;
        }
        recording = false;
        recordTarget = null;
        ticksSinceSave = 0;
        if (!data.isEmpty()) {
            save();
        }
        return data.size();
    }

    public int getFrameCount() {
        return data == null ? 0 : data.size();
    }

    public void startRecording() {
        if (recording) {
            return;
        }
        recording = true;
        recordTarget = null;
        recordStartMs = System.currentTimeMillis();
        recordTicks = 0;
        ticksSinceSave = 0;
        data.clear();
    }

    public int getRecordSeconds() {
        return recording ? (int) ((System.currentTimeMillis() - recordStartMs) / 1_000L) : 0;
    }

    @EventTarget
    public void onAttack(AttackEntityEvent event) {
        if (!recording || event.getTarget() == null) {
            return;
        }
        Entity target = event.getTarget();
        if (target instanceof LivingEntity living && living.isAlive()) {
            recordTarget = living;
        }
    }

    private LivingEntity resolveRecordTarget() {
        if (recordTarget instanceof LivingEntity living
                && living.isAlive()
                && !living.isDead()
                && mc.player.distanceTo(living) <= 8.0F) {
            return living;
        }

        LivingEntity closest = null;
        double closestDistance = Double.MAX_VALUE;
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)
                    || living == mc.player
                    || !living.isAlive()
                    || living.isDead()) {
                continue;
            }
            double distance = mc.player.distanceTo(living);
            if (distance <= 8.0D && distance < closestDistance) {
                closestDistance = distance;
                closest = living;
            }
        }
        if (closest != null) {
            recordTarget = closest;
        }
        return closest;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (!recording || mc.player == null || mc.world == null) {
            return;
        }
        if (System.currentTimeMillis() - recordStartMs >= MAX_RECORD_MS) {
            stopRecording();
            return;
        }

        LivingEntity target = resolveRecordTarget();
        if (target == null) {
            return;
        }
        Vec3d vector = EntityVectorUtil.getClosestVec(target);
        float yaw = (float) Math.toDegrees(Math.atan2(-vector.x, vector.z));
        float pitch = (float) MathHelper.clamp(
                -Math.toDegrees(Math.atan2(vector.y, Math.hypot(vector.x, vector.z))), -90.0D, 90.0D);
        float yawOffset = MathHelper.wrapDegrees(mc.player.getYaw() - yaw);
        float pitchOffset = mc.player.getPitch() - pitch;
        data.add(new NeuroFrame(yawOffset, pitchOffset));
        recordTicks++;
        ticksSinceSave++;
        if (ticksSinceSave >= AUTO_SAVE_INTERVAL) {
            ticksSinceSave = 0;
            save();
        }
    }

    @Override
    public void init() {
        super.init();
        EventManager.register(this);
    }

    public record NeuroFrame(float yawOffset, float pitchOffset) {
        public static final NeuroFrame ZERO = new NeuroFrame(0.0F, 0.0F);
    }
}
