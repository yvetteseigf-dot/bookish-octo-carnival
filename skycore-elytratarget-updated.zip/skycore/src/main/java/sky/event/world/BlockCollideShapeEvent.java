package sky.event.world;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable lookup of an abstract block state's collision shape. */
public class BlockCollideShapeEvent extends EventCancellable implements Event {
    private BlockPos pos;
    private VoxelShape voxelShape;

    public BlockCollideShapeEvent(BlockPos pos) {
        this.pos = pos;
    }

    public BlockPos getPos() {
        return pos;
    }

    public void setPos(BlockPos pos) {
        this.pos = pos;
    }

    public VoxelShape getVoxelShape() {
        return voxelShape;
    }

    public void setVoxelShape(VoxelShape voxelShape) {
        this.voxelShape = voxelShape;
    }

    protected boolean canEqual(Object object) {
        return object instanceof BlockCollideShapeEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof BlockCollideShapeEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }

        BlockPos thisPos = getPos();
        BlockPos otherPos = other.getPos();
        return thisPos == null ? otherPos == null : thisPos.equals(otherPos);
    }

    @Override
    public int hashCode() {
        BlockPos value = getPos();
        return 59 + (value == null ? 43 : value.hashCode());
    }

    @Override
    public String toString() {
        return "EventBlockCollide(pos=" + getPos() + ')';
    }
}
