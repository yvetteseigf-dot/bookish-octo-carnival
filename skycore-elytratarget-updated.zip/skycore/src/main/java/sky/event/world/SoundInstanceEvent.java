package sky.event.world;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.sound.SoundInstance;

public class SoundInstanceEvent extends EventCancellable implements Event {
    private SoundInstance sound;
    private float factor;

    public SoundInstanceEvent(SoundInstance sound, float factor) {
        this.sound = sound;
        this.factor = factor;
    }

    public SoundInstance getSound() {
        return sound;
    }

    public void setSound(SoundInstance sound) {
        this.sound = sound;
    }

    public float getFactor() {
        return factor;
    }

    public void setFactor(float factor) {
        this.factor = factor;
    }

    protected boolean canEqual(Object other) {
        return other instanceof SoundInstanceEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof SoundInstanceEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || Float.compare(getFactor(), other.getFactor()) != 0) {
            return false;
        }
        SoundInstance thisSound = getSound();
        SoundInstance otherSound = other.getSound();
        return thisSound == null ? otherSound == null : thisSound.equals(otherSound);
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getFactor());
        SoundInstance sound = getSound();
        return result * 59 + (sound == null ? 43 : sound.hashCode());
    }

    @Override
    public String toString() {
        return "EventSound(sound=" + getSound() + ", factor=" + getFactor() + ')';
    }
}
