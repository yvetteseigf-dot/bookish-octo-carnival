package sky.event.world;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

/** Event raised for a block state at a particular world position. */
public class BlockPosStateEvent extends EventCancellable implements Event {
    private final BlockState state;
    private final BlockPos pos;

    public BlockPosStateEvent(BlockState state, BlockPos pos) {
        this.state = state;
        this.pos = pos;
    }

    public BlockState getBlockState() {
        return state;
    }

    public BlockPos getPos() {
        return pos;
    }
}
