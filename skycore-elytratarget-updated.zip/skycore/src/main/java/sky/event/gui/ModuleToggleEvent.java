package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;
import sky.module.Module;

public class ModuleToggleEvent implements Event {
    private final boolean enabled;
    private final Module module;

    public ModuleToggleEvent(Module module, boolean enabled) {
        this.module = module;
        this.enabled = enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public Module getModule() {
        return module;
    }
}
