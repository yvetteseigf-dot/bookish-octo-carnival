package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import java.util.List;
import net.minecraft.item.ItemStack;

public class ContainerTickEvent extends EventCancellable implements Event {
    private List<ItemStack> items;
    private int windowId;

    public ContainerTickEvent(int windowId, List<ItemStack> items) {
        this.windowId = windowId;
        this.items = items;
    }

    public String toString() {
        return "EventContainerTick(windowId=" + getWindowId() + ", items=" + String.valueOf(getItems()) + ")";
    }

    public void setItems(List<ItemStack> items) {
        this.items = items;
    }

    public void setWindowId(int windowId) {
        this.windowId = windowId;
    }

    protected boolean canEqual(Object other) {
        return other instanceof ContainerTickEvent;
    }

    public List<ItemStack> getItems() {
        return items;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof ContainerTickEvent that)) {
            return false;
        }
        if (!that.canEqual(this) || getWindowId() != that.getWindowId()) {
            return false;
        }
        Object thisItems = getItems();
        Object thatItems = that.getItems();
        return thisItems == null ? thatItems == null : thisItems.equals(thatItems);
    }

    public int getWindowId() {
        return windowId;
    }

    public int hashCode() {
        int result = 59 + getWindowId();
        Object items = getItems();
        return result * 59 + (items == null ? 43 : items.hashCode());
    }
}
