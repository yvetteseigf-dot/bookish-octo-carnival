package sky.event.gui;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

public class WindowClickEvent extends EventCancellable implements Event {
    private SlotActionType type;
    private ItemStack clickedItemIn;
    private int mouseButton;
    private int windowId;
    private short actionNumberIn;
    private int slotId;

    public WindowClickEvent(
            int windowId,
            int slotId,
            int mouseButton,
            SlotActionType type,
            ItemStack clickedItemIn,
            short actionNumberIn) {
        this.windowId = windowId;
        this.slotId = slotId;
        this.mouseButton = mouseButton;
        this.type = type;
        this.clickedItemIn = clickedItemIn;
        this.actionNumberIn = actionNumberIn;
    }

    public int getWindowId() {
        return windowId;
    }

    public void setWindowId(int windowId) {
        this.windowId = windowId;
    }

    public int getSlotId() {
        return slotId;
    }

    public void setSlotId(int slotId) {
        this.slotId = slotId;
    }

    public int getMouseButton() {
        return mouseButton;
    }

    public void setMouseButton(int mouseButton) {
        this.mouseButton = mouseButton;
    }

    public SlotActionType getType() {
        return type;
    }

    public void setType(SlotActionType type) {
        this.type = type;
    }

    public ItemStack getClickedItemIn() {
        return clickedItemIn;
    }

    public void setClickedItemIn(ItemStack clickedItemIn) {
        this.clickedItemIn = clickedItemIn;
    }

    public short getActionNumberIn() {
        return actionNumberIn;
    }

    public void setActionNumberIn(short actionNumberIn) {
        this.actionNumberIn = actionNumberIn;
    }

    protected boolean canEqual(Object other) {
        return other instanceof WindowClickEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof WindowClickEvent other)) {
            return false;
        }
        if (!other.canEqual(this)
                || getWindowId() != other.getWindowId()
                || getSlotId() != other.getSlotId()
                || getMouseButton() != other.getMouseButton()
                || getActionNumberIn() != other.getActionNumberIn()) {
            return false;
        }
        SlotActionType thisType = getType();
        SlotActionType otherType = other.getType();
        if (thisType == null ? otherType != null : !thisType.equals(otherType)) {
            return false;
        }
        ItemStack thisClickedItemIn = getClickedItemIn();
        ItemStack otherClickedItemIn = other.getClickedItemIn();
        return thisClickedItemIn == null ? otherClickedItemIn == null : thisClickedItemIn.equals(otherClickedItemIn);
    }

    @Override
    public int hashCode() {
        int result = 59 + getWindowId();
        result = result * 59 + getSlotId();
        result = result * 59 + getMouseButton();
        result = result * 59 + getActionNumberIn();
        SlotActionType type = getType();
        result = result * 59 + (type == null ? 43 : type.hashCode());
        ItemStack clickedItemIn = getClickedItemIn();
        return result * 59 + (clickedItemIn == null ? 43 : clickedItemIn.hashCode());
    }

    @Override
    public String toString() {
        return "EventWindowClick(windowId=" + getWindowId() + ", slotId=" + getSlotId()
                + ", mouseButton=" + getMouseButton() + ", type=" + getType()
                + ", clickedItemIn=" + getClickedItemIn() + ", actionNumberIn=" + getActionNumberIn() + ')';
    }
}
