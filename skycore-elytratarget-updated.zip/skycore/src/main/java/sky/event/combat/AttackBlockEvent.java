package sky.event.combat;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

/** Mutable/cancellable start or stop block-breaking state. */
public class AttackBlockEvent extends EventCancellable {
    private State state;
    private Direction direction;
    private BlockState blockState;
    private BlockPos pos;

    public AttackBlockEvent(BlockState blockState, BlockPos pos, State state, Direction direction) {
        this.blockState = blockState;
        this.pos = pos;
        this.state = state;
        this.direction = direction;
    }

    public BlockState getBlockState() { return blockState; }
    public void setPos(BlockPos pos) { this.pos = pos; }
    public void setDirection(Direction direction) { this.direction = direction; }
    public BlockPos getPos() { return pos; }
    public Direction getDirection() { return direction; }
    public void setState(State state) { this.state = state; }
    public void setBlockState(BlockState blockState) { this.blockState = blockState; }
    protected boolean canEqual(Object object) { return object instanceof AttackBlockEvent; }
    public State getState() { return state; }

    public enum State {
        START,
        STOP
    }
}
