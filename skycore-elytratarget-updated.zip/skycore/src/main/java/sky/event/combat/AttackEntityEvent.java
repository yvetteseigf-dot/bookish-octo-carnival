package sky.event.combat;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;

/** Mutable/cancellable target before a client-side entity attack. */
public class AttackEntityEvent extends EventCancellable {
    private Entity target;

    public AttackEntityEvent(Entity target) {
        this.target = target;
    }

    public void setTarget(Entity target) { this.target = target; }
    public Entity getTarget() { return target; }
    protected boolean canEqual(Object object) { return object instanceof AttackEntityEvent; }
}
