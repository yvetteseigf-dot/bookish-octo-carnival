package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;

public class DamageSourceEvent implements Event {
    private DamageSource cause;
    private LivingEntity entity;

    public DamageSourceEvent(LivingEntity entity, DamageSource cause) {
        this.entity = entity;
        this.cause = cause;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public DamageSource getCause() {
        return cause;
    }
}
