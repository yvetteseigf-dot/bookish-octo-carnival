package sky.event.combat;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class DamageEvent extends EventCancellable implements Event {
    private final DamageType damageType;

    public DamageEvent(DamageType damageType) {
        this.damageType = damageType;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof DamageEvent that) || !that.canEqual(this)) {
            return false;
        }
        Object thisDamageType = getDamageType();
        Object thatDamageType = that.getDamageType();
        return thisDamageType == null ? thatDamageType == null : thisDamageType.equals(thatDamageType);
    }

    protected boolean canEqual(Object other) {
        return other instanceof DamageEvent;
    }

    public DamageType getDamageType() {
        return damageType;
    }

    public String toString() {
        return "EventDamage(damageType=" + String.valueOf(getDamageType()) + ")";
    }

    public int hashCode() {
        Object damageType = getDamageType();
        return 59 + (damageType == null ? 43 : damageType.hashCode());
    }

    public enum DamageType {
        FALL,
        ARROW,
        ENDER_PEARL,
        BLOCK
    }
}
