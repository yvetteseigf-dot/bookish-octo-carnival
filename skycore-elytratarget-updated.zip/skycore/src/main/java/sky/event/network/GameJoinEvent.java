package sky.event.network;

import com.darkmagician6.eventapi.events.Event;

public class GameJoinEvent implements Event {
}
