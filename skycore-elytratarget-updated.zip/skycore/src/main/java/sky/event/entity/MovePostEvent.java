package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.util.math.Vec3d;

/** Mutable movement input and speed used by an entity velocity update. */
public class MovePostEvent implements Event {
    private Vec3d movementInput;
    private float speed;

    public MovePostEvent(float speed, Vec3d movementInput) {
        this.speed = speed;
        this.movementInput = movementInput;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }

    public Vec3d getMovementInput() {
        return movementInput;
    }

    public void setMovementInput(Vec3d movementInput) {
        this.movementInput = movementInput;
    }

    protected boolean canEqual(Object object) {
        return object instanceof MovePostEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof MovePostEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || Float.compare(getSpeed(), other.getSpeed()) != 0) {
            return false;
        }

        Vec3d thisInput = getMovementInput();
        Vec3d otherInput = other.getMovementInput();
        return thisInput == null ? otherInput == null : thisInput.equals(otherInput);
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getSpeed());
        Vec3d input = getMovementInput();
        return result * 59 + (input == null ? 43 : input.hashCode());
    }

    @Override
    public String toString() {
        return "EventOnMovePost(speed=" + getSpeed() + ", movementInput=" + getMovementInput() + ')';
    }
}
