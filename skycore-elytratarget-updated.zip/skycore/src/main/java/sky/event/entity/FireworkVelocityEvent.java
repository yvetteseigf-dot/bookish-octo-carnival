package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.util.math.Vec3d;

public class FireworkVelocityEvent implements Event {
    private Vec3d velocity;

    public FireworkVelocityEvent(Vec3d velocity) {
        this.velocity = velocity;
    }

    public Vec3d getVelocity() {
        return velocity;
    }

    public void setVelocity(Vec3d velocity) {
        this.velocity = velocity;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof FireworkVelocityEvent other)) return false;
        if (!other.canEqual(this)) return false;
        Vec3d thisVelocity = getVelocity();
        Vec3d otherVelocity = other.getVelocity();
        return thisVelocity == null ? otherVelocity == null : thisVelocity.equals(otherVelocity);
    }

    @Override
    public int hashCode() {
        Vec3d velocity = getVelocity();
        return 59 + (velocity == null ? 43 : velocity.hashCode());
    }

    @Override
    public String toString() {
        return "EventFireworkVelocity(velocity=" + getVelocity() + ')';
    }

    protected boolean canEqual(Object other) {
        return other instanceof FireworkVelocityEvent;
    }
}
