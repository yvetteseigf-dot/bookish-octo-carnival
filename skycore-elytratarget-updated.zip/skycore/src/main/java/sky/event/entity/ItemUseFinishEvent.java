package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

public class ItemUseFinishEvent extends EventCancellable implements Event {
    private LivingEntity entityLiving;
    private ItemStack itemStack;
    private World worldIn;

    public ItemUseFinishEvent(ItemStack itemStack, World worldIn, LivingEntity entityLiving) {
        this.itemStack = itemStack;
        this.worldIn = worldIn;
        this.entityLiving = entityLiving;
    }

    public void setItemStack(ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public void setWorldIn(World worldIn) {
        this.worldIn = worldIn;
    }

    public World getWorldIn() {
        return worldIn;
    }

    public LivingEntity getEntityLiving() {
        return entityLiving;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public void setEntityLiving(LivingEntity entityLiving) {
        this.entityLiving = entityLiving;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof ItemUseFinishEvent other)) return false;
        if (!other.canEqual(this)) return false;
        ItemStack thisItemStack = getItemStack();
        ItemStack otherItemStack = other.getItemStack();
        if (thisItemStack == null ? otherItemStack != null : !thisItemStack.equals(otherItemStack)) return false;
        World thisWorldIn = getWorldIn();
        World otherWorldIn = other.getWorldIn();
        if (thisWorldIn == null ? otherWorldIn != null : !thisWorldIn.equals(otherWorldIn)) return false;
        LivingEntity thisEntityLiving = getEntityLiving();
        LivingEntity otherEntityLiving = other.getEntityLiving();
        return thisEntityLiving == null ? otherEntityLiving == null : thisEntityLiving.equals(otherEntityLiving);
    }

    protected boolean canEqual(Object other) {
        return other instanceof ItemUseFinishEvent;
    }

    @Override
    public String toString() {
        return "EventUseFinish(itemStack=" + getItemStack() + ", worldIn=" + getWorldIn()
                + ", entityLiving=" + getEntityLiving() + ')';
    }

    @Override
    public int hashCode() {
        ItemStack itemStack = getItemStack();
        int result = 59 + (itemStack == null ? 43 : itemStack.hashCode());
        World worldIn = getWorldIn();
        result = result * 59 + (worldIn == null ? 43 : worldIn.hashCode());
        LivingEntity entityLiving = getEntityLiving();
        return result * 59 + (entityLiving == null ? 43 : entityLiving.hashCode());
    }
}
