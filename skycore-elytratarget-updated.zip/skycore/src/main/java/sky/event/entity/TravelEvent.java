package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.LivingEntity;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event fired as a living entity begins travelling. */
public class TravelEvent extends EventCancellable implements Event {
    private LivingEntity entity;

    public TravelEvent(LivingEntity entity) {
        this.entity = entity;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public void setEntity(LivingEntity entity) {
        this.entity = entity;
    }

    protected boolean canEqual(Object other) {
        return other instanceof TravelEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof TravelEvent other) || !other.canEqual(this)) {
            return false;
        }

        LivingEntity thisEntity = getEntity();
        LivingEntity otherEntity = other.getEntity();
        return thisEntity == null ? otherEntity == null : thisEntity.equals(otherEntity);
    }

    @Override
    public int hashCode() {
        LivingEntity entity = getEntity();
        return 59 + (entity == null ? 43 : entity.hashCode());
    }

    @Override
    public String toString() {
        return "EventTravel(entity=" + getEntity() + ')';
    }
}
