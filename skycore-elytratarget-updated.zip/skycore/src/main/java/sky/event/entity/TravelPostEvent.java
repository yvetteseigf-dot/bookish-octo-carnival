package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.util.math.Vec3d;

/** Post-travel event containing the entity velocity captured before travel. */
public class TravelPostEvent implements Event {
    private Vec3d oldVelocity;

    public TravelPostEvent(Vec3d oldVelocity) {
        this.oldVelocity = oldVelocity;
    }

    public Vec3d getOldVelocity() {
        return oldVelocity;
    }

    public void setOldVelocity(Vec3d oldVelocity) {
        this.oldVelocity = oldVelocity;
    }

    protected boolean canEqual(Object other) {
        return other instanceof TravelPostEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof TravelPostEvent other) || !other.canEqual(this)) {
            return false;
        }

        Vec3d thisVelocity = getOldVelocity();
        Vec3d otherVelocity = other.getOldVelocity();
        return thisVelocity == null ? otherVelocity == null : thisVelocity.equals(otherVelocity);
    }

    @Override
    public int hashCode() {
        Vec3d velocity = getOldVelocity();
        return 59 + (velocity == null ? 43 : velocity.hashCode());
    }

    @Override
    public String toString() {
        return "EventOnTravelPost(oldVelocity=" + getOldVelocity() + ')';
    }
}
