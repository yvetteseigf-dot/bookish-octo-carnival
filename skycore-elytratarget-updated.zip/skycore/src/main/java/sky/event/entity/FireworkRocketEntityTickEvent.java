package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class FireworkRocketEntityTickEvent extends EventCancellable implements Event {
    private int fireworkAge;
    private float ySpeed;
    private float speed;

    public FireworkRocketEntityTickEvent(float speed, float ySpeed, int fireworkAge) {
        this.speed = speed;
        this.ySpeed = ySpeed;
        this.fireworkAge = fireworkAge;
    }

    public int getFireworkAge() {
        return fireworkAge;
    }

    public void setFireworkAge(int fireworkAge) {
        this.fireworkAge = fireworkAge;
    }

    public float getYSpeed() {
        return ySpeed;
    }

    public void setYSpeed(float ySpeed) {
        this.ySpeed = ySpeed;
    }

    public float getSpeed() {
        return speed;
    }

    public void setSpeed(float speed) {
        this.speed = speed;
    }
}
