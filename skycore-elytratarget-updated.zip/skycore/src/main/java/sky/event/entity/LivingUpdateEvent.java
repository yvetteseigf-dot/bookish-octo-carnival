package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;

/** Event fired while a living entity is updated. */
public class LivingUpdateEvent implements Event {
    public LivingUpdateEvent() {
    }

    protected boolean canEqual(Object other) {
        return other instanceof LivingUpdateEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        return object instanceof LivingUpdateEvent other && other.canEqual(this);
    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public String toString() {
        return "EventLivingUpdate()";
    }
}
