package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.util.math.Vec3d;

/** Event whose vector position can be replaced by listeners. */
public class PositionEvent implements Event {
    private Vec3d pos;

    public PositionEvent(Vec3d pos) {
        this.pos = pos;
    }

    public Vec3d getPos() {
        return pos;
    }

    public void setPos(Vec3d pos) {
        this.pos = pos;
    }
}
