package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import java.util.List;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;

public class ItemUseEffectsEvent extends EventCancellable implements Event {
    private final List<StatusEffectInstance> effects;
    private final LivingEntity entity;
    private final ItemStack itemStack;
    private final double distanceFactor;

    public ItemUseEffectsEvent(LivingEntity entity, ItemStack itemStack, double distanceFactor,
                             List<StatusEffectInstance> effects) {
        this.entity = entity;
        this.itemStack = itemStack;
        this.distanceFactor = distanceFactor;
        this.effects = effects;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public double getDistanceFactor() {
        return distanceFactor;
    }

    public LivingEntity getEntity() {
        return entity;
    }

    public List<StatusEffectInstance> getEffects() {
        return effects;
    }
}
