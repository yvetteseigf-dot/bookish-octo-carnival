package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.util.math.BlockPos;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event emitted while an entity collides with a block state. */
public class WebCollisionEvent extends EventCancellable implements Event {
    private BlockPos blockPos;

    public WebCollisionEvent(BlockPos blockPos) {
        this.blockPos = blockPos;
    }

    public BlockPos getBlockPos() {
        return blockPos;
    }

    public void setBlockPos(BlockPos blockPos) {
        this.blockPos = blockPos;
    }
}
