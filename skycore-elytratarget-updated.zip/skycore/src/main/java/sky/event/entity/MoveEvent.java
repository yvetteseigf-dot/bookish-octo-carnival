package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public class MoveEvent implements Event {
    private final boolean toGround;
    public Vec3d to;
    public Vec3d from;
    public boolean ignoreHorizontal;
    private final Box aabbFrom;
    public boolean collidedVertical;
    public Vec3d motion;
    public boolean collidedHorizontal;
    public boolean ignoreVertical;

    public MoveEvent(Vec3d from, Vec3d to, Vec3d motion, boolean toGround,
                        boolean collidedHorizontal, boolean collidedVertical, Box aabbFrom) {
        this.from = from;
        this.to = to;
        this.motion = motion;
        this.toGround = toGround;
        this.collidedHorizontal = collidedHorizontal;
        this.collidedVertical = collidedVertical;
        this.aabbFrom = aabbFrom;
    }

    public void setCollidedHorizontal(boolean collidedHorizontal) {
        this.collidedHorizontal = collidedHorizontal;
    }

    public boolean isIgnoreHorizontal() {
        return ignoreHorizontal;
    }

    public Vec3d motion() {
        return motion;
    }

    public void setFrom(Vec3d from) {
        this.from = from;
    }

    public void setTo(Vec3d to) {
        this.to = to;
    }

    public Vec3d getMotion() {
        return motion;
    }

    public Vec3d getTo() {
        return to;
    }

    public boolean isCollidedHorizontal() {
        return collidedHorizontal;
    }

    public void setCollidedVertical(boolean collidedVertical) {
        this.collidedVertical = collidedVertical;
    }

    public void setMotion(Vec3d motion) {
        this.motion = motion;
    }

    public boolean isToGround() {
        return toGround;
    }

    public Box getAabbFrom() {
        return aabbFrom;
    }

    public boolean isIgnoreVertical() {
        return ignoreVertical;
    }

    public Vec3d getFrom() {
        return from;
    }

    public void setIgnoreHorizontal(boolean ignoreHorizontal) {
        this.ignoreHorizontal = ignoreHorizontal;
    }

    public boolean isCollidedVertical() {
        return collidedVertical;
    }

    public void setIgnoreVertical(boolean ignoreVertical) {
        this.ignoreVertical = ignoreVertical;
    }
}
