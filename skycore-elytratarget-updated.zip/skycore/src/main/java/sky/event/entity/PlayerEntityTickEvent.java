package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;

public class PlayerEntityTickEvent implements Event {
}
