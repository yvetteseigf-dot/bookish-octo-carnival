package sky.event.entity;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable request to suppress a specific kind of entity push. */
public class NoPushEvent extends EventCancellable implements Event {
    public final NoPushType noPushType;

    public NoPushEvent(NoPushType noPushType) {
        this.noPushType = noPushType;
    }

    public NoPushType getNoPushType() {
        return noPushType;
    }

    protected boolean canEqual(Object object) {
        return object instanceof NoPushEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof NoPushEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }

        NoPushType thisType = getNoPushType();
        NoPushType otherType = other.getNoPushType();
        return thisType == null ? otherType == null : thisType.equals(otherType);
    }

    @Override
    public int hashCode() {
        NoPushType type = getNoPushType();
        return 59 + (type == null ? 43 : type.hashCode());
    }

    @Override
    public String toString() {
        return "EventNoPush(noPushType=" + getNoPushType() + ')';
    }

    public enum NoPushType {
        Block,
        Water,
        Player,
        FishingRod
    }
}
