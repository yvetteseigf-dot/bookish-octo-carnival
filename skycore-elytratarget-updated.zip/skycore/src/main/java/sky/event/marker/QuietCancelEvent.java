package sky.event.marker;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class QuietCancelEvent extends EventCancellable implements Event {
    public QuietCancelEvent() {
    }
}
