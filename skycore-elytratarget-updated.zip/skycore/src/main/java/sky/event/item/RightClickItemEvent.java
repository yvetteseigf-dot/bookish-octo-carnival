package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;

public class RightClickItemEvent extends EventCancellable implements Event {
    private ItemStack itemStack;
    private Hand hand;

    public RightClickItemEvent(ItemStack itemStack, Hand hand) {
        this.itemStack = itemStack;
        this.hand = hand;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public void setItemStack(ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public Hand getHand() {
        return hand;
    }

    public void setHand(Hand hand) {
        this.hand = hand;
    }

    protected boolean canEqual(Object other) {
        return other instanceof RightClickItemEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof RightClickItemEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }
        ItemStack thisItemStack = getItemStack();
        ItemStack otherItemStack = other.getItemStack();
        if (thisItemStack == null ? otherItemStack != null : !thisItemStack.equals(otherItemStack)) {
            return false;
        }
        Hand thisHand = getHand();
        Hand otherHand = other.getHand();
        return thisHand == null ? otherHand == null : thisHand.equals(otherHand);
    }

    @Override
    public int hashCode() {
        ItemStack itemStack = getItemStack();
        int result = 59 + (itemStack == null ? 43 : itemStack.hashCode());
        Hand hand = getHand();
        return result * 59 + (hand == null ? 43 : hand.hashCode());
    }

    @Override
    public String toString() {
        return "EventRightClickItemCheck(itemStack=" + getItemStack() + ", hand=" + getHand() + ')';
    }
}
