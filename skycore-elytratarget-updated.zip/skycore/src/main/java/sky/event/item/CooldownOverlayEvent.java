package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.item.Item;

public class CooldownOverlayEvent extends EventCancellable implements Event {
    private Item item;
    private float partialTicks;

    public CooldownOverlayEvent(Item item, float partialTicks) {
        this.item = item;
        this.partialTicks = partialTicks;
    }

    public Item getItem() {
        return item;
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public void setPartialTicks(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    protected boolean canEqual(Object other) {
        return other instanceof CooldownOverlayEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof CooldownOverlayEvent other)) {
            return false;
        }
        if (!other.canEqual(this)) {
            return false;
        }
        if (Float.compare(getPartialTicks(), other.getPartialTicks()) != 0) {
            return false;
        }
        Item thisItem = getItem();
        Item otherItem = other.getItem();
        return thisItem == null ? otherItem == null : thisItem.equals(otherItem);
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getPartialTicks());
        Item item = getItem();
        return result * 59 + (item == null ? 43 : item.hashCode());
    }

    @Override
    public String toString() {
        return "EventCooldownTracker(item=" + getItem() + ", partialTicks=" + getPartialTicks() + ')';
    }
}
