package sky.event.item;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;

public class ItemPickupEvent extends EventCancellable implements Event {
    private int amount;
    private ItemStack itemStack;
    private Entity collector;
    private Entity collectedEntity;

    public ItemPickupEvent(Entity collectedEntity, Entity collector, ItemStack itemStack, int amount) {
        this.collectedEntity = collectedEntity;
        this.collector = collector;
        this.itemStack = itemStack;
        this.amount = amount;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public ItemStack getItemStack() {
        return itemStack;
    }

    public void setItemStack(ItemStack itemStack) {
        this.itemStack = itemStack;
    }

    public Entity getCollector() {
        return collector;
    }

    public void setCollector(Entity collector) {
        this.collector = collector;
    }

    public Entity getCollectedEntity() {
        return collectedEntity;
    }

    public void setCollectedEntity(Entity collectedEntity) {
        this.collectedEntity = collectedEntity;
    }

    protected boolean canEqual(Object other) {
        return other instanceof ItemPickupEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ItemPickupEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || getAmount() != other.getAmount()) {
            return false;
        }
        Entity thisCollectedEntity = getCollectedEntity();
        Entity otherCollectedEntity = other.getCollectedEntity();
        if (thisCollectedEntity == null ? otherCollectedEntity != null : !thisCollectedEntity.equals(otherCollectedEntity)) {
            return false;
        }
        Entity thisCollector = getCollector();
        Entity otherCollector = other.getCollector();
        if (thisCollector == null ? otherCollector != null : !thisCollector.equals(otherCollector)) {
            return false;
        }
        ItemStack thisItemStack = getItemStack();
        ItemStack otherItemStack = other.getItemStack();
        return thisItemStack == null ? otherItemStack == null : thisItemStack.equals(otherItemStack);
    }

    @Override
    public int hashCode() {
        int result = 59 + getAmount();
        Entity collectedEntity = getCollectedEntity();
        result = result * 59 + (collectedEntity == null ? 43 : collectedEntity.hashCode());
        Entity collector = getCollector();
        result = result * 59 + (collector == null ? 43 : collector.hashCode());
        ItemStack itemStack = getItemStack();
        return result * 59 + (itemStack == null ? 43 : itemStack.hashCode());
    }

    @Override
    public String toString() {
        return "EventItemPickup(collectedEntity=" + getCollectedEntity() + ", collector=" + getCollector()
                + ", itemStack=" + getItemStack() + ", amount=" + getAmount() + ')';
    }
}
