package sky.event.render;

import com.darkmagician6.eventapi.events.Event;

/** Render-timing event emitted from the client render loop. */
public class GameLoopEvent implements Event {
    int smoothIntervalMS;

    public GameLoopEvent() {
    }

    public void setSmoothIntervalMS(int smoothIntervalMS) {
        this.smoothIntervalMS = smoothIntervalMS;
    }

    public int getSmoothIntervalMS() {
        return smoothIntervalMS;
    }
}
