package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event allowing the requested field of view to be overridden. */
public class FovEvent extends EventCancellable implements Event {
    private int fov;
    private final int vanillaFov;

    public FovEvent(int fov) {
        this.vanillaFov = fov;
        this.fov = fov;
    }

    public int getFov() {
        return fov;
    }

    public void setFov(int fov) {
        this.fov = fov;
    }

    public int getVanillaFov() {
        return vanillaFov;
    }
}
