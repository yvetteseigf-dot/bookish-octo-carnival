package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.gui.DrawContext;

public class HudRenderEvent implements Event {
    private final DrawContext context;
    private final float partialTicks;

    public HudRenderEvent(DrawContext context, float partialTicks) {
        this.context = context;
        this.partialTicks = partialTicks;
    }

    public DrawContext getContext() {
        return context;
    }

    public float getPartialTicks() {
        return partialTicks;
    }
}
