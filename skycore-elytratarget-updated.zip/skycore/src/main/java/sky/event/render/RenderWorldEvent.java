package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;

/** Mutable/cancellable world-render boundary. */
public class RenderWorldEvent extends EventCancellable {
    public MatrixStack matrixStack;
    float partialTicks;

    public RenderWorldEvent(float partialTicks, MatrixStack matrixStack) {
        this.partialTicks = partialTicks;
        this.matrixStack = matrixStack;
    }

    public MatrixStack getMatrixStack() { return matrixStack; }
    public void setMatrixStack(MatrixStack matrixStack) { this.matrixStack = matrixStack; }
    public float getPartialTicks() { return partialTicks; }
    public void setPartialTicks(float partialTicks) { this.partialTicks = partialTicks; }
    protected boolean canEqual(Object other) { return other instanceof RenderWorldEvent; }
}
