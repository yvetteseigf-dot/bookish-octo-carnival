package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.render.chunk.ChunkBuilder.BuiltChunk;

public class ChunkContainerRenderEvent extends EventCancellable implements Event {
    private BuiltChunk chunkRender;

    public ChunkContainerRenderEvent(BuiltChunk chunkRender) {
        this.chunkRender = chunkRender;
    }

    public BuiltChunk getChunkRender() {
        return chunkRender;
    }

    public void setChunkRender(BuiltChunk chunkRender) {
        this.chunkRender = chunkRender;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof ChunkContainerRenderEvent other)) return false;
        if (!other.canEqual(this)) return false;
        BuiltChunk thisChunkRender = getChunkRender();
        BuiltChunk otherChunkRender = other.getChunkRender();
        return thisChunkRender == null ? otherChunkRender == null : thisChunkRender.equals(otherChunkRender);
    }

    protected boolean canEqual(Object other) {
        return other instanceof ChunkContainerRenderEvent;
    }

    @Override
    public int hashCode() {
        BuiltChunk chunkRender = getChunkRender();
        return 59 + (chunkRender == null ? 43 : chunkRender.hashCode());
    }

    @Override
    public String toString() {
        return "EventRenderChunkContainer(chunkRender=" + getChunkRender() + ')';
    }
}
