package sky.event.render;

import com.darkmagician6.eventapi.events.Event;

public class FirstPersonHandEvent implements Event {
    private FirstPersonHandEvent() {
    }

    public static final class Pre implements Event {
        public Pre() {
        }
    }

    public static final class Post implements Event {
        public Post() {
        }
    }
}
