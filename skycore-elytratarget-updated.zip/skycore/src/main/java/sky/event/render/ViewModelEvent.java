package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;

public class ViewModelEvent extends EventCancellable implements Event {
    private Arm arm;
    private MatrixStack matrixStack;

    public ViewModelEvent(MatrixStack matrixStack, Arm arm) {
        this.matrixStack = matrixStack;
        this.arm = arm;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }

    public void setMatrixStack(MatrixStack matrixStack) {
        this.matrixStack = matrixStack;
    }

    public Arm getArm() {
        return arm;
    }

    public void setArm(Arm arm) {
        this.arm = arm;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) return true;
        if (!(object instanceof ViewModelEvent other)) return false;
        if (!other.canEqual(this)) return false;
        MatrixStack thisMatrixStack = getMatrixStack();
        MatrixStack otherMatrixStack = other.getMatrixStack();
        if (thisMatrixStack == null ? otherMatrixStack != null : !thisMatrixStack.equals(otherMatrixStack)) return false;
        Arm thisArm = getArm();
        Arm otherArm = other.getArm();
        return thisArm == null ? otherArm == null : thisArm.equals(otherArm);
    }

    protected boolean canEqual(Object other) {
        return other instanceof ViewModelEvent;
    }

    @Override
    public int hashCode() {
        int result = 1;
        MatrixStack matrixStack = getMatrixStack();
        result = 59 + (matrixStack == null ? 43 : matrixStack.hashCode());
        Arm arm = getArm();
        return result * 59 + (arm == null ? 43 : arm.hashCode());
    }

    @Override
    public String toString() {
        return "EventViewModel(matrixStack=" + getMatrixStack() + ", Arm=" + getArm() + ')';
    }
}
