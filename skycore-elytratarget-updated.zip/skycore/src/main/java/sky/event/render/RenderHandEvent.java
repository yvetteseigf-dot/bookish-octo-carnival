package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

/** Mutable/cancellable first-person-hand render boundary. */
public class RenderHandEvent extends EventCancellable {
    private boolean thirdperson;

    public RenderHandEvent(boolean thirdperson) {
        this.thirdperson = thirdperson;
    }

    public boolean isThirdperson() { return thirdperson; }
    public void setThirdperson(boolean thirdperson) { this.thirdperson = thirdperson; }
    protected boolean canEqual(Object other) { return other instanceof RenderHandEvent; }
}
