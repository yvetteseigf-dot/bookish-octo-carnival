package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.entity.Entity;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable camera focus-entity decision. */
public class GameRendererEvent extends EventCancellable {
    private final Entity entity;

    public GameRendererEvent(Entity entity) {
        this.entity = entity;
    }

    public Entity getEntity() { return entity; }
    protected boolean canEqual(Object other) { return other instanceof GameRendererEvent; }
}
