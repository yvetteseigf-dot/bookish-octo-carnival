package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable hotbar-render event. */
public class HotbarRenderEvent extends EventCancellable implements Event {
    private float partialTicks;
    private MatrixStack stack;

    public HotbarRenderEvent(MatrixStack stack, float partialTicks) {
        this.stack = stack;
        this.partialTicks = partialTicks;
    }

    public float getPartialTicks() {
        return partialTicks;
    }

    public void setPartialTicks(float partialTicks) {
        this.partialTicks = partialTicks;
    }

    public MatrixStack getStack() {
        return stack;
    }

    public void setStack(MatrixStack stack) {
        this.stack = stack;
    }

    protected boolean canEqual(Object other) {
        return other instanceof HotbarRenderEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof HotbarRenderEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || Float.compare(getPartialTicks(), other.getPartialTicks()) != 0) {
            return false;
        }
        Object thisStack = getStack();
        Object otherStack = other.getStack();
        return thisStack == null ? otherStack == null : thisStack.equals(otherStack);
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = result * 59 + Float.floatToIntBits(getPartialTicks());
        Object stack = getStack();
        return result * 59 + (stack == null ? 43 : stack.hashCode());
    }

    @Override
    public String toString() {
        return "EventHotbarRender(stack=" + getStack() + ", partialTicks=" + getPartialTicks() + ")";
    }
}
