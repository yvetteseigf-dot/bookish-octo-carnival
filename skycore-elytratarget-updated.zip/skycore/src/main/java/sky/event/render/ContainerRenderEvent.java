package sky.event.render;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.screen.ScreenHandler;

/** Event emitted before and after a handled-screen container is rendered. */
public class ContainerRenderEvent extends EventCancellable implements Event {
    private MatrixStack stack;
    private ScreenHandler container;
    private int guiTop;
    private int guiLeft;

    public ContainerRenderEvent(MatrixStack stack, int guiLeft, int guiTop, ScreenHandler container) {
        this.stack = stack;
        this.guiLeft = guiLeft;
        this.guiTop = guiTop;
        this.container = container;
    }

    public MatrixStack getStack() {
        return stack;
    }

    public void setStack(MatrixStack stack) {
        this.stack = stack;
    }

    public ScreenHandler getContainer() {
        return container;
    }

    public void setContainer(ScreenHandler container) {
        this.container = container;
    }

    public int getGuiTop() {
        return guiTop;
    }

    public void setGuiTop(int guiTop) {
        this.guiTop = guiTop;
    }

    public int getGuiLeft() {
        return guiLeft;
    }

    public void setGuiLeft(int guiLeft) {
        this.guiLeft = guiLeft;
    }

    protected boolean canEqual(Object other) {
        return other instanceof ContainerRenderEvent;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ContainerRenderEvent other)) {
            return false;
        }
        if (!other.canEqual(this) || getGuiLeft() != other.getGuiLeft() || getGuiTop() != other.getGuiTop()) {
            return false;
        }
        Object thisStack = getStack();
        Object otherStack = other.getStack();
        if (thisStack == null ? otherStack != null : !thisStack.equals(otherStack)) {
            return false;
        }
        Object thisContainer = getContainer();
        Object otherContainer = other.getContainer();
        return thisContainer == null ? otherContainer == null : thisContainer.equals(otherContainer);
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = result * 59 + getGuiLeft();
        result = result * 59 + getGuiTop();
        Object stack = getStack();
        result = result * 59 + (stack == null ? 43 : stack.hashCode());
        Object container = getContainer();
        return result * 59 + (container == null ? 43 : container.hashCode());
    }

    @Override
    public String toString() {
        return "EventContainerRender(stack=" + getStack() + ", guiLeft=" + getGuiLeft()
                + ", guiTop=" + getGuiTop() + ", container=" + getContainer() + ")";
    }

    public static class Pre extends ContainerRenderEvent {
        public Pre(MatrixStack stack, int guiLeft, int guiTop, ScreenHandler container) {
            super(stack, guiLeft, guiTop, container);
        }
    }

    public static class Post extends ContainerRenderEvent {
        public Post(MatrixStack stack, int guiLeft, int guiTop, ScreenHandler container) {
            super(stack, guiLeft, guiTop, container);
        }
    }
}
