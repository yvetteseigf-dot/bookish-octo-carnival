package sky.event.render;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.Cancellable;

/** Cancellable event emitted at the beginning of a dynamic render tick. */
public class BeginRenderTickEvent extends EventCancellable implements Event {
    private final long gameTime;

    public BeginRenderTickEvent(long gameTime) {
        this.gameTime = gameTime;
    }

    public long getGameTime() {
        return gameTime;
    }
}
