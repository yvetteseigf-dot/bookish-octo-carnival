package sky.event.camera;

import com.darkmagician6.eventapi.events.Event;

public class CameraRotationEvent implements Event {
    private float pitch;
    private float yaw;

    public CameraRotationEvent(float pitch, float yaw) {
        this.pitch = pitch;
        this.yaw = yaw;
    }

    public float getPitch() {
        return pitch;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public float getYaw() {
        return yaw;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }
}
