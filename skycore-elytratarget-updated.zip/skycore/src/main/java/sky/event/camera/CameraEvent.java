package sky.event.camera;

import com.darkmagician6.eventapi.events.Event;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;

public class CameraEvent implements Event {
    private final Camera renderInfo;
    private final MatrixStack matrixStack;
    private final float partialTicks;

    public CameraEvent(MatrixStack matrixStack, float partialTicks, Camera renderInfo) {
        this.matrixStack = matrixStack;
        this.partialTicks = partialTicks;
        this.renderInfo = renderInfo;
    }

    public MatrixStack getMatrixStack() {
        return matrixStack;
    }

    public Camera getRenderInfo() {
        return renderInfo;
    }

    public float getPartialTicks() {
        return partialTicks;
    }
}
