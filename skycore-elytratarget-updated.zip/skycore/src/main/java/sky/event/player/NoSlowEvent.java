package sky.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class NoSlowEvent extends EventCancellable implements Event {
    public NoSlowEvent() {
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        return other instanceof NoSlowEvent that && that.canEqual(this);
    }

    public String toString() {
        return "EventNoSlow()";
    }

    public int hashCode() {
        return 1;
    }

    protected boolean canEqual(Object other) {
        return other instanceof NoSlowEvent;
    }
}
