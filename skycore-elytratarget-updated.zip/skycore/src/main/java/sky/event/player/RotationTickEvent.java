package sky.event.player;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class RotationTickEvent extends EventCancellable implements Event {
    public RotationTickEvent() {
    }
}
