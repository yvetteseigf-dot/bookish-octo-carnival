package sky.event.player;

import com.darkmagician6.eventapi.events.Event;

public class PlayerTickEvent implements Event {
}
