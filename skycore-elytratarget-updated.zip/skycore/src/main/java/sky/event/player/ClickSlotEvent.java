package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;
import net.minecraft.screen.slot.SlotActionType;

/** Mutable/cancellable inventory click description. */
public class ClickSlotEvent extends EventCancellable {
    private SlotActionType actionType;
    private int windowId;
    private int button;
    private int slotId;

    public ClickSlotEvent(int windowId, int slotId, int button, SlotActionType actionType) {
        this.windowId = windowId;
        this.slotId = slotId;
        this.button = button;
        this.actionType = actionType;
    }

    public void setWindowId(int windowId) { this.windowId = windowId; }
    public int getWindowId() { return windowId; }
    public SlotActionType getActionType() { return actionType; }
    public void setActionType(SlotActionType actionType) { this.actionType = actionType; }
    public void setButton(int button) { this.button = button; }
    public int getButton() { return button; }
    public int getSlotId() { return slotId; }
    public void setSlotId(int slotId) { this.slotId = slotId; }
}
