package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

/** Mutable movement packet state emitted immediately before client movement is sent. */
public class MotionEvent extends EventCancellable {
    private double y;
    private boolean onGround;
    private boolean isSneaking;
    private float yaw;
    private float pitch;
    private double x;
    private boolean isSprinting;
    private double z;

    public MotionEvent(
            double x, double y, double z, float yaw, float pitch,
            boolean onGround, boolean isSneaking, boolean isSprinting
    ) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.onGround = onGround;
        this.isSneaking = isSneaking;
        this.isSprinting = isSprinting;
    }

    public void setYaw(float yaw) { this.yaw = yaw; }
    public boolean isSprinting() { return isSprinting; }
    public void setX(double x) { this.x = x; }
    public void setOnGround(boolean onGround) { this.onGround = onGround; }
    public double getY() { return y; }
    public void setPitch(float pitch) { this.pitch = pitch; }
    public boolean isSneaking() { return isSneaking; }
    protected boolean canEqual(Object object) { return object instanceof MotionEvent; }
    public float getYaw() { return yaw; }
    public void setSneaking(boolean sneaking) { isSneaking = sneaking; }
    public float getPitch() { return pitch; }
    public void setSprinting(boolean sprinting) { isSprinting = sprinting; }
    public void setZ(double z) { this.z = z; }
    public double getZ() { return z; }
    public double getX() { return x; }
    public void setY(double y) { this.y = y; }
    public boolean isOnGround() { return onGround; }
}
