package sky.event.player;

import com.darkmagician6.eventapi.events.Event;

/** Marker emitted from the second client-player tick hook. */
public class PlayerUpdateEvent implements Event {
    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        return object instanceof PlayerUpdateEvent other && other.canEqual(this);
    }

    protected boolean canEqual(Object object) {
        return object instanceof PlayerUpdateEvent;
    }

    @Override
    public int hashCode() {
        return 1;
    }

    @Override
    public String toString() {
        return "EventUpdate()";
    }
}
