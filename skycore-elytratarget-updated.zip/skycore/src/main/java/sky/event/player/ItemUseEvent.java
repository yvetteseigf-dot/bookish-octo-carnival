package sky.event.player;

import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class ItemUseEvent extends EventCancellable {
}
