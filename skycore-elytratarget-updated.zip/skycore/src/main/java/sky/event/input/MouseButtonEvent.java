package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

public class MouseButtonEvent implements Event {
    private final int button;
    private final int action;

    public MouseButtonEvent(int button, int action) {
        this.button = button;
        this.action = action;
    }

    public int getButton() {
        return button;
    }

    public int getAction() {
        return action;
    }
}
