package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

/** Key-hold event. */
public class KeyHoldEvent implements Event {
    private int key;

    public KeyHoldEvent(int key) {
        this.key = key;
    }

    protected boolean canEqual(Object other) {
        return other instanceof KeyHoldEvent;
    }

    public int getKey() {
        return key;
    }

    @Override
    public int hashCode() {
        return 59 + getKey();
    }

    public void setKey(int key) {
        this.key = key;
    }

    @Override
    public String toString() {
        return "EventHold(key=" + getKey() + ")";
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof KeyHoldEvent other)) {
            return false;
        }
        return other.canEqual(this) && getKey() == other.getKey();
    }
}
