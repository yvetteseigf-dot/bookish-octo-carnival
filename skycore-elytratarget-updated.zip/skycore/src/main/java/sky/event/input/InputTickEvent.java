package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

/** Mutable client keyboard-input state. */
public class InputTickEvent implements Event {
    private boolean backKeyDown;
    private boolean leftKeyDown;
    private double sneakSlowDownMultiplier;
    private boolean jump;
    private float strafe;
    private boolean rightKeyDown;
    private boolean sneak;
    private float forward;
    private boolean forwardKeyDown;

    public InputTickEvent(
            float forward,
            float strafe,
            boolean forwardKeyDown,
            boolean backKeyDown,
            boolean leftKeyDown,
            boolean rightKeyDown,
            boolean jump,
            boolean sneak,
            double sneakSlowDownMultiplier
    ) {
        this.forward = forward;
        this.strafe = strafe;
        this.forwardKeyDown = forwardKeyDown;
        this.backKeyDown = backKeyDown;
        this.leftKeyDown = leftKeyDown;
        this.rightKeyDown = rightKeyDown;
        this.jump = jump;
        this.sneak = sneak;
        this.sneakSlowDownMultiplier = sneakSlowDownMultiplier;
    }

    public boolean isRightKeyDown() {
        return rightKeyDown;
    }

    public void setStrafe(float strafe) {
        this.strafe = strafe;
    }

    public boolean isJump() {
        return jump;
    }

    public boolean isLeftKeyDown() {
        return leftKeyDown;
    }

    protected boolean canEqual(Object other) {
        return other instanceof InputTickEvent;
    }

    public boolean isSneak() {
        return sneak;
    }

    public void setJump(boolean jump) {
        this.jump = jump;
    }

    public void setForwardKeyDown(boolean forwardKeyDown) {
        this.forwardKeyDown = forwardKeyDown;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof InputTickEvent other)) {
            return false;
        }
        return other.canEqual(this)
                && Float.compare(getForward(), other.getForward()) == 0
                && Float.compare(getStrafe(), other.getStrafe()) == 0
                && isForwardKeyDown() == other.isForwardKeyDown()
                && isBackKeyDown() == other.isBackKeyDown()
                && isLeftKeyDown() == other.isLeftKeyDown()
                && isRightKeyDown() == other.isRightKeyDown()
                && isJump() == other.isJump()
                && isSneak() == other.isSneak()
                && Double.compare(getSneakSlowDownMultiplier(), other.getSneakSlowDownMultiplier()) == 0;
    }

    public void setForward(float forward) {
        this.forward = forward;
    }

    public void setRightKeyDown(boolean rightKeyDown) {
        this.rightKeyDown = rightKeyDown;
    }

    @Override
    public String toString() {
        return "EventInput(forward=" + getForward()
                + ", strafe=" + getStrafe()
                + ", forwardKeyDown=" + isForwardKeyDown()
                + ", backKeyDown=" + isBackKeyDown()
                + ", leftKeyDown=" + isLeftKeyDown()
                + ", rightKeyDown=" + isRightKeyDown()
                + ", jump=" + isJump()
                + ", sneak=" + isSneak()
                + ", sneakSlowDownMultiplier=" + getSneakSlowDownMultiplier()
                + ")";
    }

    public void setLeftKeyDown(boolean leftKeyDown) {
        this.leftKeyDown = leftKeyDown;
    }

    public void setSneakSlowDownMultiplier(double sneakSlowDownMultiplier) {
        this.sneakSlowDownMultiplier = sneakSlowDownMultiplier;
    }

    public float getForward() {
        return forward;
    }

    @Override
    public int hashCode() {
        int result = 59 + Float.floatToIntBits(getForward());
        result = result * 59 + Float.floatToIntBits(getStrafe());
        result = result * 59 + (isForwardKeyDown() ? 79 : 97);
        result = result * 59 + (isBackKeyDown() ? 79 : 97);
        result = result * 59 + (isLeftKeyDown() ? 79 : 97);
        result = result * 59 + (isRightKeyDown() ? 79 : 97);
        result = result * 59 + (isJump() ? 79 : 97);
        result = result * 59 + (isSneak() ? 79 : 97);
        long multiplierBits = Double.doubleToLongBits(getSneakSlowDownMultiplier());
        return result * 59 + (int) (multiplierBits >>> 32 ^ multiplierBits);
    }

    public boolean isBackKeyDown() {
        return backKeyDown;
    }

    public void setSneak(boolean sneak) {
        this.sneak = sneak;
    }

    public boolean isForwardKeyDown() {
        return forwardKeyDown;
    }

    public void setBackKeyDown(boolean backKeyDown) {
        this.backKeyDown = backKeyDown;
    }

    public double getSneakSlowDownMultiplier() {
        return sneakSlowDownMultiplier;
    }

    public float getStrafe() {
        return strafe;
    }
}
