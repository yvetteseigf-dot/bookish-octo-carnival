package sky.event.input;

import com.darkmagician6.eventapi.events.Event;

/** Key state event dispatched while a screen is open. */
public class ScreenKeyEvent implements Event {
    private boolean hold;
    private int key;

    public ScreenKeyEvent(int key, boolean hold) {
        this.key = key;
        this.hold = hold;
    }

    public void setHold(boolean hold) {
        this.hold = hold;
    }

    @Override
    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof ScreenKeyEvent other)) {
            return false;
        }
        return other.canEqual(this) && getKey() == other.getKey() && isHold() == other.isHold();
    }

    public void setKey(int key) {
        this.key = key;
    }

    public int getKey() {
        return key;
    }

    @Override
    public String toString() {
        return "EventScreenKey(key=" + getKey() + ", hold=" + isHold() + ")";
    }

    public boolean isHold() {
        return hold;
    }

    @Override
    public int hashCode() {
        int result = 59 + getKey();
        return result * 59 + (isHold() ? 79 : 97);
    }

    protected boolean canEqual(Object other) {
        return other instanceof ScreenKeyEvent;
    }
}
