package sky.event.input;

import com.darkmagician6.eventapi.events.Event;
import com.darkmagician6.eventapi.events.callables.EventCancellable;

public class MouseClickedEvent extends EventCancellable implements Event {
    private final float mouseX;
    private final int key;
    private final float mouseY;

    public MouseClickedEvent(int key, float mouseX, float mouseY) {
        this.key = key;
        this.mouseX = mouseX;
        this.mouseY = mouseY;
    }

    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if (!(other instanceof MouseClickedEvent that) || !that.canEqual(this)) {
            return false;
        }
        return getKey() == that.getKey()
                && Float.compare(getMouseX(), that.getMouseX()) == 0
                && Float.compare(getMouseY(), that.getMouseY()) == 0;
    }

    public float getMouseX() {
        return mouseX;
    }

    public int hashCode() {
        int result = 59 + getKey();
        result = result * 59 + Float.floatToIntBits(getMouseX());
        return result * 59 + Float.floatToIntBits(getMouseY());
    }

    protected boolean canEqual(Object other) {
        return other instanceof MouseClickedEvent;
    }

    public String toString() {
        return "EventMouseClicked(key=" + getKey() + ", mouseX=" + getMouseX() + ", mouseY=" + getMouseY() + ")";
    }

    public int getKey() {
        return key;
    }

    public float getMouseY() {
        return mouseY;
    }
}
