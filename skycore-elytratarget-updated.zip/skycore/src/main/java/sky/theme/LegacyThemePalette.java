package sky.theme;

import java.awt.Color;

public final class LegacyThemePalette {
    private final String id;
    private final Color accent;
    private final Color panelTop;
    private final Color panelBottom;
    private final Color cardTop;
    private final Color cardBottom;
    private final Color cardActiveTop;
    private final Color cardActiveBottom;
    private final Color modeOff;
    private final Color sliderTrack;
    private final Color hudTop;
    private final Color hudBottom;

    public LegacyThemePalette(
            String id,
            Color accent,
            Color panelTop,
            Color panelBottom,
            Color cardTop,
            Color cardBottom,
            Color cardActiveTop,
            Color cardActiveBottom,
            Color modeOff,
            Color sliderTrack,
            Color hudTop,
            Color hudBottom
    ) {
        this.id = id;
        this.accent = accent;
        this.panelTop = panelTop;
        this.panelBottom = panelBottom;
        this.cardTop = cardTop;
        this.cardBottom = cardBottom;
        this.cardActiveTop = cardActiveTop;
        this.cardActiveBottom = cardActiveBottom;
        this.modeOff = modeOff;
        this.sliderTrack = sliderTrack;
        this.hudTop = hudTop;
        this.hudBottom = hudBottom;
    }

    public String getId() {
        return id;
    }

    public Color getAccent() {
        return accent;
    }

    public void apply() {
        GuiTheme theme = GuiTheme.theme;
        theme.setPanelTop(panelTop);
        theme.setPanelBottom(panelBottom);
        theme.setCardTop(cardTop);
        theme.setCardBottom(cardBottom);
        theme.setCardActiveTop(cardActiveTop);
        theme.setCardActiveBottom(cardActiveBottom);
        theme.setAccent(accent);
        theme.setToggleOn(accent);
        theme.setModeOn(accent);
        theme.setSliderFill(accent);
        theme.setModeOff(modeOff);
        theme.setSliderTrack(sliderTrack);
    }
}
