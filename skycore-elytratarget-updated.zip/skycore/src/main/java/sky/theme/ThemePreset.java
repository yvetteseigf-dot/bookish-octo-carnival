package sky.theme;

import java.awt.Color;

/**
 * A named collection of GUI colours.  Presets are either legacy palettes,
 * release palettes, or the animated rainbow preset handled by ThemeRegistry.
 */
public final class ThemePreset {
    private final String id;
    private final String name;
    private final boolean releasePreset;
    private final boolean animated;
    private final Color clientColor;
    private final Color hudColor;
    private final Color accent;
    private final Color panelTop;
    private final Color panelBottom;
    private final Color cardTop;
    private final Color cardBottom;
    private final Color cardActiveTop;
    private final Color cardActiveBottom;
    private final Color modeOff;
    private final Color sliderTrack;
    private final Color toggleOff;
    private final Color hudSeparator;

    private ThemePreset(
            String id,
            String name,
            boolean releasePreset,
            boolean animated,
            Color clientColor,
            Color hudColor,
            Color accent,
            Color panelTop,
            Color panelBottom,
            Color cardTop,
            Color cardBottom,
            Color cardActiveTop,
            Color cardActiveBottom,
            Color modeOff,
            Color sliderTrack,
            Color toggleOff,
            Color hudSeparator
    ) {
        this.id = id;
        this.name = name;
        this.releasePreset = releasePreset;
        this.animated = animated;
        this.clientColor = clientColor;
        this.hudColor = hudColor;
        this.accent = accent;
        this.panelTop = panelTop;
        this.panelBottom = panelBottom;
        this.cardTop = cardTop;
        this.cardBottom = cardBottom;
        this.cardActiveTop = cardActiveTop;
        this.cardActiveBottom = cardActiveBottom;
        this.modeOff = modeOff;
        this.sliderTrack = sliderTrack;
        this.toggleOff = toggleOff;
        this.hudSeparator = hudSeparator;
    }

    public static ThemePreset legacy(
            String id,
            String name,
            Color accent,
            Color panelTop,
            Color panelBottom,
            Color cardTop,
            Color cardBottom,
            Color cardActiveTop,
            Color cardActiveBottom,
            Color modeOff,
            Color sliderTrack,
            Color toggleOff,
            Color hudSeparator
    ) {
        return legacy(
                id,
                name,
                accent,
                panelTop,
                panelBottom,
                cardTop,
                cardBottom,
                cardActiveTop,
                cardActiveBottom,
                modeOff,
                sliderTrack,
                toggleOff,
                hudSeparator,
                false
        );
    }

    public static ThemePreset legacy(
            String id,
            String name,
            Color accent,
            Color panelTop,
            Color panelBottom,
            Color cardTop,
            Color cardBottom,
            Color cardActiveTop,
            Color cardActiveBottom,
            Color modeOff,
            Color sliderTrack,
            Color toggleOff,
            Color hudSeparator,
            boolean animated
    ) {
        return new ThemePreset(
                id,
                name,
                false,
                animated,
                null,
                null,
                accent,
                panelTop,
                panelBottom,
                cardTop,
                cardBottom,
                cardActiveTop,
                cardActiveBottom,
                modeOff,
                sliderTrack,
                toggleOff,
                hudSeparator
        );
    }

    public static ThemePreset release(String id, String name, Color clientColor, Color hudColor) {
        return new ThemePreset(
                id,
                name,
                true,
                false,
                clientColor,
                hudColor,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null,
                null
        );
    }

    public String getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public boolean isReleasePreset() {
        return this.releasePreset;
    }

    public boolean isAnimated() {
        return this.animated;
    }

    public Color getClientColor() {
        return this.releasePreset ? this.clientColor : this.panelTop;
    }

    public Color getHudColor() {
        if (this.animated) {
            return ThemeRegistry.getRainbowColor();
        }

        return this.releasePreset ? this.hudColor : this.accent;
    }

    public Color getAccent() {
        return this.getHudColor();
    }

    public Color getPanelTop() {
        return this.releasePreset ? rgbOpaque(this.clientColor) : this.panelTop;
    }

    public Color getSwatchColor() {
        return this.getAccent();
    }

    public void apply() {
        if (this.animated) {
            ThemeRegistry.applyRainbowTheme();
            return;
        }

        if (this.releasePreset) {
            applyPalette(this.clientColor, this.hudColor);
            return;
        }

        this.applyLegacy(this.accent);
    }

    static void applyPalette(Color clientColor, Color hudColor) {
        GuiTheme theme = GuiTheme.theme;
        theme.setWindowBg(clientColor);

        Color opaqueClientColor = rgbOpaque(clientColor);
        theme.setPanelTop(scaleRgb(opaqueClientColor, 1.08F));
        theme.setPanelBottom(scaleRgb(opaqueClientColor, 0.55F));
        theme.setCardTop(scaleRgb(opaqueClientColor, 0.95F));
        theme.setCardBottom(scaleRgb(opaqueClientColor, 0.65F));
        theme.setCardActiveTop(scaleRgb(opaqueClientColor, 1.12F));
        theme.setCardActiveBottom(scaleRgb(opaqueClientColor, 0.75F));
        theme.setAccent(hudColor);
        theme.setToggleOn(hudColor);
        theme.setModeOn(hudColor);
        theme.setSliderFill(hudColor);
        theme.setModeOff(withAlpha(scaleRgb(opaqueClientColor, 1.15F), 180));
        theme.setSliderTrack(scaleRgb(opaqueClientColor, 0.85F));
        theme.setToggleOff(scaleRgb(opaqueClientColor, 0.72F));
        theme.setHudSeparator(scaleRgb(opaqueClientColor, 0.48F));
    }

    private void applyLegacy(Color accentColor) {
        GuiTheme theme = GuiTheme.theme;
        theme.setWindowBg(GuiTheme.DEFAULT_WINDOW_BG);
        theme.setPanelTop(this.panelTop);
        theme.setPanelBottom(this.panelBottom);
        theme.setCardTop(this.cardTop);
        theme.setCardBottom(this.cardBottom);
        theme.setCardActiveTop(this.cardActiveTop);
        theme.setCardActiveBottom(this.cardActiveBottom);
        theme.setAccent(accentColor);
        theme.setToggleOn(accentColor);
        theme.setModeOn(accentColor);
        theme.setSliderFill(accentColor);
        theme.setModeOff(this.modeOff);
        theme.setSliderTrack(this.sliderTrack);
        theme.setToggleOff(this.toggleOff);
        theme.setHudSeparator(this.hudSeparator);
    }

    private static int clampChannel(float value) {
        return Math.max(0, Math.min(255, Math.round(value)));
    }

    private static Color scaleRgb(Color color, float factor) {
        return new Color(
                clampChannel(color.getRed() * factor),
                clampChannel(color.getGreen() * factor),
                clampChannel(color.getBlue() * factor),
                color.getAlpha()
        );
    }

    private static Color withAlpha(Color color, int alpha) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
    }

    private static Color rgbOpaque(Color color) {
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), 255);
    }
}
