package sky.ui.animation;

import sky.util.animation.TweenFloat;

/**
 * Slide-in offset applied to the pause menu side panel.
 */
public final class EscPanelAnimation {
    private static final TweenFloat PANEL = new TweenFloat(0.0f);

    private EscPanelAnimation() {
    }

    public static void beginOpen(boolean animated) {
        if (animated) {
            PANEL.setDuration(240L);
            PANEL.snap(28.0f);
            PANEL.animateTo(0.0f);
        } else {
            PANEL.snap(0.0f);
        }
    }

    public static float updateOffset() {
        return PANEL.update();
    }
}
