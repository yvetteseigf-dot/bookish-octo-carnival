package sky.ui.animation;

import java.util.Objects;

import net.minecraft.util.math.MathHelper;

/**
 * Tweens a highlight rectangle between list entries. The first selection snaps into place;
 * every later change to a different key eases across from wherever the indicator currently is.
 */
public final class SelectionIndicatorAnimation {
    private Object selectionKey;

    private float x;
    private float y;
    private float width;
    private float height;

    private float fromX;
    private float fromY;
    private float fromWidth;
    private float fromHeight;

    private float targetX;
    private float targetY;
    private float targetWidth;
    private float targetHeight;

    private long startMs;
    private long durationMs = 280L;
    private boolean initialized;
    private boolean animating;

    public void setDuration(long durationMs) {
        this.durationMs = Math.max(1L, durationMs);
    }

    public void setSelection(Object key, float x, float y, float width, float height) {
        if (!initialized) {
            snapTo(x, y, width, height);
            selectionKey = key;
            initialized = true;
            return;
        }

        if (Objects.equals(selectionKey, key)) {
            targetX = x;
            targetY = y;
            targetWidth = width;
            targetHeight = height;

            if (!animating) {
                snapTo(x, y, width, height);
            }

            return;
        }

        selectionKey = key;
        fromX = this.x;
        fromY = this.y;
        fromWidth = this.width;
        fromHeight = this.height;
        targetX = x;
        targetY = y;
        targetWidth = width;
        targetHeight = height;
        startMs = System.currentTimeMillis();
        animating = true;
    }

    public void update() {
        if (!initialized || !animating) {
            return;
        }

        float progress = MathHelper.clamp((System.currentTimeMillis() - startMs) / (float) durationMs, 0.0f, 1.0f);
        float inverse = 1.0f - progress;
        progress = 1.0f - inverse * inverse * inverse * inverse;

        x = fromX + (targetX - fromX) * progress;
        y = fromY + (targetY - fromY) * progress;
        width = fromWidth + (targetWidth - fromWidth) * progress;
        height = fromHeight + (targetHeight - fromHeight) * progress;

        if (progress >= 1.0f) {
            snapTo(targetX, targetY, targetWidth, targetHeight);
            animating = false;
        }
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    private void snapTo(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        fromX = x;
        fromY = y;
        fromWidth = width;
        fromHeight = height;
        targetX = x;
        targetY = y;
        targetWidth = width;
        targetHeight = height;
    }
}
