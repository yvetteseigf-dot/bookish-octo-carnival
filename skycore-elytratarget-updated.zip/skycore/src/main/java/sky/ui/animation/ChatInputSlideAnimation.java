package sky.ui.animation;

import sky.util.animation.TweenFloat;

/**
 * Slides the chat input field up into place when the chat screen opens.
 */
public final class ChatInputSlideAnimation {
    private static final float START_OFFSET = 18.0f;

    private final TweenFloat offset;
    private boolean active;

    public ChatInputSlideAnimation() {
        this.offset = new TweenFloat(0.0f);
    }

    public void start(long durationMs) {
        active = true;
        offset.setDuration(durationMs);
        offset.snap(START_OFFSET);
        offset.animateTo(0.0f);
    }

    public void update() {
        if (active) {
            offset.update();
        }
    }

    public float getOffset() {
        return active ? offset.get() : 0.0f;
    }

    public boolean isSliding() {
        return active && offset.get() > 0.05f;
    }

    public void reset() {
        active = false;
        offset.snap(0.0f);
    }
}
