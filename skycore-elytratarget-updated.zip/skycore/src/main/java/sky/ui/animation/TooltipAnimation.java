package sky.ui.animation;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.client.gui.tooltip.TooltipPositioner;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import sky.mixin.gui.DrawContextAccessor;
import sky.module.visuals.Animations;
import sky.util.animation.TweenFloat;

/**
 * Scale/fade animation for vanilla tooltips.
 *
 * <p>The last drawn tooltip is cached so the closing animation can keep replaying it for a few
 * frames after the game stopped asking for it.</p>
 */
public final class TooltipAnimation {
    private static final TweenFloat progress = new TweenFloat(0.0f);

    private static int lastFingerprint = Integer.MIN_VALUE;
    private static boolean seenThisFrame;
    private static boolean bypass;
    private static boolean hasCache;
    private static TextRenderer cachedRenderer;
    private static List<TooltipComponent> cachedComponents;
    private static int cachedX;
    private static int cachedY;
    private static TooltipPositioner cachedPositioner;
    private static Identifier cachedTexture;
    private static boolean matrixPushed;
    private static boolean colorPushed;

    private TooltipAnimation() {
    }

    public static boolean enabled() {
        return Animations.effect(Animations.TOOLTIP);
    }

    public static float beginDraw(TextRenderer textRenderer, List<TooltipComponent> components, int mouseX, int mouseY,
                                  TooltipPositioner positioner, Identifier texture) {
        if (bypass) {
            return MathHelper.clamp(progress.get(), 0.0f, 1.0f);
        }
        if (!enabled() || components == null || components.isEmpty()) {
            return 1.0f;
        }
        if (InventoryCloseAnimation.shouldHideContent()) {
            return 0.0f;
        }

        seenThisFrame = true;

        int fingerprint = fingerprint(textRenderer, components);
        if (fingerprint != lastFingerprint) {
            lastFingerprint = fingerprint;
            progress.setDuration(160L);
            progress.snap(0.0f);
            progress.animateTo(1.0f);
        } else if (progress.getTarget() < 0.5f) {
            progress.setDuration(140L);
            progress.animateTo(1.0f);
        }

        cachedRenderer = textRenderer;
        cachedComponents = new ArrayList<>(components);
        cachedX = mouseX;
        cachedY = mouseY;
        cachedPositioner = positioner;
        cachedTexture = texture;
        hasCache = true;

        return MathHelper.clamp(progress.update(), 0.0f, 1.0f);
    }

    public static void applyTransform(DrawContext context, int mouseX, int mouseY, float t) {
        matrixPushed = false;
        colorPushed = false;

        if (t >= 0.999f) {
            return;
        }
        if (t <= 0.01f) {
            return;
        }

        float scale = 0.88f + 0.12f * easeOutBack(t);
        float alpha = MathHelper.clamp(t * 1.2f, 0.0f, 1.0f);

        context.getMatrices().push();
        context.getMatrices().translate(mouseX, mouseY, 0.0f);
        context.getMatrices().scale(scale, scale, 1.0f);
        context.getMatrices().translate(-mouseX, -mouseY, 0.0f);
        matrixPushed = true;

        if (alpha < 0.999f) {
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, alpha);
            colorPushed = true;
        }
    }

    public static void endDraw(DrawContext context) {
        if (colorPushed) {
            RenderSystem.setShaderColor(1.0f, 1.0f, 1.0f, 1.0f);
            colorPushed = false;
        }
        if (matrixPushed) {
            context.getMatrices().pop();
            matrixPushed = false;
        }
    }

    /**
     * Replays the cached tooltip while it fades out, once the game no longer requests it.
     */
    public static void endFrame(DrawContext context) {
        if (!enabled()) {
            seenThisFrame = false;
            return;
        }
        if (seenThisFrame) {
            seenThisFrame = false;
            return;
        }
        if (!hasCache || cachedRenderer == null || cachedComponents == null || cachedComponents.isEmpty()) {
            reset();
            return;
        }
        if (InventoryCloseAnimation.shouldHideContent()) {
            reset();
            return;
        }

        if (progress.getTarget() > 0.01f) {
            progress.setDuration(120L);
            progress.animateTo(0.0f);
        }
        progress.update();

        if (progress.get() <= 0.02f) {
            reset();
            return;
        }

        bypass = true;
        try {
            ((DrawContextAccessor) context).callDrawTooltip(cachedRenderer, cachedComponents, cachedX, cachedY,
                    cachedPositioner, cachedTexture);
        } finally {
            bypass = false;
        }

        seenThisFrame = false;
    }

    public static void reset() {
        seenThisFrame = false;
        bypass = false;
        hasCache = false;
        lastFingerprint = Integer.MIN_VALUE;
        cachedRenderer = null;
        cachedComponents = null;
        cachedPositioner = null;
        cachedTexture = null;
        progress.snap(0.0f);
    }

    private static int fingerprint(TextRenderer textRenderer, List<TooltipComponent> components) {
        int hash = components.size();
        int sampled = Math.min(components.size(), 4);
        for (int i = 0; i < sampled; i++) {
            TooltipComponent component = components.get(i);
            hash = hash * 31 + component.getWidth(textRenderer);
            hash = hash * 31 + component.getHeight(textRenderer);
        }
        return hash;
    }

    private static float easeOutBack(float t) {
        t = MathHelper.clamp(t, 0.0f, 1.0f);
        float overshoot = 1.70158f;
        float scaled = overshoot + 1.0f;
        float offset = t - 1.0f;
        return 1.0f + scaled * offset * offset * offset + overshoot * offset * offset;
    }
}
