package sky.ui.animation;

import sky.util.animation.TweenFloat;

/**
 * Per-line chat animation: slides a new line in horizontally and pushes it up as newer lines arrive.
 */
public final class ChatLineAnimation {
    private final TweenFloat offsetX;
    private final TweenFloat offsetY;

    public ChatLineAnimation(float startX, long durationMs) {
        this.offsetX = new TweenFloat(startX);
        this.offsetX.setDuration(durationMs);
        this.offsetX.animateTo(0.0f);
        this.offsetY = new TweenFloat(0.0f);
        this.offsetY.setDuration(durationMs);
    }

    public void pushUp(float lineHeight, long durationMs) {
        offsetY.setDuration(durationMs);
        offsetY.snap(offsetY.get() + lineHeight);
        offsetY.animateTo(0.0f);
    }

    public void update() {
        offsetX.update();
        offsetY.update();
    }

    public float getX() {
        return offsetX.get();
    }

    public float getY() {
        return offsetY.get();
    }

    public boolean isFinished() {
        return offsetX.isDone() && offsetY.isDone()
                && Math.abs(offsetX.get()) < 0.05f
                && Math.abs(offsetY.get()) < 0.05f;
    }
}
