package sky.ui.animation;

import net.minecraft.util.math.MathHelper;
import sky.module.visuals.Animations;
import sky.util.animation.TweenFloat;

/**
 * Staggered reveal of the ghost recipe overlay slots in the crafting screen.
 */
public final class GhostRecipeAnimation {
    private static final TweenFloat progress = new TweenFloat(1.0f);
    private static int lastCount = -1;

    private GhostRecipeAnimation() {
    }

    public static float beginDraw(int itemCount) {
        if (!Animations.effect(Animations.TOOLTIP)) {
            return 1.0f;
        }

        if (itemCount <= 0) {
            lastCount = 0;
            progress.snap(0.0f);
            return 0.0f;
        }

        if (lastCount <= 0) {
            progress.setDuration(240L);
            progress.snap(0.0f);
            progress.animateTo(1.0f);
        }

        lastCount = itemCount;
        return MathHelper.clamp(progress.update(), 0.0f, 1.0f);
    }

    public static float slotScale(float global, int index) {
        float delay = index * 0.045f;
        float local = MathHelper.clamp((global - delay) / 0.6f, 0.0f, 1.0f);
        float remaining = 1.0f - local;
        return 0.7f + 0.3f * (1.0f - remaining * remaining * remaining);
    }

    public static void onClear() {
        lastCount = 0;
        progress.snap(0.0f);
    }

    public static void reset() {
        lastCount = -1;
        progress.snap(1.0f);
    }
}
