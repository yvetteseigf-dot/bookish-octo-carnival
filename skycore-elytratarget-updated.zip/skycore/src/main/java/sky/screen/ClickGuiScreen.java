package sky.screen;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import sky.SkyInit;
import sky.config.BindCapture;
import sky.debug.BlurDebugLogger;
import sky.debug.ClickGuiDebugLogger;
import sky.theme.GuiTheme;
import sky.theme.ThemeRegistry;
import sky.module.Category;
import sky.module.Module;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.GuiSurfaceRenderer;
import sky.render.DrawHelper;
import sky.clickgui.ClickGuiLayout;
import sky.clickgui.ClickGuiSidebar;
import sky.clickgui.ConfigPanel;
import sky.clickgui.ModuleCard;
import sky.clickgui.ModuleListPanel;
import sky.clickgui.ModuleSearchBar;
import sky.clickgui.NavTab;
import sky.clickgui.ThemesPanel;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;
import sky.util.render.HudScaleUtil;
import sky.util.animation.SmoothFloat;

/**
 * The click GUI: a fixed-size window with a category sidebar and one swappable content panel.
 */
public final class ClickGuiScreen extends Screen {
    private static final long OPEN_DURATION_MS = 420L;
    private static final float OPEN_FLY_DIST = 64.0f;
    private static final float SECTION_SMOOTHING = 0.11f;
    private static final float SECTION_SLIDE = 26.0f;

    private final Map<Category, ModuleListPanel> categoryViews = new EnumMap<>(Category.class);
    private final List<Module> allModules = new ArrayList<>();
    private final FadeAnimation openAnimation = new FadeAnimation();
    private final SmoothFloat sectionAlpha = new SmoothFloat(SECTION_SMOOTHING);
    private final SmoothFloat sectionSlideY = new SmoothFloat(SECTION_SMOOTHING);
    private final SmoothFloat sectionSlideX = new SmoothFloat(SECTION_SMOOTHING);
    private final ThemesPanel themesView = new ThemesPanel();
    private final ConfigPanel configsView = new ConfigPanel();
    private NavTab renderedSection = NavTab.COMBAT;

    private final ModuleListPanel globalSearchView;
    private final ModuleSearchBar searcher;
    private final ClickGuiSidebar sidebar;

    private float windowX;
    private float windowY;
    private boolean closing;

    public ClickGuiScreen() {
        super(Text.literal("Skycore"));

        List<ModuleCard> allCards = new ArrayList<>();
        for (Category category : Category.values()) {
            List<ModuleCard> cards = new ArrayList<>();
            for (Module module : SkyInit.getInstance().getModuleManager().getModules(category)) {
                ModuleCard card = new ModuleCard(module);
                cards.add(card);
                allCards.add(card);
                allModules.add(module);
            }

            categoryViews.put(category, new ModuleListPanel(cards));
        }

        globalSearchView = new ModuleListPanel(allCards);
        searcher = new ModuleSearchBar(allModules);
        sidebar = new ClickGuiSidebar(searcher);

        sectionAlpha.setImmediate(1.0f);
        sectionSlideY.setImmediate(0.0f);
        sectionSlideX.setImmediate(0.0f);
    }

    @Override
    protected void init() {
        super.init();
        closing = false;
        openAnimation.reset();
        openAnimation.fadeIn(OPEN_DURATION_MS);
        ThemeRegistry.apply(ThemeRegistry.getCurrent());
        layoutWindow();
        collapseAllModules();
    }

    @Override
    public void tick() {
        openAnimation.update();
        if (closing && !openAnimation.isVisible()) {
            finishClose();
        }
    }

    @Override
    public void close() {
        if (closing) {
            return;
        }

        closing = true;
        openAnimation.fadeOut(OPEN_DURATION_MS);
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        float alpha = openAnimation.getAlpha();
        openAnimation.update();
        if (alpha <= 0.01f) {
            return;
        }

        ClickGuiDebugLogger.log("Screen", "FULL render alpha=" + alpha + " window=" + windowX + "," + windowY
                + " style=" + String.valueOf(GuiTheme.theme.getGuiStyle()) + " " + BlurDebugLogger.describeKawase());

        themesView.syncStyleFromSettings();
        ThemeRegistry.update();
        sectionAlpha.update();
        sectionSlideY.update();
        sectionSlideX.update();

        DrawHelper.runOverlay(() -> {
            float windowTop = getAnimatedWindowY();
            GuiSurfaceRenderer.drawWindowBackground(renderer, windowX, windowTop, 450.0f, 370.0f, 36.0f, alpha,
                    context.getMatrices());
            sidebar.render(renderer, context.getMatrices(), windowX, windowTop, 370.0f, mouseX, mouseY, alpha);

            float panelX = ClickGuiLayout.contentX(windowX) - 7.0f;
            float panelY = ClickGuiLayout.contentY(windowTop);
            GuiSurfaceRenderer.drawPanelBackground(renderer, panelX, panelY, 322.0f, 354.0f, 34.0f, alpha,
                    context.getMatrices());

            NavTab selected = sidebar.getSelected();
            if (selected != renderedSection) {
                int direction = Integer.compare(selected.ordinal(), renderedSection.ordinal());
                if (direction == 0) {
                    direction = 1;
                }

                renderedSection = selected;
                sectionAlpha.setImmediate(Math.max(0.18f, sectionAlpha.get() * 0.45f));
                sectionAlpha.setTarget(1.0f);
                sectionSlideY.setImmediate(direction * SECTION_SLIDE);
                sectionSlideY.setTarget(0.0f);
                sectionSlideX.setImmediate(direction > 0 ? 10.0f : -10.0f);
                sectionSlideX.setTarget(0.0f);

                if (selected.isCategory()) {
                    categoryViews.get(selected.getCategory()).onShow();
                }
            }

            float sectionFade = alpha * Math.max(0.05f, sectionAlpha.get());
            float slideY = sectionSlideY.get();
            float slideX = sectionSlideX.get();

            if (searcher.hasActiveQuery()) {
                globalSearchView.render(renderer, context, panelX, panelY, 322.0f, 354.0f, mouseX, mouseY,
                        sectionFade, searcher.getQuery(), slideX, slideY);
            } else if (selected.isCategory()) {
                ModuleListPanel view = categoryViews.get(selected.getCategory());
                view.render(renderer, context, panelX, panelY, 322.0f, 354.0f, mouseX, mouseY,
                        sectionFade, "", slideX, slideY);
            } else if (selected == NavTab.THEMES) {
                themesView.render(renderer, context, panelX + slideX, panelY + slideY, 322.0f, 354.0f,
                        mouseX, mouseY, sectionFade);
            } else {
                configsView.render(renderer, context, panelX + slideX, panelY + slideY, 322.0f, 354.0f,
                        mouseX, mouseY, sectionFade);
            }

            renderBindHint(renderer, context, alpha, windowTop);
        });
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (BindCapture.hasActive() && button >= 0) {
            BindCapture.applyKey(button);
            return true;
        }

        float windowTop = getAnimatedWindowY();
        float contentX = ClickGuiLayout.contentX(windowX);
        float contentY = ClickGuiLayout.contentY(windowTop);

        if (sidebar.mouseClicked(mouseX, mouseY, button, windowX, windowTop, 370.0f, this::focusModule)) {
            return true;
        }

        NavTab selected = sidebar.getSelected();
        if (searcher.hasActiveQuery()) {
            if (globalSearchView.mouseClicked(mouseX, mouseY, button, contentX, contentY, 322.0f, 354.0f,
                    searcher.getQuery())) {
                return true;
            }
        } else if (selected.isCategory()) {
            ModuleListPanel view = categoryViews.get(selected.getCategory());
            if (view.mouseClicked(mouseX, mouseY, button, contentX, contentY, 322.0f, 354.0f, "")) {
                return true;
            }
        } else if (selected == NavTab.THEMES) {
            if (themesView.mouseClicked(mouseX, mouseY, button, contentX, contentY, 322.0f, 354.0f)) {
                return true;
            }
        } else if (configsView.mouseClicked(mouseX, mouseY, button, contentX, contentY, 322.0f, 354.0f)) {
            return true;
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        NavTab selected = sidebar.getSelected();
        float contentX = ClickGuiLayout.contentX(windowX);
        float contentY = ClickGuiLayout.contentY(getAnimatedWindowY());

        if (searcher.hasActiveQuery()) {
            globalSearchView.mouseReleased(mouseX, mouseY, button, contentX, contentY, 322.0f, searcher.getQuery());
        } else if (selected.isCategory()) {
            categoryViews.get(selected.getCategory())
                    .mouseReleased(mouseX, mouseY, button, contentX, contentY, 322.0f, "");
        } else if (selected == NavTab.THEMES) {
            themesView.mouseReleased(mouseX, mouseY, button);
        }

        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        NavTab selected = sidebar.getSelected();
        float contentX = ClickGuiLayout.contentX(windowX);
        float contentY = ClickGuiLayout.contentY(getAnimatedWindowY());

        if (searcher.hasActiveQuery()) {
            if (globalSearchView.mouseDragged(mouseX, mouseY, button, contentX, contentY, 322.0f,
                    searcher.getQuery())) {
                return true;
            }
        } else if (selected.isCategory()) {
            if (categoryViews.get(selected.getCategory())
                    .mouseDragged(mouseX, mouseY, button, contentX, contentY, 322.0f, "")) {
                return true;
            }
        } else if (selected == NavTab.THEMES) {
            if (themesView.mouseDragged(mouseX, mouseY, button)) {
                return true;
            }
        }

        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        float contentX = ClickGuiLayout.contentX(windowX);
        float contentY = ClickGuiLayout.contentY(getAnimatedWindowY());
        NavTab selected = sidebar.getSelected();

        if (searcher.hasActiveQuery()) {
            if (globalSearchView.mouseScrolled(mouseX, mouseY, verticalAmount, contentX, contentY, 322.0f, 354.0f,
                    searcher.getQuery())) {
                return true;
            }
        } else if (selected.isCategory()) {
            if (categoryViews.get(selected.getCategory()).mouseScrolled(mouseX, mouseY, verticalAmount,
                    contentX, contentY, 322.0f, 354.0f, "")) {
                return true;
            }
        } else if (selected == NavTab.THEMES) {
            if (themesView.mouseScrolled(mouseX, mouseY, verticalAmount, contentX, contentY, 322.0f, 354.0f)) {
                return true;
            }
        } else if (configsView.mouseScrolled(mouseX, mouseY, verticalAmount, contentX, contentY, 322.0f, 354.0f)) {
            return true;
        }

        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (BindCapture.hasActive()) {
            if (keyCode == 256) {
                BindCapture.applyKey(-1);
            } else {
                BindCapture.applyKey(keyCode);
            }

            return true;
        }

        if (searcher.keyPressed(keyCode)) {
            return true;
        }

        if (configsView.keyPressed(keyCode)) {
            return true;
        }

        NavTab selected = sidebar.getSelected();
        if (searcher.hasActiveQuery()) {
            globalSearchView.keyPressed(keyCode, scanCode, modifiers);
        } else if (selected.isCategory()) {
            categoryViews.get(selected.getCategory()).keyPressed(keyCode, scanCode, modifiers);
        } else if (selected == NavTab.THEMES) {
            themesView.keyPressed(keyCode, scanCode, modifiers);
        }

        if (keyCode == 256 || keyCode == 344) {
            close();
            return true;
        }

        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean charTyped(char chr, int modifiers) {
        if (searcher.charTyped(chr)) {
            return true;
        }

        if (configsView.charTyped(chr)) {
            return true;
        }

        return super.charTyped(chr, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return true;
    }

    private void renderBindHint(DrawHelper renderer, DrawContext context, float alpha, float drawY) {
        if (!BindCapture.hasActive()) {
            return;
        }

        GuiTheme theme = GuiTheme.theme;
        FontRenderer font = FontRegistry.getClickGuiRegular(14);
        if (font == null) {
            return;
        }

        String label = BindCapture.getListeningLabel();
        float width = Math.max(72.0f, font.getWidth(label) + 18.0f);
        float x = HudScaleUtil.getRenderWidth() / 2.0f - width / 2.0f;
        float y = drawY - 20.0f - 8.0f;

        theme.drawGradient(renderer, x, y, width, 20.0f, 20.0f / 2.0f,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha),
                context.getMatrices());

        font.drawCentered(label, x + width / 2.0f, y + (20.0f - font.getLineHeight(label)) / 2.0f,
                ColorUtil.withAlpha(theme.getAccent(), alpha), context.getMatrices());
    }

    private void focusModule(Module module) {
        sidebar.selectCategory(module.getCategory());

        ModuleListPanel view = categoryViews.get(module.getCategory());
        view.focusModule(module, ClickGuiLayout.contentX(windowX),
                ClickGuiLayout.contentY(getAnimatedWindowY()), 322.0f, 354.0f);
    }

    private void collapseAllModules() {
        for (ModuleListPanel view : categoryViews.values()) {
            view.collapseAll();
        }

        globalSearchView.collapseAll();
    }

    private void layoutWindow() {
        float renderWidth = HudScaleUtil.getRenderWidth();
        float renderHeight = HudScaleUtil.getRenderHeight();
        windowX = (renderWidth - 450.0f) / 2.0f;
        windowY = (renderHeight - 370.0f) / 2.0f;
    }

    /** Window top edge including the open/close fly-in offset. */
    private float getAnimatedWindowY() {
        float alpha = openAnimation.getAlpha();
        if (closing) {
            return windowY + (1.0f - alpha) * OPEN_FLY_DIST;
        }

        return windowY + (1.0f - alpha) * -OPEN_FLY_DIST;
    }

    private void finishClose() {
        SkyInit.getInstance().getClientConfig().saveCurrentSettings();
        closing = false;
        super.close();
    }
}
