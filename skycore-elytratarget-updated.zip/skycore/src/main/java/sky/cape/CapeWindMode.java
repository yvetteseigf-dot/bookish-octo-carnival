package sky.cape;

public enum CapeWindMode {
    NONE,
    WAVES
}
