package sky.cape;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import sky.model.CapePhysicsSimulation;
import sky.module.movement.AirStuck;
import sky.util.math.MutableXY;
import sky.util.math.MutableXYZ;

/** Provides the per-player simulation update used by the cape renderer. */
public interface CapeSimulationHolder {
    default void updateSimulation(AbstractClientPlayerEntity player, int pointCount) {
        CapePhysicsSimulation simulation = getSimulation();
        if (simulation == null) {
            return;
        }

        if (simulation.init(pointCount)) {
            simulation.applyMovement(new MutableXYZ(1.0F, 1.0F, 0.0F));
            for (int index = 0; index < 5; index++) {
                simulate(player);
            }
        }
    }

    default void simulate(AbstractClientPlayerEntity player) {
        CapePhysicsSimulation simulation = getSimulation();
        if (simulation == null || simulation.empty()) {
            return;
        }

        if (AirStuck.INSTANCE.isFrozen()) {
            simulation.setGravityDirection(new MutableXYZ(0.0F, -1.0F, 0.0F));
            simulation.setGravity(CapeManager.config.gravity);
            simulation.applyMovement(new MutableXYZ(0.0F, 0.0F, 0.0F));
            simulation.simulate();
            return;
        }

        double deltaX = player.lastRenderX - player.getX();
        double deltaZ = player.lastRenderZ - player.getZ();
        float bodyYaw = player.bodyYaw;
        double sinYaw = MathHelper.sin(bodyYaw * 0.017453292F);
        double negativeCosYaw = -MathHelper.cos(bodyYaw * 0.017453292F);
        float heightMultiplier = CapeManager.config.heightMultiplier;
        float strafeMultiplier = CapeManager.config.straveMultiplier;

        if (player.isTouchingWater()) {
            heightMultiplier *= 2.0F;
        }

        double verticalDelta = MathHelper.clamp((player.lastRenderY - player.getY()) * 10.0D, 0.0D, 1.0D);
        if (player.isTouchingWater()) {
            simulation.setGravity(CapeManager.config.gravity / 10.0F);
        } else {
            simulation.setGravity(CapeManager.config.gravity);
        }

        MutableXYZ gravityDirection = new MutableXYZ(0.0F, -1.0F, 0.0F);
        MutableXY horizontalMovement = new MutableXY(
                (float) (player.getX() - player.lastRenderX),
                (float) (player.getZ() - player.lastRenderZ)
        );
        horizontalMovement.rotateDegrees(-player.getYaw());

        double forwardMovement = deltaX * sinYaw + deltaZ * negativeCosYaw + verticalDelta
                + (player.isSneaking() && !simulation.isSneaking() ? 3.0D : 0.0D);
        double verticalMovement = (player.getY() - player.lastRenderY) * heightMultiplier
                + (player.isSneaking() && !simulation.isSneaking() ? 1.0D : 0.0D);
        double sidewaysMovement = -horizontalMovement.x * strafeMultiplier;

        simulation.setSneaking(player.isSneaking());
        MutableXYZ movement = new MutableXYZ(
                (float) forwardMovement,
                (float) verticalMovement,
                (float) sidewaysMovement
        );
        simulation.setGravityDirection(gravityDirection);
        simulation.applyMovement(movement);
        simulation.simulate();
    }

    CapePhysicsSimulation getSimulation();
}
