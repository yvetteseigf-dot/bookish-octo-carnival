package sky.cape;

public enum CapeStyle {
    SMOOTH,
    SEGMENTED
}
