package sky.macro;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.util.Formatting;
import sky.SkyInit;
import sky.util.text.CommandFeedback;
import sky.util.input.KeyCode;

import java.util.List;
import sky.command.Command;
import sky.command.KeyArgumentType;
import sky.command.MacroArgumentType;

public final class Macro extends Command {
    public Macro() {
        super("macro");
    }

    @Override
    public void register(CommandDispatcher<CommandSource> dispatcher) {
        for (String alias : List.of("macro", "mac")) {
            LiteralArgumentBuilder<CommandSource> builder = LiteralArgumentBuilder.literal(alias);
            execute(builder);
            dispatcher.register(builder);
        }
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(arg("name", StringArgumentType.word())
                .then(arg("bind", KeyArgumentType.create())
                        .then(arg("text", StringArgumentType.greedyString()).executes(context -> {
                            String name = context.getArgument("name", String.class);
                            String bind = context.getArgument("bind", String.class);
                            String text = context.getArgument("text", String.class);
                            int keyCode = KeyCode.getKeyCode(bind);
                            if (keyCode == -1) {
                                CommandFeedback.displayInfo("Key " + String.valueOf(Formatting.WHITE)
                                        + bind.toUpperCase() + String.valueOf(Formatting.GRAY) + " not found");
                                return 1;
                            }
                            SkyInit.getInstance().getMacroManager().addMacro(name, keyCode, text);
                            CommandFeedback.displayInfo("Macro " + String.valueOf(Formatting.WHITE) + name
                                    + String.valueOf(Formatting.GRAY) + " on key "
                                    + String.valueOf(Formatting.WHITE) + bind.toUpperCase()
                                    + String.valueOf(Formatting.GRAY) + " added");
                            return 1;
                        })))));

        builder.then(literal("remove").then(arg("name", MacroArgumentType.create()).executes(context -> {
            String name = context.getArgument("name", String.class);
            boolean exists = SkyInit.getInstance().getMacroManager().getMacros().stream()
                    .anyMatch(entry -> entry.getName().equalsIgnoreCase(name));
            if (!exists) {
                CommandFeedback.displayInfo("Macro " + String.valueOf(Formatting.WHITE) + name
                        + String.valueOf(Formatting.GRAY) + " not found");
                return 1;
            }
            SkyInit.getInstance().getMacroManager().removeMacro(name);
            CommandFeedback.displayInfo("Macro " + String.valueOf(Formatting.WHITE) + name
                    + String.valueOf(Formatting.GRAY) + " removed");
            return 1;
        })));

        builder.then(literal("list").executes(context -> {
            List<MacrosFile.MacroEntry> macros = SkyInit.getInstance().getMacroManager().getMacros();
            if (macros.isEmpty()) {
                CommandFeedback.displayInfo("Macro list is empty");
                return 1;
            }
            StringBuilder text = new StringBuilder();
            for (MacrosFile.MacroEntry entry : macros) {
                text.append("\n")
                        .append(Formatting.GRAY)
                        .append(entry.getName())
                        .append(Formatting.WHITE)
                        .append(" [")
                        .append(KeyCode.getKeyName(entry.getKeyCode()))
                        .append("] ")
                        .append(Formatting.GREEN)
                        .append(entry.getCommand());
            }
            CommandFeedback.displayInfo(text.toString());
            return 1;
        }));

        builder.then(literal("clear").executes(context -> {
            if (SkyInit.getInstance().getMacroManager().getMacros().isEmpty()) {
                CommandFeedback.displayInfo("Macro list is empty");
                return 1;
            }
            SkyInit.getInstance().getMacroManager().clear();
            CommandFeedback.displayInfo("Macro list cleared");
            return 1;
        }));
    }
}
