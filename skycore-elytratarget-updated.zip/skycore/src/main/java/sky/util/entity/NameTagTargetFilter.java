package sky.util.entity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import sky.SkyInit;
import sky.module.visuals.Tags;

public final class NameTagTargetFilter {
    private NameTagTargetFilter() {
    }

    public static boolean shouldHideVanillaNameTag(Entity entity) {
        Tags module = Tags.INSTANCE;
        if (!module.isEnabled() || !module.hideOriginal.get()) {
            return false;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return false;
        }

        if (entity instanceof ItemEntity) {
            return module.rendering.is("Items");
        }
        if (entity instanceof LivingEntity living && living.isAlive()) {
            return isEntityTarget(living, module);
        }
        return false;
    }

    public static boolean isEntityTarget(LivingEntity entity, Tags module) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (entity == client.player) {
            return module.rendering.is("Self") && !client.options.getPerspective().isFirstPerson();
        }
        if (entity instanceof PlayerEntity player) {
            String profileName = player.getGameProfile() == null ? "" : player.getGameProfile().getName();
            boolean friend = SkyInit.getInstance() != null
                    && SkyInit.getInstance().getFriendManager() != null
                    && SkyInit.getInstance().getFriendManager().isFriend(profileName);
            if (friend) {
                return module.rendering.is("Friends");
            }
            if (module.rendering.is("Players")) {
                return true;
            }
            return module.rendering.is("Naked") && hasNoArmor(player);
        }
        if (entity instanceof VillagerEntity) {
            return module.rendering.is("Villagers");
        }
        if (entity instanceof AnimalEntity) {
            return module.rendering.is("Animals");
        }
        if (entity instanceof MobEntity) {
            return module.rendering.is("Monsters");
        }
        return false;
    }

    private static boolean hasNoArmor(PlayerEntity player) {
        for (ItemStack stack : player.getArmorItems()) {
            if (!stack.isEmpty()) {
                return false;
            }
        }
        return true;
    }
}
