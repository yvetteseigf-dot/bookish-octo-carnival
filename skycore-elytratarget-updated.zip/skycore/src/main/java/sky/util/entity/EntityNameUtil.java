package sky.util.entity;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import sky.util.text.TextUtil;

public final class EntityNameUtil {
    private EntityNameUtil() {
    }

    public static Text resolveEntityDisplayName(LivingEntity entity) {
        Text name = TextUtil.sanitizeDisplayText(resolveRawDisplayName(entity));
        if (entity instanceof PlayerEntity player) {
            name = TextUtil.truncateAfterPlayerName(name, player.getGameProfile().getName());
        }
        return TextUtil.replaceSymbols(name);
    }

    public static String resolvePlainName(LivingEntity entity) {
        Text name = resolveEntityDisplayName(entity);
        return TextUtil.replaceSymbols(name.getString());
    }

    private static Text resolveRawDisplayName(LivingEntity entity) {
        if (entity instanceof PlayerEntity player) {
            MinecraftClient client = MinecraftClient.getInstance();
            ClientPlayNetworkHandler networkHandler = client.getNetworkHandler();
            if (networkHandler != null) {
                PlayerListEntry entry = networkHandler.getPlayerListEntry(player.getUuid());
                if (entry == null) {
                    entry = networkHandler.getPlayerListEntry(player.getGameProfile().getName());
                }
                if (entry != null && entry.getDisplayName() != null) {
                    return entry.getDisplayName();
                }
            }

            Team team = player.getScoreboardTeam();
            if (team != null) {
                return Team.decorateName(team, player.getName());
            }
        }
        return entity.getDisplayName();
    }
}
