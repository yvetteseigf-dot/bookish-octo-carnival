package sky.util.entity;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.access.MinecraftAccess;

public final class EntityVectorUtil implements MinecraftAccess {
    private EntityVectorUtil() {
    }

    public static Vec3d getVector(Entity entity) {
        Vec3d playerEyePos = mc.player.getEyePos();
        double distanceWeight = MathHelper.clamp(
                playerEyePos.distanceTo(entity.getPos().add(0.0D, entity.getEyeHeight(entity.getPose()), 0.0D)) / 3.0D,
                0.0D,
                1.0D);
        Box box = entity.getBoundingBox();
        double targetY = MathHelper.lerp(distanceWeight, box.minY, MathHelper.clamp(playerEyePos.y, box.minY, box.maxY));
        Vec3d target = new Vec3d(entity.getX(), targetY, entity.getZ());
        Vec3d direction = target.subtract(playerEyePos);
        return direction.normalize().multiply(playerEyePos.distanceTo(entity.getEyePos()));
    }

    public static Direction getFacingFromVector(Vec3d vector) {
        if (Math.abs(vector.x) > Math.abs(vector.y)) {
            if (Math.abs(vector.x) > Math.abs(vector.z)) {
                return vector.x > 0.0D ? Direction.EAST : Direction.WEST;
            }
            return vector.z > 0.0D ? Direction.SOUTH : Direction.NORTH;
        }
        if (Math.abs(vector.y) > Math.abs(vector.z)) {
            return vector.y > 0.0D ? Direction.UP : Direction.DOWN;
        }
        return vector.z > 0.0D ? Direction.SOUTH : Direction.NORTH;
    }

    public static Vec3d getClosestVec(Vec3d point, Box box) {
        return new Vec3d(
                MathHelper.clamp(point.x, box.minX, box.maxX),
                MathHelper.clamp(point.y, box.minY, box.maxY),
                MathHelper.clamp(point.z, box.minZ, box.maxZ));
    }

    public static Vec3d getClosestVec(Entity entity) {
        Vec3d playerEyePos = mc.player.getEyePos();
        return getClosestVec(playerEyePos, entity).subtract(playerEyePos);
    }

    public static Vec3d getClosestVec(Vec3d point, Entity entity) {
        return getClosestVec(point, entity.getBoundingBox());
    }

    public static double getStrictDistance(Entity entity) {
        return getClosestVec(entity).length();
    }
}
