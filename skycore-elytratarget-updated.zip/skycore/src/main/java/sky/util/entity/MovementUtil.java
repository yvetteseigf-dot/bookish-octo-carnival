package sky.util.entity;

import java.util.Objects;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.camera.FreeLookCamera;
import sky.access.MinecraftAccess;
import sky.event.input.StrafeInputEvent;
import sky.util.combat.RotationUtil;

/**
 * Movement helpers that convert an arbitrary heading into the discrete forward/strafe pair the
 * vanilla input system understands, plus the strafe maths used to set velocity directly.
 */
public final class MovementUtil implements MinecraftAccess {

    private MovementUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static boolean hasPlayerMovement() {
        return mc.player.input.movementForward != 0.0F || mc.player.input.movementSideways != 0.0F;
    }

    public static double direction(float rotationYaw, float moveForward, float moveStrafing) {
        if (moveForward < 0.0F) {
            rotationYaw += 180.0F;
        }

        float forwardScale = 1.0F;
        if (moveForward < 0.0F) {
            forwardScale = -0.5F;
        }
        if (moveForward > 0.0F) {
            forwardScale = 0.5F;
        }

        if (moveStrafing > 0.0F) {
            rotationYaw -= 90.0F * forwardScale;
        }
        if (moveStrafing < 0.0F) {
            rotationYaw += 90.0F * forwardScale;
        }

        return Math.toRadians(rotationYaw);
    }

    public static double getDirection(boolean toRadians) {
        float yaw = mc.player.getYaw();
        float forward = mc.player.input.movementForward;
        float strafe = mc.player.input.movementSideways;

        if (forward < 0.0F) {
            yaw += 180.0F;
        }

        float forwardScale = 1.0F;
        if (forward < 0.0F) {
            forwardScale = -0.5F;
        } else if (forward > 0.0F) {
            forwardScale = 0.5F;
        }

        if (strafe > 0.0F) {
            yaw -= 90.0F * forwardScale;
        }
        if (strafe < 0.0F) {
            yaw += 90.0F * forwardScale;
        }

        return toRadians ? Math.toRadians(yaw) : yaw;
    }

    public static double getSpeedSqrt(Entity entity) {
        double deltaX = entity.getX() - entity.lastRenderX;
        double deltaY = entity.getY() - entity.lastRenderY;
        double deltaZ = entity.getZ() - entity.lastRenderZ;
        return Math.sqrt(deltaX * deltaX + deltaZ * deltaZ + deltaY * deltaY);
    }

    public static double getDegreesRelativeToView(Vec3d positionRelativeToPlayer, float yaw) {
        float angle = (float) Math.atan2(-positionRelativeToPlayer.x, positionRelativeToPlayer.z);
        double viewAngle = Math.toRadians(MathHelper.wrapDegrees(yaw));
        return Math.toDegrees(MathHelper.wrapDegrees(angle - viewAngle));
    }

    /**
     * Resolves the current input into a world-space movement vector of the requested length,
     * collapsing diagonal input onto a single 45-degree-offset axis the way vanilla does.
     *
     * @return the horizontal offset as {@code { x, z }}
     */
    public static double[] calculateDirection(double distance) {
        float forward = mc.player.input.movementForward;
        float strafe = mc.player.input.movementSideways;
        float yaw = mc.player.getYaw();

        if (forward != 0.0F) {
            if (strafe > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }

        double sin = Math.sin(Math.toRadians(yaw + 90.0F));
        double cos = Math.cos(Math.toRadians(yaw + 90.0F));

        double x = forward * distance * cos + strafe * distance * sin;
        double z = forward * distance * sin - strafe * distance * cos;
        return new double[] { x, z };
    }

    public static void setVelocity(double velocity) {
        double[] direction = calculateDirection(velocity);
        Objects.requireNonNull(mc.player).setVelocity(direction[0], mc.player.getVelocity().getY(), direction[1]);
    }

    public static void setVelocity(double velocity, double y) {
        double[] direction = calculateDirection(velocity);
        Objects.requireNonNull(mc.player).setVelocity(direction[0], y, direction[1]);
    }

    public static void fixMovement(StrafeInputEvent event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();

        float sourceYaw = mc.player.isGliding() ? yaw : mc.player.getYaw();
        double targetYaw = MathHelper.wrapDegrees(Math.toDegrees(direction(sourceYaw, forward, strafe)));

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float candidateForward = -1.0F; candidateForward <= 1.0F; candidateForward += 1.0F) {
            for (float candidateStrafe = -1.0F; candidateStrafe <= 1.0F; candidateStrafe += 1.0F) {
                if (candidateStrafe == 0.0F && candidateForward == 0.0F) {
                    continue;
                }

                double candidateYaw = MathHelper.wrapDegrees(Math.toDegrees(
                        direction(yaw, candidateForward, candidateStrafe)));
                double difference = Math.abs(targetYaw - candidateYaw);

                if (difference < bestDifference) {
                    bestDifference = (float) difference;
                    bestForward = candidateForward;
                    bestStrafe = candidateStrafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }

    public static void fixMovementFull(StrafeInputEvent event, float aimYaw, LivingEntity target) {
        if (target == null || mc.player == null) {
            return;
        }

        float targetYaw = RotationUtil.calculateAngle(target.getPos()).getYaw();
        float forward = event.getForward();
        float strafe = event.getStrafe();

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        double targetDirection = MathHelper.wrapDegrees(Math.toDegrees(direction(targetYaw, forward, strafe)));

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float candidateForward = -1.0F; candidateForward <= 1.0F; candidateForward += 1.0F) {
            for (float candidateStrafe = -1.0F; candidateStrafe <= 1.0F; candidateStrafe += 1.0F) {
                if (candidateStrafe == 0.0F && candidateForward == 0.0F) {
                    continue;
                }

                double candidateYaw = MathHelper.wrapDegrees(Math.toDegrees(
                        direction(aimYaw, candidateForward, candidateStrafe)));
                double difference = Math.abs(targetDirection - candidateYaw);

                if (difference < bestDifference) {
                    bestDifference = (float) difference;
                    bestForward = candidateForward;
                    bestStrafe = candidateStrafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }

    public static void fixMovementFocus(StrafeInputEvent event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        double targetYaw = MathHelper.wrapDegrees(Math.toDegrees(direction(yaw, forward, strafe)));

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float candidateForward = -1.0F; candidateForward <= 1.0F; candidateForward += 1.0F) {
            for (float candidateStrafe = -1.0F; candidateStrafe <= 1.0F; candidateStrafe += 1.0F) {
                if (candidateForward == 0.0F && candidateStrafe == 0.0F) {
                    continue;
                }

                double candidateYaw = MathHelper.wrapDegrees(Math.toDegrees(
                        direction(yaw, candidateForward, candidateStrafe)));
                float difference = Math.abs(MathHelper.wrapDegrees((float) (targetYaw - candidateYaw)));

                if (difference < bestDifference) {
                    bestDifference = difference;
                    bestForward = candidateForward;
                    bestStrafe = candidateStrafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }

    public static void fixMovementFree(StrafeInputEvent event) {
        float forward = event.getForward();
        float strafe = event.getStrafe();

        float sourceYaw = mc.player.isGliding() ? mc.player.getYaw() : FreeLookCamera.getFreeYaw();
        double targetYaw = MathHelper.wrapDegrees(Math.toDegrees(direction(sourceYaw, forward, strafe)));

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float candidateForward = -1.0F; candidateForward <= 1.0F; candidateForward += 1.0F) {
            for (float candidateStrafe = -1.0F; candidateStrafe <= 1.0F; candidateStrafe += 1.0F) {
                if (candidateStrafe == 0.0F && candidateForward == 0.0F) {
                    continue;
                }

                double candidateYaw = MathHelper.wrapDegrees(Math.toDegrees(
                        direction(mc.player.getYaw(), candidateForward, candidateStrafe)));
                double difference = Math.abs(targetYaw - candidateYaw);

                if (difference < bestDifference) {
                    bestDifference = (float) difference;
                    bestForward = candidateForward;
                    bestStrafe = candidateStrafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }

    public static PlayerInput getDirectionalInputForDegrees(PlayerInput input, double dgs) {
        return getDirectionalInputForDegrees(input, dgs, 20.0F);
    }

    public static PlayerInput getDirectionalInputForDegrees(PlayerInput input, double dgs, float deadAngle) {
        boolean forward = input.forward();
        boolean backward = input.backward();
        boolean left = input.left();
        boolean right = input.right();

        if (dgs >= -90.0F + deadAngle && dgs <= 90.0F - deadAngle) {
            forward = true;
        } else if (dgs < -90.0F - deadAngle || dgs > 90.0F + deadAngle) {
            backward = true;
        }

        if (dgs >= 0.0F + deadAngle && dgs <= 180.0F - deadAngle) {
            right = true;
        } else if (dgs >= -180.0F + deadAngle && dgs <= 0.0F - deadAngle) {
            left = true;
        }

        return new PlayerInput(forward, backward, left, right, input.jump(), input.sneak(), input.sprint());
    }
}
