package sky.util.entity;

import com.google.common.collect.Lists;
import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.SequencedPacketCreator;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.scoreboard.ReadableScoreboardScore;
import net.minecraft.scoreboard.ScoreboardDisplaySlot;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.MutableText;
import net.minecraft.util.Hand;
import net.minecraft.util.collection.DefaultedList;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import sky.session.SilentPacketUtil;
import sky.access.SkyClientAccess;
import sky.mixin.network.ClientPlayerInteractionManagerAccessor;
import sky.util.render.ArgbUtil;

public final class PlayerUtil implements SkyClientAccess {
    private PlayerUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static boolean nullCheck() {
        return mc.player == null || mc.world == null;
    }

    public static InputUtil.Type getKeyType(int key) {
        if (key < 8) {
            return InputUtil.Type.MOUSE;
        }
        return InputUtil.Type.KEYSYM;
    }

    public static boolean isKey(InputUtil.Key key) {
        return isKey(key.getCategory(), key.getCode());
    }

    public static boolean isKey(InputUtil.Type type, int keyCode) {
        if (keyCode == -1) {
            return false;
        }
        switch (type) {
            case KEYSYM:
                return GLFW.glfwGetKey(mc.getWindow().getHandle(), keyCode) == 1;
            case MOUSE:
                return GLFW.glfwGetMouseButton(mc.getWindow().getHandle(), keyCode) == 1;
            default:
                return false;
        }
    }

    public static boolean isChat(Screen screen) {
        return screen instanceof ChatScreen;
    }

    public static void sendPacketWithOutEvent(Packet<?> packet) {
        mc.getNetworkHandler().getConnection().send(packet, (PacketCallbacks) null);
    }

    public static void sendSequencedPacket(SequencedPacketCreator packetCreator) {
        ((ClientPlayerInteractionManagerAccessor) mc.interactionManager).skycore$sendSequencedPacket(mc.world, packetCreator);
    }

    public static void useItem(Hand hand) {
        if (mc.player == null || mc.interactionManager == null || hand == null) {
            return;
        }
        mc.interactionManager.interactItem(mc.player, hand);
    }

    public static void startFallFlying() {
        mc.player.networkHandler.sendPacket(
            new ClientCommandC2SPacket(mc.player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        mc.player.startGliding();
    }

    public static boolean canChangeIntoPose(EntityPose pose) {
        return mc.player.getWorld().isSpaceEmpty(
            mc.player,
            mc.player.getDimensions(pose).getBoxAt(mc.player.getPos()).contract(1.0E-7D));
    }

    public static boolean isPotionActive(RegistryEntry<StatusEffect> statusEffect) {
        return mc.player.getActiveStatusEffects().containsKey(statusEffect);
    }

    public static Stream<Entity> streamEntities() {
        return StreamSupport.stream(mc.world.getEntities().spliterator(), false);
    }

    public static List<BlockPos> getCube(BlockPos start, BlockPos end) {
        List<BlockPos> positions = new ArrayList<>();
        for (int x = start.getX(); x <= end.getX(); x++) {
            for (int z = start.getZ(); z <= end.getZ(); z++) {
                for (int y = start.getY(); y <= end.getY(); y++) {
                    positions.add(new BlockPos(x, y, z));
                }
            }
        }
        return positions;
    }

    public static List<BlockPos> getCube(BlockPos center, float radius) {
        return getCube(center, radius, radius, true);
    }

    public static List<BlockPos> getCube(BlockPos center, float radiusXZ, float radiusY) {
        return getCube(center, radiusXZ, radiusY, true);
    }

    public static List<BlockPos> getCube(BlockPos center, float radiusXZ, float radiusY, boolean down) {
        List<BlockPos> positions = new ArrayList<>();
        int centerX = center.getX();
        int centerY = center.getY();
        int centerZ = center.getZ();
        int startY = down ? centerY - (int) radiusY : centerY;

        for (int x = centerX - (int) radiusXZ; x <= centerX + radiusXZ; x++) {
            for (int z = centerZ - (int) radiusXZ; z <= centerZ + radiusXZ; z++) {
                for (int y = startY; y <= centerY + radiusY; y++) {
                    positions.add(new BlockPos(x, y, z));
                }
            }
        }
        return positions;
    }

    public static boolean isBox(Box box, Predicate<BlockPos> pos) {
        return BlockPos.stream(box).anyMatch(pos);
    }

    public static boolean isBoxInBlock(Box box, Block block) {
        return isBox(box, pos -> mc.world.getBlockState(pos).getBlock().equals(block));
    }

    public static boolean isBoxInBlocks(Box box, List<Block> blocks) {
        return isBox(box, pos -> blocks.contains(mc.world.getBlockState(pos).getBlock()));
    }

    public static boolean isPlayerInBlock(Block block) {
        return isBoxInBlock(mc.player.getBoundingBox().expand(-0.001D), block);
    }

    public static boolean isPlayerInWeb() {
        if (mc.player == null || mc.world == null) {
            return false;
        }

        Box box = mc.player.getBoundingBox();
        double minX = box.minX + 0.001D;
        double minZ = box.minZ + 0.001D;
        double maxX = box.maxX - 0.001D;
        double maxZ = box.maxZ - 0.001D;
        double minY = box.minY;
        double maxY = box.maxY;
        double height = maxY - minY;
        double inset = height * 0.119D;
        double lowerY = minY + inset / 2.0D;
        double upperY = maxY - inset / 2.0D;
        double stepX = (maxX - minX) / 4.0D;
        double stepZ = (maxZ - minZ) / 4.0D;
        double stepY = (upperY - lowerY) / 8.0D;

        for (double x = minX; x <= maxX + 1.0E-4D; x += stepX) {
            for (double y = lowerY; y <= upperY + 1.0E-4D; y += stepY) {
                for (double z = minZ; z <= maxZ + 1.0E-4D; z += stepZ) {
                    if (mc.world.getBlockState(BlockPos.ofFloored(x, y, z)).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }

        double[][] corners = {
            { minX, lowerY, minZ },
            { minX, lowerY, maxZ },
            { minX, upperY, minZ },
            { minX, upperY, maxZ },
            { maxX, lowerY, minZ },
            { maxX, lowerY, maxZ },
            { maxX, upperY, minZ },
            { maxX, upperY, maxZ }
        };
        for (double[] corner : corners) {
            if (mc.world.getBlockState(BlockPos.ofFloored(corner[0], corner[1], corner[2])).isOf(Blocks.COBWEB)) {
                return true;
            }
        }

        BlockPos abovePos = BlockPos.ofFloored(mc.player.getX(), upperY + 0.1D, mc.player.getZ());
        BlockPos belowPos = BlockPos.ofFloored(mc.player.getX(), lowerY - 0.1D, mc.player.getZ());
        return mc.world.getBlockState(abovePos).isOf(Blocks.COBWEB)
            || mc.world.getBlockState(belowPos).isOf(Blocks.COBWEB);
    }

    public static boolean isAir(BlockPos blockPos) {
        return isAir(mc.world.getBlockState(blockPos));
    }

    public static boolean isAir(BlockState state) {
        return state.isAir()
            || state.getBlock().equals(Blocks.CAVE_AIR)
            || state.getBlock().equals(Blocks.VOID_AIR);
    }

    public static void clickSlot(int syncId, int slotId, int button, SlotActionType actionType, PlayerEntity player) {
        ClickSlotC2SPacket packet = createClickSlotPacket(syncId, slotId, button, actionType, player);
        if (packet != null) {
            SilentPacketUtil.sendSilentPacket(packet);
        }
    }

    public static ClickSlotC2SPacket createClickSlotPacket(int syncId, int slotId, int button,
                                                           SlotActionType actionType, PlayerEntity player) {
        ScreenHandler handler = player.currentScreenHandler;
        if (syncId != handler.syncId) {
            return null;
        }

        DefaultedList<Slot> slots = handler.slots;
        int slotCount = slots.size();
        List<ItemStack> previousStacks = Lists.newArrayListWithCapacity(slotCount);
        for (Slot slot : slots) {
            previousStacks.add(slot.getStack().copy());
        }

        handler.onSlotClick(slotId, button, actionType, player);

        Int2ObjectMap<ItemStack> changedStacks = new Int2ObjectOpenHashMap<>();
        for (int index = 0; index < slotCount; index++) {
            ItemStack previous = previousStacks.get(index);
            ItemStack current = slots.get(index).getStack();
            if (!ItemStack.areEqual(previous, current)) {
                changedStacks.put(index, current.copy());
            }
        }

        return new ClickSlotC2SPacket(syncId, handler.getRevision(), slotId, button, actionType,
            handler.getCursorStack().copy(), changedStacks);
    }

    public static float getHealth(LivingEntity entity) {
        float health = entity.getHealth() + entity.getAbsorptionAmount();
        if (entity instanceof PlayerEntity player) {
            ScoreboardObjective objective = player.getScoreboard().getObjectiveForSlot(ScoreboardDisplaySlot.BELOW_NAME);
            if (objective != null) {
                MutableText score = ReadableScoreboardScore.getFormattedScore(
                    player.getScoreboard().getScore(player, objective),
                    objective.getNumberFormatOr(StyledNumberFormat.EMPTY));
                try {
                    health = Float.parseFloat(ArgbUtil.removeFormatting(score.getString()));
                } catch (NumberFormatException ignored) {
                }
            }
        }
        return MathHelper.clamp(health, 0.0F, entity.getMaxHealth());
    }

    public static String getHealthString(LivingEntity entity) {
        return getHealthString(getHealth(entity));
    }

    public static String getHealthString(float hp) {
        return String.format("%.1f", hp).replace(",", ".").replace(".0", "");
    }
}
