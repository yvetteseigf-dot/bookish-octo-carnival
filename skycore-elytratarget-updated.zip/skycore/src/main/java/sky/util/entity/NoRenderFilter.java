package sky.util.entity;

import sky.module.visuals.NoRender;

public final class NoRenderFilter {
    private NoRenderFilter() {
    }

    public static boolean shouldCancel(Type type) {
        NoRender module = NoRender.INSTANCE;
        if (!module.isEnabled()) {
            return false;
        }
        return switch (type) {
            case FIRE -> module.mode.is("Fire");
            case BOSSBAR -> module.mode.is("Boss bar");
            case SCOREBOARD -> module.mode.is("Scoreboard");
            case TITLE -> module.mode.is("Titles");
            case TOTEM -> module.mode.is("Totem pop");
            case CAMERA_CLIP -> module.mode.is("Camera clip");
            case FISHING_ROD -> module.mode.is("Fishing rod on screen");
            case RAIN -> module.mode.is("Rain");
            case SHADOWS -> module.mode.is("Shadows");
            case GLOWING -> module.mode.is("Player glow");
            case VIGNETTE -> module.mode.is("Vignette");
            case ARROWS -> module.mode.is("Stuck arrows");
            case HOLOGRAMS -> module.mode.is("Holograms");
            case GRASS -> module.mode.is("Grass");
            case BAD_EFFECTS -> module.mode.is("Bad effects");
            case UNDERWATER_BLUR -> module.mode.is("Underwater blur");
            case BREAK_PARTICLES -> module.mode.is("Break particles");
            case SMOKE -> module.mode.is("Smoke");
        };
    }

    public enum Type {
        FIRE,
        BOSSBAR,
        SCOREBOARD,
        TITLE,
        TOTEM,
        CAMERA_CLIP,
        FISHING_ROD,
        RAIN,
        SHADOWS,
        GLOWING,
        VIGNETTE,
        ARROWS,
        HOLOGRAMS,
        GRASS,
        BAD_EFFECTS,
        UNDERWATER_BLUR,
        BREAK_PARTICLES,
        SMOKE
    }
}
