package sky.util.entity;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.access.MinecraftAccess;
import sky.event.input.StrafeInputEvent;

/**
 * Translates a desired world-space heading into the discrete forward/strafe pair the vanilla
 * input system accepts, so movement stays consistent while the camera yaw is being overridden.
 */
public final class MovementFixUtil implements MinecraftAccess {

    private MovementFixUtil() {
    }

    public static boolean isMoving() {
        return mc.player != null
                && (mc.player.input.movementSideways != 0.0F || mc.player.input.movementForward != 0.0F);
    }

    public static void moveToPosition(StrafeInputEvent event, Vec3d position, float currentYaw) {
        double deltaX = position.x - mc.player.getX();
        double deltaZ = position.z - mc.player.getZ();

        double targetYaw = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0;
        targetYaw = MathHelper.wrapDegrees(targetYaw);

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float forward = -1.0F; forward <= 1.0F; forward += 1.0F) {
            for (float strafe = -1.0F; strafe <= 1.0F; strafe += 1.0F) {
                if (forward == 0.0F && strafe == 0.0F) {
                    continue;
                }

                double candidateYaw = Math.toDegrees(direction(currentYaw, forward, strafe));
                double difference = Math.abs(targetYaw - MathHelper.wrapDegrees(candidateYaw));

                if (difference < bestDifference) {
                    bestDifference = (float) difference;
                    bestForward = forward;
                    bestStrafe = strafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }

    public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
        if (moveForward < 0.0) {
            rotationYaw += 180.0F;
        }

        float forwardScale = 1.0F;
        if (moveForward < 0.0) {
            forwardScale = -0.5F;
        } else if (moveForward > 0.0) {
            forwardScale = 0.5F;
        }

        if (moveStrafing > 0.0) {
            rotationYaw -= 90.0F * forwardScale;
        }
        if (moveStrafing < 0.0) {
            rotationYaw += 90.0F * forwardScale;
        }

        return Math.toRadians(rotationYaw);
    }

    public static void fixMovement(StrafeInputEvent event, float yaw) {
        float forward = event.getForward();
        float strafe = event.getStrafe();

        float sourceYaw = mc.player.isGliding() ? mc.player.getYaw() : yaw;
        double targetYaw = MathHelper.wrapDegrees(Math.toDegrees(direction(sourceYaw, forward, strafe)));

        if (forward == 0.0F && strafe == 0.0F) {
            return;
        }

        float bestForward = 0.0F;
        float bestStrafe = 0.0F;
        float bestDifference = Float.MAX_VALUE;

        for (float candidateForward = -1.0F; candidateForward <= 1.0F; candidateForward += 1.0F) {
            for (float candidateStrafe = -1.0F; candidateStrafe <= 1.0F; candidateStrafe += 1.0F) {
                if (candidateStrafe == 0.0F && candidateForward == 0.0F) {
                    continue;
                }

                double candidateYaw = MathHelper.wrapDegrees(Math.toDegrees(
                        direction(mc.player.getYaw(), candidateForward, candidateStrafe)));
                double difference = Math.abs(targetYaw - candidateYaw);

                if (difference < bestDifference) {
                    bestDifference = (float) difference;
                    bestForward = candidateForward;
                    bestStrafe = candidateStrafe;
                }
            }
        }

        event.setForward(bestForward);
        event.setStrafe(bestStrafe);
    }
}
