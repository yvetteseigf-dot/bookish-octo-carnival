package sky.util.inventory;

import it.unimi.dsi.fastutil.ints.Int2ObjectMap;
import it.unimi.dsi.fastutil.ints.Int2ObjectOpenHashMap;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import net.minecraft.block.BlockState;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.SwordItem;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.collection.DefaultedList;
import sky.SkyInit;
import sky.misc.HeldItemVisualSpoof;
import sky.access.MinecraftAccess;
import sky.scheduler.ScriptTaskQueue;
import sky.session.SilentPacketUtil;
import sky.event.player.PlayerUpdateEvent;
import sky.mixin.network.ClientPlayerInteractionManagerAccessor;
import sky.util.entity.PlayerUtil;
import sky.util.text.ChatNotifier;

public final class ItemSwapUtil implements MinecraftAccess {
    private ItemSwapUtil() {
    }

    public static int getSlot(Item item) {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty() && stack.getItem() == item) {
                return slot;
            }
        }
        return -1;
    }

    public static int getItemSlot(Item item) {
        int found = -1;
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() == item) {
                found = slot;
                break;
            }
        }
        if (found < 9 && found != -1) {
            found += 36;
        }
        return found;
    }

    public static int find(Item item) {
        int found = -1;
        for (ItemStack stack : mc.player.getInventory().armor) {
            if (stack.getItem() == item) {
                return -2;
            }
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() == item) {
                found = slot;
                break;
            }
        }
        if (found < 9 && found != -1) {
            found += 36;
        }
        return found;
    }

    public static Slot getSlottest(Item item) {
        if (mc.player == null) {
            return null;
        }
        return mc.player.currentScreenHandler.slots.stream()
            .filter(slot -> slot.getStack().getItem() == item)
            .findFirst()
            .orElse(null);
    }

    public static boolean haveHotBar(Item item) {
        for (int slot = 0; slot < 9; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() == item) {
                return true;
            }
        }
        return false;
    }

    public static boolean isOnHotBar(int slot) {
        return slot >= 36 && slot <= 44;
    }

    public static int getItemCount(Item item) {
        if (mc.player == null) {
            return 0;
        }
        int count = 0;
        for (ItemStack stack : mc.player.getInventory().main) {
            if (!stack.isEmpty() && stack.getItem() == item) {
                count += stack.getCount();
            }
        }
        return count;
    }

    public static int findEmptyInventorySlot() {
        if (mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty()) {
                return slot < 9 ? slot + 36 : slot;
            }
        }
        return -1;
    }

    private static int findEmptySlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty()) {
                return slot < 9 ? slot + 36 : slot;
            }
        }
        return -1;
    }

    public static int findAxeSlot() {
        for (int slot = 0; slot < 45; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty() && stack.getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    public static int getAxe(boolean hotbarOnly) {
        int start = hotbarOnly ? 0 : 9;
        int end = hotbarOnly ? 9 : 36;
        for (int slot = start; slot < end; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return -1;
    }

    public static int findEnchantedTotemSlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 45; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty() && stack.getItem() == Items.TOTEM_OF_UNDYING && stack.hasEnchantments()) {
                return slot;
            }
        }
        return -1;
    }

    public static int getBestFoodSlot() {
        if (mc == null || mc.player == null) {
            return -1;
        }
        int bestSlot = -1;
        int bestCount = 0;
        for (int slot = 0; slot < 45; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (!stack.isEmpty()
                && stack.get(DataComponentTypes.FOOD) != null
                && stack.getCount() > bestCount) {
                bestSlot = slot;
                bestCount = stack.getCount();
            }
        }
        return bestSlot;
    }

    public static int getChestPlateSlot() {
        if (mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 36; slot++) {
            ItemStack stack = mc.player.getInventory().getStack(slot);
            if (stack.isEmpty() || stack.getItem() == Items.ELYTRA) {
                continue;
            }
            if (stack.getItem() instanceof ArmorItem armor) {
                String name = armor.toString().toLowerCase();
                if (name.contains("chestplate") || name.contains("tunic")) {
                    return slot;
                }
            }
        }
        return -1;
    }

    public static int findBestToolForBlock(BlockState state) {
        if (mc.player == null) {
            return -1;
        }
        int previousSlot = mc.player.getInventory().selectedSlot;
        int bestSlot = -1;
        float bestSpeed = 1.0F;
        try {
            for (int slot = 0; slot < 9; slot++) {
                ItemStack stack = mc.player.getInventory().getStack(slot);
                if (stack.isEmpty()) {
                    continue;
                }
                if (!(stack.getItem() instanceof MiningToolItem) && !(stack.getItem() instanceof SwordItem)) {
                    continue;
                }
                mc.player.getInventory().selectedSlot = slot;
                float speed = mc.player.getBlockBreakingSpeed(state);
                if (speed > bestSpeed) {
                    bestSpeed = speed;
                    bestSlot = slot;
                }
            }
        } finally {
            mc.player.getInventory().selectedSlot = previousSlot;
        }
        return bestSlot;
    }

    public static boolean hasBallName(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        String name = Formatting.strip(stack.getName().getString());
        if (name == null || name.isEmpty()) {
            return false;
        }
        return name.toLowerCase().contains("\u0448\u0430\u0440");
    }

    public static boolean isBall(ItemStack stack) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }
        if (stack.isOf(Items.PLAYER_HEAD)) {
            return true;
        }
        return hasBallName(stack);
    }

    public static Slot findBallSlot() {
        if (mc.player == null) {
            return null;
        }
        Slot playerHeadSlot = null;
        Slot fallbackSlot = null;
        for (Slot slot : mc.player.currentScreenHandler.slots) {
            if (slot.id == 45) {
                continue;
            }
            ItemStack stack = slot.getStack();
            if (stack.isEmpty() || !isBall(stack)) {
                continue;
            }
            String name = Formatting.strip(stack.getName().getString());
            if (name != null && name.equalsIgnoreCase("\u0428\u0430\u0440 \u0417\u0435\u043c\u043b\u0438")) {
                return slot;
            }
            if (stack.isOf(Items.PLAYER_HEAD)) {
                playerHeadSlot = slot;
            } else if (fallbackSlot == null) {
                fallbackSlot = slot;
            }
        }
        return playerHeadSlot != null ? playerHeadSlot : fallbackSlot;
    }

    public static boolean stackHasAnyEffect(ItemStack stack, boolean normal, boolean splash, boolean lingering,
                                            StatusEffect... effects) {
        if (stack == null || stack.isEmpty()) {
            return false;
        }

        Item item = stack.getItem();
        boolean matchesType = (normal && item == Items.POTION)
            || (splash && item == Items.SPLASH_POTION)
            || (lingering && item == Items.LINGERING_POTION);
        if (!matchesType) {
            return false;
        }

        PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
        if (contents == null) {
            return false;
        }
        for (StatusEffectInstance instance : contents.getEffects()) {
            for (StatusEffect effect : effects) {
                if (instance.getEffectType().value() == effect) {
                    return true;
                }
            }
        }
        return false;
    }

    public static int findPotionSlotWithEffects(boolean hotbarOnly, boolean normal, boolean splash, boolean lingering,
                                                StatusEffect... effects) {
        if (mc.player == null) {
            return -1;
        }
        if (hotbarOnly) {
            for (int slot = 0; slot < 9; slot++) {
                ItemStack stack = mc.player.getInventory().getStack(slot);
                if (stackHasAnyEffect(stack, normal, splash, lingering, effects)) {
                    return slot;
                }
            }
        } else {
            for (int slot = 0; slot < 9; slot++) {
                ItemStack stack = mc.player.getInventory().getStack(slot);
                if (stackHasAnyEffect(stack, normal, splash, lingering, effects)) {
                    return slot;
                }
            }
            for (int slot = 9; slot < 36; slot++) {
                ItemStack stack = mc.player.getInventory().getStack(slot);
                if (stackHasAnyEffect(stack, normal, splash, lingering, effects)) {
                    return slot;
                }
            }
        }
        return -1;
    }

    public static void clickSlotId(int slot, int button, SlotActionType actionType) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        InventorySwapBypass.runWithBypass(
            () -> mc.interactionManager.clickSlot(0, slot, button, actionType, mc.player));
    }

    public static void clickSlotId(int slot, int button, SlotActionType actionType, boolean silent) {
        clickSlotId(mc.player.currentScreenHandler.syncId, slot, button, actionType, silent);
    }

    public static void clickSlotId(int syncId, int slot, int button, SlotActionType actionType, boolean silent) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        if (silent) {
            sendClickPacket(syncId, slot, button, actionType);
        } else {
            InventorySwapBypass.runWithBypass(
                () -> mc.interactionManager.clickSlot(syncId, slot, button, actionType, mc.player));
        }
    }

    private static void sendClickPacket(int syncId, int slot, int button, SlotActionType actionType) {
        ScreenHandler handler = mc.player.currentScreenHandler;
        DefaultedList<Slot> slots = handler.slots;
        int size = slots.size();

        List<ItemStack> before = new ArrayList<>(size);
        for (Slot handlerSlot : slots) {
            before.add(handlerSlot.getStack().copy());
        }

        handler.onSlotClick(slot, button, actionType, mc.player);

        Int2ObjectMap<ItemStack> changed = new Int2ObjectOpenHashMap<>();
        for (int index = 0; index < size; index++) {
            ItemStack previous = before.get(index);
            ItemStack current = slots.get(index).getStack();
            if (!ItemStack.areEqual(previous, current)) {
                changed.put(index, current.copy());
            }
        }

        SilentPacketUtil.sendPacket(new ClickSlotC2SPacket(
            syncId,
            handler.getRevision(),
            slot,
            button,
            actionType,
            handler.getCursorStack().copy(),
            changed
        ));
    }

    public static void pickupItem(int slot, int button) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        mc.interactionManager.clickSlot(0, slot, button, SlotActionType.PICKUP, mc.player);
    }

    public static void pickItem(int from, int to) {
        if (from == to) {
            return;
        }
        from = from < 9 ? from + 36 : from;
        pickupItem(from, 0);
        pickupItem(to, 0);
        pickupItem(from, 0);
    }

    public static void swapItem(int from, int to) {
        if (from == to) {
            return;
        }
        from = from < 9 ? from + 36 : from;
        int syncId = mc.player.currentScreenHandler.syncId;
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(syncId, to, 0, SlotActionType.SWAP, mc.player);
        mc.interactionManager.clickSlot(syncId, from, 0, SlotActionType.SWAP, mc.player);
    }

    public static void moveItem(int from, int to) {
        if (from == to || from == -1 || mc.player == null || mc.interactionManager == null) {
            return;
        }
        from = from < 9 ? from + 36 : from;
        if (to == 45) {
            clickSlotId(from, 40, SlotActionType.SWAP);
        } else {
            clickSlotId(from, 0, SlotActionType.SWAP);
            clickSlotId(to, 0, SlotActionType.SWAP);
            clickSlotId(from, 0, SlotActionType.SWAP);
        }
    }

    public static void moveItemtest(int from, int to) {
        if (from == to || from == -1) {
            return;
        }
        from = from < 9 ? from + 36 : from;
        clickSlotId(from, 0, SlotActionType.SWAP, false);
        clickSlotId(to, 0, SlotActionType.SWAP, false);
        clickSlotId(from, 0, SlotActionType.SWAP, false);
    }

    public static void moveToArmor(int from, int armorSlot) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        int source = from < 9 ? from + 36 : from;
        clickSlotId(source, 40, SlotActionType.SWAP, false);
        clickSlotId(armorSlot, 40, SlotActionType.SWAP, false);
        clickSlotId(source, 40, SlotActionType.SWAP, false);
    }

    public static void swapHand(int slotId, Hand hand, boolean silent) {
        if (slotId == -1) {
            return;
        }
        int hotbarSlot = hand.equals(Hand.MAIN_HAND) ? mc.player.getInventory().selectedSlot : 40;
        clickSlotId(slotId, hotbarSlot, SlotActionType.SWAP, silent);
    }

    public static void swapHand(Slot slot, Hand hand, boolean silent) {
        if (slot != null) {
            swapHand(slot.id, hand, silent);
        }
    }

    public static void swapToOffHand(int slotId) {
        if (slotId < 0 || mc.player == null) {
            return;
        }
        clickSlotId(slotId, 40, SlotActionType.SWAP, false);
    }

    public static void swapToOffHand(Slot slot) {
        if (slot == null || slot.id == -1 || mc.player == null) {
            return;
        }
        clickSlotId(slot.id, 40, SlotActionType.SWAP, false);
    }

    public static void switchToHotbarSlot(int slot) {
        if (mc.player == null || slot < 0 || slot > 8) {
            return;
        }
        if (mc.player.getInventory().selectedSlot == slot) {
            return;
        }
        mc.player.getInventory().selectedSlot = slot;
        syncCurrentPlayItem();
    }

    public static void syncCurrentPlayItem() {
        if (mc.interactionManager == null) {
            return;
        }
        ((ClientPlayerInteractionManagerAccessor) mc.interactionManager).skycore$syncSelectedSlot();
    }

    public static void useItem(Hand hand) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        PlayerUtil.useItem(hand);
    }

    public static void findItemAndThrow(Item item) {
        if (mc.player.getItemCooldownManager().isCoolingDown(item.getDefaultStack())) {
            ChatNotifier.displayWarning(item.getName().getString()
                + " - \u043d\u0430\u0445\u043e\u0434\u0438\u0442\u044c\u0441\u044f \u0432 \u043a\u0443\u043b\u0434\u0430\u0443\u043d\u0435");
            return;
        }

        Slot slot = getSlottest(item);
        if (slot == null) {
            ChatNotifier.displayWarning(item.getName().getString()
                + " - \u043d\u0435 \u043e\u0431\u043d\u0430\u0440\u0443\u0436\u0435\u043d \u0432 \u0438\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u0435");
            return;
        }
        findItemAndThrow(slot);
    }

    public static void findItemAndThrow(Slot slot) {
        swapHand(slot, Hand.MAIN_HAND, true);
        useItem(Hand.MAIN_HAND);
        swapHand(slot, Hand.MAIN_HAND, true);
    }

    public static void inventorySwapClick(Item item) {
        if (mc.player == null || mc.interactionManager == null) {
            return;
        }
        if (mc.player.getMainHandStack().isOf(item)) {
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            return;
        }
        if (mc.player.getOffHandStack().isOf(item)) {
            mc.interactionManager.interactItem(mc.player, Hand.OFF_HAND);
            return;
        }

        int slot = getSlot(item);
        if (slot == -1) {
            return;
        }
        int selectedSlot = mc.player.getInventory().selectedSlot;

        if (slot < 9) {
            if (slot != selectedSlot) {
                HeldItemVisualSpoof.hold(selectedSlot, 8);
                switchToHotbarSlot(slot);
            }
            mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
            if (slot != selectedSlot) {
                ScriptTaskQueue.ScriptTask task = new ScriptTaskQueue.ScriptTask();
                task.schedule(PlayerUpdateEvent.class, event -> {
                    if (mc.player != null) {
                        switchToHotbarSlot(selectedSlot);
                        HeldItemVisualSpoof.hold(selectedSlot, 6);
                    }
                    return true;
                });
                SkyInit.getInstance().getScriptManager().addTask(task);
            }
            return;
        }

        ItemStack heldBefore = mc.player.getInventory().getStack(selectedSlot).copy();
        HeldItemVisualSpoof.hold(selectedSlot, 10);
        clickSlotId(slot, selectedSlot, SlotActionType.SWAP, false);
        mc.interactionManager.interactItem(mc.player, Hand.MAIN_HAND);
        clickSlotId(slot, selectedSlot, SlotActionType.SWAP, false);
        mc.player.getInventory().setStack(selectedSlot, heldBefore);
        HeldItemVisualSpoof.hold(selectedSlot, 6);
    }

    public static void switchItem(Item item, int hotbarSlot, boolean swapBack, int delayTicks) {
        if (getSlot(item) == -1) {
            return;
        }
        int slot = getItemSlot(item);
        mc.interactionManager.clickSlot(0, slot, hotbarSlot, SlotActionType.SWAP, mc.player);

        if (swapBack) {
            ScriptTaskQueue.ScriptTask task = new ScriptTaskQueue.ScriptTask();
            for (int tick = 0; tick < delayTicks; tick++) {
                task.schedule(PlayerUpdateEvent.class, event -> false);
            }
            task.schedule(PlayerUpdateEvent.class, event -> {
                mc.interactionManager.clickSlot(0, slot, hotbarSlot, SlotActionType.SWAP, mc.player);
                return true;
            });
            SkyInit.getInstance().getScriptManager().addTask(task);
        }
    }

    public static int antipoletToOffhand(Item item) {
        if (getSlot(item) == -1 || mc.player == null) {
            return -1;
        }
        for (int slot = 0; slot < 36; slot++) {
            if (mc.player.getInventory().getStack(slot).getItem() != item) {
                continue;
            }

            int inventorySlot = slot < 9 ? 36 + slot : slot;
            moveItem(inventorySlot, 45);

            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    if (mc != null && mc.options != null && !mc.options.sneakKey.isPressed()) {
                        mc.options.sneakKey.setPressed(true);
                    }
                }
            }, 150L);
            new Timer().schedule(new TimerTask() {
                @Override
                public void run() {
                    if (mc != null && mc.options != null && mc.options.sneakKey.isPressed()) {
                        mc.options.sneakKey.setPressed(false);
                    }
                }
            }, 200L);

            return inventorySlot;
        }
        return -1;
    }
}
