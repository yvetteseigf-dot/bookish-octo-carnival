package sky.util.inventory;

import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.entry.RegistryEntry;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class EnchantmentUtil {
    private static final Map<String, String> SHORT_NAMES = Map.ofEntries(
            Map.entry("protection", "Pr"),
            Map.entry("fire_protection", "FP"),
            Map.entry("feather_falling", "FF"),
            Map.entry("blast_protection", "BP"),
            Map.entry("projectile_protection", "PP"),
            Map.entry("respiration", "Re"),
            Map.entry("aqua_affinity", "AA"),
            Map.entry("thorns", "Th"),
            Map.entry("depth_strider", "DS"),
            Map.entry("frost_walker", "FW"),
            Map.entry("binding_curse", "BC"),
            Map.entry("soul_speed", "SS"),
            Map.entry("swift_sneak", "SN"),
            Map.entry("sharpness", "Sh"),
            Map.entry("smite", "Sm"),
            Map.entry("bane_of_arthropods", "BA"),
            Map.entry("knockback", "Kb"),
            Map.entry("fire_aspect", "FA"),
            Map.entry("looting", "Lo"),
            Map.entry("sweeping_edge", "SE"),
            Map.entry("efficiency", "Ef"),
            Map.entry("silk_touch", "ST"),
            Map.entry("unbreaking", "Un"),
            Map.entry("fortune", "Fo"),
            Map.entry("power", "Po"),
            Map.entry("punch", "Pu"),
            Map.entry("flame", "Fl"),
            Map.entry("infinity", "In"),
            Map.entry("luck_of_the_sea", "LS"),
            Map.entry("lure", "Lu"),
            Map.entry("loyalty", "Ly"),
            Map.entry("impaling", "Im"),
            Map.entry("riptide", "Ri"),
            Map.entry("channeling", "Ch"),
            Map.entry("multishot", "Mu"),
            Map.entry("quick_charge", "QC"),
            Map.entry("piercing", "Pi"),
            Map.entry("mending", "Me"),
            Map.entry("vanishing_curse", "VC"),
            Map.entry("density", "De"),
            Map.entry("breach", "Br"),
            Map.entry("wind_burst", "WB"));

    private EnchantmentUtil() {
    }

    private static String abbreviate(String name) {
        String normalized = name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9_]+", "_");
        String[] segments = normalized.split("_+");
        StringBuilder abbreviation = new StringBuilder(2);
        for (String segment : segments) {
            if (!segment.isEmpty()) {
                abbreviation.append(Character.toUpperCase(segment.charAt(0)));
            }
            if (abbreviation.length() >= 2) {
                return abbreviation.toString();
            }
        }
        if (abbreviation.length() == 1) {
            return abbreviation.append(abbreviation.charAt(0)).toString();
        }
        return "En";
    }

    public static List<String> getEnchantments(ItemStack stack) {
        List<String> enchantments = new ArrayList<>();
        ItemEnchantmentsComponent component = EnchantmentHelper.getEnchantments(stack);
        for (RegistryEntry<Enchantment> entry : component.getEnchantments()) {
            String name = entry.getKey()
                    .map(RegistryKey::getValue)
                    .map(identifier -> identifier.getPath())
                    .orElseGet(() -> entry.value().description().getString());
            String shortName = SHORT_NAMES.getOrDefault(name, abbreviate(name));
            int level = component.getLevel(entry);
            int maxLevel = entry.value().getMaxLevel();
            enchantments.add(maxLevel == 1 && level == 1 ? shortName : shortName + level);
        }
        return enchantments;
    }
}
