package sky.util.inventory;

import sky.module.movement.GuiMove;

/**
 * Runs an action while GuiMove's inventory-swap guard is lifted, so hotbar swaps
 * issued from inside a screen are not swallowed by world-mode movement handling.
 */
public final class InventorySwapBypass {
    private InventorySwapBypass() {
    }

    public static void runWithBypass(Runnable action) {
        GuiMove guiMove = GuiMove.INSTANCE;
        if (guiMove == null || !guiMove.isReallyworldMode()) {
            action.run();
            return;
        }
        boolean previous = guiMove.bypassInventorySwap;
        guiMove.bypassInventorySwap = true;
        try {
            action.run();
        } finally {
            guiMove.bypassInventorySwap = previous;
        }
    }
}
