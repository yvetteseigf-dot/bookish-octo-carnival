package sky.util.math;

/**
 * MT19937 pseudo-random number generator with optional value throttling.
 */
public class MersenneTwisterRandom {
    private static final int N = 624;
    private int[] mt;
    private float lastGeneratedNumber;
    private int index;
    private static final int MATRIX_A = 0x9908B0DF;
    private static final int M = 397;
    private long delay;
    private long lastGenerationTime;
    private static final int LOWER_MASK = 0x7FFFFFFF;
    private static final int UPPER_MASK = 0x80000000;

    public long getDelay() {
        return this.delay;
    }

    private void twist() {
        for (int i = 0; i < N; i++) {
            int value = (this.mt[i] & UPPER_MASK) + (this.mt[(i + 1) % N] & LOWER_MASK);
            int twisted = value >>> 1;
            if (value % 2 != 0) {
                twisted ^= MATRIX_A;
            }
            this.mt[i] = this.mt[(i + M) % N] ^ twisted;
        }
        this.index = 0;
    }

    public MersenneTwisterRandom() {
        this(System.currentTimeMillis());
    }

    public float nextFloat() {
        return (float) (this.nextInt() & 4294967295L) / 4.2949673E9F;
    }

    private int nextInt() {
        if (this.index >= N) {
            this.twist();
        }

        int value = this.mt[this.index++];
        value ^= value >>> 11;
        value ^= value << 7 & 0x9D2C5680;
        value ^= value << 15 & 0xEFC60000;
        value ^= value >>> 18;
        return value;
    }

    public void setDelay(long delay) {
        this.delay = delay;
    }

    private void init(long seed) {
        this.mt[0] = (int) (seed & 4294967295L);
        this.index = 1;
        while (this.index < N) {
            this.mt[this.index] = 1812433253 * (this.mt[this.index - 1] ^ this.mt[this.index - 1] >>> 30) + this.index;
            this.index++;
        }
    }

    public MersenneTwisterRandom(long seed) {
        this.mt = new int[N];
        this.index = N + 1;
        this.lastGenerationTime = 0L;
        this.delay = 0L;
        this.lastGeneratedNumber = 0.0F;
        this.init(seed);
    }

    public float randomNumber(float firstNumber, float secondNumber, boolean isInt) {
        long now = System.currentTimeMillis();
        if (now - this.lastGenerationTime < this.delay) {
            return this.lastGeneratedNumber;
        }

        if (firstNumber > secondNumber) {
            float temporary = firstNumber;
            firstNumber = secondNumber;
            secondNumber = temporary;
        }

        float randomNumber;
        do {
            float generated = this.nextFloat();
            randomNumber = firstNumber + generated * (secondNumber - firstNumber);
            if (isInt) {
                randomNumber = (float) (int) randomNumber;
            }
        } while (randomNumber == this.lastGeneratedNumber);

        this.lastGenerationTime = now;
        this.lastGeneratedNumber = randomNumber;
        return randomNumber;
    }
}
