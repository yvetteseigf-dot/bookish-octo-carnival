package sky.util.math;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

/**
 * A {@link Random} facade which lazily creates a seeded generator after a seed
 * is supplied.  The superclass constructor also supplies a seed through this
 * override, so ordinary instances retain deterministic {@link Random}
 * semantics.
 */
public class FastRandom extends Random {
    private Random random;
    private volatile long seed;
    private volatile boolean seedSet;
    private volatile boolean seedUpdated;
    private final ThreadLocalRandom threadLocalRandom;

    @Override
    public void setSeed(long seed) {
        this.seed = seed;
        this.seedSet = true;
        this.seedUpdated = true;
    }

    @Override
    public int nextInt() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextInt();
        }
        return this.threadLocalRandom.nextInt();
    }

    @Override
    public float nextFloat() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextFloat();
        }
        return this.threadLocalRandom.nextFloat();
    }

    @Override
    public boolean nextBoolean() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextBoolean();
        }
        return this.threadLocalRandom.nextBoolean();
    }

    @Override
    public double nextDouble() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextDouble();
        }
        return this.threadLocalRandom.nextDouble();
    }

    private void validateRandom() {
        if (this.random == null) {
            this.random = new Random(this.seed);
            this.seedUpdated = false;
        } else if (this.seedUpdated) {
            this.random.setSeed(this.seed);
            this.seedUpdated = false;
        }
    }

    @Override
    public long nextLong() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextLong();
        }
        return this.threadLocalRandom.nextLong();
    }

    @Override
    public void nextBytes(byte[] bytes) {
        if (this.seedSet) {
            this.validateRandom();
            this.random.nextBytes(bytes);
        } else {
            this.threadLocalRandom.nextBytes(bytes);
        }
    }

    public FastRandom() {
        super();
        this.threadLocalRandom = ThreadLocalRandom.current();
        this.random = null;
    }

    public static long mix(long value, long salt) {
        value *= value * 6364136223846793005L + 1442695040888963407L;
        return value + salt;
    }

    @Override
    public int nextInt(int bound) {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextInt(bound);
        }
        return this.threadLocalRandom.nextInt(bound);
    }

    @Override
    public double nextGaussian() {
        if (this.seedSet) {
            this.validateRandom();
            return this.random.nextGaussian();
        }
        return this.threadLocalRandom.nextGaussian();
    }
}
