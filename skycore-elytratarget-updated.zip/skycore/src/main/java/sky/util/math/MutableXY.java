package sky.util.math;

import net.minecraft.util.math.MathHelper;

/** Mutable two-dimensional float vector. */
public class MutableXY {
    public float x;
    public float y;

    public MutableXY(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public MutableXY normalize() {
        float length = MathHelper.sqrt(x * x + y * y);
        if (length < 0.0001F) {
            x = 0.0F;
            y = 0.0F;
        } else {
            x /= length;
            y /= length;
        }
        return this;
    }

    public MutableXY rotateDegrees(float degrees) {
        float originalX = x;
        float originalY = y;
        float radians = (float) Math.toRadians(degrees);
        x = MathHelper.cos(radians) * originalX - MathHelper.sin(radians) * originalY;
        y = MathHelper.sin(radians) * originalX + MathHelper.cos(radians) * originalY;
        return this;
    }

    public MutableXY add(MutableXY other) {
        x += other.x;
        y += other.y;
        return this;
    }

    public MutableXY subtract(MutableXY other) {
        x -= other.x;
        y -= other.y;
        return this;
    }

    @Override
    public MutableXY clone() {
        return new MutableXY(x, y);
    }

    public MutableXY mul(float scalar) {
        x *= scalar;
        y *= scalar;
        return this;
    }

    public void copy(MutableXY other) {
        x = other.x;
        y = other.y;
    }

    public MutableXY div(float scalar) {
        x /= scalar;
        y /= scalar;
        return this;
    }

    @Override
    public String toString() {
        return "MutableXY{x=" + x + ", y=" + y + '}';
    }
}
