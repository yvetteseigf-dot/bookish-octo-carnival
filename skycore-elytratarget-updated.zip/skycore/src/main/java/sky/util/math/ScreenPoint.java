package sky.util.math;

/** Mutable pair of float coordinates. */
public class ScreenPoint {
    public float x;
    public float y;

    public ScreenPoint(float x, float y) {
        this.x = x;
        this.y = y;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getX() {
        return x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public float getY() {
        return y;
    }

    @Override
    public String toString() {
        return "ScreenPoint{x=" + x + ", y=" + y + '}';
    }
}
