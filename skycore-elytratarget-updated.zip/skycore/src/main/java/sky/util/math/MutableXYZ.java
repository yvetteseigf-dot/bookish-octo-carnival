package sky.util.math;

import net.minecraft.util.math.MathHelper;

/** A mutable three-dimensional float vector. */
public class MutableXYZ {
    public float x;
    public float y;
    public float z;

    public MutableXYZ(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public float sqrMagnitude() {
        return x * x + y * y + z * z;
    }

    public MutableXYZ subtract(MutableXYZ other) {
        x -= other.x;
        y -= other.y;
        z -= other.z;
        return this;
    }

    public MutableXYZ add(MutableXYZ other) {
        x += other.x;
        y += other.y;
        z += other.z;
        return this;
    }

    /** Rotates this vector in the X/Y plane; Z is left unchanged. */
    public MutableXYZ rotateDegrees(float degrees) {
        float originalX = x;
        float originalY = y;
        float radians = (float) Math.toRadians(degrees);
        x = MathHelper.cos(radians) * originalX - MathHelper.sin(radians) * originalY;
        y = MathHelper.sin(radians) * originalX + MathHelper.cos(radians) * originalY;
        return this;
    }

    public MutableXYZ normalize() {
        float magnitude = MathHelper.sqrt(sqrMagnitude());
        if (magnitude < 0.0001F) {
            x = 0.0F;
            y = 0.0F;
            z = 0.0F;
        } else {
            x /= magnitude;
            y /= magnitude;
            z /= magnitude;
        }
        return this;
    }

    public MutableXYZ mul(float scalar) {
        x *= scalar;
        y *= scalar;
        z *= scalar;
        return this;
    }

    public void copy(MutableXYZ other) {
        x = other.x;
        y = other.y;
        z = other.z;
    }

    public MutableXYZ div(float scalar) {
        x /= scalar;
        y /= scalar;
        z /= scalar;
        return this;
    }

    @Override
    public MutableXYZ clone() {
        return new MutableXYZ(x, y, z);
    }

    @Override
    public String toString() {
        return "Vector3 [x=" + x + ", y=" + y + ", z=" + z + ']';
    }
}
