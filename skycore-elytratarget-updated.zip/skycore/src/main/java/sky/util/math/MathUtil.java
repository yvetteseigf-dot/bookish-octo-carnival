package sky.util.math;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3d;
import sky.access.MinecraftAccess;

public final class MathUtil implements MinecraftAccess {
    private static final int TABLE_SIZE = 65536;
    private static final double[] TRIG_TABLE;
    public static double PI2;
    private static final double TWO_PI = 6.283185307179586d;

    static {
        PI2 = TWO_PI;
        TRIG_TABLE = new double[TABLE_SIZE];
        for (int i = 0; i < TABLE_SIZE; i++) {
            TRIG_TABLE[i] = Math.sin(i * TWO_PI / 65536.0d);
        }
    }

    private MathUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static double round(double num, double increment) {
        double rounded = Math.round(num / increment) * increment;
        return Math.round(rounded * 100.0d) / 100.0d;
    }

    public static double getDistance(Vec3d pos1, Vec3d pos2) {
        double dx = pos1.getX() - pos2.getX();
        double dy = pos1.getY() - pos2.getY();
        double dz = pos1.getZ() - pos2.getZ();
        return MathHelper.sqrt((float) (dx * dx + dy * dy + dz * dz));
    }

    public static float randomtest(float min, float max) {
        return (float) getRandom(min, max);
    }

    public static double sin(double radians) {
        int index = (int) (radians * 10430.378350470453d) & 65535;
        return TRIG_TABLE[index];
    }

    public static Vec3d interpolate(Vec3d prevPos, Vec3d pos) {
        return new Vec3d(
                interpolate(prevPos.x, pos.x),
                interpolate(prevPos.y, pos.y),
                interpolate(prevPos.z, pos.z)
        );
    }

    public static double interpolateSmooth(double smooth, double orig, double prev) {
        return MathHelper.lerp(mc.getRenderTickCounter().getLastDuration() / smooth, orig, prev);
    }

    public static float randomizeFloat(float min, float max) {
        return (float) (Math.random() * (max - min)) + min;
    }

    public static Vector3d interpolate(Vector3d pos, Vector3d prevPos) {
        return new Vector3d(
                interpolate(pos.x, prevPos.x),
                interpolate(pos.y, prevPos.y),
                interpolate(pos.z, prevPos.z)
        );
    }

    public static double roundHalfUp(double num, double increment) {
        double rounded = Math.round(num / increment) * increment;
        return new BigDecimal(rounded).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    public static double getRandom(double min, double max) {
        if (min == max) {
            return min;
        }
        if (min > max) {
            double tmp = min;
            min = max;
            max = tmp;
        }
        return ThreadLocalRandom.current().nextDouble() * (max - min) + min;
    }

    public static boolean isHoveredByCords(double mouseX, double mouseY, int x, int y, int xEnd, int yEnd) {
        return mouseX >= x && mouseX <= xEnd && mouseY >= y && mouseY <= yEnd;
    }

    public static float random(double min, double max) {
        return (float) (min + (max - min) * Math.random());
    }

    public static float angleDifference(float angle2, float angle1) {
        float difference = (angle2 - angle1) % 360.0f;
        if (difference < -180.0f) {
            difference += 360.0f;
        } else if (difference > 180.0f) {
            difference -= 360.0f;
        }
        return difference;
    }

    public static int interpolateSmooth(double smooth, int orig, int prev) {
        return (int) MathHelper.lerp(mc.getRenderTickCounter().getLastDuration() / smooth, orig, prev);
    }

    public static Vec3d cosSin(int i, int size, double width) {
        int n = Math.min(i, size);
        float x = (float) (Math.cos(n * PI2 / size) * width);
        float z = (float) (-Math.sin(n * PI2 / size) * width);
        return new Vec3d(x, 0.0d, z);
    }

    public static float interpolate(float prev, float orig) {
        return MathHelper.lerp(mc.getRenderTickCounter().getTickDelta(false), prev, orig);
    }

    public static double interpolate(double orig, double prev) {
        return MathHelper.lerp(mc.getRenderTickCounter().getTickDelta(false), orig, prev);
    }

    public static boolean isHovered(double mouseX, double mouseY, double x, double y, double width, double height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }

    public static Vec3d interpolate(Entity entity) {
        if (entity == null) {
            return Vec3d.ZERO;
        }
        return new Vec3d(
                interpolate(entity.lastRenderX, entity.getX()),
                interpolate(entity.lastRenderY, entity.getY()),
                interpolate(entity.lastRenderZ, entity.getZ())
        );
    }

    public static double getBps(Entity entity, int decimal) {
        if (entity == null) {
            return 0.0d;
        }
        double dx = entity.getX() - entity.lastRenderX;
        double dy = entity.getY() - entity.lastRenderY;
        double dz = entity.getZ() - entity.lastRenderZ;
        double bps = Math.sqrt(dx * dx + dy * dy + dz * dz) * 20.0d;
        return roundHalfUp(bps, decimal);
    }

    public static float round(float value) {
        return Math.round(value * 10.0f) / 10.0f;
    }

    public static double cubicBezier(double t, double p0, double p1, double p2, double p3) {
        return Math.pow(1.0d - t, 3.0d) * p0
                + 3.0d * t * Math.pow(1.0d - t, 2.0d) * p1
                + 3.0d * Math.pow(t, 2.0d) * (1.0d - t) * p2
                + Math.pow(t, 3.0d) * p3;
    }

    public static float goodSubtract(float value2, float value1) {
        return Math.abs(value2 - value1);
    }

    public static float interpolateSmooth(double smooth, float orig, float prev) {
        return (float) MathHelper.lerp(mc.getRenderTickCounter().getLastDuration() / smooth, orig, prev);
    }

    public static int levenshtein(String a, String b) {
        int aLen = a.length();
        int bLen = b.length();
        int[] row = new int[bLen + 1];
        for (int j = 0; j <= bLen; j++) {
            row[j] = j;
        }
        for (int i = 1; i <= aLen; i++) {
            int prev = row[0];
            row[0] = i;
            for (int j = 1; j <= bLen; j++) {
                int temp = row[j];
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                row[j] = Math.min(Math.min(row[j] + 1, row[j - 1] + 1), prev + cost);
                prev = temp;
            }
        }
        return row[bLen];
    }

    public static double cos(double radians) {
        int index = (int) (radians * 10430.378350470453d + 16384.0d) & 65535;
        return TRIG_TABLE[index];
    }

    public static float interpolate(double oldValue, double newValue, double interpolationValue) {
        return (float) (oldValue + (newValue - oldValue) * interpolationValue);
    }
}
