package sky.util.math;

/** Immutable corner-radius definition used by rounded UI geometry. */
public record CornerRadii(float topLeft, float topRight, float bottomRight, float bottomLeft) {
    public static final CornerRadii ZERO = new CornerRadii(0.0F, 0.0F, 0.0F, 0.0F);

    public static CornerRadii all(float radius) {
        return new CornerRadii(radius, radius, radius, radius);
    }

    public static CornerRadii top(float radius) {
        return new CornerRadii(radius, radius, 0.0F, 0.0F);
    }

    public static CornerRadii bottom(float radius) {
        return new CornerRadii(0.0F, 0.0F, radius, radius);
    }
}
