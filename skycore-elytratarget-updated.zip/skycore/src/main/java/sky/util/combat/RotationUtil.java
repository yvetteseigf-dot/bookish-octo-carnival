package sky.util.combat;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import sky.access.MinecraftAccess;

public final class RotationUtil implements MinecraftAccess {
    private RotationUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Rotation getClientRotation() {
        return new Rotation(mc.player.getYaw(), mc.player.getPitch());
    }

    public static Rotation calculateAngle(Vec3d to) {
        return fromVec3d(to.subtract(mc.player.getEyePos()));
    }

    public static Rotation fromVec3d(Vec3d vector) {
        return new Rotation(
            (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(vector.z, vector.x)) - 90.0D),
            (float) MathHelper.wrapDegrees(Math.toDegrees(-Math.atan2(vector.y, Math.hypot(vector.x, vector.z))))
        );
    }

    public static Vec2f getRotations(Vec3d vec3d) {
        double x = vec3d.x - mc.player.getX();
        double y = vec3d.y - mc.player.getEyeY();
        double z = vec3d.z - mc.player.getZ();
        double horizontal = MathHelper.sqrt((float) (x * x + z * z));
        float yaw = (float) (MathHelper.atan2(z, x) * 57.29577951308232D - 90.0D);
        float pitch = (float) (-MathHelper.atan2(y, horizontal) * 57.29577951308232D);
        return new Vec2f(yaw, pitch);
    }
}
