package sky.util.combat;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.SwordItem;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import sky.access.MinecraftAccess;

public final class CombatAiHelper implements MinecraftAccess {
    private CombatAiHelper() {
    }

    public static boolean cooldownIsReached(boolean reduced) {
        if (mc.player == null || mc.gameRenderer == null) {
            return false;
        }

        float threshold = 0.0F;
        if (mc.player.getMainHandStack().isEmpty()) {
            threshold = 0.9F;
        }
        if (mc.player.getMainHandStack().getItem() instanceof SwordItem) {
            threshold = 0.52F;
        }
        if (reduced) {
            threshold -= 0.15F;
        }
        return mc.gameRenderer.firstPersonRenderer.equipProgressMainHand > threshold;
    }

    public static float getAICooldown() {
        if (mc.player == null) {
            return 0.93F;
        }
        if (mc.player.getMainHandStack().isOf(Items.AIR)) {
            return 0.9F;
        }
        if (mc.player.getMainHandStack().getItem() instanceof AxeItem
                || mc.player.getMainHandStack().getItem() instanceof ShovelItem) {
            return 0.95F;
        }
        return 0.93F;
    }

    public static boolean canCritical(LivingEntity target) {
        if (mc.player == null) {
            return false;
        }

        return !mc.player.hasStatusEffect(StatusEffects.LEVITATION)
                && !mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
                && !mc.player.isSubmergedIn(FluidTags.WATER)
                && !mc.player.isSubmergedIn(FluidTags.LAVA)
                && !mc.player.getAbilities().flying
                && !mc.player.isGliding()
                && !mc.player.isClimbing()
                && !mc.player.hasVehicle()
                && mc.player.fallDistance > 0.0F
                && !mc.player.isOnGround();
    }

    public static boolean canAIFall() {
        BlockPos under = BlockPos.ofFloored(mc.player.getPos().add(0.0D, -0.4D, 0.0D));
        if (mc.world.getBlockState(under).isOf(Blocks.WATER)) {
            return true;
        }

        return (getBlock(0.0D, 3.0D, 0.0D) == Blocks.AIR
                && getBlock(0.0D, 2.0D, 0.0D) == Blocks.AIR
                && getBlock(0.0D, 1.0D, 0.0D) == Blocks.AIR)
                || mc.player.fallDistance < (getBlock(0.0D, 2.0D, 0.0D) == Blocks.AIR ? 0.6F : 0.08F)
                || mc.player.fallDistance > 1.2F;
    }

    private static Block getBlock(double offsetX, double offsetY, double offsetZ) {
        return mc.world.getBlockState(mc.player.getBlockPos()
                .add((int) offsetX, (int) offsetY, (int) offsetZ)).getBlock();
    }
}
