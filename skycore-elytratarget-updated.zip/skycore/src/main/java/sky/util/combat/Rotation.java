package sky.util.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Immutable yaw/pitch pair with Minecraft sensitivity quantization helpers. */
public class Rotation {
    public static final Rotation ZERO = new Rotation(0.0F, 0.0F);

    private final float yaw;
    private final float pitch;
    private boolean isNormalized;

    public Rotation(float yaw, float pitch) {
        this(yaw, pitch, false);
    }

    public Rotation(float yaw, float pitch, boolean normalized) {
        this.yaw = yaw;
        this.pitch = pitch;
        this.isNormalized = normalized;
    }

    public boolean approximatelyEquals(Rotation other, float threshold) {
        return angleTo(other) <= threshold;
    }

    public Rotation add(RotationDelta delta) {
        return new Rotation(yaw + delta.getDeltaYaw(), pitch + delta.getDeltaPitch());
    }

    public static Rotation fromRotationVec(Vec3d vector) {
        double x = vector.x;
        double y = vector.y;
        double z = vector.z;
        return new Rotation(
                (float) MathHelper.wrapDegrees(Math.toDegrees(Math.atan2(z, x)) - 90.0D),
                (float) MathHelper.wrapDegrees(-Math.toDegrees(Math.atan2(y, Math.sqrt(x * x + z * z))))
        );
    }

    public Rotation normalize(Rotation reference) {
        if (!isNormalized && !equals(reference)) {
            RotationDelta delta = reference.rotationDeltaTo(this);
            double gcd = gcd();
            int yawSteps = (int) ((double) delta.getDeltaYaw() / gcd);
            int pitchSteps = (int) ((double) delta.getDeltaPitch() / gcd);
            return new Rotation(
                    (float) ((double) reference.getYaw() + (double) yawSteps * gcd),
                    (float) ((double) reference.getPitch() + (double) pitchSteps * gcd),
                    true
            );
        }
        return this;
    }

    public float getYaw() {
        return yaw;
    }

    public static float applyGCD(float target, float previous) {
        float delta = target - previous;
        float gcd = gcd();
        return previous + Math.round(delta / gcd) * gcd;
    }

    public Rotation towardsLinear(Rotation target, float yawSpeed, float pitchSpeed) {
        RotationDelta delta = rotationDeltaTo(target);
        float length = delta.length();
        if (length == 0.0F) {
            return this;
        }
        float yawLimit = Math.abs(delta.getDeltaYaw() / length) * yawSpeed;
        float pitchLimit = Math.abs(delta.getDeltaPitch() / length) * pitchSpeed;
        float yawDelta = MathHelper.clamp(delta.getDeltaYaw(), -yawLimit, yawLimit);
        float pitchDelta = MathHelper.clamp(delta.getDeltaPitch(), -pitchLimit, pitchLimit);
        return new Rotation(yaw + yawDelta, pitch + pitchDelta);
    }

    public boolean isNormalized() {
        return isNormalized;
    }

    public float angleTo(Rotation other) {
        return Math.min(rotationDeltaTo(other).length(), 180.0F);
    }

    public float getDelta(Rotation other) {
        float yawDelta = MathHelper.wrapDegrees(other.getYaw() - yaw);
        float pitchDelta = other.getPitch() - pitch;
        return (float) Math.hypot(Math.abs(yawDelta), Math.abs(pitchDelta));
    }

    private float angleDifference(float first, float second) {
        return MathHelper.wrapDegrees(first - second);
    }

    public final Vec3d toVector() {
        float pitchRadians = pitch * 0.017453292F;
        float yawRadians = -yaw * 0.017453292F;
        float cosYaw = MathHelper.cos(yawRadians);
        float sinYaw = MathHelper.sin(yawRadians);
        float cosPitch = MathHelper.cos(pitchRadians);
        float sinPitch = MathHelper.sin(pitchRadians);
        return new Vec3d(sinYaw * cosPitch, -sinPitch, cosYaw * cosPitch);
    }

    public static float applyGCDWithJitter(float target, float previous, float jitterStrength) {
        float delta = target - previous;
        float gcd = gcd();
        float result = previous + Math.round(delta / gcd) * gcd;
        if (jitterStrength > 0.0F && Math.abs(delta) > gcd * 2.0F) {
            result += (float) (Math.random() - 0.5D) * gcd * jitterStrength;
        }
        return result;
    }

    /** Preserves the original inverted predicate: true means invalid values. */
    public boolean check() {
        return Float.isInfinite(yaw) || Float.isNaN(yaw)
                || Float.isInfinite(pitch) || Float.isNaN(pitch);
    }

    public static Rotation getRotations(Vec3d target) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return ZERO;
        }
        double x = target.x - client.player.getX();
        double y = target.y - client.player.getEyeY();
        double z = target.z - client.player.getZ();
        double horizontal = MathHelper.sqrt((float) (x * x + z * z));
        return new Rotation(
                (float) (MathHelper.atan2(z, x) * 57.29577951308232D - 90.0D),
                (float) (-MathHelper.atan2(y, horizontal) * 57.29577951308232D)
        );
    }

    public static float gcd() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options == null) {
            return 0.15F;
        }
        double sensitivity = client.options.getMouseSensitivity().getValue() * 0.6000000238418579D
                + 0.20000000298023224D;
        return (float) (sensitivity * sensitivity * sensitivity * 8.0D * 0.15000000596046448D);
    }

    public RotationDelta rotationDeltaTo(Rotation other) {
        return new RotationDelta(
                angleDifference(yaw, other.yaw),
                angleDifference(pitch, other.pitch)
        );
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Rotation other)) {
            return false;
        }
        return other.yaw == yaw && other.pitch == pitch;
    }

    public Vec3d getDirectionVector() {
        return Vec3d.fromPolar(pitch, yaw);
    }

    public static Rotation lookingAt(Vec3d from, Vec3d to) {
        return fromRotationVec(from.subtract(to));
    }

    public float getPitch() {
        return pitch;
    }
}
