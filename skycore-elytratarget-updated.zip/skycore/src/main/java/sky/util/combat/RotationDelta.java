package sky.util.combat;

import net.minecraft.util.math.Vec2f;

/** The yaw and pitch difference between two rotations. */
public class RotationDelta {
    private final float deltaYaw;
    private final float deltaPitch;

    public RotationDelta(float deltaYaw, float deltaPitch) {
        this.deltaYaw = deltaYaw;
        this.deltaPitch = deltaPitch;
    }

    public boolean isInRange(float yawRange, float pitchRange) {
        return Math.abs(deltaYaw) < yawRange && Math.abs(deltaPitch) < pitchRange;
    }

    public boolean isInRange(float range) {
        return isInRange(range, range);
    }

    public float getDeltaYaw() {
        return deltaYaw;
    }

    public float getDeltaPitch() {
        return deltaPitch;
    }

    public Vec2f toVec2f() {
        return new Vec2f(deltaYaw, deltaPitch);
    }

    public float length() {
        return (float) Math.sqrt(deltaYaw * deltaYaw + deltaPitch * deltaPitch);
    }
}
