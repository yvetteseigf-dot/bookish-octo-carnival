package sky.util.combat;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import sky.access.MinecraftAccess;

/** Sends an attack together with the arm swing the vanilla client would normally pair it with. */
public final class AttackPacketUtil implements MinecraftAccess {
    private static boolean swingAfterAttack;

    private AttackPacketUtil() {
    }

    public static void notifyAttackCancelled() {
        swingAfterAttack = false;
    }

    public static void sendFixedAttack(PlayerEntity attacker, Entity target) {
        if (mc.interactionManager == null || attacker == null || target == null) {
            return;
        }
        swingAfterAttack = true;
        mc.interactionManager.attackEntity(attacker, target);
        if (swingAfterAttack) {
            attacker.swingHand(Hand.MAIN_HAND);
        }
    }
}
