package sky.util.animation;

public final class FadeAnimation {
    private static final long DEFAULT_DURATION_MS = 250L;

    private long durationMs = DEFAULT_DURATION_MS;
    private long phaseStartMs;
    private Phase phase = Phase.CLOSED;

    private float progress() {
        float elapsed = (float) (System.currentTimeMillis() - phaseStartMs);
        return Math.min(1.0F, Math.max(0.0F, elapsed / (float) durationMs));
    }

    public void fadeOut() {
        fadeOut(DEFAULT_DURATION_MS);
    }

    public float getAlpha() {
        return switch (phase) {
            case CLOSED -> 0.0F;
            case FADING_IN -> ease(progress());
            case OPEN -> 1.0F;
            case FADING_OUT -> 1.0F - ease(progress());
        };
    }

    public void update() {
        if (phase == Phase.FADING_IN && progress() >= 1.0F) {
            phase = Phase.OPEN;
        } else if (phase == Phase.FADING_OUT && progress() >= 1.0F) {
            phase = Phase.CLOSED;
        }
    }

    private static float inverseEase(float target) {
        target = Math.min(1.0F, Math.max(0.0F, target));
        if (target <= 0.0F) {
            return 0.0F;
        }
        if (target >= 1.0F) {
            return 1.0F;
        }

        float low = 0.0F;
        float high = 1.0F;
        for (int i = 0; i < 14; i++) {
            float middle = (low + high) * 0.5F;
            if (ease(middle) < target) {
                low = middle;
            } else {
                high = middle;
            }
        }
        return (low + high) * 0.5F;
    }

    public void reset() {
        phase = Phase.CLOSED;
    }

    public void restart(long durationMs) {
        this.durationMs = Math.max(1L, durationMs);
        phase = Phase.FADING_IN;
        phaseStartMs = System.currentTimeMillis();
    }

    public boolean isVisible() {
        return phase != Phase.CLOSED;
    }

    public void fadeOut(long durationMs) {
        if (phase == Phase.CLOSED || phase == Phase.FADING_OUT) {
            return;
        }

        float alpha = getAlpha();
        this.durationMs = Math.max(1L, durationMs);
        phase = Phase.FADING_OUT;
        phaseStartMs = System.currentTimeMillis()
                - (long) (inverseEase(1.0F - alpha) * (float) this.durationMs);
    }

    public void fadeIn() {
        fadeIn(DEFAULT_DURATION_MS);
    }

    public void fadeIn(long durationMs) {
        if (phase == Phase.OPEN || phase == Phase.FADING_IN) {
            return;
        }

        float alpha = getAlpha();
        this.durationMs = Math.max(1L, durationMs);
        phase = Phase.FADING_IN;
        phaseStartMs = System.currentTimeMillis()
                - (long) (inverseEase(alpha) * (float) this.durationMs);
    }

    public boolean isOpen() {
        return phase == Phase.OPEN || phase == Phase.FADING_IN;
    }

    private static float ease(float value) {
        if (value < 0.5F) {
            return 4.0F * value * value * value;
        }
        return 1.0F - (float) Math.pow(-2.0F * value + 2.0F, 3.0D) / 2.0F;
    }

    private enum Phase {
        CLOSED,
        FADING_IN,
        OPEN,
        FADING_OUT
    }
}
