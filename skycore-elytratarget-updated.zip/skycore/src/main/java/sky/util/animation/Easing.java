package sky.util.animation;

import sky.util.math.MathUtil;

/**
 * Collection of Robert Penner-style interpolation curves used by the client.
 * Every curve accepts elapsed time, start value, change and duration.
 */
public interface Easing {
    Easing GUI_OPEN = generate(0.45F, 1.45F, 0.49F, 1.15F);
    Easing GUI_OPEN_COMPACT = generate(0.45F, 1.45F, 0.43F, 0.91F);
    Easing GUI_PAGE = generate(0.1F, 1.07F, 0.34F, 1.04F);
    Easing GUI_SCALE = generate(0.27F, 1.09F, 0.49F, 1.06F);
    Easing GUI_CLOSE = generate(0.62D, -0.16D, 0.8D, 0.37D);
    Easing GUI_PANEL = generate(0.25D, 1.07D, 0.11D, 1.1D);
    Easing FIGMA_EASE_IN_OUT = generate(0.42D, 0.0D, 0.58D, 1.0D);

    Easing SMOOTH_STEP = (t, b, c, d) -> {
        float value = c * t / d + b;
        return (float) (-2.0D * Math.pow(value, 3.0D) + 3.0D * Math.pow(value, 2.0D));
    };
    Easing BOTH_CUBIC = (t, b, c, d) -> {
        float value = c * t / d + b;
        return value < 0.5D
                ? 4.0F * value * value * value
                : (float) (1.0D - Math.pow(-2.0F * value + 2.0F, 3.0D) / 2.0D);
    };
    Easing LINEAR = (t, b, c, d) -> c * t / d + b;
    Easing QUAD_IN = (t, b, c, d) -> c * (t /= d) * t + b;
    Easing QUAD_OUT = (t, b, c, d) -> -c * (t /= d) * (t - 2.0F) + b;
    Easing QUAD_IN_OUT = (t, b, c, d) -> (t /= d / 2.0F) < 1.0F
            ? c / 2.0F * t * t + b
            : -c / 2.0F * ((--t) * (t - 2.0F) - 1.0F) + b;
    Easing CUBIC_IN = (t, b, c, d) -> c * (t /= d) * t * t + b;
    Easing CUBIC_OUT = (t, b, c, d) -> c * ((t = t / d - 1.0F) * t * t + 1.0F) + b;
    Easing CUBIC_IN_OUT = (t, b, c, d) -> (t /= d / 2.0F) < 1.0F
            ? c / 2.0F * t * t * t + b
            : c / 2.0F * ((t -= 2.0F) * t * t + 2.0F) + b;
    Easing QUARTIC_IN = (t, b, c, d) -> c * (t /= d) * t * t * t + b;
    Easing QUARTIC_OUT = (t, b, c, d) -> -c * ((t = t / d - 1.0F) * t * t * t - 1.0F) + b;
    Easing QUARTIC_IN_OUT = (t, b, c, d) -> (t /= d / 2.0F) < 1.0F
            ? c / 2.0F * t * t * t * t + b
            : -c / 2.0F * ((t -= 2.0F) * t * t * t - 2.0F) + b;
    Easing QUINTIC_IN = (t, b, c, d) -> c * (t /= d) * t * t * t * t + b;
    Easing QUINTIC_OUT = (t, b, c, d) -> c * ((t = t / d - 1.0F) * t * t * t * t + 1.0F) + b;
    Easing QUINTIC_IN_OUT = (t, b, c, d) -> (t /= d / 2.0F) < 1.0F
            ? c / 2.0F * t * t * t * t * t + b
            : c / 2.0F * ((t -= 2.0F) * t * t * t * t + 2.0F) + b;
    Easing SINE_IN = (t, b, c, d) -> -c * (float) MathUtil.cos(t / d * (Math.PI / 2.0D)) + c + b;
    Easing SINE_OUT = (t, b, c, d) -> c * (float) MathUtil.sin(t / d * (Math.PI / 2.0D)) + b;
    Easing SINE_IN_OUT = (t, b, c, d) -> -c / 2.0F * ((float) MathUtil.cos(Math.PI * t / d) - 1.0F) + b;
    Easing EXPO_IN = (t, b, c, d) -> t == 0.0F ? b : c * (float) Math.pow(2.0D, 10.0F * (t / d - 1.0F)) + b;
    Easing EXPO_OUT = (t, b, c, d) -> t == d ? b + c : c * (-(float) Math.pow(2.0D, -10.0F * t / d) + 1.0F) + b;
    Easing EXPO_IN_OUT = (t, b, c, d) -> {
        if (t == 0.0F) {
            return b;
        }
        if (t == d) {
            return b + c;
        }
        return (t /= d / 2.0F) < 1.0F
                ? c / 2.0F * (float) Math.pow(2.0D, 10.0F * (t - 1.0F)) + b
                : c / 2.0F * (-(float) Math.pow(2.0D, -10.0F * --t) + 2.0F) + b;
    };
    Easing CIRC_IN = (t, b, c, d) -> -c * ((float) Math.sqrt(1.0F - (t /= d) * t) - 1.0F) + b;
    Easing CIRC_OUT = (t, b, c, d) -> c * (float) Math.sqrt(1.0F - (t = t / d - 1.0F) * t) + b;
    Easing CIRC_IN_OUT = (t, b, c, d) -> (t /= d / 2.0F) < 1.0F
            ? -c / 2.0F * ((float) Math.sqrt(1.0F - t * t) - 1.0F) + b
            : c / 2.0F * ((float) Math.sqrt(1.0F - (t -= 2.0F) * t) + 1.0F) + b;

    Elastic ELASTIC_IN = new ElasticIn();
    Elastic ELASTIC_OUT = new ElasticOut();
    Elastic ELASTIC_IN_OUT = new ElasticInOut();
    Back BACK_IN = new BackIn();
    Back BACK_OUT = new BackOut();
    Back BACK_IN_OUT = new BackInOut();

    Easing BOUNCE_OUT = (t, b, c, d) -> {
        if ((t /= d) < 1.0F / 2.75F) {
            return c * 7.5625F * t * t + b;
        }
        if (t < 2.0F / 2.75F) {
            return c * (7.5625F * (t -= 1.5F / 2.75F) * t + 0.75F) + b;
        }
        return t < 2.5F / 2.75F
                ? c * (7.5625F * (t -= 2.25F / 2.75F) * t + 0.9375F) + b
                : c * (7.5625F * (t -= 2.625F / 2.75F) * t + 0.984375F) + b;
    };
    Easing BOUNCE_IN = (t, b, c, d) -> c - BOUNCE_OUT.ease(d - t, 0.0F, c, d) + b;
    Easing BOUNCE_IN_OUT = (t, b, c, d) -> t < d / 2.0F
            ? BOUNCE_IN.ease(t * 2.0F, 0.0F, c, d) * 0.5F + b
            : BOUNCE_OUT.ease(t * 2.0F - d, 0.0F, c, d) * 0.5F + c * 0.5F + b;

    float ease(float time, float start, float change, float duration);

    /** Builds a curve from the two control points of a CSS-style cubic bezier. */
    static Easing generate(double x1, double y1, double x2, double y2) {
        return new Easing() {
            @Override
            public float ease(float t, float b, float c, float d) {
                if (d <= 0.0F || t <= 0.0F) {
                    return b;
                }
                if (t >= d) {
                    return b + c;
                }
                float progress = t / d;
                float parameter = solveTBez((float) x1, (float) x2, progress);
                float value = bezierY(parameter, (float) y1, (float) y2);
                return b + c * value;
            }

            private float solveTBez(float x1, float x2, float progress) {
                float t = progress;
                for (int i = 0; i < 8; i++) {
                    float x = bezierX(t, x1, x2);
                    float dx = bezierDX(t, x1, x2);
                    if (Math.abs(x - progress) < 1.0E-5F) {
                        break;
                    }
                    if (Math.abs(dx) < 1.0E-6F) {
                        break;
                    }
                    t -= (x - progress) / dx;
                    t = Math.max(0.0F, Math.min(1.0F, t));
                }
                return t;
            }

            private float bezierX(float t, float x1, float x2) {
                return 3.0F * (1.0F - t) * (1.0F - t) * t * x1 + 3.0F * (1.0F - t) * t * t * x2 + t * t * t;
            }

            private float bezierY(float t, float y1, float y2) {
                return 3.0F * (1.0F - t) * (1.0F - t) * t * y1 + 3.0F * (1.0F - t) * t * t * y2 + t * t * t;
            }

            private float bezierDX(float t, float x1, float x2) {
                return 3.0F * ((1.0F - t) * (1.0F - 3.0F * t) * x1 + (2.0F * t - 3.0F * t * t) * x2) + 3.0F * t * t;
            }
        };
    }

    abstract class Back implements Easing {
        public static final float DEFAULT_OVERSHOOT = 1.70158F;

        private float overshoot;

        public Back() {
            this(DEFAULT_OVERSHOOT);
        }

        public Back(float overshoot) {
            this.overshoot = overshoot;
        }

        public float getOvershoot() {
            return overshoot;
        }

        public void setOvershoot(float overshoot) {
            this.overshoot = overshoot;
        }
    }

    class BackIn extends Back {
        public BackIn() {
        }

        public BackIn(float overshoot) {
            super(overshoot);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * (t /= d) * t * ((s + 1.0F) * t - s) + b;
        }
    }

    class BackOut extends Back {
        public BackOut() {
        }

        public BackOut(float overshoot) {
            super(overshoot);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return c * ((t = t / d - 1.0F) * t * ((s + 1.0F) * t + s) + 1.0F) + b;
        }
    }

    class BackInOut extends Back {
        public BackInOut() {
        }

        public BackInOut(float overshoot) {
            super(overshoot);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float s = getOvershoot();
            return (t /= d / 2.0F) < 1.0F
                    ? c / 2.0F * t * t * (((s *= 1.525F) + 1.0F) * t - s) + b
                    : c / 2.0F * ((t -= 2.0F) * t * (((s *= 1.525F) + 1.0F) * t + s) + 2.0F) + b;
        }
    }

    abstract class Elastic implements Easing {
        private float amplitude;
        private float period;

        public Elastic() {
            this(-1.0F, 0.0F);
        }

        public Elastic(float amplitude, float period) {
            this.amplitude = amplitude;
            this.period = period;
        }

        public float getAmplitude() {
            return amplitude;
        }

        public void setAmplitude(float amplitude) {
            this.amplitude = amplitude;
        }

        public float getPeriod() {
            return period;
        }

        public void setPeriod(float period) {
            this.period = period;
        }
    }

    class ElasticIn extends Elastic {
        public ElasticIn() {
        }

        public ElasticIn(float amplitude, float period) {
            super(amplitude, period);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0.0F) {
                return b;
            }
            if ((t /= d) == 1.0F) {
                return b + c;
            }
            if (p == 0.0F) {
                p = d * 0.3F;
            }
            float s;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4.0F;
            } else {
                s = p / (float) (2.0D * Math.PI) * (float) Math.asin(c / a);
            }
            return -(a * (float) Math.pow(2.0D, 10.0F * (t -= 1.0F))
                    * (float) MathUtil.sin((t * d - s) * (2.0D * Math.PI) / p)) + b;
        }
    }

    class ElasticOut extends Elastic {
        public ElasticOut() {
        }

        public ElasticOut(float amplitude, float period) {
            super(amplitude, period);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0.0F) {
                return b;
            }
            if ((t /= d) == 1.0F) {
                return b + c;
            }
            if (p == 0.0F) {
                p = d * 0.3F;
            }
            float s;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4.0F;
            } else {
                s = p / (float) (2.0D * Math.PI) * (float) Math.asin(c / a);
            }
            return a * (float) Math.pow(2.0D, -10.0F * t)
                    * (float) MathUtil.sin((t * d - s) * (2.0D * Math.PI) / p) + c + b;
        }
    }

    class ElasticInOut extends Elastic {
        public ElasticInOut() {
        }

        public ElasticInOut(float amplitude, float period) {
            super(amplitude, period);
        }

        @Override
        public float ease(float t, float b, float c, float d) {
            float a = getAmplitude();
            float p = getPeriod();
            if (t == 0.0F) {
                return b;
            }
            if ((t /= d / 2.0F) == 2.0F) {
                return b + c;
            }
            if (p == 0.0F) {
                p = d * (0.3F * 1.5F);
            }
            float s;
            if (a < Math.abs(c)) {
                a = c;
                s = p / 4.0F;
            } else {
                s = p / (float) (2.0D * Math.PI) * (float) Math.asin(c / a);
            }
            return t < 1.0F
                    ? -0.5F * a * (float) Math.pow(2.0D, 10.0F * (t -= 1.0F))
                            * (float) MathUtil.sin((t * d - s) * (2.0D * Math.PI) / p) + b
                    : a * (float) Math.pow(2.0D, -10.0F * (t -= 1.0F))
                            * (float) MathUtil.sin((t * d - s) * (2.0D * Math.PI) / p) * 0.5F + c + b;
        }
    }
}
