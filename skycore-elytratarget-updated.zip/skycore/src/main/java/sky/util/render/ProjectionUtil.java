package sky.util.render;

import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4d;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import sky.access.MinecraftAccess;
import sky.render.ProjectionMatrixCapture;
import sky.util.combat.Rotation;
import sky.util.combat.RotationUtil;
import sky.util.math.MathUtil;

public final class ProjectionUtil implements MinecraftAccess {
    private ProjectionUtil() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d worldSpaceToScreenSpace(Vec3d position) {
        Vector3f relative = position
            .subtract(mc.getEntityRenderDispatcher().camera.getPos())
            .toVector3f();
        int[] viewport = new int[4];
        GL11.glGetIntegerv(GL11.GL_VIEWPORT, viewport);
        Vector3f projected = new Vector3f();
        Vector4f transformed = new Vector4f(relative.x, relative.y, relative.z, 1.0F)
            .mul(ProjectionMatrixCapture.getWorldSpace());
        Matrix4f projection = new Matrix4f(ProjectionMatrixCapture.getProjection());
        projection.project(transformed.x(), transformed.y(), transformed.z(), viewport, projected);
        return new Vec3d(
            projected.x / mc.getWindow().getScaleFactor(),
            (mc.getWindow().getHeight() - projected.y) / mc.getWindow().getScaleFactor(),
            projected.z
        );
    }

    public static Vec3d[] getVec3ds(Entity entity, Vec3d position) {
        Box box = entity.getBoundingBox();
        Box interpolatedBox = new Box(
            box.minX - entity.getX() + position.x - 0.10000000149011612D,
            box.minY - entity.getY() + position.y - 0.10000000149011612D,
            box.minZ - entity.getZ() + position.z - 0.10000000149011612D,
            box.maxX - entity.getX() + position.x + 0.10000000149011612D,
            box.maxY - entity.getY() + position.y + 0.10000000149011612D,
            box.maxZ - entity.getZ() + position.z + 0.10000000149011612D
        );
        return new Vec3d[]{
            new Vec3d(interpolatedBox.minX, interpolatedBox.minY, interpolatedBox.minZ),
            new Vec3d(interpolatedBox.minX, interpolatedBox.maxY, interpolatedBox.minZ),
            new Vec3d(interpolatedBox.maxX, interpolatedBox.minY, interpolatedBox.minZ),
            new Vec3d(interpolatedBox.maxX, interpolatedBox.maxY, interpolatedBox.minZ),
            new Vec3d(interpolatedBox.minX, interpolatedBox.minY, interpolatedBox.maxZ),
            new Vec3d(interpolatedBox.minX, interpolatedBox.maxY, interpolatedBox.maxZ),
            new Vec3d(interpolatedBox.maxX, interpolatedBox.minY, interpolatedBox.maxZ),
            new Vec3d(interpolatedBox.maxX, interpolatedBox.maxY, interpolatedBox.maxZ)
        };
    }

    public static Vector4d getVector4D(Entity entity) {
        Vector4d bounds = null;
        for (Vec3d corner : getVec3ds(entity, MathUtil.interpolate(entity))) {
            Vec3d projected = worldSpaceToScreenSpace(new Vec3d(corner.x, corner.y, corner.z));
            if (projected.z > 0.0D && projected.z < 1.0D) {
                if (bounds == null) {
                    bounds = new Vector4d(projected.x, projected.y, projected.z, 0.0D);
                }
                bounds.x = Math.min(projected.x, bounds.x);
                bounds.y = Math.min(projected.y, bounds.y);
                bounds.z = Math.max(projected.x, bounds.z);
                bounds.w = Math.max(projected.y, bounds.w);
            }
        }
        return bounds;
    }

    public static boolean canSee(Box box) {
        return box != null && mc.world != null;
    }

    public static double centerX(Vector4d vector) {
        return vector.x + (vector.z - vector.x) / 2.0D;
    }

    public static boolean canSee(Vec3d position) {
        Camera camera = mc.getEntityRenderDispatcher().camera;
        Rotation rotation = RotationUtil.calculateAngle(position);
        if (Math.abs(MathHelper.wrapDegrees(rotation.getYaw() - camera.getYaw())) < 90.0F
            && Math.abs(MathHelper.wrapDegrees(rotation.getPitch() - camera.getPitch())) < 60.0F) {
            return true;
        }
        return canSee(new Box(BlockPos.ofFloored(position)));
    }

    public static boolean canSee(Vector4d vector) {
        return vector == null
            || vector.x < 0.0D && vector.z < 1.0D
            || vector.y < 0.0D && vector.w < 1.0D;
    }
}
