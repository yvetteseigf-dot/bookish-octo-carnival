package sky.util.render;

import net.minecraft.util.math.MathHelper;

import java.awt.Color;

public final class ColorUtil {
    private ColorUtil() {
    }

    public static Color lerp(Color first, Color second, float progress) {
        if (first == null) {
            first = Color.WHITE;
        }
        if (second == null) {
            second = Color.WHITE;
        }
        progress = MathHelper.clamp(progress, 0.0F, 1.0F);
        int red = (int) (first.getRed() + (second.getRed() - first.getRed()) * progress);
        int green = (int) (first.getGreen() + (second.getGreen() - first.getGreen()) * progress);
        int blue = (int) (first.getBlue() + (second.getBlue() - first.getBlue()) * progress);
        int alpha = (int) (first.getAlpha() + (second.getAlpha() - first.getAlpha()) * progress);
        return new Color(red, green, blue, alpha);
    }

    public static float bluef(int color) {
        return (color & 255) / 255.0F;
    }

    public static float redf(int color) {
        return (color >> 16 & 255) / 255.0F;
    }

    public static String removeFormatting(String text) {
        return text == null ? "" : text.replaceAll("§.", "");
    }

    public static Color withAlpha(Color color, int alpha) {
        if (color == null) {
            color = Color.WHITE;
        }
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp(alpha, 0, 255));
    }

    public static float greenf(int color) {
        return (color >> 8 & 255) / 255.0F;
    }

    public static float alphaf(int color) {
        return (color >> 24 & 255) / 255.0F;
    }

    public static int fixBrightness(int color) {
        return (color >> 24 & 255) != 0 ? color : color | 0xFF000000;
    }

    public static int rgba(int red, int green, int blue, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24
                | MathHelper.clamp(red, 0, 255) << 16
                | MathHelper.clamp(green, 0, 255) << 8
                | MathHelper.clamp(blue, 0, 255);
    }

    public static Color withAlpha(Color color, float alpha) {
        if (color == null) {
            color = Color.WHITE;
        }
        float clampedAlpha = MathHelper.clamp(alpha, 0.0F, 1.0F);
        int newAlpha = Math.round(color.getAlpha() * clampedAlpha);
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), MathHelper.clamp(newAlpha, 0, 255));
    }

    public static Color darken(Color color, float amount) {
        if (color == null) {
            color = Color.WHITE;
        }
        amount = MathHelper.clamp(amount, 0.0F, 1.0F);
        return new Color(
                Math.round(color.getRed() * (1.0F - amount)),
                Math.round(color.getGreen() * (1.0F - amount)),
                Math.round(color.getBlue() * (1.0F - amount)),
                color.getAlpha());
    }
}
