package sky.util.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import org.lwjgl.glfw.GLFW;
import sky.render.HudProjectionManager;

/**
 * Bridges HUD-space coordinates and the framebuffer-space projection that
 * {@link HudProjectionManager} installs while the client overlay is drawn.
 */
public final class HudScaleUtil {
    private static float scale = 1.0F;

    private HudScaleUtil() {
    }

    public static void begin(double renderScale) {
        HudProjectionManager.begin(renderScale);
    }

    public static void end() {
        HudProjectionManager.end();
    }

    public static void forceEnd() {
        HudProjectionManager.forceEnd();
    }

    public static boolean isActive() {
        return HudProjectionManager.isActive();
    }

    public static void markActive(double renderScale) {
        scale = (float) renderScale;
    }

    public static void markInactive() {
        scale = (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
    }

    public static float getScale() {
        if (!HudProjectionManager.isActive()) {
            return (float) MinecraftClient.getInstance().getWindow().getScaleFactor();
        }
        return scale;
    }

    public static float getRenderWidth() {
        Window window = MinecraftClient.getInstance().getWindow();
        if (HudProjectionManager.isActive()) {
            return (float) (window.getFramebufferWidth() / 2.0D);
        }
        return window.getScaledWidth();
    }

    public static float getRenderHeight() {
        Window window = MinecraftClient.getInstance().getWindow();
        if (HudProjectionManager.isActive()) {
            return (float) (window.getFramebufferHeight() / 2.0D);
        }
        return window.getScaledHeight();
    }

    private static float getOverlayRenderWidth() {
        Window window = MinecraftClient.getInstance().getWindow();
        return (float) (window.getFramebufferWidth() / 2.0D);
    }

    private static float getOverlayRenderHeight() {
        Window window = MinecraftClient.getInstance().getWindow();
        return (float) (window.getFramebufferHeight() / 2.0D);
    }

    public static double[] getScaledMouse() {
        Window window = MinecraftClient.getInstance().getWindow();
        double[] cursorX = new double[1];
        double[] cursorY = new double[1];
        GLFW.glfwGetCursorPos(window.getHandle(), cursorX, cursorY);
        return new double[] {
                cursorX[0] * window.getScaledWidth() / window.getFramebufferWidth(),
                cursorY[0] * window.getScaledHeight() / window.getFramebufferHeight()
        };
    }

    public static double getScaledMouseX() {
        return getScaledMouse()[0];
    }

    public static double getScaledMouseY() {
        return getScaledMouse()[1];
    }

    public static float toHudX(double scaledMouseX) {
        Window window = MinecraftClient.getInstance().getWindow();
        return (float) (scaledMouseX * getOverlayRenderWidth() / window.getScaledWidth());
    }

    public static float toHudY(double scaledMouseY) {
        Window window = MinecraftClient.getInstance().getWindow();
        return (float) (scaledMouseY * getOverlayRenderHeight() / window.getScaledHeight());
    }

    public static float mouseHudX() {
        return toHudX(getScaledMouseX());
    }

    public static float mouseHudY() {
        return toHudY(getScaledMouseY());
    }
}
