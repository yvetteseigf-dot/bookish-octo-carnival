package sky.util.elytra;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import sky.access.SkyClientAccess;

public final class ElytraPhysicsBoost implements SkyClientAccess {
    private ElytraPhysicsBoost() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d getBoost(LivingEntity entity) {
        float yaw = Math.abs((entity.getYaw() - 360.0F) % 360.0F);

        float[] diagonals = {45.0F, 135.0F, 225.0F, 315.0F};
        float nearestDiagonal = diagonals[0];
        float nearestDelta = 9999.0F;
        for (float diagonal : diagonals) {
            float delta = Math.abs(yaw - diagonal);
            if (delta < nearestDelta) {
                nearestDelta = delta;
                nearestDiagonal = diagonal;
            }
        }

        float diagonalOffset = Math.abs(yaw - nearestDiagonal);
        float boost = 2.4F - diagonalOffset * 0.05F;

        Vec3d facing = entity.getRotationVector();
        Vec3d velocity = Vec3d.fromPolar(entity.getPitch(), entity.getYaw()).multiply(Math.max(boost, 1.61F));

        float pitchRadians = entity.getPitch() * 0.017453292F;
        double facingHorizontalLength = Math.sqrt(facing.x * facing.x + facing.z * facing.z);
        double horizontalSpeed = velocity.horizontalLength();

        boolean falling = entity.getVelocity().y <= 0.0D;
        double gravity = falling && entity.hasStatusEffect(StatusEffects.SLOW_FALLING)
            ? Math.min(entity.getFinalGravity(), 0.01D)
            : entity.getFinalGravity();

        double pitchCosSquared = MathHelper.square(Math.cos(pitchRadians));
        velocity = velocity.add(0.0D, gravity * (-1.0D + pitchCosSquared * 0.75D), 0.0D);

        if (velocity.y < 0.0D && facingHorizontalLength > 0.0D) {
            double lift = velocity.y * -0.1D * pitchCosSquared;
            velocity = velocity.add(
                facing.x * lift / facingHorizontalLength,
                lift,
                facing.z * lift / facingHorizontalLength
            );
        }

        if (pitchRadians < 0.0F && facingHorizontalLength > 0.0D) {
            double dive = horizontalSpeed * -MathHelper.sin(pitchRadians) * 0.04D;
            velocity = velocity.add(
                -facing.x * dive / facingHorizontalLength,
                dive * 3.2D,
                -facing.z * dive / facingHorizontalLength
            );
        }

        if (facingHorizontalLength > 0.0D) {
            velocity = velocity.add(
                (facing.x / facingHorizontalLength * horizontalSpeed - velocity.x) * 0.1D,
                0.0D,
                (facing.z / facingHorizontalLength * horizontalSpeed - velocity.z) * 0.1D
            );
        }

        double speed = new Vec3d(velocity.x, velocity.y, velocity.z).length();
        return new Vec3d(speed, speed, speed).multiply(0.99D, 0.98D, 0.99D);
    }
}
