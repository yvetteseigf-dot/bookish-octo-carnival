package sky.util.elytra;

import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Vec3d;
import sky.access.SkyClientAccess;

public final class ElytraBoostTable implements SkyClientAccess {
    private ElytraBoostTable() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }

    public static Vec3d getBoost(LivingEntity entity) {
        float yaw = entity.getYaw();
        float pitch = entity.getPitch();

        float normalizedYaw = yaw % 180.0F;
        if (normalizedYaw > 90.0F) {
            normalizedYaw -= 180.0F;
        } else if (normalizedYaw < -90.0F) {
            normalizedYaw += 180.0F;
        }

        float normalizedPitch = pitch % 180.0F;
        if (normalizedPitch > 90.0F) {
            normalizedPitch -= 180.0F;
        } else if (normalizedPitch < -90.0F) {
            normalizedPitch += 180.0F;
        }

        float horizontal = getSpeedForPitch(normalizedPitch, normalizedYaw);
        float vertical = getSpeedYForPitch(normalizedPitch);
        return new Vec3d(horizontal, vertical, horizontal);
    }

    private static float getSpeedForPitch(float pitch, float yaw) {
        float absPitch = Math.abs(pitch);
        float absYaw = Math.abs(yaw);

        if (absPitch >= 38.0F && absPitch <= 52.0F) {
            return 1.98F;
        }
        if (absPitch >= 32.0F && absPitch <= 58.0F) {
            return 1.97F;
        }
        if (absPitch >= 28.0F && absPitch <= 62.0F) {
            return 1.95F;
        }
        if ((absYaw >= 29.0F && absYaw <= 61.0F) || (absPitch >= 29.0F && absPitch <= 61.0F)) {
            return 1.963F;
        }
        if ((absYaw >= 27.0F && absYaw <= 63.0F) || (absPitch >= 27.0F && absPitch <= 63.0F)) {
            return 1.87F;
        }
        if ((absYaw >= 22.0F && absYaw <= 68.0F) || (absPitch >= 22.0F && absPitch <= 68.0F)) {
            return 1.77F;
        }
        if ((absYaw >= 15.0F && absYaw <= 75.0F) || (absPitch >= 15.0F && absPitch <= 75.0F)) {
            return 1.7F;
        }
        if ((absYaw >= 13.0F && absYaw <= 77.0F) || (absPitch >= 13.0F && absPitch <= 77.0F)) {
            return 1.68F;
        }
        if ((absYaw >= 12.0F && absYaw <= 78.0F) || (absPitch >= 12.0F && absPitch <= 78.0F)) {
            return 1.68F;
        }
        if ((absYaw >= 8.0F && absYaw <= 82.0F) || (absPitch >= 11.0F && absPitch <= 79.0F)) {
            return 1.66F;
        }
        return (absYaw >= 5.0F && absYaw <= 85.0F) || (absPitch >= 8.0F && absPitch <= 82.0F) ? 1.63F : 1.621F;
    }

    private static float getSpeedYForPitch(float pitch) {
        float absPitch = Math.abs(pitch);

        if (absPitch >= 37.0F && absPitch <= 38.0F) {
            return 2.03F;
        }
        if (absPitch >= 20.0F && absPitch <= 37.0F) {
            return 2.06F;
        }
        if (absPitch >= 25.0F && absPitch <= 30.0F) {
            return 2.0F;
        }
        if (absPitch >= 35.0F && absPitch <= 45.0F) {
            return 1.99F;
        }
        if (absPitch >= 40.0F && absPitch <= 50.0F) {
            return 1.97F;
        }
        if (absPitch >= 50.0F && absPitch <= 60.0F) {
            return 1.96F;
        }
        if (absPitch >= 51.0F && absPitch <= 61.0F) {
            return 1.87F;
        }
        return absPitch >= 52.0F && absPitch <= 65.0F ? 1.7F : 1.59F;
    }
}
