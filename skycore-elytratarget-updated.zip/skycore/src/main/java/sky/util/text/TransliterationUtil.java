package sky.util.text;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import sky.access.MinecraftAccess;
import sky.util.combat.HealthUtil;

public final class TransliterationUtil implements MinecraftAccess {
    private static final Map<String, String> TRANSLIT_MAP = new LinkedHashMap<>();

    static {
        TRANSLIT_MAP.put("\uA500", Formatting.GRAY + "PLAYER");
        TRANSLIT_MAP.put("\uA504", Formatting.BLUE + "HERO");
        TRANSLIT_MAP.put("\uA508", Formatting.YELLOW + "TITAN");
        TRANSLIT_MAP.put("\uA512", Formatting.GREEN + "AVENGER");
        TRANSLIT_MAP.put("\uA516", Formatting.AQUA + "OVERLORD");
        TRANSLIT_MAP.put("\uA520", Formatting.GOLD + "MAGISTER");
        TRANSLIT_MAP.put("\uA524", Formatting.RED + "IMPERATOR");
        TRANSLIT_MAP.put("\uA528", Formatting.LIGHT_PURPLE + "DRAGON");
        TRANSLIT_MAP.put("\uA532", Formatting.DARK_PURPLE + "BULL");
        TRANSLIT_MAP.put("\uA536", Formatting.GOLD + "TIGER");
        TRANSLIT_MAP.put("\uA540", Formatting.DARK_GREEN + "HYDRA");
        TRANSLIT_MAP.put("\uA541", Formatting.GOLD + "LEGENDA");
        TRANSLIT_MAP.put("\uA544", Formatting.DARK_RED + "DRACULA");
        TRANSLIT_MAP.put("\uA545", Formatting.BLUE + "RAIN");
        TRANSLIT_MAP.put("\uA548", Formatting.GREEN + "COBRA");
        TRANSLIT_MAP.put("\uA549", Formatting.GREEN + "LIME");
        TRANSLIT_MAP.put("\uA552", Formatting.WHITE + "RABBIT");
        TRANSLIT_MAP.put("\uA553", Formatting.LIGHT_PURPLE + "SAKURA");
        TRANSLIT_MAP.put("\uA556", Formatting.BLACK + "BUNNY");
        TRANSLIT_MAP.put("\uA560", Formatting.YELLOW + "D.HELPER");
        TRANSLIT_MAP.put("\uA509", Formatting.YELLOW + "HELPER");
        TRANSLIT_MAP.put("\uA513", Formatting.BLUE + "ML.MODER");
        TRANSLIT_MAP.put("\uA517", Formatting.BLUE + "MODER");
        TRANSLIT_MAP.put("\uA521", Formatting.DARK_PURPLE + "MODER+");
        TRANSLIT_MAP.put("\uA529", Formatting.BLUE + "GL.MODER");
        TRANSLIT_MAP.put("\uA533", Formatting.AQUA + "ML.ADMIN");
        TRANSLIT_MAP.put("\uA537\uA538", Formatting.RED + "ADMIN");
        TRANSLIT_MAP.put("\uA537", Formatting.RED + "ADMIN");
        TRANSLIT_MAP.put("\uA505", Formatting.RED + "YT");
        TRANSLIT_MAP.put("\uA501", Formatting.LIGHT_PURPLE + "MEDIA");
    }

    private TransliterationUtil() {
    }

    public static Text translate(Text input) {
        if (input == null) {
            return Text.empty();
        }
        if (isServerForFix()) {
            String stripped = Formatting.strip(input.getString().replace("●", "").trim());
            if (stripped == null) {
                stripped = "";
            }
            return Text.literal(translate(stripped).trim()).setStyle(input.getStyle());
        }
        return translateRecursive(input);
    }

    private static Text translateRecursive(Text input) {
        MutableText result = Text.literal(translate(input.getString())).setStyle(input.getStyle());
        for (Text sibling : input.getSiblings()) {
            result.append(translateRecursive(sibling));
        }
        return result;
    }

    public static boolean isServerForFix() {
        return HealthUtil.isConnectedToServer("reallyworld")
                || HealthUtil.isConnectedToServer("playrw")
                || HealthUtil.isConnectedToServer("legendsgrief")
                || HealthUtil.isConnectedToServer("cakeworld");
    }

    public static String translate(String input) {
        if (input == null || input.isEmpty()) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        int index = 0;
        while (index < input.length()) {
            if (index + 1 < input.length()) {
                String pair = input.substring(index, index + 2);
                if (TRANSLIT_MAP.containsKey(pair)) {
                    result.append(TRANSLIT_MAP.get(pair));
                    index += 2;
                    continue;
                }
            }
            String character = input.substring(index, index + 1);
            result.append(TRANSLIT_MAP.getOrDefault(character, character));
            index++;
        }
        return result.toString();
    }
}
