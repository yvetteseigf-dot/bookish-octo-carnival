package sky.util.text;

import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import sky.access.MinecraftAccess;

public final class ChatNotifier implements MinecraftAccess {
    private ChatNotifier() {
    }

    public static void displayInfo(Object message) {
        send(Formatting.GRAY, message);
    }

    public static void displayError(Object message) {
        send(Formatting.RED, message);
    }

    private static void send(Formatting formatting, Object message) {
        if (mc.player == null) {
            return;
        }

        mc.player.sendMessage(Text.literal(String.valueOf(message)).formatted(formatting), false);
    }

    public static void displayWarning(Object message) {
        send(Formatting.YELLOW, message);
    }
}
