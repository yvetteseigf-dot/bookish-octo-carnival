package sky.util.text;

import net.minecraft.text.Text;

public final class CommandFeedback {
    private CommandFeedback() {
    }

    public static void displayInfo(String message) {
        ChatUtil.displayInfo(message);
    }

    public static void send(Text message) {
        ChatUtil.send(message);
    }
}
