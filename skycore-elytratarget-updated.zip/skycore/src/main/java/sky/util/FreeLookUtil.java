package sky.util;

import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import sky.camera.FreeLookCamera;
import sky.access.MinecraftAccess;

public final class FreeLookUtil implements MinecraftAccess {
    private FreeLookUtil() {
    }

    /** Unwraps {@code target} into the continuous rotation space of {@code current} so the player never spins the long way round. */
    public static float toContinuousYaw(float current, float target) {
        return current + MathHelper.wrapDegrees(target - current);
    }

    public static void snapToFreeLook() {
        if (mc.player == null) {
            return;
        }

        float pitch = FreeLookCamera.getFreePitch();
        float yaw = FreeLookCamera.getFreeYaw();

        if (mc.gameRenderer != null && mc.gameRenderer.getCamera() != null) {
            yaw = mc.gameRenderer.getCamera().getYaw();
            pitch = mc.gameRenderer.getCamera().getPitch();
            if (mc.options.getPerspective() == Perspective.THIRD_PERSON_FRONT) {
                yaw = MathHelper.wrapDegrees(yaw + 180.0F);
                pitch = -pitch;
            }
        }

        float continuousYaw = toContinuousYaw(mc.player.getYaw(), yaw);
        float clampedPitch = MathHelper.clamp(pitch, -90.0F, 90.0F);

        FreeLookCamera.setFreeYaw(continuousYaw);
        FreeLookCamera.setFreePitch(clampedPitch);

        mc.player.setYaw(continuousYaw);
        mc.player.setPitch(clampedPitch);
        mc.player.headYaw = continuousYaw;
        mc.player.bodyYaw = continuousYaw;
        mc.player.lastYaw = continuousYaw;
        mc.player.lastPitch = clampedPitch;
        mc.player.prevHeadYaw = continuousYaw;
        mc.player.prevBodyYaw = continuousYaw;
    }
}
