package sky.util.input;

import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public final class KeyNameUtil {
    private KeyNameUtil() {
    }

    public static String getKey(int keyCode) {
        if (keyCode < 0) {
            return "NONE";
        }

        String name = KeyCode.getKeyName(keyCode);
        if (name == null || name.isEmpty() || "NONE".equalsIgnoreCase(name)) {
            String glfwName = GLFW.glfwGetKeyName(keyCode, 0);
            return glfwName != null ? glfwName.toUpperCase() : "KEY" + keyCode;
        }
        return name;
    }

    /** Abbreviates a bind down to at most four characters so it fits inside compact HUD elements. */
    public static String toShortBind(int keyCode) {
        if (keyCode < 0) {
            return "";
        }

        try {
            InputUtil.Type type = keyCode < 8 ? InputUtil.Type.MOUSE : InputUtil.Type.KEYSYM;
            String label = type.createFromCode(keyCode).getTranslationKey()
                .replace("key.keyboard.", "")
                .replace("key.mouse.", "M")
                .replace("MOUSE", "M")
                .replace("CONTROL", "C")
                .replace("LEFT", "L")
                .replace("RIGHT", "R")
                .replace("_", "");

            if (label.equals("semicolon")) {
                label = ";";
            }
            if (label.equals("apostrophe")) {
                label = "'";
            }
            if (label.equals("3")) {
                label = "M3";
            }
            if (label.equals("4")) {
                label = "M4";
            }
            if (label.length() > 4) {
                label = label.substring(0, 4);
            }
            return label.toUpperCase();
        } catch (Exception exception) {
            return getKey(keyCode);
        }
    }
}
