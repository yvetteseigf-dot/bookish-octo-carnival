package sky.hud;

/**
 * Screen placement and size of the timer HUD panel.
 */
public final class TimerHudPosition {
    private static final float DEFAULT_WIDTH = 110.0f;
    private static final float DEFAULT_HEIGHT = 18.0f;

    private float x;
    private float y;
    private float width = DEFAULT_WIDTH;
    private float height = DEFAULT_HEIGHT;
    private boolean initialized;

    public void ensureInitialized(float screenWidth, float screenHeight) {
        if (!initialized) {
            x = (screenWidth - width) / 2.0f;
            y = screenHeight - height - 54.0f;
            initialized = true;
        }
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0f, width);
        this.height = Math.max(DEFAULT_HEIGHT, height);
    }

    public boolean contains(float renderX, float renderY) {
        return renderX >= x && renderX <= x + width && renderY >= y && renderY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
