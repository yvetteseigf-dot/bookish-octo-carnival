package sky.hud;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Formatting;
import sky.theme.GuiTheme;
import sky.access.MinecraftAccess;
import sky.social.StaffManager;
import sky.social.StaffPlayer;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;
import sky.util.text.TransliterationUtil;
import sky.social.Staff;

/**
 * HUD panel listing the staff members currently detected on the server, with their rank prefix
 * and a status word coloured by how close they are to the player.
 */
public final class StaffListHud implements MinecraftAccess {

    private static final String TITLE = "Staff online";
    private static final String STAFF_ICON = "d";

    private final FadeAnimation globalFade = new FadeAnimation();
    private final Map<String, FadeAnimation> rowFades = new HashMap<>();

    private float animatedWidth = 70.0f;
    private float animatedStatusColumn = 0.0f;
    private float targetWidth = 70.0f;
    private float targetStatusColumn = 0.0f;
    private float layoutWidthFrom = 70.0f;
    private float layoutStatusFrom = 0.0f;
    private long layoutAnimStartMs;
    private boolean layoutAnimating;

    public void tick() {
        if (!Interface.INSTANCE.isStaffListEnabled()) {
            return;
        }

        List<StaffPlayer> staff = StaffManager.getInstance().getStaff();

        boolean hasStaff = !staff.isEmpty();
        boolean visible = hasStaff || ChatScreenDetector.isActive();
        if (visible) {
            if (!globalFade.isOpen()) {
                globalFade.fadeIn(250L);
            }
        } else if (globalFade.isVisible()) {
            globalFade.fadeOut(250L);
        }
        globalFade.update();

        for (StaffPlayer member : staff) {
            FadeAnimation fade = rowFades.computeIfAbsent(member.getName(), ignored -> new FadeAnimation());
            if (!fade.isOpen()) {
                fade.fadeIn(250L);
            }
            fade.update();
        }

        for (String key : List.copyOf(rowFades.keySet())) {
            boolean stillOnline = staff.stream().anyMatch(member -> member.getName().equals(key));
            FadeAnimation fade = rowFades.get(key);
            if (!stillOnline && fade != null && fade.isVisible()) {
                fade.fadeOut(250L);
                fade.update();
            }
        }
    }

    public void render(MatrixStack matrices, float screenWidth) {
        if (!Interface.INSTANCE.isStaffListEnabled()) {
            return;
        }

        globalFade.update();
        if (!globalFade.isVisible()) {
            return;
        }

        float alpha = globalFade.getAlpha();
        if (alpha <= 0.01f) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null || matrices == null) {
            return;
        }

        FontRenderer titleFont = FontRegistry.getKrisaMedium(13);
        FontRenderer rowFont = FontRegistry.getKrisaMedium(13);
        FontRenderer iconFont = FontRegistry.getSkycore(12);
        if (titleFont == null || rowFont == null) {
            return;
        }
        if (iconFont == null) {
            iconFont = rowFont;
        }

        List<StaffPlayer> staff = StaffManager.getInstance().getStaff();

        float statusColumn = 0.0f;
        float panelWidth = 92.0f;
        for (StaffPlayer member : staff) {
            FadeAnimation fade = rowFades.get(member.getName());
            float rowAlpha = fade == null ? 0.0f : fade.getAlpha();
            if (!shouldRenderRow(rowAlpha)) {
                continue;
            }

            String statusText = getStatusText(member);
            statusColumn = Math.max(statusColumn, rowFont.getWidth(statusText));

            float prefixWidth = rowFont.getWidth(getPrefixPlain(member));
            float nameWidth = rowFont.getWidth(member.getName());
            float rowWidth = 5.0f + prefixWidth + nameWidth + 8.0f + rowFont.getWidth(statusText) + 16.0f;
            panelWidth = Math.max(panelWidth, rowWidth);
        }

        startLayoutAnimation(panelWidth, statusColumn);
        updateLayoutAnimation();

        float width = animatedWidth;
        float height = 23.0f;
        for (StaffPlayer member : staff) {
            FadeAnimation fade = rowFades.get(member.getName());
            float rowAlpha = fade == null ? 0.0f : fade.getAlpha();
            if (shouldRenderRow(rowAlpha)) {
                height += 9.0f * rowAlpha;
            }
        }

        StaffListHudPosition position = HudEditor.getInstance().getStaffList();
        position.setSize(width, height);
        position.ensureInitialized(screenWidth);

        float x = position.getX();
        float y = position.getY();
        GuiTheme theme = GuiTheme.theme;

        HudPanelRenderer.drawBackground(renderer, x, y, width, height, 13.0f,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha), alpha, matrices);

        float iconWidth = iconFont.getWidth(STAFF_ICON);
        iconFont.draw(STAFF_ICON, x + width - 5.0f - iconWidth, y + 5.5f,
                ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
        titleFont.draw(TITLE, x + 6.0f, y + 4.5f, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        HudPanelRenderer.drawHeaderSeparator(renderer, matrices, x, y + 15.0f, width, alpha, theme);

        float rowY = y + 18.0f;
        for (StaffPlayer member : staff) {
            FadeAnimation fade = rowFades.get(member.getName());
            if (fade == null) {
                continue;
            }

            float rowAlpha = fade.getAlpha();
            if (!shouldRenderRow(rowAlpha)) {
                continue;
            }
            if (rowAlpha <= 0.01f) {
                continue;
            }

            fade.update();

            float rowFadeAlpha = rowAlpha * alpha;
            float rowTop = rowY + 1.0f;
            float textY = rowTop + (9.0f - rowFont.getLineHeight(member.getName())) / 2.0f;
            float textX = x + 6.0f;

            String prefix = getPrefixPlain(member);
            if (!prefix.isEmpty()) {
                rowFont.drawText(matrices, TransliterationUtil.translate(member.getPrefix()), textX, textY + 1.5f,
                        ColorUtil.withAlpha(Color.WHITE, rowFadeAlpha));
                textX += rowFont.getWidth(prefix);
            }

            rowFont.draw(member.getName(), textX, textY,
                    ColorUtil.withAlpha(theme.getText(), rowFadeAlpha), matrices);

            String statusText = getStatusText(member);
            float statusX = x + width - 5.0f - rowFont.getWidth(statusText) - 1.0f;
            rowFont.draw(statusText, statusX, textY,
                    ColorUtil.withAlpha(resolveStateColor(member), rowFadeAlpha), matrices);

            rowY += 9.0f * rowAlpha;
        }

        cleanupRowAnimations(staff);
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    private boolean shouldRenderRow(float rowAlpha) {
        if (ChatScreenDetector.isActive()) {
            return true;
        }
        return rowAlpha > 0.01f;
    }

    private String getStatusText(StaffPlayer member) {
        return member.isVanished() ? "[V]" : "[Online]";
    }

    private String getPrefixPlain(StaffPlayer member) {
        String stripped = Formatting.strip(TransliterationUtil.translate(member.getPrefix()).getString());
        return stripped == null ? "" : stripped;
    }

    /**
     * Red while vanished, amber once the member is rendered within 100 blocks, green otherwise.
     */
    private Color resolveStateColor(StaffPlayer member) {
        if (member.isVanished()) {
            return new Color(255, 70, 70);
        }

        if (mc.world == null || mc.player == null) {
            return new Color(76, 235, 120);
        }

        AbstractClientPlayerEntity match = null;
        for (AbstractClientPlayerEntity player : mc.world.getPlayers()) {
            if (player.getName().getString().equals(member.getName())) {
                match = player;
                break;
            }
        }

        if (match != null && mc.player.distanceTo(match) <= 100.0) {
            return new Color(255, 205, 74);
        }
        return new Color(76, 235, 120);
    }

    private void cleanupRowAnimations(List<StaffPlayer> activeStaff) {
        Iterator<Map.Entry<String, FadeAnimation>> iterator = rowFades.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, FadeAnimation> entry = iterator.next();
            if (entry.getValue().isVisible()) {
                continue;
            }

            boolean stillOnline = activeStaff.stream()
                    .anyMatch(staff -> staff.getName().equals(entry.getKey()));
            if (!stillOnline) {
                iterator.remove();
            }
        }
    }

    private void startLayoutAnimation(float width, float statusColumn) {
        if (Math.abs(width - targetWidth) < 0.5f && Math.abs(statusColumn - targetStatusColumn) < 0.5f) {
            return;
        }

        layoutWidthFrom = animatedWidth;
        layoutStatusFrom = animatedStatusColumn;
        targetWidth = width;
        targetStatusColumn = statusColumn;
        layoutAnimStartMs = System.currentTimeMillis();
        layoutAnimating = true;
    }

    private void updateLayoutAnimation() {
        if (!layoutAnimating) {
            return;
        }

        float progress = getSmoothProgress(layoutAnimStartMs);
        animatedWidth = layoutWidthFrom + (targetWidth - layoutWidthFrom) * progress;
        animatedStatusColumn = layoutStatusFrom + (targetStatusColumn - layoutStatusFrom) * progress;

        if (progress >= 1.0f) {
            animatedWidth = targetWidth;
            animatedStatusColumn = targetStatusColumn;
            layoutAnimating = false;
        }
    }

    private float getSmoothProgress(long startMs) {
        float elapsed = System.currentTimeMillis() - startMs;
        float linear = Math.min(1.0f, Math.max(0.0f, elapsed / 250.0f));
        float eased = linear * linear * (3.0f - 2.0f * linear);
        return eased * eased * (3.0f - 2.0f * eased);
    }
}
