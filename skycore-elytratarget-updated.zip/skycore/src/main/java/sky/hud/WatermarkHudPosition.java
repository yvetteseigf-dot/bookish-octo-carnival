package sky.hud;

/**
 * Screen placement and size of the watermark HUD panel.
 */
public final class WatermarkHudPosition {
    private static final float DEFAULT_WIDTH = 180.0f;
    private static final float DEFAULT_HEIGHT = 19.0f;

    private float width = DEFAULT_WIDTH;
    private float height = DEFAULT_HEIGHT;
    private float x;
    private float y = 7.0f;
    private boolean initialized;

    public void ensureInitialized(float screenWidth) {
        if (!initialized) {
            x = (screenWidth - width) / 2.0f;
            initialized = true;
        }
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setWidth(float width) {
        this.width = Math.max(48.0f, width);
    }

    public void setHeight(float height) {
        this.height = Math.max(DEFAULT_HEIGHT, height);
    }

    public boolean contains(float pointX, float pointY) {
        return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
