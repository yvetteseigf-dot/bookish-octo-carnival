package sky.hud;

/**
 * Placement and bounds of the staff list HUD panel, as edited by the HUD editor.
 */
public final class StaffListHudPosition {

    private float width = 70.0f;
    private float height = 22.0f;
    private float x = 223.5f;
    private float y = 50.0f;
    private boolean initialized;

    /**
     * Pulls the panel back on screen once if the saved default would overflow the right edge.
     */
    public void ensureInitialized(float screenWidth) {
        if (!initialized) {
            x = Math.min(x, Math.max(70.0f, screenWidth - width));
            initialized = true;
        }
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0f, width);
        this.height = Math.max(22.0f, height);
    }

    public boolean contains(float renderX, float renderY) {
        return renderX >= x && renderX <= x + width && renderY >= y && renderY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
