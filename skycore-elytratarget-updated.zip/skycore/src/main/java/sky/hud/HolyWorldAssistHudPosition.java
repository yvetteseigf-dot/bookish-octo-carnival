package sky.hud;

/**
 * Draggable placement and measured size of the HolyWorld assist HUD panel.
 */
public final class HolyWorldAssistHudPosition {
    private float x = 6.0f;
    private float y = 120.0f;
    private float width = 70.0f;
    private float height = 22.0f;
    private boolean initialized;

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0f, width);
        this.height = Math.max(22.0f, height);
    }

    public void ensureInitialized(float scale) {
        if (!initialized) {
            x = 6.0f;
            y = 120.0f;
            initialized = true;
        }
    }

    public boolean contains(float pointX, float pointY) {
        return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
