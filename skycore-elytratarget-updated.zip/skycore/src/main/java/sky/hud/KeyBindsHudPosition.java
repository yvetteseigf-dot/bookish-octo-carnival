package sky.hud;

/**
 * Placement and bounds of the key binds HUD panel, as edited by the HUD editor.
 */
public final class KeyBindsHudPosition {

    private float x = 6.0F;
    private float y = 36.0F;
    private float width = 70.0F;
    private float height = 22.0F;
    private boolean initialized;

    /**
     * Applies the default placement once, unless a position has already been set.
     */
    public void ensureInitialized(float renderWidth) {
        if (initialized) {
            return;
        }

        x = 6.0F;
        y = 36.0F;
        initialized = true;
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0F, width);
        this.height = Math.max(22.0F, height);
    }

    public boolean contains(float pointX, float pointY) {
        return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
