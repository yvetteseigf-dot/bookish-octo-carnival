package sky.hud;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.Registries;

import sky.theme.GuiTheme;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;

/**
 * Panel listing the local player's active status effects. Rows fade in and out individually
 * and the panel width is animated so the list does not snap while effects come and go.
 */
public final class PotionEffectsHud {
    private static final String TITLE = "Potions";
    private static final String POTION_ICON = "e";

    private final FadeAnimation globalFade = new FadeAnimation();
    private final Map<String, FadeAnimation> rowFades = new HashMap<>();
    private final Map<String, StatusEffectInstance> effectSnapshots = new HashMap<>();

    private float animatedWidth = 70.0f;
    private float targetWidth = 70.0f;
    private float layoutWidthFrom = 70.0f;
    private long layoutAnimStartMs;
    private boolean layoutAnimating;

    public void tick() {
        if (!Interface.INSTANCE.isPotionsEnabled()) {
            return;
        }

        List<StatusEffectInstance> activeEffects = collectActiveEffects();
        for (StatusEffectInstance instance : activeEffects) {
            String key = getEffectKey(instance);
            effectSnapshots.put(key, instance);

            FadeAnimation fade = rowFades.computeIfAbsent(key, ignored -> new FadeAnimation());
            if (!fade.isOpen()) {
                fade.fadeIn(250L);
            }

            fade.update();
        }

        for (String key : List.copyOf(rowFades.keySet())) {
            boolean stillActive = activeEffects.stream().anyMatch(effect -> getEffectKey(effect).equals(key));
            FadeAnimation fade = rowFades.get(key);
            if (!stillActive && fade != null && fade.isVisible()) {
                fade.fadeOut(250L);
                fade.update();
            }
        }

        boolean hasActiveEffects = !activeEffects.isEmpty();
        boolean shouldShow = hasActiveEffects || ChatScreenDetector.isActive() || hasVisibleRows();
        if (shouldShow) {
            if (!globalFade.isOpen()) {
                globalFade.fadeIn(250L);
            }
        } else if (globalFade.isVisible()) {
            globalFade.fadeOut(250L);
        }

        globalFade.update();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public void render(MatrixStack matrices, float screenWidth) {
        if (!Interface.INSTANCE.isPotionsEnabled()) {
            return;
        }

        globalFade.update();
        if (!globalFade.isVisible()) {
            return;
        }

        float alpha = globalFade.getAlpha();
        if (alpha <= 0.01f) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null || matrices == null) {
            return;
        }

        FontRenderer titleFont = FontRegistry.getKrisaMedium(13);
        FontRenderer rowFont = FontRegistry.getKrisaMedium(13);
        FontRenderer iconFont = FontRegistry.getSkycore(12);
        if (titleFont == null || rowFont == null) {
            return;
        }

        if (iconFont == null) {
            iconFont = rowFont;
        }

        List<StatusEffectInstance> activeEffects = collectActiveEffects();
        for (StatusEffectInstance instance : activeEffects) {
            effectSnapshots.put(getEffectKey(instance), instance);
        }

        List<StatusEffectInstance> visibleEffects = collectVisibleEffects(activeEffects);
        boolean showPreview = visibleEffects.isEmpty() && ChatScreenDetector.isActive();

        float width = 72.5f;
        for (StatusEffectInstance instance : visibleEffects) {
            FadeAnimation fade = rowFades.get(getEffectKey(instance));
            float rowAlpha = fade == null ? 0.0f : fade.getAlpha();
            if (!shouldRenderRow(rowAlpha)) {
                continue;
            }

            String durationText = getDurationText(instance);
            float rowWidth = 5.0f + rowFont.getWidth(getRowLabel(instance)) + 18.0f
                    + rowFont.getWidth(durationText) + 5.0f;
            width = Math.max(width, rowWidth);
        }

        if (showPreview) {
            StatusEffect previewEffect = getPreviewEffect();
            String previewLabel = getRowLabel(previewEffect, 0);
            float previewWidth = 5.0f + rowFont.getWidth(previewLabel) + 18.0f + rowFont.getWidth("1:20") + 5.0f;
            width = Math.max(width, previewWidth);
        }

        startLayoutAnimation(width);
        updateLayoutAnimation();

        float panelWidth = animatedWidth;
        float panelHeight = 23.0f;
        if (showPreview) {
            panelHeight = 23.0f + 9.0f;
        } else {
            for (StatusEffectInstance instance : visibleEffects) {
                FadeAnimation fade = rowFades.get(getEffectKey(instance));
                float rowAlpha = fade == null ? 0.0f : fade.getAlpha();
                if (shouldRenderRow(rowAlpha)) {
                    panelHeight += 9.0f * rowAlpha;
                }
            }
        }

        PotionsHudPosition position = HudEditor.getInstance().getPotions();
        position.setSize(panelWidth, panelHeight);
        position.ensureInitialized(screenWidth);

        float x = position.getX();
        float y = position.getY();
        GuiTheme theme = GuiTheme.theme;

        HudPanelRenderer.drawBackground(renderer, x, y, panelWidth, panelHeight, 13.0f,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha),
                alpha, matrices);

        float iconWidth = iconFont.getWidth(POTION_ICON);
        iconFont.draw(POTION_ICON, x + panelWidth - 5.0f - iconWidth, y + 5.5f,
                ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);

        titleFont.draw(TITLE, Math.round(x + 6.0f), Math.round(y + 4.5f),
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);

        HudPanelRenderer.drawHeaderSeparator(renderer, matrices, x, y + 15.0f, panelWidth, alpha, theme);

        float rowY = y + 18.0f;
        for (StatusEffectInstance instance : visibleEffects) {
            FadeAnimation fade = rowFades.get(getEffectKey(instance));
            if (fade == null) {
                continue;
            }

            float rowAlpha = fade.getAlpha();
            if (!shouldRenderRow(rowAlpha)) {
                continue;
            }

            if (rowAlpha <= 0.01f) {
                continue;
            }

            fade.update();

            float rowFadeAlpha = rowAlpha * alpha;
            float rowTop = rowY + 1.0f;
            String label = getRowLabel(instance);
            String durationText = getDurationText(instance);
            float textY = Math.round(rowTop + (9.0f - rowFont.getLineHeight(label)) / 2.0f);

            rowFont.draw(label, Math.round(x + 6.0f), textY,
                    ColorUtil.withAlpha(theme.getText(), rowFadeAlpha), matrices);

            float durationX = x + panelWidth - 5.0f - rowFont.getWidth(durationText) - 1.0f;
            rowFont.draw(durationText, Math.round(durationX), textY,
                    ColorUtil.withAlpha(theme.getAccent(), rowFadeAlpha), matrices);

            rowY += 9.0f * rowAlpha;
        }

        if (showPreview) {
            StatusEffect previewEffect = getPreviewEffect();
            String previewLabel = getRowLabel(previewEffect, 0);
            float textY = Math.round(rowY + 1.0f + (9.0f - rowFont.getLineHeight(previewLabel)) / 2.0f);

            rowFont.draw(previewLabel, Math.round(x + 6.0f), textY,
                    ColorUtil.withAlpha(theme.getText(), alpha), matrices);
            rowFont.draw("1:20", Math.round(x + panelWidth - 5.0f - rowFont.getWidth("1:20") - 1.0f), textY,
                    ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
        }

        cleanupRowAnimations(activeEffects);
    }

    private List<StatusEffectInstance> collectActiveEffects() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return List.of();
        }

        List<StatusEffectInstance> effects = new ArrayList<>();
        for (StatusEffectInstance instance : client.player.getStatusEffects()) {
            if (!Interface.INSTANCE.showHarmfulPotions.get()
                    && instance.getEffectType().value().getCategory() == StatusEffectCategory.HARMFUL) {
                continue;
            }

            effects.add(instance);
        }

        effects.sort(Comparator.comparing(this::getEffectName));
        return effects;
    }

    private List<StatusEffectInstance> collectVisibleEffects(List<StatusEffectInstance> activeEffects) {
        List<StatusEffectInstance> visible = new ArrayList<>(activeEffects);

        for (Map.Entry<String, FadeAnimation> entry : rowFades.entrySet()) {
            boolean stillActive = activeEffects.stream()
                    .anyMatch(effect -> getEffectKey(effect).equals(entry.getKey()));
            if (stillActive) {
                continue;
            }

            if (!entry.getValue().isVisible()) {
                continue;
            }

            StatusEffectInstance snapshot = effectSnapshots.get(entry.getKey());
            if (snapshot != null) {
                visible.add(snapshot);
            }
        }

        visible.sort(Comparator.comparing(this::getEffectName));
        return visible;
    }

    private void cleanupRowAnimations(List<StatusEffectInstance> activeEffects) {
        Iterator<Map.Entry<String, FadeAnimation>> iterator = rowFades.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, FadeAnimation> entry = iterator.next();
            if (entry.getValue().isVisible()) {
                continue;
            }

            boolean stillActive = activeEffects.stream()
                    .anyMatch(effect -> getEffectKey(effect).equals(entry.getKey()));
            if (stillActive) {
                continue;
            }

            effectSnapshots.remove(entry.getKey());
            iterator.remove();
        }
    }

    private boolean hasVisibleRows() {
        for (FadeAnimation fade : rowFades.values()) {
            if (fade.isVisible()) {
                return true;
            }
        }

        return false;
    }

    private boolean shouldRenderRow(float rowAlpha) {
        return rowAlpha > 0.01f;
    }

    private void startLayoutAnimation(float width) {
        if (Math.abs(width - targetWidth) < 0.5f) {
            return;
        }

        layoutWidthFrom = animatedWidth;
        targetWidth = width;
        layoutAnimStartMs = System.currentTimeMillis();
        layoutAnimating = true;
    }

    private void updateLayoutAnimation() {
        if (!layoutAnimating) {
            return;
        }

        float progress = getSmoothProgress(layoutAnimStartMs);
        animatedWidth = layoutWidthFrom + (targetWidth - layoutWidthFrom) * progress;
        if (progress >= 1.0f) {
            animatedWidth = targetWidth;
            layoutAnimating = false;
        }
    }

    private float getSmoothProgress(long startMs) {
        float elapsed = System.currentTimeMillis() - startMs;
        float progress = Math.min(1.0f, Math.max(0.0f, elapsed / 250.0f));
        float smoothed = progress * progress * (3.0f - 2.0f * progress);
        return smoothed * smoothed * (3.0f - 2.0f * smoothed);
    }

    private StatusEffect getPreviewEffect() {
        List<StatusEffect> effects = Registries.STATUS_EFFECT.stream().toList();
        if (effects.isEmpty()) {
            return StatusEffects.SPEED.value();
        }

        int index = (int) (System.currentTimeMillis() / 1200L % effects.size());
        return effects.get(index);
    }

    private String getEffectKey(StatusEffectInstance instance) {
        return instance.getEffectType().getIdAsString();
    }

    private String getEffectName(StatusEffectInstance instance) {
        return instance.getEffectType().value().getName().getString();
    }

    private String getRowLabel(StatusEffectInstance instance) {
        return getRowLabel(instance.getEffectType().value(), instance.getAmplifier());
    }

    private String getRowLabel(StatusEffect effect, int amplifier) {
        String name = effect.getName().getString();
        if (amplifier <= 0) {
            return name;
        }

        return name + " " + (amplifier + 1);
    }

    private String getDurationText(StatusEffectInstance instance) {
        if (instance.getDuration() > 655340) {
            return "**:**";
        }

        return StatusEffectUtil.getDurationText(instance, 1.0f, 20.0f).getString();
    }
}
