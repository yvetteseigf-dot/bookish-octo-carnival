package sky.hud;

import com.google.gson.JsonObject;
import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import sky.SkyInit;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.HudScaleUtil;

/**
 * Drag-and-drop layout editor for the HUD panels, active while the chat screen is open.
 * <p>
 * Holds the placement of every movable panel and persists it through the client config.
 * Dragging snaps a panel to the screen centre unless CTRL is held.
 */
public final class HudEditor {

    private static final float SNAP_DISTANCE = 10.0F;
    private static final float SCREEN_PADDING = 0.0F;
    private static final float GRID_LINE_SIZE = 1.0F;
    private static final float HINT_OFFSET_ABOVE_CENTER = 200.0F;
    private static final int HINT_FONT_SIZE = 18;
    private static final String HINT_TEXT = "CTRL — free move";
    private static final long FADE_DURATION_MS = 250L;

    private static final HudEditor INSTANCE = new HudEditor();

    private final WatermarkHudPosition watermark = new WatermarkHudPosition();
    private final TargetHudPosition targetHud = new TargetHudPosition();
    private final NotificationsHudPosition notifications = new NotificationsHudPosition();
    private final KeyBindsHudPosition keyBinds = new KeyBindsHudPosition();
    private final HolyWorldAssistHudPosition holyWorldAssist = new HolyWorldAssistHudPosition();
    private final CooldownHudPosition cooldowns = new CooldownHudPosition();
    private final PotionsHudPosition potions = new PotionsHudPosition();
    private final StaffListHudPosition staffList = new StaffListHudPosition();
    private final MediaPlayerHudPosition mediaPlayer = new MediaPlayerHudPosition();
    private final TimerHudPosition timerHud = new TimerHudPosition();

    private DragElement dragElement = DragElement.NONE;
    private float dragOffsetX;
    private float dragOffsetY;

    private HudEditor() {
    }

    public static HudEditor getInstance() {
        return INSTANCE;
    }

    public WatermarkHudPosition getWatermark() {
        return watermark;
    }

    public TargetHudPosition getTargetHud() {
        return targetHud;
    }

    public NotificationsHudPosition getNotifications() {
        return notifications;
    }

    public KeyBindsHudPosition getKeyBinds() {
        return keyBinds;
    }

    public HolyWorldAssistHudPosition getHolyWorldAssist() {
        return holyWorldAssist;
    }

    public CooldownHudPosition getCooldowns() {
        return cooldowns;
    }

    public PotionsHudPosition getPotions() {
        return potions;
    }

    public StaffListHudPosition getStaffList() {
        return staffList;
    }

    public MediaPlayerHudPosition getMediaPlayer() {
        return mediaPlayer;
    }

    public TimerHudPosition getTimerHud() {
        return timerHud;
    }

    public JsonObject savePositions() {
        JsonObject root = new JsonObject();

        JsonObject watermarkJson = new JsonObject();
        watermarkJson.addProperty("x", watermark.getX());
        watermarkJson.addProperty("y", watermark.getY());
        root.add("watermark", watermarkJson);

        JsonObject targetHudJson = new JsonObject();
        targetHudJson.addProperty("x", targetHud.getX());
        targetHudJson.addProperty("y", targetHud.getY());
        root.add("targetHud", targetHudJson);

        JsonObject notificationsJson = new JsonObject();
        notificationsJson.addProperty("y", notifications.getY());
        root.add("notifications", notificationsJson);

        JsonObject keyBindsJson = new JsonObject();
        keyBindsJson.addProperty("x", keyBinds.getX());
        keyBindsJson.addProperty("y", keyBinds.getY());
        root.add("keyBinds", keyBindsJson);

        JsonObject holyWorldAssistJson = new JsonObject();
        holyWorldAssistJson.addProperty("x", holyWorldAssist.getX());
        holyWorldAssistJson.addProperty("y", holyWorldAssist.getY());
        root.add("holyWorldAssist", holyWorldAssistJson);

        JsonObject cooldownsJson = new JsonObject();
        cooldownsJson.addProperty("x", cooldowns.getX());
        cooldownsJson.addProperty("y", cooldowns.getY());
        root.add("cooldowns", cooldownsJson);

        JsonObject potionsJson = new JsonObject();
        potionsJson.addProperty("x", potions.getX());
        potionsJson.addProperty("y", potions.getY());
        root.add("potions", potionsJson);

        JsonObject staffListJson = new JsonObject();
        staffListJson.addProperty("x", staffList.getX());
        staffListJson.addProperty("y", staffList.getY());
        root.add("staffList", staffListJson);

        JsonObject mediaPlayerJson = new JsonObject();
        mediaPlayerJson.addProperty("x", mediaPlayer.getX());
        mediaPlayerJson.addProperty("y", mediaPlayer.getY());
        root.add("mediaPlayer", mediaPlayerJson);

        JsonObject timerHudJson = new JsonObject();
        timerHudJson.addProperty("x", timerHud.getX());
        timerHudJson.addProperty("y", timerHud.getY());
        root.add("timerHud", timerHudJson);

        return root;
    }

    public void loadPositions(JsonObject hud) {
        if (hud.has("watermark")) {
            JsonObject section = hud.getAsJsonObject("watermark");
            if (section.has("x") && section.has("y")) {
                watermark.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("targetHud")) {
            JsonObject section = hud.getAsJsonObject("targetHud");
            if (section.has("x") && section.has("y")) {
                targetHud.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("notifications")) {
            JsonObject section = hud.getAsJsonObject("notifications");
            if (section.has("y")) {
                notifications.loadAnchorY(section.get("y").getAsFloat());
            }
        }

        if (hud.has("keyBinds")) {
            JsonObject section = hud.getAsJsonObject("keyBinds");
            if (section.has("x") && section.has("y")) {
                keyBinds.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("holyWorldAssist")) {
            JsonObject section = hud.getAsJsonObject("holyWorldAssist");
            if (section.has("x") && section.has("y")) {
                holyWorldAssist.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("cooldowns")) {
            JsonObject section = hud.getAsJsonObject("cooldowns");
            if (section.has("x") && section.has("y")) {
                cooldowns.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("potions")) {
            JsonObject section = hud.getAsJsonObject("potions");
            if (section.has("x") && section.has("y")) {
                potions.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("staffList")) {
            JsonObject section = hud.getAsJsonObject("staffList");
            if (section.has("x") && section.has("y")) {
                staffList.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("mediaPlayer")) {
            JsonObject section = hud.getAsJsonObject("mediaPlayer");
            if (section.has("x") && section.has("y")) {
                mediaPlayer.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }

        if (hud.has("timerHud")) {
            JsonObject section = hud.getAsJsonObject("timerHud");
            if (section.has("x") && section.has("y")) {
                timerHud.setPosition(section.get("x").getAsFloat(), section.get("y").getAsFloat());
            }
        }
    }

    public boolean isDragging() {
        return dragElement != DragElement.NONE;
    }

    public boolean tryStartDrag() {
        if (!ChatScreenDetector.isActive()) {
            return false;
        }

        float renderWidth = HudScaleUtil.getRenderWidth();
        float renderHeight = HudScaleUtil.getRenderHeight();
        double[] mouse = HudScaleUtil.getScaledMouse();
        float hudX = HudScaleUtil.toHudX(mouse[0]);
        float hudY = HudScaleUtil.toHudY(mouse[1]);

        targetHud.ensureInitialized(renderWidth, renderHeight);
        if (targetHud.contains(hudX, hudY)) {
            dragElement = DragElement.TARGET_HUD;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - targetHud.getX();
            dragOffsetY = hudY - targetHud.getY();
            return true;
        }

        watermark.ensureInitialized(renderWidth);
        if (watermark.contains(hudX, hudY)) {
            dragElement = DragElement.WATERMARK;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - watermark.getX();
            dragOffsetY = hudY - watermark.getY();
            return true;
        }

        notifications.ensureInitialized(renderWidth, renderHeight);
        if (notifications.contains(hudX, hudY)) {
            dragElement = DragElement.NOTIFICATIONS;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = 0.0F;
            dragOffsetY = hudY - notifications.getY();
            return true;
        }

        keyBinds.ensureInitialized(renderWidth);
        if (keyBinds.contains(hudX, hudY)) {
            dragElement = DragElement.KEY_BINDS;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - keyBinds.getX();
            dragOffsetY = hudY - keyBinds.getY();
            return true;
        }

        holyWorldAssist.ensureInitialized(renderWidth);
        if (holyWorldAssist.contains(hudX, hudY)) {
            dragElement = DragElement.HOLY_WORLD_ASSIST;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - holyWorldAssist.getX();
            dragOffsetY = hudY - holyWorldAssist.getY();
            return true;
        }

        cooldowns.ensureInitialized(renderWidth);
        if (cooldowns.contains(hudX, hudY)) {
            dragElement = DragElement.COOLDOWNS;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - cooldowns.getX();
            dragOffsetY = hudY - cooldowns.getY();
            return true;
        }

        potions.ensureInitialized(renderWidth);
        if (potions.contains(hudX, hudY)) {
            dragElement = DragElement.POTIONS;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - potions.getX();
            dragOffsetY = hudY - potions.getY();
            return true;
        }

        staffList.ensureInitialized(renderWidth);
        if (staffList.contains(hudX, hudY)) {
            dragElement = DragElement.STAFF_LIST;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - staffList.getX();
            dragOffsetY = hudY - staffList.getY();
            return true;
        }

        mediaPlayer.ensureInitialized(renderWidth, renderHeight);
        if (mediaPlayer.contains(hudX, hudY)) {
            dragElement = DragElement.MEDIA_PLAYER;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - mediaPlayer.getX();
            dragOffsetY = hudY - mediaPlayer.getY();
            return true;
        }

        timerHud.ensureInitialized(renderWidth, renderHeight);
        if (timerHud.contains(hudX, hudY)) {
            dragElement = DragElement.TIMER_HUD;
            HudEditorAnimations.DRAG_GRID.fadeIn(FADE_DURATION_MS);
            dragOffsetX = hudX - timerHud.getX();
            dragOffsetY = hudY - timerHud.getY();
            return true;
        }

        return false;
    }

    public void updateDragPosition() {
        if (dragElement == DragElement.NONE || !ChatScreenDetector.isActive()) {
            return;
        }

        double[] mouse = HudScaleUtil.getScaledMouse();
        applyPosition(mouse[0], mouse[1]);
    }

    public void stopDragging() {
        if (dragElement == DragElement.NONE) {
            return;
        }

        dragElement = DragElement.NONE;
        HudEditorAnimations.DRAG_GRID.fadeOut(FADE_DURATION_MS);
        SkyInit.getInstance().getClientConfig().saveCurrentSettings();
    }

    public void onMouseButton(int button, int action) {
        if (!ChatScreenDetector.isActive()) {
            if (isDragging()) {
                stopDragging();
            }
            return;
        }

        if (button == 0 && action == 0) {
            stopDragging();
        }
    }

    public boolean isOverWatermark() {
        if (!ChatScreenDetector.isActive()) {
            return false;
        }

        float renderWidth = HudScaleUtil.getRenderWidth();
        watermark.ensureInitialized(renderWidth);

        double[] mouse = HudScaleUtil.getScaledMouse();
        return watermark.contains(HudScaleUtil.toHudX(mouse[0]), HudScaleUtil.toHudY(mouse[1]));
    }

    public void tickAnimations() {
        boolean chatActive = ChatScreenDetector.isActive();
        if (chatActive) {
            HudEditorAnimations.LAYOUT_HINT.fadeIn(FADE_DURATION_MS);
        } else if (HudEditorAnimations.LAYOUT_HINT.isOpen()) {
            HudEditorAnimations.LAYOUT_HINT.fadeOut(FADE_DURATION_MS);
        }

        if (!chatActive && isDragging()) {
            stopDragging();
        }

        HudEditorAnimations.updateAll();
    }

    public boolean shouldRenderOverlay() {
        return HudEditorAnimations.LAYOUT_HINT.isVisible() || HudEditorAnimations.DRAG_GRID.isVisible();
    }

    public void renderOverlay(DrawHelper renderer, MatrixStack matrices) {
        tickAnimations();
        if (!shouldRenderOverlay()) {
            return;
        }

        float renderWidth = HudScaleUtil.getRenderWidth();
        float renderHeight = HudScaleUtil.getRenderHeight();
        float centerX = renderWidth / 2.0F;
        float centerY = renderHeight / 2.0F;

        float hintAlpha = HudEditorAnimations.LAYOUT_HINT.getAlpha() * 220.0F;
        if (hintAlpha > 0.5F) {
            FontRenderer hintFont = FontRegistry.getRegular(HINT_FONT_SIZE);
            if (hintFont != null) {
                float hintY = centerY - HINT_OFFSET_ABOVE_CENTER;
                hintFont.drawCentered(HINT_TEXT, centerX, hintY, withAlpha(255, 255, 255, hintAlpha), matrices);
            }
        }

        float gridAlpha = HudEditorAnimations.DRAG_GRID.getAlpha() * 180.0F;
        if (gridAlpha > 0.5F) {
            Color gridColor = withAlpha(255, 255, 255, gridAlpha);
            renderer.drawRoundedRect(0.0F, centerY - 0.5F, renderWidth, GRID_LINE_SIZE, gridColor, matrices);
            renderer.drawRoundedRect(centerX - 0.5F, 0.0F, GRID_LINE_SIZE, renderHeight, gridColor, matrices);
        }
    }

    private void applyPosition(double scaledMouseX, double scaledMouseY) {
        float renderWidth = HudScaleUtil.getRenderWidth();
        float renderHeight = HudScaleUtil.getRenderHeight();
        float hudX = HudScaleUtil.toHudX(scaledMouseX);
        float hudY = HudScaleUtil.toHudY(scaledMouseY);
        float newX = hudX - dragOffsetX;
        float newY = hudY - dragOffsetY;

        float width;
        float height;
        if (dragElement == DragElement.TARGET_HUD) {
            width = targetHud.getWidth();
            height = targetHud.getHeight();
        } else if (dragElement == DragElement.NOTIFICATIONS) {
            width = notifications.getWidth();
            height = notifications.getHeight();
        } else if (dragElement == DragElement.KEY_BINDS) {
            width = keyBinds.getWidth();
            height = keyBinds.getHeight();
        } else if (dragElement == DragElement.HOLY_WORLD_ASSIST) {
            width = holyWorldAssist.getWidth();
            height = holyWorldAssist.getHeight();
        } else if (dragElement == DragElement.COOLDOWNS) {
            width = cooldowns.getWidth();
            height = cooldowns.getHeight();
        } else if (dragElement == DragElement.POTIONS) {
            width = potions.getWidth();
            height = potions.getHeight();
        } else if (dragElement == DragElement.STAFF_LIST) {
            width = staffList.getWidth();
            height = staffList.getHeight();
        } else if (dragElement == DragElement.MEDIA_PLAYER) {
            width = mediaPlayer.getWidth();
            height = mediaPlayer.getHeight();
        } else if (dragElement == DragElement.TIMER_HUD) {
            width = timerHud.getWidth();
            height = timerHud.getHeight();
        } else {
            width = watermark.getWidth();
            height = watermark.getHeight();
        }

        if (!isCtrlDown()) {
            float centerX = newX + width / 2.0F;
            float centerY = newY + height / 2.0F;
            float screenCenterX = renderWidth / 2.0F;
            float screenCenterY = renderHeight / 2.0F;

            if (dragElement != DragElement.NOTIFICATIONS
                    && Math.abs(centerX - screenCenterX) <= SNAP_DISTANCE) {
                newX = screenCenterX - width / 2.0F;
            }
            if (Math.abs(centerY - screenCenterY) <= SNAP_DISTANCE) {
                newY = screenCenterY - height / 2.0F;
            }
        }

        if (dragElement == DragElement.NOTIFICATIONS) {
            newX = renderWidth / 2.0F - width / 2.0F;
        }

        newX = clamp(newX, SCREEN_PADDING, renderWidth - width - SCREEN_PADDING);
        newY = clamp(newY, SCREEN_PADDING, renderHeight - height - SCREEN_PADDING);

        if (dragElement == DragElement.TARGET_HUD) {
            targetHud.setPosition(newX, newY);
        } else if (dragElement == DragElement.NOTIFICATIONS) {
            notifications.setAnchorY(newY, renderWidth);
        } else if (dragElement == DragElement.KEY_BINDS) {
            keyBinds.setPosition(newX, newY);
        } else if (dragElement == DragElement.HOLY_WORLD_ASSIST) {
            holyWorldAssist.setPosition(newX, newY);
        } else if (dragElement == DragElement.COOLDOWNS) {
            cooldowns.setPosition(newX, newY);
        } else if (dragElement == DragElement.POTIONS) {
            potions.setPosition(newX, newY);
        } else if (dragElement == DragElement.STAFF_LIST) {
            staffList.setPosition(newX, newY);
        } else if (dragElement == DragElement.MEDIA_PLAYER) {
            mediaPlayer.setPosition(newX, newY);
        } else if (dragElement == DragElement.TIMER_HUD) {
            timerHud.setPosition(newX, newY);
        } else {
            watermark.setPosition(newX, newY);
        }
    }

    private boolean isCtrlDown() {
        long handle = MinecraftClient.getInstance().getWindow().getHandle();
        return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static Color withAlpha(int red, int green, int blue, float alpha) {
        return new Color(red, green, blue, Math.round(Math.min(255.0F, Math.max(0.0F, alpha))));
    }

    private enum DragElement {
        NONE,
        WATERMARK,
        TARGET_HUD,
        NOTIFICATIONS,
        KEY_BINDS,
        HOLY_WORLD_ASSIST,
        COOLDOWNS,
        POTIONS,
        STAFF_LIST,
        MEDIA_PLAYER,
        TIMER_HUD
    }
}
