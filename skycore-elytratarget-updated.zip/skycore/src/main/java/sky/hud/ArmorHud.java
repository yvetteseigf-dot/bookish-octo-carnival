package sky.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.util.inventory.EnchantmentUtil;

/**
 * Armour row drawn above the right half of the hotbar, with enchantment lines stacked over
 * each piece.
 */
public final class ArmorHud {
    private static final EquipmentSlot[] DISPLAY_ORDER = {
            EquipmentSlot.HEAD,
            EquipmentSlot.CHEST,
            EquipmentSlot.LEGS,
            EquipmentSlot.FEET
    };

    private static final int SLOT_SIZE = 16;
    private static final int SLOT_GAP = 2;
    private static final float ENCHANT_LINE_STEP = 6.0f;

    private final MinecraftClient client = MinecraftClient.getInstance();

    public void render(DrawContext context, float screenWidth, float screenHeight) {
        if (!Interface.INSTANCE.isArmorHudEnabled() || client.player == null) {
            return;
        }

        List<ItemStack> armor = collectArmor();
        if (armor.isEmpty()) {
            return;
        }

        int centerX = Math.round(screenWidth) / 2;
        int hotbarTop = Math.round(screenHeight) - 39;

        int totalWidth = armor.size() * SLOT_SIZE + (armor.size() - 1) * SLOT_GAP;
        int startX = centerX + 91 - totalWidth;
        int y = hotbarTop - SLOT_SIZE - 4;

        FontRenderer font = FontRegistry.getMedium(10);
        MatrixStack matrices = context.getMatrices();

        for (int i = 0; i < armor.size(); i++) {
            ItemStack stack = armor.get(i);
            int x = startX + i * (SLOT_SIZE + SLOT_GAP);

            if (font != null) {
                drawEnchantments(font, matrices, stack, x + 8.0f, y - 5.0f);
            }

            context.drawItem(stack, x, y);
            context.drawStackOverlay(client.textRenderer, stack, x, y);
        }
    }

    private void drawEnchantments(FontRenderer font, MatrixStack matrices, ItemStack stack, float itemCenterX,
                                  float startY) {
        float lineY = startY;
        for (String line : EnchantmentUtil.getEnchantments(stack)) {
            float lineWidth = font.getWidth(line);
            font.draw(line, itemCenterX - lineWidth / 2.0f, lineY, Color.WHITE, matrices);
            lineY -= ENCHANT_LINE_STEP;
        }
    }

    private List<ItemStack> collectArmor() {
        List<ItemStack> armor = new ArrayList<>(4);
        for (EquipmentSlot slot : DISPLAY_ORDER) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                armor.add(stack);
            }
        }

        return armor;
    }
}
