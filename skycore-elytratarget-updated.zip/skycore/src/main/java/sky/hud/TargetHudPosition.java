package sky.hud;

/**
 * Placement and bounds of the target HUD panel, as edited by the HUD editor.
 */
public final class TargetHudPosition {

    private float x;
    private float y;
    private float width = 96.0F;
    private float height = 32.0F;
    private boolean initialized;

    /**
     * Centres the panel horizontally and slightly below the screen middle, once.
     */
    public void ensureInitialized(float screenWidth, float screenHeight) {
        if (!initialized) {
            x = (screenWidth - width) / 2.0F;
            y = screenHeight / 2.0F + 36.0F - height / 2.0F;
            initialized = true;
        }
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        this.initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(48.0F, width);
        this.height = Math.max(20.0F, height);
    }

    public boolean contains(float renderX, float renderY) {
        return renderX >= x && renderX <= x + width && renderY >= y && renderY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
