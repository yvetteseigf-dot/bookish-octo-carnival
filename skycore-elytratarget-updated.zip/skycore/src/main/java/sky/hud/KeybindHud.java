package sky.hud;

import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.client.util.math.MatrixStack;
import sky.SkyInit;
import sky.config.BindCapture;
import sky.theme.GuiTheme;
import sky.module.Module;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;
import sky.util.render.HudScaleUtil;
import sky.util.input.KeyNameUtil;

/**
 * HUD panel listing every module that has a key bind, together with the bind itself.
 * <p>
 * While the chat screen is open the panel also accepts middle clicks on a row to start
 * capturing a new bind for that module.
 */
public final class KeybindHud {

    private static final String TITLE = "Keybinds";
    private static final String KEYBOARD_ICON = "c";
    private static final Color TEXT_COLOR = new Color(255, 255, 255, 255);

    private final FadeAnimation globalFade = new FadeAnimation();
    private final Map<String, FadeAnimation> rowFades = new HashMap<>();

    private float animatedWidth = 70.0F;
    private float animatedBindColumn = 0.0F;
    private float targetWidth = 70.0F;
    private float targetBindColumn = 0.0F;
    private float layoutWidthFrom = 70.0F;
    private float layoutBindFrom = 0.0F;
    private long layoutAnimStartMs;
    private boolean layoutAnimating;

    public void tick() {
        if (!Interface.INSTANCE.isKeyBindsEnabled()) {
            return;
        }

        boolean anyBoundModuleEnabled = false;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() >= 0 && module.isEnabled()) {
                anyBoundModuleEnabled = true;
                break;
            }
        }

        boolean visible = anyBoundModuleEnabled || ChatScreenDetector.isActive();
        if (visible) {
            if (!globalFade.isOpen()) {
                globalFade.fadeIn(250L);
            }
        } else if (globalFade.isVisible()) {
            globalFade.fadeOut(250L);
        }
        globalFade.update();

        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.computeIfAbsent(module.getName(), name -> new FadeAnimation());
            if (module.isEnabled()) {
                if (!fade.isOpen()) {
                    fade.fadeIn(250L);
                }
            } else if (fade.isVisible()) {
                fade.fadeOut(250L);
            }
            fade.update();
        }
    }

    public void render(MatrixStack matrices, float renderWidth) {
        if (!Interface.INSTANCE.isKeyBindsEnabled()) {
            return;
        }

        globalFade.update();
        if (!globalFade.isVisible()) {
            return;
        }

        float alpha = globalFade.getAlpha();
        if (alpha <= 0.01F) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null || matrices == null) {
            return;
        }

        FontRenderer titleFont = FontRegistry.getKrisaMedium(13);
        FontRenderer rowFont = FontRegistry.getKrisaMedium(13);
        FontRenderer iconFont = FontRegistry.getSkycore(12);
        if (titleFont == null || rowFont == null) {
            return;
        }
        if (iconFont == null) {
            iconFont = rowFont;
        }

        if (SkyInit.getInstance() == null || SkyInit.getInstance().getModuleManager() == null) {
            return;
        }

        float bindColumn = 0.0F;
        float panelWidth = 72.5F;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.get(module.getName());
            float rowAlpha = fade == null ? 0.0F : fade.getAlpha();
            if (!shouldRenderRow(module, rowAlpha)) {
                continue;
            }

            String bindText = getBindText(module);
            bindColumn = Math.max(bindColumn, rowFont.getWidth(bindText));

            float rowWidth = 5.0F + rowFont.getWidth(module.getName()) + 18.0F + rowFont.getWidth(bindText) + 5.0F;
            panelWidth = Math.max(panelWidth, rowWidth);
        }

        startLayoutAnimation(panelWidth, bindColumn);
        updateLayoutAnimation();

        float width = animatedWidth;
        float height = 23.0F;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.get(module.getName());
            float rowAlpha = fade == null ? 0.0F : fade.getAlpha();
            if (shouldRenderRow(module, rowAlpha)) {
                height += 9.0F * rowAlpha;
            }
        }

        KeyBindsHudPosition position = HudEditor.getInstance().getKeyBinds();
        position.setSize(width, height);
        position.ensureInitialized(renderWidth);

        float x = position.getX();
        float y = position.getY();
        GuiTheme theme = GuiTheme.theme;

        HudPanelRenderer.drawBackground(renderer, x, y, width, height, 13.0F,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha), alpha, matrices);

        float iconWidth = iconFont.getWidth(KEYBOARD_ICON);
        float iconX = x + width - 5.0F - iconWidth;
        iconFont.draw(KEYBOARD_ICON, iconX, y + 5.5F, ColorUtil.withAlpha(theme.getAccent(), alpha), matrices);
        titleFont.draw(TITLE, x + 6.0F, y + 4.5F, ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        HudPanelRenderer.drawHeaderSeparator(renderer, matrices, x, y + 15.0F, width, alpha, theme);

        float rowY = y + 18.0F;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.get(module.getName());
            if (fade == null) {
                continue;
            }

            float rowAlpha = fade.getAlpha();
            if (!shouldRenderRow(module, rowAlpha)) {
                continue;
            }
            if (rowAlpha <= 0.01F) {
                continue;
            }

            fade.update();

            float rowFadeAlpha = rowAlpha * alpha;
            float rowTop = rowY + 1.0F;
            String bindText = getBindText(module);
            float textY = rowTop + (9.0F - rowFont.getLineHeight(module.getName())) / 2.0F;

            rowFont.draw(module.getName(), x + 6.0F, textY,
                    ColorUtil.withAlpha(theme.getText(), rowFadeAlpha), matrices);

            float bindX = x + width - 5.0F - rowFont.getWidth(bindText) - 1.0F;
            rowFont.draw(bindText, bindX, textY,
                    ColorUtil.withAlpha(theme.getAccent(), rowFadeAlpha), matrices);

            rowY += 9.0F * rowAlpha;
        }

        cleanupRowAnimations();
    }

    public boolean handleMouseClick(double mouseX, double mouseY, int button) {
        if (!Interface.INSTANCE.isKeyBindsEnabled() || !ChatScreenDetector.isActive()) {
            return false;
        }
        if (button != 2) {
            return false;
        }

        float renderWidth = HudScaleUtil.getRenderWidth();
        KeyBindsHudPosition position = HudEditor.getInstance().getKeyBinds();
        position.ensureInitialized(renderWidth);

        float hudX = HudScaleUtil.toHudX(mouseX);
        float hudY = HudScaleUtil.toHudY(mouseY);
        if (!position.contains(hudX, hudY)) {
            return false;
        }

        float rowY = position.getY() + 18.0F;
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.get(module.getName());
            float rowAlpha = fade == null ? 0.0F : fade.getAlpha();
            if (!shouldRenderRow(module, rowAlpha)) {
                continue;
            }

            float rowHeight = 9.0F * rowAlpha;
            if (GuiRowHit.isHovered(hudX, hudY, position.getX(), rowY, position.getWidth(), rowHeight)) {
                BindCapture.beginModule(module);
                return true;
            }

            rowY += rowHeight;
        }

        return false;
    }

    public boolean hasVisibleRows() {
        if (!Interface.INSTANCE.isKeyBindsEnabled()) {
            return false;
        }

        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            if (module.getKeyBind() < 0) {
                continue;
            }

            FadeAnimation fade = rowFades.get(module.getName());
            float rowAlpha = fade == null ? 0.0F : fade.getAlpha();
            if (shouldRenderRow(module, rowAlpha)) {
                return true;
            }
        }

        return false;
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive();
    }

    private boolean shouldRenderRow(Module module, float rowAlpha) {
        if (ChatScreenDetector.isActive()) {
            return module.isEnabled();
        }
        return rowAlpha > 0.01F || module.isEnabled();
    }

    private String getBindText(Module module) {
        if (BindCapture.isActive(module)) {
            return BindCapture.getListeningLabel();
        }
        return KeyNameUtil.toShortBind(module.getKeyBind());
    }

    private void startLayoutAnimation(float width, float bindColumn) {
        if (Math.abs(width - targetWidth) < 0.5F && Math.abs(bindColumn - targetBindColumn) < 0.5F) {
            return;
        }

        layoutWidthFrom = animatedWidth;
        layoutBindFrom = animatedBindColumn;
        targetWidth = width;
        targetBindColumn = bindColumn;
        layoutAnimStartMs = System.currentTimeMillis();
        layoutAnimating = true;
    }

    private void updateLayoutAnimation() {
        if (!layoutAnimating) {
            return;
        }

        float progress = getSmoothProgress(layoutAnimStartMs);
        animatedWidth = layoutWidthFrom + (targetWidth - layoutWidthFrom) * progress;
        animatedBindColumn = layoutBindFrom + (targetBindColumn - layoutBindFrom) * progress;

        if (progress >= 1.0F) {
            animatedWidth = targetWidth;
            animatedBindColumn = targetBindColumn;
            layoutAnimating = false;
        }
    }

    private float getSmoothProgress(long startMs) {
        float elapsed = System.currentTimeMillis() - startMs;
        float linear = Math.min(1.0F, Math.max(0.0F, elapsed / 250.0F));
        float eased = linear * linear * (3.0F - 2.0F * linear);
        return eased * eased * (3.0F - 2.0F * eased);
    }

    private void cleanupRowAnimations() {
        Iterator<Map.Entry<String, FadeAnimation>> iterator = rowFades.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, FadeAnimation> entry = iterator.next();
            if (entry.getValue().isVisible()) {
                continue;
            }

            boolean stillBound = SkyInit.getInstance().getModuleManager().getModules().stream()
                    .anyMatch(module -> module.getName().equals(entry.getKey()) && module.getKeyBind() >= 0);
            if (!stillBound) {
                iterator.remove();
            }
        }
    }

    private static final class GuiRowHit {

        private GuiRowHit() {
        }

        private static boolean isHovered(float pointX, float pointY, float x, float y, float width, float height) {
            return pointX >= x && pointX <= x + width && pointY >= y && pointY <= y + height;
        }
    }
}
