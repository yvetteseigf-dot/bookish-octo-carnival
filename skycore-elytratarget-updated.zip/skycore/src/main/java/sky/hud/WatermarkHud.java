package sky.hud;

import java.awt.Color;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.math.MatrixStack;
import org.lwjgl.glfw.GLFW;
import sky.SkyInit;
import sky.theme.GuiTheme;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.GuiSurfaceRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.render.ScissorStack;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;
import sky.util.animation.FadeAnimation;
import sky.util.render.GuiCoordinateUtil;
import sky.util.render.HudScaleUtil;

/**
 * Client watermark bar showing the player name, framerate, latency and current server.
 *
 * <p>Right-clicking the bar while the chat screen is open opens a small panel that lets the user
 * override the displayed name.</p>
 */
public final class WatermarkHud {
    private static final float MENU_WIDTH = 136.0f;
    private static final float MENU_HEIGHT_ENABLED = 68.0f;
    private static final float MENU_HEIGHT_DISABLED = 44.0f;
    private static final float MENU_PADDING = 10.0f;
    private static final float MENU_GAP = 6.0f;
    private static final float FIELD_HEIGHT = 18.0f;
    private static final float TOGGLE_WIDTH = 18.0f;
    private static final float TOGGLE_HEIGHT = 9.0f;
    private static final int MAX_CUSTOM_NAME_LENGTH = 32;
    private static final long MENU_ANIMATION_MS = 180L;
    private static final long TOGGLE_ANIMATION_MS = 180L;
    private static final long BACKSPACE_FIRST_REPEAT_MS = 230L;
    private static final long BACKSPACE_REPEAT_MS = 35L;

    private String customName = "";
    private boolean customNameEnabled;
    private boolean menuOpen;
    private boolean textFocused;
    private boolean backspaceHeld;
    private long nextBackspaceRepeatMs;
    private final FadeAnimation menuAnimation = new FadeAnimation();
    private final FadeAnimation toggleAnimation = new FadeAnimation();

    public void render(MatrixStack matrices, float screenWidth) {
        Interface module = Interface.INSTANCE;
        if (!module.isWatermarkEnabled()) {
            return;
        }

        DrawHelper render2D = DrawHelper.get();
        if (render2D == null) {
            return;
        }

        WatermarkHudPosition position = HudEditor.getInstance().getWatermark();
        FontRenderer valueFont = FontRegistry.getKrisaMedium(12);
        FontRenderer unitFont = FontRegistry.getKrisaRegular(11);
        FontRenderer iconFont = FontRegistry.getWatermarkIcons(14);
        FontRenderer logoFont = FontRegistry.getSkycore(14);
        if (valueFont == null || unitFont == null || iconFont == null || logoFont == null) {
            return;
        }

        String name = getWatermarkName();
        String fps = String.valueOf(MinecraftClient.getInstance().getCurrentFps());
        String ping = getPingValue();
        ServerAddress server = splitServerAddress(getServerAddress());

        float contentWidth = getContentWidth(name, fps, ping, server, valueFont, unitFont, iconFont);
        position.setWidth(contentWidth);
        position.setHeight(19.0f);
        position.ensureInitialized(screenWidth);

        float x = position.getX();
        float y = position.getY();
        GuiTheme theme = GuiTheme.theme;
        Color accent = theme.getAccent();
        Color text = theme.getText();
        Color unitColor = ColorUtil.withAlpha(text, 125);
        Color logoDivider = ColorUtil.withAlpha(text, 10);
        Color separator = ColorUtil.withAlpha(text, 31);

        HudPanelRenderer.drawWatermarkBackground(render2D, x, y, position.getWidth(), 19.0f, 12.0f,
                theme.getPanelTop(), theme.getPanelBottom(), 1.0f, matrices);
        render2D.drawRoundedRect(x + 19.0f, y, 1.0f, 19.0f, 0.0f, logoDivider, matrices);
        logoFont.draw("a", x + 6.3f, y + 5.4f, accent, matrices);

        float cursorX = x + 25.5f;

        iconFont.draw("'", cursorX, y + 0.5f, accent, matrices);
        cursorX += iconFont.getWidth("'") + 3.0f;
        valueFont.draw(name, cursorX, y + 5.6f, text, matrices);
        cursorX += valueFont.getWidth(name) + 4.0f;

        cursorX = drawSeparator(render2D, matrices, cursorX, y, separator);
        iconFont.draw("&", cursorX, y + 0.5f, accent, matrices);
        cursorX += iconFont.getWidth("&") + 3.0f;
        valueFont.draw(fps, cursorX, y + 5.6f, text, matrices);
        cursorX += valueFont.getWidth(fps);
        unitFont.draw("fps", cursorX, y + 6.1f, unitColor, matrices);
        cursorX += unitFont.getWidth("fps") + 4.0f;

        cursorX = drawSeparator(render2D, matrices, cursorX, y, separator);
        iconFont.draw(",", cursorX, y + 0.5f, accent, matrices);
        cursorX += iconFont.getWidth(",") + 3.0f;
        valueFont.draw(ping, cursorX, y + 5.6f, text, matrices);
        cursorX += valueFont.getWidth(ping);
        unitFont.draw("ms", cursorX, y + 6.1f, unitColor, matrices);
        cursorX += unitFont.getWidth("ms") + 4.0f;

        cursorX = drawSeparator(render2D, matrices, cursorX, y, separator);
        iconFont.draw(".", cursorX, y + 0.8f, accent, matrices);
        cursorX += iconFont.getWidth(".") + 3.0f;
        drawServerAddress(valueFont, unitFont, server, cursorX, y + 5.6f, text, unitColor, matrices);

        updateBackspaceRepeat();
        renderCustomNameMenu(render2D, matrices, position, screenWidth);
    }

    public void loadCustomNameSettings(boolean enabled, String name) {
        this.customNameEnabled = enabled;
        this.customName = name == null ? "" : limitName(name);
        if (enabled) {
            toggleAnimation.fadeIn(0L);
        }
    }

    public boolean isCustomNameEnabled() {
        return customNameEnabled;
    }

    public String getCustomName() {
        return customName;
    }

    public boolean handleMouseClicked(double mouseX, double mouseY, int button) {
        if (!ChatScreenDetector.isActive() || !Interface.INSTANCE.isWatermarkEnabled()) {
            closeMenu();
            return false;
        }

        float hudX = HudScaleUtil.toHudX(mouseX);
        float hudY = HudScaleUtil.toHudY(mouseY);
        WatermarkHudPosition position = HudEditor.getInstance().getWatermark();
        float screenWidth = getHudScreenWidth();
        float screenHeight = getHudScreenHeight();
        position.ensureInitialized(screenWidth);

        boolean overWatermark = position.contains(hudX, hudY);
        if (button == 1 && overWatermark) {
            menuOpen = true;
            textFocused = false;
            return true;
        }

        if (!menuOpen && !menuAnimation.isVisible()) {
            return false;
        }

        float menuX = getMenuX(position, screenWidth);
        float menuY = getMenuY(position, screenHeight);
        float menuHeight = getMenuHeight();

        if (button != 0) {
            return menuOpen
                    && GuiCoordinateUtil.isHovered(hudX, hudY, menuX, menuY, MENU_WIDTH, menuHeight);
        }

        if (GuiCoordinateUtil.isHovered(hudX, hudY, menuX + MENU_PADDING, getToggleRowY(menuY),
                MENU_WIDTH - MENU_PADDING * 2.0f, FIELD_HEIGHT)) {
            customNameEnabled = !customNameEnabled;
            textFocused = customNameEnabled;
            saveCustomNameSettings();
            return true;
        }

        if (customNameEnabled && GuiCoordinateUtil.isHovered(hudX, hudY, menuX + MENU_PADDING, getFieldY(menuY),
                MENU_WIDTH - MENU_PADDING * 2.0f, FIELD_HEIGHT)) {
            textFocused = true;
            return true;
        }

        if (!GuiCoordinateUtil.isHovered(hudX, hudY, menuX, menuY, MENU_WIDTH, menuHeight) && !overWatermark) {
            closeMenu();
        }
        return true;
    }

    public boolean handleKeyPressed(int keyCode) {
        if (!menuOpen) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            closeMenu();
            return true;
        }
        if (!textFocused) {
            return false;
        }
        if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
            textFocused = false;
            saveCustomNameSettings();
            return true;
        }
        if (keyCode == GLFW.GLFW_KEY_BACKSPACE) {
            if (backspaceHeld) {
                return true;
            }
            deleteLastCustomNameChar();
            backspaceHeld = true;
            nextBackspaceRepeatMs = System.currentTimeMillis() + BACKSPACE_FIRST_REPEAT_MS;
            return true;
        }
        return false;
    }

    public boolean handleKeyReleased(int keyCode) {
        if (keyCode != GLFW.GLFW_KEY_BACKSPACE) {
            return false;
        }
        backspaceHeld = false;
        return menuOpen && textFocused;
    }

    public boolean handleCharTyped(char character) {
        if (!menuOpen || !textFocused || !customNameEnabled || Character.isISOControl(character)) {
            return false;
        }
        if (customName.length() >= MAX_CUSTOM_NAME_LENGTH) {
            return true;
        }
        customName = customName + character;
        saveCustomNameSettings();
        return true;
    }

    private void renderCustomNameMenu(DrawHelper render2D, MatrixStack matrices, WatermarkHudPosition position,
                                      float screenWidth) {
        if (!ChatScreenDetector.isActive() && menuOpen) {
            closeMenu();
        }

        if (ChatScreenDetector.isActive() && menuOpen) {
            menuAnimation.fadeIn(MENU_ANIMATION_MS);
        } else {
            menuAnimation.fadeOut(MENU_ANIMATION_MS);
        }
        menuAnimation.update();
        if (!menuAnimation.isVisible()) {
            return;
        }

        if (customNameEnabled) {
            toggleAnimation.fadeIn(TOGGLE_ANIMATION_MS);
        } else {
            toggleAnimation.fadeOut(TOGGLE_ANIMATION_MS);
        }
        toggleAnimation.update();

        GuiTheme theme = GuiTheme.theme;
        FontRenderer titleFont = FontRegistry.getRegular(13);
        FontRenderer fieldFont = FontRegistry.getRegular(12);
        FontRenderer labelFont = FontRegistry.getRegular(13);
        if (titleFont == null || fieldFont == null || labelFont == null) {
            return;
        }

        float menuX = getMenuX(position, screenWidth);
        float menuY = getMenuY(position, HudScaleUtil.getRenderHeight());
        float menuHeight = getMenuHeight();
        float alpha = menuAnimation.getAlpha();
        float scale = 0.92f + 0.08f * alpha;
        float pivotX = menuX;
        float pivotY = menuY + MENU_PADDING;

        matrices.push();
        matrices.translate(pivotX, pivotY, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate(-pivotX, -pivotY, 0.0f);

        GuiSurfaceRenderer.drawHudSurface(render2D, menuX, menuY, MENU_WIDTH, menuHeight, MENU_PADDING,
                0.96f * alpha, matrices);
        titleFont.draw("Watermark", menuX + MENU_PADDING, menuY + 7.0f,
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);

        float toggleRowY = getToggleRowY(menuY);
        float toggleY = toggleRowY + 1.0f;
        float toggleX = menuX + MENU_WIDTH - MENU_PADDING - TOGGLE_WIDTH;
        labelFont.draw("Custom name", menuX + MENU_PADDING, toggleRowY,
                ColorUtil.withAlpha(theme.getText(), alpha), matrices);
        renderToggle(render2D, matrices, toggleX, toggleY, alpha, theme);

        if (!customNameEnabled) {
            matrices.pop();
            return;
        }

        float fieldX = menuX + MENU_PADDING;
        float fieldY = getFieldY(menuY);
        render2D.drawRoundedRect(fieldX, fieldY, MENU_WIDTH - MENU_PADDING * 2.0f, FIELD_HEIGHT, MENU_GAP,
                ColorUtil.withAlpha(theme.getModeOff(), 0.82f * alpha), matrices);

        String displayed = customName.isEmpty() ? "Name..." : customName;
        Color textColor = customName.isEmpty() ? theme.getTextDim() : theme.getText();
        if (textFocused && System.currentTimeMillis() % 1000L < 520L) {
            displayed = displayed + "_";
        }

        ScissorStack.enable(fieldX + 5.0f, fieldY, MENU_WIDTH - MENU_PADDING * 3.0f, FIELD_HEIGHT);
        try {
            fieldFont.draw(displayed, fieldX + 7.0f,
                    fieldY + (FIELD_HEIGHT - fieldFont.getLineHeight(displayed)) / 2.0f,
                    ColorUtil.withAlpha(textColor, alpha), matrices);
        } finally {
            ScissorStack.disable();
        }

        matrices.pop();
    }

    private void renderToggle(DrawHelper render2D, MatrixStack matrices, float x, float y, float alpha,
                              GuiTheme theme) {
        float animation = toggleAnimation.getAlpha();
        Color track = ColorUtil.lerp(theme.getToggleOff(), theme.getToggleOn(), animation);
        render2D.drawRoundedRect(x, y, TOGGLE_WIDTH, TOGGLE_HEIGHT, 4.5f,
                ColorUtil.withAlpha(track, alpha), matrices);

        float travel = TOGGLE_WIDTH - 7.0f - 2.0f;
        render2D.drawRoundedRect(x + 1.0f + travel * animation, y + 1.0f, 7.0f, 7.0f, 7.0f / 2.0f,
                ColorUtil.withAlpha(Color.WHITE, alpha), matrices);
    }

    private float drawSeparator(DrawHelper render2D, MatrixStack matrices, float x, float y, Color color) {
        render2D.drawCircle(x + 1.5f, y + 9.5f, 1.5f, color, matrices);
        return x + 7.0f;
    }

    private void drawServerAddress(FontRenderer valueFont, FontRenderer unitFont, ServerAddress server, float x,
                                   float y, Color nameColor, Color partColor, MatrixStack matrices) {
        unitFont.draw(server.prefix(), x, y + 0.5f, partColor, matrices);
        x += unitFont.getWidth(server.prefix());
        valueFont.draw(server.name(), x, y, nameColor, matrices);
        x += valueFont.getWidth(server.name());
        unitFont.draw(server.suffix(), x, y + 0.5f, partColor, matrices);
    }

    private float getContentWidth(String name, String fps, String ping, ServerAddress server,
                                  FontRenderer valueFont, FontRenderer unitFont, FontRenderer iconFont) {
        float width = 25.5f
                + iconFont.getWidth("'") + 3.0f
                + valueFont.getWidth(name) + 4.0f
                + 7.0f
                + iconFont.getWidth("&") + 3.0f
                + valueFont.getWidth(fps) + unitFont.getWidth("fps") + 4.0f
                + 7.0f
                + iconFont.getWidth(",") + 3.0f
                + valueFont.getWidth(ping) + unitFont.getWidth("ms") + 4.0f
                + 7.0f
                + iconFont.getWidth(".") + 3.0f
                + getServerWidth(server, valueFont, unitFont)
                + 6.0f;
        return width;
    }

    private float getServerWidth(ServerAddress server, FontRenderer valueFont, FontRenderer unitFont) {
        return unitFont.getWidth(server.prefix())
                + valueFont.getWidth(server.name())
                + unitFont.getWidth(server.suffix());
    }

    private ServerAddress splitServerAddress(String address) {
        String host = address == null || address.isBlank() ? "singleplayer" : address;
        String port = "";

        int colon = host.lastIndexOf(':');
        if (colon > host.lastIndexOf(']')) {
            port = host.substring(colon);
            host = host.substring(0, colon);
        }

        String[] labels = host.split("\\.");
        if (labels.length < 2) {
            return new ServerAddress("", host, port);
        }

        if (labels.length >= 3) {
            StringBuilder tail = new StringBuilder();
            for (int i = 2; i < labels.length; i++) {
                tail.append('.').append(labels[i]);
            }
            tail.append(port);
            return new ServerAddress(labels[0] + ".", labels[1], tail.toString());
        }

        return new ServerAddress("", labels[0], "." + labels[1] + port);
    }

    private String getServerAddress() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() == null
                || client.getNetworkHandler().getServerInfo() == null
                || client.getNetworkHandler().getServerInfo().address == null) {
            return "singleplayer";
        }
        return client.getNetworkHandler().getServerInfo().address;
    }

    private String getPingValue() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) {
            return "--";
        }
        PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
        return entry == null ? "--" : String.valueOf(entry.getLatency());
    }

    private String getWatermarkName() {
        String trimmed = customName == null ? "" : customName.trim();
        if (customNameEnabled && !trimmed.isEmpty()) {
            return trimmed;
        }
        return getPcName();
    }

    private String getPcName() {
        return MinecraftClient.getInstance().getSession().getUsername();
    }

    private void updateBackspaceRepeat() {
        if (!backspaceHeld || !menuOpen || !textFocused || !customNameEnabled) {
            return;
        }
        long now = System.currentTimeMillis();
        if (now < nextBackspaceRepeatMs) {
            return;
        }
        deleteLastCustomNameChar();
        nextBackspaceRepeatMs = now + BACKSPACE_REPEAT_MS;
    }

    private void deleteLastCustomNameChar() {
        if (customName.isEmpty()) {
            return;
        }
        customName = customName.substring(0, customName.length() - 1);
        saveCustomNameSettings();
    }

    private void saveCustomNameSettings() {
        SkyInit.getInstance().getClientConfig().onWatermarkCustomNameChanged(customNameEnabled, customName);
    }

    private void closeMenu() {
        menuOpen = false;
        textFocused = false;
        backspaceHeld = false;
    }

    private static String limitName(String name) {
        if (name.length() <= MAX_CUSTOM_NAME_LENGTH) {
            return name;
        }
        return name.substring(0, MAX_CUSTOM_NAME_LENGTH);
    }

    private float getMenuX(WatermarkHudPosition position, float screenWidth) {
        float right = position.getX() + position.getWidth() + MENU_GAP;
        if (right + MENU_WIDTH <= screenWidth - 4.0f) {
            return right;
        }
        return Math.max(4.0f, position.getX() - MENU_WIDTH - MENU_GAP);
    }

    private float getMenuY(WatermarkHudPosition position, float screenHeight) {
        return Math.max(4.0f, Math.min(position.getY(), screenHeight - getMenuHeight() - 4.0f));
    }

    private float getMenuHeight() {
        return customNameEnabled ? MENU_HEIGHT_ENABLED : MENU_HEIGHT_DISABLED;
    }

    private float getToggleRowY(float menuY) {
        return menuY + 22.0f;
    }

    private float getFieldY(float menuY) {
        return menuY + 42.0f;
    }

    private float getHudScreenWidth() {
        MinecraftClient client = MinecraftClient.getInstance();
        return HudScaleUtil.toHudX(client.getWindow().getScaledWidth());
    }

    private float getHudScreenHeight() {
        MinecraftClient client = MinecraftClient.getInstance();
        return HudScaleUtil.toHudY(client.getWindow().getScaledHeight());
    }

    private record ServerAddress(String prefix, String name, String suffix) {
    }
}
