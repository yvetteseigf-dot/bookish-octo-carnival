package sky.hud;

/**
 * Draggable anchor for the potion effects panel. It defaults to the top-right corner,
 * inset by a fixed margin.
 */
public final class PotionsHudPosition {
    private float x;
    private float y = 36.0f;
    private float width = 70.0f;
    private float height = 22.0f;
    private boolean initialized;

    public void ensureInitialized(float screenWidth) {
        if (!initialized) {
            x = screenWidth - width - 6.0f;
            y = 36.0f;
            initialized = true;
        }
    }

    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
        initialized = true;
    }

    public void setSize(float width, float height) {
        this.width = Math.max(70.0f, width);
        this.height = Math.max(22.0f, height);
    }

    public boolean contains(float renderX, float renderY) {
        return renderX >= x && renderX <= x + width && renderY >= y && renderY <= y + height;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }
}
