package sky.hud;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

import sky.theme.GuiTheme;
import sky.module.Module;
import sky.module.visuals.Interface;
import sky.render.font.FontRegistry;
import sky.render.font.FontRenderer;
import sky.render.HudPanelRenderer;
import sky.render.DrawHelper;
import sky.util.ChatScreenDetector;
import sky.util.render.ColorUtil;

/**
 * Stacked toast notifications drawn above the hotbar. While the chat screen is open and
 * nothing real is queued, a sample toast is shown so the HUD editor has something to grab.
 */
public final class NotificationManager {
    private static final String PREVIEW_TEXT = "This is a sample notification";

    private static final String ICON_TOGGLE_LEFT = "a";
    private static final String ICON_TOGGLE_RIGHT = "b";
    private static final String ICON_CONFIG = "c";
    private static final String ICON_SWAP = "d";
    private static final String ICON_LOST_TOTEM = "e";
    private static final String ICON_SPEC = "'";

    private static final int TEXT_SIZE = 12;
    private static final int NOTIFICATION_ICON_SIZE = 14;
    private static final int SPEC_ICON_SIZE = 14;

    private static final float HEIGHT = 16.0f;
    private static final float PADDING_X = 5.0f;
    private static final float ITEM_GAP = 3.0f;
    private static final float STACK_GAP = 2.5f;
    private static final float RADIUS = 10.0f;
    private static final float RING_RADIUS = 2.5f;
    private static final float RING_THICKNESS = 1.5f;
    private static final float SLIDE_OFFSET = 4.0f;
    private static final float LAYOUT_ANIM_RATE = 11.0f;

    private static final long SHOW_MS = 2000L;
    private static final long ANIM_MS = 350L;
    private static final long TOGGLE_ANIM_MS = 280L;

    private static final Color SUCCESS_COLOR = new Color(151, 255, 125, 255);
    private static final Color FAILURE_COLOR = new Color(255, 125, 125, 255);
    private static final Color INFO_BLUE = new Color(104, 174, 255, 255);
    private static final Color RING_TRACK_COLOR = new Color(36, 36, 36, 255);

    private final List<Entry> entries = new ArrayList<>();

    private boolean chatWasOpen;
    private boolean previewDismissing;
    private long previewAnimStartMs;
    private long lastRenderNs;

    public void push(Module module, boolean enabled) {
        Interface notificationsModule = Interface.INSTANCE;
        if (module == notificationsModule) {
            return;
        }

        pushModuleToggle(module.getName(), enabled);
    }

    public void pushModuleToggle(String moduleName, boolean enabled) {
        if (!canPush()) {
            return;
        }

        addEntry(new Entry(Kind.MODULE_TOGGLE, moduleName, enabled));
    }

    public void pushConfigLoaded(String configName) {
        if (!canPush()) {
            return;
        }

        addEntry(new Entry(Kind.CONFIG, configName == null ? "" : configName.trim()));
    }

    public void pushSpecWarning(String playerName) {
        if (!canPush() || playerName == null || playerName.isBlank()) {
            return;
        }

        addEntry(new Entry(Kind.SPEC_WARNING, playerName.trim()));
    }

    public void pushSwapToElytra() {
        if (!canPush()) {
            return;
        }

        addEntry(new Entry(Kind.SWAP_ELYTRA));
    }

    public void pushSwapToChestplate() {
        if (!canPush()) {
            return;
        }

        addEntry(new Entry(Kind.SWAP_CHESTPLATE));
    }

    public void pushItemSwap(String itemName) {
        if (!canPush() || itemName == null || itemName.isBlank()) {
            return;
        }

        addEntry(new Entry(Kind.ITEM_SWAP, itemName.trim()));
    }

    public void pushTotemLost(String playerName, int count) {
        if (!canPush() || playerName == null || playerName.isBlank()) {
            return;
        }

        addEntry(new Entry(Kind.TOTEM_LOST, playerName.trim(), Math.max(1, count)));
    }

    public void pushMessage(String message) {
        pushMessage(message, true);
    }

    public void pushMessage(String message, boolean enabled) {
        if (!canPush()) {
            return;
        }

        addEntry(new Entry(Kind.GENERIC, message, enabled));
    }

    public void tick() {
        int previousSize = entries.size();
        entries.removeIf(Entry::isFinished);

        if (entries.size() != previousSize) {
            syncStackTargets(HEIGHT + STACK_GAP);

            if (entries.isEmpty() && ChatScreenDetector.isActive()) {
                previewDismissing = false;
                previewAnimStartMs = System.currentTimeMillis();
                chatWasOpen = true;
            }
        }

        updatePreviewState();
    }

    public boolean shouldRenderInChatOverlay() {
        return ChatScreenDetector.isActive() && !previewDismissing;
    }

    public boolean shouldRenderInMainHud() {
        return !ChatScreenDetector.isActive() || previewDismissing;
    }

    public void render(MatrixStack matrices, float screenWidth, float screenHeight) {
        if (!Interface.INSTANCE.isNotificationsEnabled()) {
            return;
        }

        updatePreviewState();

        boolean hasEntries = !entries.isEmpty();
        boolean showPreview = !hasEntries && (ChatScreenDetector.isActive() || previewDismissing);
        if (!hasEntries && !showPreview) {
            return;
        }

        DrawHelper renderer = DrawHelper.get();
        if (renderer == null) {
            return;
        }

        NotificationsHudPosition position = HudEditor.getInstance().getNotifications();
        float frameDelta = getFrameDeltaSeconds();

        if (showPreview) {
            FontRenderer font = FontRegistry.getKrisaMedium(TEXT_SIZE);
            float previewWidth = measurePreviewWidth(font);

            position.setWidth(previewWidth);
            position.ensureInitialized(screenWidth, screenHeight, HEIGHT);
            position.syncCenterX(screenWidth);
            position.setHitHeight(HEIGHT);

            long elapsed = Math.max(0L, System.currentTimeMillis() - previewAnimStartMs);
            float alpha;
            float slide;
            if (previewDismissing) {
                alpha = 1.0f - easeOutCubic(Math.min(1.0f, elapsed / (float) ANIM_MS));
                slide = -SLIDE_OFFSET * easeOutCubic(Math.min(1.0f, elapsed / (float) ANIM_MS));
            } else if (elapsed < ANIM_MS) {
                float progress = easeOutCubic(elapsed / (float) ANIM_MS);
                alpha = progress;
                slide = -SLIDE_OFFSET * (1.0f - progress);
            } else {
                alpha = 1.0f;
                slide = 0.0f;
            }

            renderPreview(renderer, matrices, font, position.getX(), position.getY() + slide, previewWidth, alpha);
            return;
        }

        FontRenderer font = FontRegistry.getKrisaMedium(TEXT_SIZE);
        FontRenderer iconFont = FontRegistry.getNotificationIcons(NOTIFICATION_ICON_SIZE);
        FontRenderer specIconFont = FontRegistry.getWatermarkIcons(SPEC_ICON_SIZE);

        float widest = 0.0f;
        for (Entry entry : entries) {
            widest = Math.max(widest, entry.measureWidth(font, iconFont, specIconFont));
        }

        position.setWidth(widest);
        position.ensureInitialized(screenWidth, screenHeight, HEIGHT);
        position.syncCenterX(screenWidth);

        float stackHeight = entries.size() * HEIGHT + Math.max(0, entries.size() - 1) * STACK_GAP;
        position.setHitHeight(stackHeight);

        float baseY = position.getY();
        float centerX = position.getCenterX();
        syncStackTargets(HEIGHT + STACK_GAP);

        for (Entry entry : entries) {
            entry.updateLayout(frameDelta);
            float width = entry.measureWidth(font, iconFont, specIconFont);
            float x = centerX - width / 2.0f;
            entry.render(renderer, matrices, font, iconFont, specIconFont, x, baseY + entry.layoutY, width);
        }
    }

    private void addEntry(Entry entry) {
        entries.add(0, entry);
        syncStackTargets(HEIGHT + STACK_GAP);
    }

    private boolean canPush() {
        if (!Interface.INSTANCE.isNotificationsEnabled()) {
            return false;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        return client.world != null && client.player != null;
    }

    private void syncStackTargets(float stackStep) {
        for (int i = 0; i < entries.size(); i++) {
            entries.get(i).setTargetLayoutY(i * stackStep);
        }
    }

    private void updatePreviewState() {
        boolean chatOpen = ChatScreenDetector.isActive();
        boolean hasEntries = !entries.isEmpty();

        if (hasEntries) {
            previewDismissing = false;
            previewAnimStartMs = 0L;
            chatWasOpen = chatOpen;
            return;
        }

        if (chatOpen) {
            if (!chatWasOpen) {
                previewDismissing = false;
                previewAnimStartMs = System.currentTimeMillis();
            }
        } else if (chatWasOpen && previewAnimStartMs != 0L && !previewDismissing) {
            previewDismissing = true;
            previewAnimStartMs = System.currentTimeMillis();
        } else if (!chatOpen && !previewDismissing) {
            previewAnimStartMs = 0L;
        }

        if (previewDismissing) {
            long elapsed = System.currentTimeMillis() - previewAnimStartMs;
            if (elapsed >= ANIM_MS) {
                previewDismissing = false;
                previewAnimStartMs = 0L;
            }
        }

        chatWasOpen = chatOpen;
    }

    private void renderPreview(DrawHelper renderer, MatrixStack matrices, FontRenderer font,
                               float x, float y, float width, float alpha) {
        if (alpha <= 0.001f) {
            return;
        }

        drawThemedBackground(renderer, matrices, x, y, width, alpha);
        drawStatusText(font, matrices, x + PADDING_X, y + 1.6f, PREVIEW_TEXT, SUCCESS_COLOR, Color.WHITE, alpha);

        float ringX = x + width - PADDING_X - RING_RADIUS;
        float ringY = y + 8.0f;
        renderer.drawArc(ringX, ringY, RING_RADIUS, -90.0f, 360.0f, RING_THICKNESS,
                ColorUtil.withAlpha(RING_TRACK_COLOR, alpha), matrices);
        renderer.drawArc(ringX, ringY, RING_RADIUS, -90.0f, 270.0f, RING_THICKNESS,
                ColorUtil.withAlpha(SUCCESS_COLOR, alpha), matrices);
    }

    private void drawThemedBackground(DrawHelper renderer, MatrixStack matrices,
                                      float x, float y, float width, float alpha) {
        GuiTheme theme = GuiTheme.theme;
        HudPanelRenderer.drawBackground(renderer, x, y, width, HEIGHT, RADIUS,
                ColorUtil.withAlpha(theme.getPanelTop(), alpha),
                ColorUtil.withAlpha(theme.getPanelBottom(), alpha),
                alpha, matrices);
    }

    private void drawKindIcon(FontRenderer iconFont, FontRenderer specIconFont, MatrixStack matrices,
                              Kind kind, float x, float y, float alpha) {
        switch (kind) {
            case CONFIG -> drawNotificationIcon(iconFont, matrices, ICON_CONFIG, x, y, INFO_BLUE, alpha);
            case SPEC_WARNING -> drawNotificationIcon(specIconFont, matrices, ICON_SPEC, x, y, FAILURE_COLOR, alpha);
            case SWAP_ELYTRA, SWAP_CHESTPLATE, ITEM_SWAP ->
                    drawNotificationIcon(iconFont, matrices, ICON_SWAP, x, y, Color.WHITE, alpha);
            case TOTEM_LOST -> drawNotificationIcon(iconFont, matrices, ICON_LOST_TOTEM, x, y, Color.WHITE, alpha);
        }
    }

    private void drawModuleToggleIcon(FontRenderer iconFont, MatrixStack matrices, float x, float y,
                                      boolean enabled, long elapsed, float alpha) {
        float progress = resolveToggleProgress(enabled, elapsed);
        float leftAlpha = alpha * (1.0f - progress);
        float rightAlpha = alpha * progress;

        if (leftAlpha > 0.01f) {
            drawNotificationIcon(iconFont, matrices, ICON_TOGGLE_LEFT, x, y, FAILURE_COLOR, leftAlpha);
        }

        if (rightAlpha > 0.01f) {
            drawNotificationIcon(iconFont, matrices, ICON_TOGGLE_RIGHT, x, y, SUCCESS_COLOR, rightAlpha);
        }
    }

    private void drawNotificationIcon(FontRenderer font, MatrixStack matrices, String glyph,
                                      float x, float y, Color color, float alpha) {
        if (font == null || alpha <= 0.001f) {
            return;
        }

        font.draw(glyph, x, getIconDrawY(font, y, glyph), ColorUtil.withAlpha(color, alpha), matrices);
    }

    private float getIconDrawY(FontRenderer font, float rowY, String glyph) {
        return rowY + (HEIGHT - font.getLineHeight(glyph)) / 2.0f - 2.0f;
    }

    private void drawStatusText(FontRenderer font, MatrixStack matrices, float x, float y, String message,
                                Color prefixColor, Color suffixColor, float alpha) {
        if (prefixColor.equals(suffixColor)) {
            font.draw(message, Math.round(x + 0.5f), Math.round(y + 2.0f),
                    ColorUtil.withAlpha(prefixColor, alpha), matrices);
            return;
        }

        int split = message.indexOf(' ');
        if (split < 0) {
            font.draw(message, Math.round(x + 0.5f), Math.round(y + 2.0f),
                    ColorUtil.withAlpha(prefixColor, alpha), matrices);
            return;
        }

        String prefix = message.substring(0, split);
        font.draw(prefix, Math.round(x + 0.5f), Math.round(y + 2.0f),
                ColorUtil.withAlpha(prefixColor, alpha), matrices);
        font.draw(message.substring(split), Math.round(x + font.getWidth(prefix) + 0.5f), Math.round(y + 2.0f),
                ColorUtil.withAlpha(suffixColor, alpha), matrices);
    }

    private void drawTextSegments(FontRenderer font, MatrixStack matrices, float x, float y,
                                  List<TextSegment> segments, float alpha) {
        float cursorX = x + 0.5f;
        float drawY = Math.round(y + 2.0f);

        for (TextSegment segment : segments) {
            if (segment.text.isEmpty()) {
                continue;
            }

            font.draw(segment.text, Math.round(cursorX), drawY, ColorUtil.withAlpha(segment.color, alpha), matrices);
            cursorX += font.getWidth(segment.text);
        }
    }

    private float measurePreviewWidth(FontRenderer font) {
        return measureTextWidth(font, PREVIEW_TEXT, 0.0f);
    }

    private float measureTextWidth(FontRenderer font, String message, float leftInset) {
        return PADDING_X + leftInset + font.getWidth(message) + ITEM_GAP + PADDING_X + PADDING_X;
    }

    private float measureTextWidth(FontRenderer font, List<TextSegment> segments, float leftInset) {
        return PADDING_X + leftInset + measureSegmentsWidth(font, segments) + ITEM_GAP + PADDING_X + PADDING_X;
    }

    private float measureSegmentsWidth(FontRenderer font, List<TextSegment> segments) {
        float width = 0.0f;
        for (TextSegment segment : segments) {
            width += font.getWidth(segment.text);
        }

        return width;
    }

    private float getFrameDeltaSeconds() {
        long now = System.nanoTime();
        if (lastRenderNs == 0L) {
            lastRenderNs = now;
            return 0.016f;
        }

        float delta = (now - lastRenderNs) / 1.0E9f;
        lastRenderNs = now;
        return Math.max(0.001f, Math.min(0.05f, delta));
    }

    private static float resolveAlpha(long elapsed) {
        if (elapsed < ANIM_MS) {
            return easeOutCubic(elapsed / (float) ANIM_MS);
        }

        if (elapsed < SHOW_MS) {
            return 1.0f;
        }

        if (elapsed < SHOW_MS + ANIM_MS) {
            float progress = (elapsed - SHOW_MS) / (float) ANIM_MS;
            return 1.0f - easeOutCubic(progress);
        }

        return 0.0f;
    }

    private static float resolveSlideOffset(long elapsed, float slideOffset) {
        if (elapsed < ANIM_MS) {
            float progress = easeOutCubic(elapsed / (float) ANIM_MS);
            return -slideOffset * (1.0f - progress);
        }

        if (elapsed < SHOW_MS) {
            return 0.0f;
        }

        if (elapsed < SHOW_MS + ANIM_MS) {
            float progress = easeOutCubic((elapsed - SHOW_MS) / (float) ANIM_MS);
            return -slideOffset * progress;
        }

        return -slideOffset;
    }

    private static float resolveToggleProgress(boolean enabled, long elapsed) {
        float progress = Math.min(1.0f, elapsed / (float) TOGGLE_ANIM_MS);
        float eased = easeOutBack(progress);
        return enabled ? eased : 1.0f - eased;
    }

    private static float expSmoothFactor(float rate, float deltaSeconds) {
        return 1.0f - (float) Math.exp(-rate * deltaSeconds);
    }

    private static float easeOutCubic(float value) {
        float inverse = 1.0f - Math.max(0.0f, Math.min(1.0f, value));
        return 1.0f - inverse * inverse * inverse;
    }

    private static float easeOutBack(float value) {
        float clamped = Math.max(0.0f, Math.min(1.0f, value));
        float overshoot = 1.70158f + 1.0f;
        return 1.0f + overshoot * (float) Math.pow(clamped - 1.0f, 3.0)
                + 1.70158f * (float) Math.pow(clamped - 1.0f, 2.0);
    }

    private enum Kind {
        MODULE_TOGGLE,
        CONFIG,
        SPEC_WARNING,
        SWAP_ELYTRA,
        SWAP_CHESTPLATE,
        ITEM_SWAP,
        TOTEM_LOST,
        GENERIC
    }

    private record TextSegment(String text, Color color) {
    }

    private final class Entry {
        private final Kind kind;
        private final String primary;
        private final boolean enabled;
        private final int count;
        private final long startMs;

        private float layoutY;
        private float targetLayoutY;

        private Entry(Kind kind) {
            this(kind, "", true, 1);
        }

        private Entry(Kind kind, String primary) {
            this(kind, primary, true, 1);
        }

        private Entry(Kind kind, String primary, boolean enabled) {
            this(kind, primary, enabled, 1);
        }

        private Entry(Kind kind, String primary, int count) {
            this(kind, primary, true, count);
        }

        private Entry(Kind kind, String primary, boolean enabled, int count) {
            this.startMs = System.currentTimeMillis();
            this.kind = kind;
            this.primary = primary;
            this.enabled = enabled;
            this.count = count;
        }

        private boolean isFinished() {
            return System.currentTimeMillis() - startMs >= SHOW_MS + ANIM_MS;
        }

        private void setTargetLayoutY(float targetLayoutY) {
            this.targetLayoutY = targetLayoutY;
        }

        private void updateLayout(float frameDelta) {
            float factor = expSmoothFactor(LAYOUT_ANIM_RATE, frameDelta);
            layoutY += (targetLayoutY - layoutY) * factor;
        }

        private void render(DrawHelper renderer, MatrixStack matrices, FontRenderer font, FontRenderer iconFont,
                            FontRenderer specIconFont, float x, float y, float width) {
            long elapsed = System.currentTimeMillis() - startMs;
            float alpha = resolveAlpha(elapsed);
            if (alpha <= 0.001f) {
                return;
            }

            float slide = resolveSlideOffset(elapsed, SLIDE_OFFSET);
            float rowY = y + slide;
            Color accent = getAccentColor();
            Color ringColor = getRingColor();

            drawThemedBackground(renderer, matrices, x, rowY, width, alpha);

            float iconX = x + PADDING_X;
            if (kind == Kind.MODULE_TOGGLE) {
                drawModuleToggleIcon(iconFont, matrices, iconX, rowY, enabled, elapsed, alpha);
            } else if (kind != Kind.GENERIC) {
                drawKindIcon(iconFont, specIconFont, matrices, kind, iconX, rowY, alpha);
            }

            float textX = iconX + leftInset(iconFont, specIconFont);
            if (kind == Kind.GENERIC) {
                Color prefixColor = accent;
                Color suffixColor = Color.WHITE;
                drawStatusText(font, matrices, textX, rowY + 1.6f, primary, prefixColor, suffixColor, alpha);
            } else {
                drawTextSegments(font, matrices, textX, rowY + 1.6f, getTextSegments(), alpha);
            }

            float ringX = x + width - PADDING_X - RING_RADIUS;
            float ringY = rowY + 8.0f;
            renderer.drawArc(ringX, ringY, RING_RADIUS, -90.0f, 360.0f, RING_THICKNESS,
                    ColorUtil.withAlpha(RING_TRACK_COLOR, alpha), matrices);

            float remaining = Math.max(0.0f, 1.0f - elapsed / (float) (SHOW_MS + ANIM_MS));
            renderer.drawArc(ringX, ringY, RING_RADIUS, -90.0f, 360.0f * remaining, RING_THICKNESS,
                    ColorUtil.withAlpha(ringColor, alpha), matrices);
        }

        private float measureWidth(FontRenderer font, FontRenderer iconFont, FontRenderer specIconFont) {
            if (kind == Kind.GENERIC) {
                return measureTextWidth(font, primary, leftInset(iconFont, specIconFont));
            }

            return measureTextWidth(font, getTextSegments(), leftInset(iconFont, specIconFont));
        }

        private float leftInset(FontRenderer iconFont, FontRenderer specIconFont) {
            return switch (kind) {
                case MODULE_TOGGLE -> iconFont.getWidth(ICON_TOGGLE_LEFT) + ITEM_GAP;
                case CONFIG -> iconFont.getWidth(ICON_CONFIG) + ITEM_GAP;
                case SPEC_WARNING -> specIconFont.getWidth(ICON_SPEC) + ITEM_GAP;
                case SWAP_ELYTRA, SWAP_CHESTPLATE, ITEM_SWAP -> iconFont.getWidth(ICON_SWAP) + ITEM_GAP;
                case TOTEM_LOST -> iconFont.getWidth(ICON_LOST_TOTEM) + ITEM_GAP;
                default -> 0.0f;
            };
        }

        private List<TextSegment> getTextSegments() {
            Color accent = GuiTheme.theme.getAccent();
            Color white = Color.WHITE;

            return switch (kind) {
                case MODULE_TOGGLE -> List.of(
                        new TextSegment(enabled ? "Works!" : "Failure...", accentColor()),
                        new TextSegment(enabled
                                ? " Module " + primary + " enabled"
                                : " Module " + primary + " disabled", white));
                case CONFIG -> List.of(
                        new TextSegment("Config ", white),
                        new TextSegment(primary, accent),
                        new TextSegment(" loaded", white));
                case SPEC_WARNING -> List.of(
                        new TextSegment("Warning!", FAILURE_COLOR),
                        new TextSegment(" " + primary + " requested ", white),
                        new TextSegment("spec!", FAILURE_COLOR));
                case SWAP_ELYTRA -> List.of(
                        new TextSegment("Swapped to ", white),
                        new TextSegment("elytra!", accent));
                case SWAP_CHESTPLATE -> List.of(
                        new TextSegment("Swapped to ", white),
                        new TextSegment("chestplate!", accent));
                case ITEM_SWAP -> List.of(
                        new TextSegment("Swapped to ", white),
                        new TextSegment(primary, accent));
                case TOTEM_LOST -> List.of(
                        new TextSegment(primary, accent),
                        new TextSegment(" lost ", white),
                        new TextSegment("Totem of Undying ", accent),
                        new TextSegment("x" + count, white));
                default -> List.of(new TextSegment(primary, white));
            };
        }

        private Color accentColor() {
            return enabled ? SUCCESS_COLOR : FAILURE_COLOR;
        }

        private Color getAccentColor() {
            return switch (kind) {
                case MODULE_TOGGLE -> enabled ? SUCCESS_COLOR : FAILURE_COLOR;
                case CONFIG, SWAP_ELYTRA, SWAP_CHESTPLATE, ITEM_SWAP -> INFO_BLUE;
                case SPEC_WARNING -> FAILURE_COLOR;
                case TOTEM_LOST -> GuiTheme.theme.getAccent();
                case GENERIC -> enabled ? SUCCESS_COLOR : FAILURE_COLOR;
            };
        }

        private Color getRingColor() {
            return switch (kind) {
                case MODULE_TOGGLE, SPEC_WARNING, TOTEM_LOST -> getAccentColor();
                case CONFIG, SWAP_ELYTRA, SWAP_CHESTPLATE, ITEM_SWAP -> INFO_BLUE;
                case GENERIC -> enabled ? SUCCESS_COLOR : FAILURE_COLOR;
            };
        }
    }
}
