package sky.misc;

import net.minecraft.item.ItemStack;
import sky.mixin.gui.InGameHudAccessor;
import sky.module.player.AutoTool;
import sky.access.MinecraftAccess;

public final class HeldItemVisualSpoof implements MinecraftAccess {
    private static int visualSlot = -1;
    private static ItemStack frozenStack = ItemStack.EMPTY;
    private static int ticksLeft;

    private HeldItemVisualSpoof() {
    }

    public static boolean shouldSuppressTooltip() {
        return ticksLeft > 0 || visualSlot >= 0 || AutoTool.shouldSuppressHeldItemTooltip();
    }

    public static ItemStack getVisualStack(ItemStack original) {
        int slot = getVisualSlot();
        if (slot < 0 || slot > 8 || mc.player == null) {
            return original;
        }
        if (visualSlot == slot && !frozenStack.isEmpty()) {
            return frozenStack;
        }
        return mc.player.getInventory().getStack(slot);
    }

    private static void suppressTooltip() {
        if (mc != null && mc.inGameHud != null) {
            ((InGameHudAccessor) mc.inGameHud).setHeldItemTooltipFade(0);
        }
    }

    public static int getVisualSlot() {
        int autoToolSlot = AutoTool.getVisualSlot();
        return autoToolSlot >= 0 ? autoToolSlot : visualSlot;
    }

    public static void hold(int slot, int ticks) {
        if (slot < 0 || slot > 8 || mc.player == null) {
            return;
        }
        visualSlot = slot;
        ticksLeft = Math.max(ticks, 1);
        frozenStack = mc.player.getInventory().getStack(slot).copy();
        suppressTooltip();
    }

    public static void clear() {
        visualSlot = -1;
        ticksLeft = 0;
        frozenStack = ItemStack.EMPTY;
    }

    public static void tick() {
        if (ticksLeft <= 0) {
            return;
        }
        ticksLeft--;
        suppressTooltip();
        if (ticksLeft <= 0) {
            clear();
        }
    }
}
