package sky.misc;

import net.minecraft.text.ClickEvent;

public class CustomClickEvent extends ClickEvent {
    public CustomClickEvent(Action action, String value) {
        super(action, value);
    }
}
