package sky.misc;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import sky.SkyInit;
import sky.util.text.CommandFeedback;
import sky.command.Command;
import sky.config.NeuroFile;
import sky.module.combat.AttackAura;

/** Records and inspects the aim dataset that the Neuro rotation mode replays. */
public class Neuro extends Command {
    public Neuro() {
        super("neuro");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(ctx -> {
            CommandFeedback.displayInfo("Usage: .neuro record | stop | status");
            return 1;
        });
        builder.then(literal("record").executes(ctx -> record()));
        builder.then(literal("stop").executes(ctx -> stop()));
        builder.then(literal("status").executes(ctx -> status()));
    }

    private int record() {
        NeuroFile recorder = SkyInit.getInstance().getNeuroRecorder();
        if (recorder.isRecording()) {
            CommandFeedback.displayInfo("Recording already in progress (" + recorder.getRecordSeconds() + " sec)");
            return 0;
        }

        recorder.startRecording();
        CommandFeedback.displayInfo("Neuro: recording started. Hit the target for 1-2 minutes, then .neuro stop");
        return 1;
    }

    private int stop() {
        NeuroFile recorder = SkyInit.getInstance().getNeuroRecorder();
        if (!recorder.isRecording()) {
            CommandFeedback.displayInfo("Recording is not active");
            return 0;
        }

        int frames = recorder.stopRecording();
        if (frames < 20) {
            CommandFeedback.displayInfo(
                    "Not enough data recorded (" + frames + " ticks). Hit the target longer for better results");
        } else {
            CommandFeedback.displayInfo("Neuro saved: " + frames + " ticks. Recording will persist after reconnect");
        }
        return 1;
    }

    private int status() {
        NeuroFile recorder = SkyInit.getInstance().getNeuroRecorder();
        if (recorder.isRecording()) {
            CommandFeedback.displayInfo(
                    "Recording: " + recorder.getRecordSeconds() + " sec, " + recorder.getFrameCount() + " ticks");
            return 1;
        }
        if (recorder.hasData()) {
            CommandFeedback.displayInfo(
                    "Neuro loaded: " + recorder.getFrameCount() + " ticks. Select Neuro rotation in AttackAura");
            return 1;
        }

        CommandFeedback.displayInfo("Neuro is empty. Use .neuro record");
        return 1;
    }
}
