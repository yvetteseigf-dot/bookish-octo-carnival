package sky.scheduler;

/** Global tick-rate multiplier shared between the timer module and the render tick counter. */
public final class TimerSpeedController {
    private static volatile float speed = 1.0F;

    private TimerSpeedController() {
    }

    public static void setSpeed(float value) {
        speed = Float.isFinite(value) ? Math.max(0.05F, value) : 1.0F;
    }

    public static float getSpeed() {
        return speed;
    }

    public static void resetSpeed() {
        speed = 1.0F;
    }
}
