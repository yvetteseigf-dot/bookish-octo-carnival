package sky.scheduler;

public final class TickRateLimiter {
    private static final float DEFAULT_RATE = 10.0F;
    private static final double NANOS_PER_SECOND = 1.0E9D;
    private static float currentRate = DEFAULT_RATE;
    private static boolean active;
    private static long lastNanoTime;

    private TickRateLimiter() {
    }

    public static void setActive(boolean value) {
        active = value;
        if (!value) {
            lastNanoTime = 0L;
        }
    }

    public static void reset() {
        active = false;
        currentRate = DEFAULT_RATE;
        lastNanoTime = 0L;
    }

    public static boolean isActive() {
        return active;
    }

    public static float getCurrentRate() {
        return currentRate;
    }

    public static void setCurrentRate(float value) {
        currentRate = value;
    }

    public static boolean canProceed() {
        if (!active) {
            lastNanoTime = 0L;
            return true;
        }
        long now = System.nanoTime();
        long interval = (long) (NANOS_PER_SECOND / Math.max(1.0F, currentRate));
        if (lastNanoTime == 0L || now - lastNanoTime >= interval) {
            lastNanoTime = now;
            return true;
        }
        return false;
    }
}
