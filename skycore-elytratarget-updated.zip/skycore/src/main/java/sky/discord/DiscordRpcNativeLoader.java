package sky.discord;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Optional;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;

/** Unpacks the bundled discord-rpc native into the game directory and reports its absolute path. */
public final class DiscordRpcNativeLoader {
    private static final String MOD_ID = "skycore";

    private DiscordRpcNativeLoader() {
    }

    public static String loadDiscordRpcLibrary() {
        if (!isWindows()) {
            throw new UnsatisfiedLinkError("Discord RPC is only supported on Windows");
        }

        Path nativesDirectory = FabricLoader.getInstance().getGameDir().resolve("SkyCore").resolve("natives");
        Path libraryFile = nativesDirectory.resolve("discord-rpc.dll");
        try {
            Files.createDirectories(nativesDirectory);
            extractLibrary(libraryFile);
        } catch (IOException exception) {
            throw new UnsatisfiedLinkError("Failed to extract discord-rpc.dll: " + exception.getMessage());
        }
        return libraryFile.toAbsolutePath().toString();
    }

    private static void extractLibrary(Path destination) throws IOException {
        boolean is64Bit = is64BitJvm();
        String[] candidates = is64Bit
                ? new String[] {
                    "assets/skycore/natives/win32-x86-64/discord-rpc.dll",
                    "assets/win32-x86-64/discord-rpc.dll"
                }
                : new String[] {
                    "assets/skycore/natives/win32-x86/discord-rpc.dll",
                    "assets/win32-x86/discord-rpc.dll"
                };

        Optional<ModContainer> container = FabricLoader.getInstance().getModContainer(MOD_ID);
        for (String candidate : candidates) {
            if (container.isPresent()) {
                Optional<Path> bundled = container.get().findPath(candidate);
                if (bundled.isPresent() && Files.exists(bundled.get())) {
                    Files.copy(bundled.get(), destination, StandardCopyOption.REPLACE_EXISTING);
                    return;
                }
            }

            try (InputStream stream = DiscordRpcNativeLoader.class.getClassLoader().getResourceAsStream(candidate)) {
                if (stream != null) {
                    Files.copy(stream, destination, StandardCopyOption.REPLACE_EXISTING);
                    return;
                }
            }
        }

        throw new IOException("discord-rpc.dll not found for " + (is64Bit ? "x64" : "x86") + " JVM");
    }

    private static boolean isWindows() {
        String osName = System.getProperty("os.name", "").toLowerCase();
        return osName.contains("win");
    }

    private static boolean is64BitJvm() {
        String architecture = System.getProperty("os.arch", "").toLowerCase();
        return architecture.contains("64") || "amd64".equals(architecture) || "aarch64".equals(architecture);
    }
}
