package sky.discord;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class DiscordRichPresence extends Structure {
    public int partySize;
    public long startTimestamp;
    public int instance;
    public String state;
    public String smallImageText;
    public int partyMax;
    public String largeImageText;
    public String joinSecret;
    public String smallImageKey;
    public String button_label_2;
    public String details;
    public String button_url_2;
    public String partyId;
    public long endTimestamp;
    public String spectateSecret;
    public String matchSecret;
    public String button_label_1;
    public String button_url_1;
    public String largeImageKey;
    public String partyPrivacy;

    public DiscordRichPresence() {
        setStringEncoding("UTF-8");
    }

    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList(
                "state",
                "details",
                "startTimestamp",
                "endTimestamp",
                "largeImageKey",
                "largeImageText",
                "smallImageKey",
                "smallImageText",
                "partyId",
                "partySize",
                "partyMax",
                "partyPrivacy",
                "matchSecret",
                "joinSecret",
                "spectateSecret",
                "button_label_1",
                "button_url_1",
                "button_label_2",
                "button_url_2",
                "instance");
    }

    public static class Builder {
        private final DiscordRichPresence richPresence = new DiscordRichPresence();

        public Builder setState(String state) {
            if (state != null && !state.isEmpty()) {
                richPresence.state = state.substring(0, Math.min(state.length(), 128));
            }
            return this;
        }

        public Builder setDetails(String details) {
            if (details != null && !details.isEmpty()) {
                richPresence.details = details.substring(0, Math.min(details.length(), 128));
            }
            return this;
        }

        public Builder setLargeImage(String key, String text) {
            richPresence.largeImageKey = key;
            richPresence.largeImageText = text;
            return this;
        }

        public void setStartTimestamp(long timestamp) {
            richPresence.startTimestamp = timestamp;
        }

        public void setButtons(DiscordRpcButton button1, DiscordRpcButton button2) {
            setButtons(Arrays.asList(button1, button2));
        }

        public Builder setButtons(DiscordRpcButton button) {
            return setButtons(Collections.singletonList(button));
        }

        public Builder setButtons(List<DiscordRpcButton> buttons) {
            if (buttons != null && !buttons.isEmpty()) {
                int count = Math.min(buttons.size(), 2);
                richPresence.button_label_1 = buttons.get(0).getLabel();
                richPresence.button_url_1 = buttons.get(0).getUrl();
                if (count == 2) {
                    richPresence.button_label_2 = buttons.get(1).getLabel();
                    richPresence.button_url_2 = buttons.get(1).getUrl();
                }
            }
            return this;
        }

        public DiscordRichPresence build() {
            return richPresence;
        }
    }
}
