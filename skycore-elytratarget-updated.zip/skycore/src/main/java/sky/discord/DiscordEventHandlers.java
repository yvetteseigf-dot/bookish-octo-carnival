package sky.discord;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.List;

public class DiscordEventHandlers extends Structure {
    public DiscordSpectateGameCallback spectateGame;
    public DiscordJoinRequestCallback joinRequest;
    public DiscordDisconnectedCallback disconnected;
    public DiscordJoinGameCallback joinGame;
    public DiscordReadyCallback ready;
    public DiscordErroredCallback errored;

    @Override
    protected List<String> getFieldOrder() {
        return Arrays.asList("ready", "disconnected", "errored", "joinGame", "spectateGame", "joinRequest");
    }

    public static class Builder {
        private final DiscordEventHandlers handlers = new DiscordEventHandlers();

        public DiscordEventHandlers build() {
            return handlers;
        }
    }
}
