package sky.discord;

import com.sun.jna.Callback;

public interface DiscordReadyCallback extends Callback {
    void apply(DiscordUser user);
}
