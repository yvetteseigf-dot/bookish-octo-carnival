package sky.discord;

import com.sun.jna.Library;
import com.sun.jna.Native;
import com.sun.jna.NativeLibrary;
import java.io.File;

public interface DiscordRpcLibrary extends Library {

    static DiscordRpcLibrary getInstance() {
        return Holder.get();
    }

    void Discord_Register(String applicationId, String command);

    void Discord_RegisterSteamGame(String applicationId, String steamId);

    void Discord_Initialize(String applicationId, DiscordEventHandlers handlers, boolean autoRegister, String steamId);

    void Discord_Shutdown();

    void Discord_RunCallbacks();

    void Discord_UpdateConnection();

    void Discord_UpdateHandlers(DiscordEventHandlers handlers);

    void Discord_UpdatePresence(DiscordRichPresence presence);

    void Discord_ClearPresence();

    void Discord_Respond(String userId, int reply);

    final class Holder {
        private static DiscordRpcLibrary instance;

        private Holder() {
        }

        static DiscordRpcLibrary get() {
            if (instance == null) {
                String libraryPath = DiscordRpcNativeLoader.loadDiscordRpcLibrary();
                NativeLibrary.addSearchPath("discord-rpc", new File(libraryPath).getParent());
                instance = Native.load(libraryPath, DiscordRpcLibrary.class);
            }
            return instance;
        }
    }
}
