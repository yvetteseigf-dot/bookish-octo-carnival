package sky.discord;

import com.sun.jna.Callback;

public interface DiscordErroredCallback extends Callback {
    void apply(int errorCode, String message);
}
