package sky.discord;

import com.sun.jna.Callback;

public interface DiscordJoinRequestCallback extends Callback {
    void apply(DiscordUser request);
}
