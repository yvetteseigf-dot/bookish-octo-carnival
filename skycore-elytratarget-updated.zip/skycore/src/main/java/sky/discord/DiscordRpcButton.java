package sky.discord;

import java.io.Serializable;

public class DiscordRpcButton implements Serializable {
    private final String label;
    private final String url;

    protected DiscordRpcButton(String label, String url) {
        this.label = label;
        this.url = url;
    }

    public static DiscordRpcButton create(String label, String url) {
        return new DiscordRpcButton(label.substring(0, Math.min(label.length(), 31)), url);
    }

    public String getLabel() {
        return label;
    }

    public String getUrl() {
        return url;
    }
}
