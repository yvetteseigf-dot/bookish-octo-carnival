package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(InGameHud.class)
public interface InGameHudAccessor {
    @Invoker("renderStatusBars")
    void invokeRenderStatusBars(DrawContext context);

    @Accessor("heldItemTooltipFade")
    void setHeldItemTooltipFade(int ticks);
}
