package sky.mixin.gui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.module.misc.InventoryPlus;
import sky.module.player.ItemScroller;
import sky.module.visuals.Animations;
import sky.ui.animation.InventoryCloseAnimation;
import sky.util.animation.TweenFloat;

@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {
    @Shadow
    protected abstract boolean isPointOverSlot(Slot slot, double pointX, double pointY);

    @Shadow
    protected abstract void onMouseClick(Slot slot, int slotId, int button, SlotActionType actionType);

    @Shadow
    protected abstract void drawBackground(DrawContext context, float delta, int mouseX, int mouseY);

    @Shadow
    protected abstract Slot getSlotAt(double mouseX, double mouseY);

    @Unique
    private final TweenFloat skycore$openAnim = new TweenFloat(1.0F);

    @Unique
    private long skycore$openStartMs;

    @Unique
    private boolean skycore$openStarted;

    @Unique
    private boolean skycore$contentMatrixPushed;

    @Unique
    private boolean skycore$colorPushed;

    @Unique
    private boolean skycore$slotMatrixPushed;

    @Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
    private void skycore$inventoryPlusExtraClick(double mouseX, double mouseY, int button,
                                                CallbackInfoReturnable<Boolean> cir) {
        if (!InventoryPlus.INSTANCE.isEnabled() || button > 1) {
            return;
        }

        Slot slot = this.getSlotAt(mouseX, mouseY);
        if (slot != null && !slot.isEnabled()) {
            this.onMouseClick(slot, slot.id, button, SlotActionType.PICKUP);
            cir.setReturnValue(true);
        }
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void skycore$invOpenInit(CallbackInfo ci) {
        this.skycore$openStarted = false;
        this.skycore$openStartMs = System.currentTimeMillis();
        this.skycore$openAnim.snap(0.0F);
    }

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void skycore$safeTick(CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            InventoryCloseAnimation.cancel();
            ci.cancel();
            if (client.currentScreen == (Object) this) {
                client.setScreen(null);
            }
        }
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void skycore$invAnimHead(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        InventoryCloseAnimation.tick();
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        if (InventoryCloseAnimation.isClosing(self) && InventoryCloseAnimation.shouldHideContent()) {
            ci.cancel();
            return;
        }

        ItemScroller itemScroller = ItemScroller.INSTANCE;
        if (!itemScroller.isEnabled()) {
            itemScroller.mouseHold = false;
            return;
        }

        long window = MinecraftClient.getInstance().getWindow().getHandle();
        itemScroller.mouseHold = GLFW.glfwGetMouseButton(window, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (!itemScroller.mouseHold) {
            return;
        }

        boolean shiftHeld = InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_LEFT_SHIFT)
                || InputUtil.isKeyPressed(window, GLFW.GLFW_KEY_RIGHT_SHIFT);
        if (!shiftHeld) {
            return;
        }

        long now = System.currentTimeMillis();
        long waitMs = (long) (itemScroller.delay.getCurrent() * 10.0F);
        if (waitMs > 0L && now - itemScroller.lastClickMs < waitMs) {
            return;
        }

        for (Slot slot : self.getScreenHandler().slots) {
            if (slot.isEnabled() && slot.id >= 0 && this.isPointOverSlot(slot, mouseX, mouseY) && !slot.getStack().isEmpty()) {
                this.onMouseClick(slot, slot.id, 0, SlotActionType.QUICK_MOVE);
                itemScroller.lastClickMs = now;
                break;
            }
        }
    }

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void skycore$invContentTransform(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;

        this.skycore$ensureOpenAnimStarted();

        this.skycore$contentMatrixPushed = false;
        this.skycore$colorPushed = false;

        float scale = 1.0F;
        float alpha = 1.0F;
        float dimAlpha = 1.0F;
        if (InventoryCloseAnimation.isClosing(self)) {
            float progress = InventoryCloseAnimation.getProgress();
            scale = progress;
            alpha = progress;
            dimAlpha = progress;
        } else if (Animations.effect(Animations.INV_OPEN)) {
            float t = this.skycore$openAnim.update();
            scale = skycore$easeOutBack(t);
            alpha = MathHelper.clamp(t * 1.15F, 0.0F, 1.0F);
            dimAlpha = 1.0F;
        } else {
            this.skycore$openAnim.update();
        }

        this.skycore$drawDim(context, dimAlpha);

        if (Math.abs(scale - 1.0F) > 0.001F || alpha < 0.999F) {
            float cx = self.width / 2.0F;
            float cy = self.height / 2.0F;
            context.getMatrices().push();
            context.getMatrices().translate(cx, cy, 0.0F);
            context.getMatrices().scale(Math.max(0.001F, scale), Math.max(0.001F, scale), 1.0F);
            context.getMatrices().translate(-cx, -cy, 0.0F);
            this.skycore$contentMatrixPushed = true;
            if (alpha < 0.999F) {
                RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, MathHelper.clamp(alpha, 0.0F, 1.0F));
                this.skycore$colorPushed = true;
            }
        }

        this.drawBackground(context, delta, mouseX, mouseY);
        ci.cancel();
    }

    @Unique
    private void skycore$ensureOpenAnimStarted() {
        if (this.skycore$openStarted) {
            return;
        }
        this.skycore$openStarted = true;
        this.skycore$openStartMs = System.currentTimeMillis();
        if (Animations.effect(Animations.INV_OPEN) || Animations.effect(Animations.INV_SLOTS)) {
            this.skycore$openAnim.setDuration(280L);
            this.skycore$openAnim.snap(0.0F);
            this.skycore$openAnim.animateTo(1.0F);
        } else {
            this.skycore$openAnim.snap(1.0F);
        }
    }

    @Unique
    private void skycore$drawDim(DrawContext context, float alpha) {
        float a = MathHelper.clamp(alpha, 0.0F, 1.0F);
        if (a <= 0.01F) {
            return;
        }
        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        int topA = Math.round(192.0F * a);
        int bottomA = Math.round(208.0F * a);
        int top = (topA << 24) | 0x101010;
        int bottom = (bottomA << 24) | 0x101010;
        context.fillGradient(0, 0, self.width, self.height, top, bottom);
    }

    @Unique
    private static float skycore$easeOutBack(float t) {
        t = MathHelper.clamp(t, 0.0F, 1.0F);
        float c1 = 1.70158F;
        float c3 = c1 + 1.0F;
        float x = t - 1.0F;
        return 1.0F + c3 * x * x * x + c1 * x * x;
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$invAnimTail(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (this.skycore$colorPushed) {
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
            this.skycore$colorPushed = false;
        }
        if (this.skycore$contentMatrixPushed) {
            context.getMatrices().pop();
            this.skycore$contentMatrixPushed = false;
        }
    }

    @Unique
    private float skycore$slotCascadeScale(Slot slot) {
        float elapsed = (System.currentTimeMillis() - this.skycore$openStartMs) / 1000.0F;
        float delay = (slot.id & 63) * 0.016F;
        float local = MathHelper.clamp((elapsed - delay) / 0.22F, 0.0F, 1.0F);
        return skycore$easeOutBack(local);
    }

    @Inject(method = "drawSlot", at = @At("HEAD"))
    private void skycore$slotCascadeHead(DrawContext context, Slot slot, CallbackInfo ci) {
        this.skycore$slotMatrixPushed = false;
        if (!Animations.effect(Animations.INV_SLOTS)) {
            return;
        }

        HandledScreen<?> self = (HandledScreen<?>) (Object) this;
        if (InventoryCloseAnimation.isClosing(self)) {
            return;
        }

        this.skycore$ensureOpenAnimStarted();
        float slotScale = this.skycore$slotCascadeScale(slot);
        if (Math.abs(slotScale - 1.0F) < 0.001F) {
            return;
        }

        float cx = slot.x + 8.0F;
        float cy = slot.y + 8.0F;
        context.getMatrices().push();
        context.getMatrices().translate(cx, cy, 0.0F);
        context.getMatrices().scale(Math.max(0.001F, slotScale), Math.max(0.001F, slotScale), 1.0F);
        context.getMatrices().translate(-cx, -cy, 0.0F);
        this.skycore$slotMatrixPushed = true;
    }

    @Inject(method = "drawSlot", at = @At("RETURN"))
    private void skycore$slotCascadeTail(DrawContext context, Slot slot, CallbackInfo ci) {
        if (this.skycore$slotMatrixPushed) {
            context.getMatrices().pop();
            this.skycore$slotMatrixPushed = false;
        }
    }
}
