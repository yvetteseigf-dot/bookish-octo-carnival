package sky.mixin.gui;

import com.mojang.brigadier.ParseResults;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.suggestion.Suggestions;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatInputSuggestor;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.command.CommandSource;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;
import sky.SkyInit;
import sky.session.ChatPasswordHider;

import java.util.concurrent.CompletableFuture;

@Mixin(ChatInputSuggestor.class)
public abstract class ChatInputSuggestorMixin {
    @Final
    @Shadow
    TextFieldWidget textField;

    @Shadow
    boolean completingSuggestions;

    @Shadow
    private ParseResults<CommandSource> parse;

    @Shadow
    private CompletableFuture<Suggestions> pendingSuggestions;

    @Shadow
    private ChatInputSuggestor.SuggestionWindow window;

    @Shadow
    protected abstract void showCommandSuggestions();

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void skycore$hidePasswordSuggestions(DrawContext context, int mouseX, int mouseY, CallbackInfo ci) {
        if (ChatPasswordHider.shouldHide(this.textField.getText())) {
            ci.cancel();
        }
    }

    @Inject(
            method = "refresh",
            at = @At(value = "INVOKE", target = "Lcom/mojang/brigadier/StringReader;canRead()Z", remap = false),
            cancellable = true,
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    public void refreshHook(CallbackInfo ci, String string, StringReader reader) {
        if (reader.canRead(SkyInit.getInstance().getCommandManager().getPrefix().length())
                && reader.getString().startsWith(
                        SkyInit.getInstance().getCommandManager().getPrefix(), reader.getCursor())) {
            reader.setCursor(reader.getCursor() + SkyInit.getInstance().getCommandManager().getPrefix().length());
            if (this.parse == null) {
                this.parse = SkyInit.getInstance().getCommandManager().getDispatcher()
                        .parse(reader, SkyInit.getInstance().getCommandManager().getSource());
            }

            int cursor = this.textField.getCursor();
            if (cursor >= 1 && (this.window == null || !this.completingSuggestions)) {
                this.pendingSuggestions = SkyInit.getInstance().getCommandManager().getDispatcher()
                        .getCompletionSuggestions(this.parse, cursor);
                this.pendingSuggestions.thenRun(() -> {
                    if (this.pendingSuggestions.isDone()) {
                        this.showCommandSuggestions();
                    }
                });
            }

            ci.cancel();
        }
    }
}
