package sky.mixin.gui;

import net.minecraft.client.gui.hud.PlayerListHud;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import sky.module.visuals.BetterTab;

@Mixin(PlayerListHud.class)
public class PlayerListHudMixin {
    @ModifyConstant(method = "collectPlayerEntries", constant = @Constant(longValue = 80L), require = 0)
    private long skycore$maxListedPlayersLong(long original) {
        return listedPlayerLimit(original);
    }

    @ModifyConstant(method = "collectPlayerEntries", constant = @Constant(intValue = 80), require = 0)
    private int skycore$maxListedPlayersInt(int original) {
        return (int) listedPlayerLimit(original);
    }

    @ModifyConstant(method = "render", constant = @Constant(intValue = 20), require = 0)
    private int skycore$maxPlayersPerColumn(int original) {
        if (BetterTab.INSTANCE.isEnabled()) {
            return Math.max(1, Math.round(BetterTab.INSTANCE.maxPlayers.get()));
        }
        return original;
    }

    private long listedPlayerLimit(long original) {
        if (!BetterTab.INSTANCE.isEnabled()) {
            return original;
        }
        long rows = Math.max(1, Math.round(BetterTab.INSTANCE.maxPlayers.get()));
        long columns = Math.max(1, Math.round(BetterTab.INSTANCE.maxColumns.get()));
        return Math.max(original, rows * columns);
    }
}
