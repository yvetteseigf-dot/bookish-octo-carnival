package sky.mixin.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.ui.animation.EscPanelAnimation;

@Mixin(Screen.class)
public abstract class ScreenMixin {
    @Unique
    private boolean skycore$escMatrixPushed;

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/Screen;renderBackground(Lnet/minecraft/client/gui/DrawContext;IIF)V",
                    shift = At.Shift.AFTER
            )
    )
    private void skycore$escPanelAfterBg(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        skycore$escMatrixPushed = false;

        if (!((Object) this instanceof GameMenuScreen) || !Animations.effect(Animations.ESC_PANEL)) {
            return;
        }

        float offset = EscPanelAnimation.updateOffset();
        if (offset > 0.05F) {
            context.getMatrices().push();
            context.getMatrices().translate(0.0F, offset, 0.0F);
            skycore$escMatrixPushed = true;
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$escPanelTail(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (skycore$escMatrixPushed) {
            context.getMatrices().pop();
            skycore$escMatrixPushed = false;
        }
    }
}
