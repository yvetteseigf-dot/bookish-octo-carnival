package sky.mixin.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.Animations;
import sky.ui.animation.ChatLineAnimation;

import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;

@Mixin(ChatHud.class)
public abstract class ChatHudMixin {
    @Shadow
    @Final
    private MinecraftClient client;

    @Shadow
    @Final
    private List<ChatHudLine.Visible> visibleMessages;

    @Shadow
    private int scrolledLines;

    @Unique
    private Map<ChatHudLine.Visible, ChatLineAnimation> skycore$animators;

    @Unique
    private int skycore$renderIndex;

    @Shadow
    public abstract int getWidth();

    @Unique
    private Map<ChatHudLine.Visible, ChatLineAnimation> skycore$animators() {
        if (this.skycore$animators == null) {
            this.skycore$animators = new IdentityHashMap<>();
        }
        return this.skycore$animators;
    }

    @Unique
    private boolean skycore$chatAnim() {
        return Animations.effect(Animations.CHAT_SLIDE) || Animations.effect(Animations.CHAT_STACK);
    }

    @Unique
    private int skycore$lineHeight() {
        return (int) (9.0D * (this.client.options.getChatLineSpacing().getValue() + 1.0D));
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void skycore$chatRenderHead(
            DrawContext context,
            int currentTick,
            int mouseX,
            int mouseY,
            boolean focused,
            CallbackInfo ci
    ) {
        if (!this.skycore$chatAnim()) {
            return;
        }

        Map<ChatHudLine.Visible, ChatLineAnimation> map = this.skycore$animators();
        map.values().forEach(ChatLineAnimation::update);
        map.entrySet().removeIf(entry -> entry.getValue().isFinished());
        this.skycore$renderIndex = 0;
    }

    @Redirect(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;III)I"
            )
    )
    private int skycore$offsetChatText(
            DrawContext context,
            TextRenderer textRenderer,
            OrderedText text,
            int x,
            int y,
            int color
    ) {
        float ox = 0.0F;
        float oy = 0.0F;
        if (this.skycore$chatAnim()) {
            int index = this.skycore$renderIndex + this.scrolledLines;
            if (index >= 0 && index < this.visibleMessages.size()) {
                ChatLineAnimation animator = this.skycore$animators().get(this.visibleMessages.get(index));
                if (animator != null) {
                    if (Animations.effect(Animations.CHAT_SLIDE)) {
                        ox = animator.getX();
                    }
                    if (Animations.effect(Animations.CHAT_STACK)) {
                        oy = animator.getY();
                    }
                }
            }
            this.skycore$renderIndex++;
        }

        return context.drawTextWithShadow(textRenderer, text, x + Math.round(ox), y + Math.round(oy), color);
    }

    @Inject(
            method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
            at = @At("TAIL")
    )
    private void skycore$onChatMessage(
            Text message,
            MessageSignatureData signatureData,
            MessageIndicator indicator,
            CallbackInfo ci
    ) {
        if (!this.skycore$chatAnim() || this.visibleMessages.isEmpty()) {
            return;
        }

        long duration = 220L;
        int lineHeight = this.skycore$lineHeight();
        Map<ChatHudLine.Visible, ChatLineAnimation> map = this.skycore$animators();
        ChatHudLine.Visible newest = this.visibleMessages.get(0);
        if (Animations.effect(Animations.CHAT_STACK)) {
            for (Map.Entry<ChatHudLine.Visible, ChatLineAnimation> entry : map.entrySet()) {
                if (entry.getKey() != newest) {
                    entry.getValue().pushUp(lineHeight, duration);
                }
            }
        }

        if (!map.containsKey(newest)) {
            float startX = Animations.effect(Animations.CHAT_SLIDE) ? -this.getWidth() : 0.0F;
            map.put(newest, new ChatLineAnimation(startX, duration));
        }
    }

    @Inject(method = "clear", at = @At("HEAD"))
    private void skycore$clearChatAnim(boolean clearHistory, CallbackInfo ci) {
        if (this.skycore$animators != null) {
            this.skycore$animators.clear();
        }
    }
}
