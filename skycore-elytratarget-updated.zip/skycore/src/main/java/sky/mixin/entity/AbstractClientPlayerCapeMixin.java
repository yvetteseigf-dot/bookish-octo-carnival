package sky.mixin.entity;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.cape.CapeSimulationHolder;
import sky.model.CapePhysicsSimulation;

@Mixin(AbstractClientPlayerEntity.class)
public class AbstractClientPlayerCapeMixin implements CapeSimulationHolder {
    @Unique
    private final CapePhysicsSimulation skycore$simulation = new CapePhysicsSimulation();

    @Override
    public CapePhysicsSimulation getSimulation() {
        return skycore$simulation;
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void skycore$capeSimulate(CallbackInfo ci) {
        AbstractClientPlayerEntity player = (AbstractClientPlayerEntity) (Object) this;
        if (player.getWorld() == null || !(player instanceof ClientPlayerEntity)) {
            return;
        }
        this.updateSimulation(player, 16);
        this.simulate(player);
    }
}
