package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import sky.event.entity.FireworkRocketEntityTickEvent;

@Mixin(FireworkRocketEntity.class)
public abstract class FireworkRocketEntityMixin extends ProjectileEntity {
    @Unique
    private Vec3d rotation;

    @Unique
    private int skycore$fireworkAge;

    @Shadow
    private LivingEntity shooter;

    public FireworkRocketEntityMixin(EntityType<? extends ProjectileEntity> entityType, World world) {
        super(entityType, world);
    }

    @ModifyExpressionValue(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"
            )
    )
    public Vec3d skycore$captureRotation(Vec3d original) {
        this.rotation = original;
        return this.rotation;
    }

    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/math/Vec3d;add(DDD)Lnet/minecraft/util/math/Vec3d;",
                    ordinal = 0
            )
    )
    public Vec3d skycore$elytraBoost(Vec3d instance, double x, double y, double z) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean localGliding = this.shooter instanceof ClientPlayerEntity
                && client.player != null
                && this.shooter == client.player
                && client.player.isGliding();
        if (localGliding && this.rotation != null) {
            FireworkRocketEntityTickEvent event = new FireworkRocketEntityTickEvent(1.5F, 1.5F, this.skycore$fireworkAge++);
            EventManager.call(event);
            float speedXZ = event.getSpeed();
            float speedY = event.getYSpeed();
            return instance.add(
                    this.rotation.x * 0.1 + (this.rotation.x * speedXZ - instance.x) * 0.5,
                    this.rotation.y * 0.1 + (this.rotation.y * speedY - instance.y) * 0.5,
                    this.rotation.z * 0.1 + (this.rotation.z * speedXZ - instance.z) * 0.5
            );
        }

        this.skycore$fireworkAge = 0;
        return instance.add(x, y, z);
    }
}
