package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.event.entity.NoPushEvent;

@Mixin(FishingBobberEntity.class)
public abstract class FishingBobberEntityMixin {
    @Inject(method = "pullHookedEntity", at = @At("HEAD"), cancellable = true)
    private void skycore$pullHookedEntity(Entity entity, CallbackInfo ci) {
        if (entity != MinecraftClient.getInstance().player) {
            return;
        }

        NoPushEvent event = new NoPushEvent(NoPushEvent.NoPushType.FishingRod);
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }
}
