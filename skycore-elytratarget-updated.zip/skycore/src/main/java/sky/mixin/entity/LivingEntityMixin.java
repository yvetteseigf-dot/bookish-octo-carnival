package sky.mixin.entity;

import com.darkmagician6.eventapi.EventManager;
import java.util.Collections;
import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.access.MinecraftAccess;
import sky.access.SwingTimerAccess;
import sky.event.combat.ThornsDamageEvent;
import sky.event.entity.SwingSpeedEvent;
import sky.event.entity.JumpEvent;
import sky.event.entity.LivingUpdateEvent;
import sky.event.entity.TravelPostEvent;
import sky.event.entity.TravelEvent;
import sky.event.entity.LandingPredictEvent;
import sky.module.combat.AntiThorns;
import sky.util.MsTimer;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin implements MinecraftAccess, SwingTimerAccess {
    @Unique
    private static final List<VoxelShape> SKYCORE$EMPTY_COLLISIONS = Collections.emptyList();

    private final MsTimer skycore$lastSwing = new MsTimer();

    @Shadow
    protected abstract double getGravity();

    @Override
    public MsTimer skycore$getLastSwing() {
        return this.skycore$lastSwing;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void skycore$livingUpdate(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        EventManager.call(new LivingUpdateEvent());
    }

    @Inject(method = "jump", at = @At("HEAD"), cancellable = true)
    private void skycore$jump(CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        JumpEvent event = new JumpEvent();
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
        }
    }

    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void skycore$travel(Vec3d movementInput, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        TravelEvent event = new TravelEvent(self);
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
        }
    }

    @Inject(method = "travel", at = @At("RETURN"))
    private void skycore$travelPost(Vec3d movementInput, CallbackInfo ci) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        TravelPostEvent event = new TravelPostEvent(self.getVelocity());
        EventManager.call(event);
        self.setVelocity(event.getOldVelocity());

        if (!self.hasNoGravity()) {
            double gravity = this.getGravity();
            double dy2 = (self.getVelocity().y - gravity) * 0.98D;
            if (dy2 < 0.0D) {
                Vec3d attempt = new Vec3d(0.0D, dy2, 0.0D);
                Box box = self.getBoundingBox();
                Vec3d allowed = Entity.adjustMovementForCollisions(
                        self, attempt, box, self.getWorld(), SKYCORE$EMPTY_COLLISIONS);
                EventManager.call(new LandingPredictEvent(allowed.y != dy2));
            } else {
                EventManager.call(new LandingPredictEvent(false));
            }
        }
    }

    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void skycore$handSwingDuration(CallbackInfoReturnable<Integer> cir) {
        LivingEntity self = (LivingEntity) (Object) this;
        if (self != MinecraftClient.getInstance().player) {
            return;
        }

        Hand hand = self.handSwinging ? self.preferredHand : Hand.MAIN_HAND;
        SwingSpeedEvent event = new SwingSpeedEvent(6, hand);
        EventManager.call(event);
        if (event.isCancelled() || event.getSwipeSpeed() != 6) {
            cir.setReturnValue(Math.max(1, event.getSwipeSpeed()));
        }
    }

    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    private void skycore$antiThorns(
            ServerWorld world,
            DamageSource source,
            float amount,
            CallbackInfoReturnable<Boolean> cir
    ) {
        if (!((Object) this instanceof ClientPlayerEntity) || mc.player != (Object) this) {
            return;
        }

        if (!source.isOf(DamageTypes.THORNS)) {
            return;
        }

        AntiThorns antiThorns = AntiThorns.INSTANCE;
        if (!antiThorns.isEnabled()) {
            return;
        }

        Entity attacker = source.getAttacker();
        ThornsDamageEvent event =
                new ThornsDamageEvent(attacker, (LivingEntity) (Object) this, 0, amount);
        EventManager.call(event);
        if (event.isCancelled() || antiThorns.shouldCancelThornsDamage(attacker)) {
            cir.setReturnValue(false);
            cir.cancel();
        }
    }
}
