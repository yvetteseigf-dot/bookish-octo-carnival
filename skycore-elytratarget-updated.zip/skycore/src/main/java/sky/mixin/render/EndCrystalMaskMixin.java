package sky.mixin.render;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.state.EndCrystalEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.decoration.EndCrystalEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.CustomCrystal;

@Mixin(EndCrystalEntityRenderer.class)
public abstract class EndCrystalMaskMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void skycore$captureCrystalMask(
            EndCrystalEntityRenderState state,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        if (!CustomCrystal.INSTANCE.isEnabled() || CustomCrystal.INSTANCE.isRenderingMask()) {
            return;
        }

        if (vertexConsumers instanceof VertexConsumerProvider.Immediate immediate) {
            immediate.draw();
        }

        matrices.push();
        CustomCrystal.INSTANCE.applyTransform(matrices);
        CustomCrystal.INSTANCE.captureMask((EndCrystalEntityRenderer) (Object) this, state, matrices, light);
        matrices.pop();
        if (CustomCrystal.INSTANCE.shouldHideOriginal()) {
            ci.cancel();
        }
    }

    @Inject(method = "updateRenderState", at = @At("TAIL"))
    private void skycore$updateCrystalState(
            EndCrystalEntity entity,
            EndCrystalEntityRenderState state,
            float tickDelta,
            CallbackInfo ci
    ) {
        CustomCrystal.INSTANCE.observe(state, entity);
    }
}
