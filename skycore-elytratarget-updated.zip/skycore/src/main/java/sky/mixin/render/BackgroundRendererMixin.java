package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.Fog;
import net.minecraft.client.render.FogShape;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.render.FogColorEvent;
import sky.util.render.ColorUtil;
import sky.util.entity.NoRenderFilter;

@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {
    @Inject(method = "getFogModifier", at = @At("HEAD"), cancellable = true)
    private static void skycore$hideBadEffectFog(Entity entity, float tickDelta, CallbackInfoReturnable<?> cir) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.BAD_EFFECTS)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(method = "getFogColor", at = @At("HEAD"), cancellable = true)
    private static void skycore$getFogColor(
            Camera camera,
            float tickDelta,
            ClientWorld world,
            int clampedViewDistance,
            float skyDarkness,
            CallbackInfoReturnable<Vector4f> cir
    ) {
        FogColorEvent event = new FogColorEvent();
        EventManager.call(event);
        if (event.isCancel() && event.hasColor()) {
            int color = event.getColor();
            cir.setReturnValue(new Vector4f(
                    ColorUtil.redf(color),
                    ColorUtil.greenf(color),
                    ColorUtil.bluef(color),
                    ColorUtil.alphaf(color)
            ));
        }
    }

    @Inject(method = "applyFog", at = @At("HEAD"), cancellable = true)
    private static void skycore$applyFog(
            Camera camera,
            BackgroundRenderer.FogType fogType,
            Vector4f color,
            float viewDistance,
            boolean thickenFog,
            float tickDelta,
            CallbackInfoReturnable<Fog> cir
    ) {
        FogColorEvent event = new FogColorEvent();
        EventManager.call(event);
        if (event.isCancel()) {
            float red;
            float green;
            float blue;
            float alpha;
            if (event.hasColor()) {
                int fogColor = event.getColor();
                red = ColorUtil.redf(fogColor);
                green = ColorUtil.greenf(fogColor);
                blue = ColorUtil.bluef(fogColor);
                alpha = ColorUtil.alphaf(fogColor);
            } else {
                red = color.x;
                green = color.y;
                blue = color.z;
                alpha = color.w;
            }
            cir.setReturnValue(new Fog(
                    event.getStart(),
                    event.getDistance(),
                    FogShape.CYLINDER,
                    red,
                    green,
                    blue,
                    alpha
            ));
        }
    }
}
