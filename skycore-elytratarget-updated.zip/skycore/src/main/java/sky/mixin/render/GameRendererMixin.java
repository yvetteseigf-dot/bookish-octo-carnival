package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.debug.BlurDebugLogger;
import sky.theme.GuiTheme;
import sky.event.render.FirstPersonHandEvent;
import sky.event.render.GameRendererEvent;
import sky.event.render.ProjectionMatrixEvent;
import sky.event.render.RenderHandEvent;
import sky.event.render.RenderWorldEvent;
import sky.module.movement.FreeCamera;
import sky.module.visuals.CustomCrystal;
import sky.module.visuals.FogBlur;
import sky.render.framebuffer.BlurManager;
import sky.render.ProjectionMatrixCapture;
import sky.render.WorldDrawHelper;
import sky.render.shader.ShaderLibrary;
import sky.clickgui.GuiStyle;
import sky.util.entity.NoRenderFilter;

import java.util.function.Predicate;

@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Shadow
    private boolean renderHand;

    @Shadow
    private float zoom;

    @Shadow
    private float zoomX;

    @Shadow
    private float zoomY;

    @Unique
    private Perspective skycore$savedHandPerspective;

    @Shadow
    protected abstract float getFarPlaneDistance();

    @Inject(method = "getBasicProjectionMatrix", at = @At("TAIL"), cancellable = true)
    private void skycore$aspectRatio(float fov, CallbackInfoReturnable<Matrix4f> cir) {
        float nativeAspect = (float) MinecraftClient.getInstance().getWindow().getFramebufferWidth()
                / (float) MinecraftClient.getInstance().getWindow().getFramebufferHeight();
        ProjectionMatrixEvent event = new ProjectionMatrixEvent(nativeAspect);
        EventManager.call(event);
        if (!event.isCancelled()) {
            return;
        }
        Matrix4f matrix = new Matrix4f();
        if (this.zoom != 1.0F) {
            matrix.translate(this.zoomX, -this.zoomY, 0.0F);
            matrix.scale(this.zoom, this.zoom, 1.0F);
        }
        matrix.perspective(fov * 0.017453292F, event.getAspectRatio(), 0.05F, this.getFarPlaneDistance());
        cir.setReturnValue(matrix);
    }

    @Inject(method = "renderWorld", at = @At("HEAD"))
    private void skycore$beginCustomCrystalFrame(RenderTickCounter tickCounter, CallbackInfo ci) {
        CustomCrystal.INSTANCE.beginFrame();
    }

    @Inject(method = "renderWorld", at = @At("RETURN"))
    private void skycore$compositeCustomCrystalFrame(RenderTickCounter tickCounter, CallbackInfo ci) {
        CustomCrystal.INSTANCE.compositeFrame();
    }

    @Inject(method = "renderWorld", at = @At("RETURN"))
    private void skycore$captureClickGuiBlur(RenderTickCounter tickCounter, CallbackInfo ci) {
        if (!GuiTheme.theme.getGuiStyle().usesKawaseBlur()) {
            return;
        }
        BlurDebugLogger.log("GameRenderer", "captureBlur AFTER renderWorld (style=" + String.valueOf(GuiTheme.theme.getGuiStyle()) + ")");
        BlurDebugLogger.dumpGl("GameRenderer-before-update");
        ShaderLibrary.loadBlurShaders();
        BlurDebugLogger.log("GameRenderer", "shaders " + BlurDebugLogger.describeRegistryShader("blurred_round_rect")
                + " | " + BlurDebugLogger.describeKawasePrograms());
        GuiStyle style = GuiTheme.theme.getGuiStyle();
        if (style == GuiStyle.KAWASE) {
            BlurManager.BLUR.updateBlur(3.0F, 3);
        } else {
            BlurManager.BLUR.updateBlur(2.0F, 2);
        }
        BlurDebugLogger.log("GameRenderer", "after update " + BlurDebugLogger.describeKawase());
        BlurDebugLogger.dumpGl("GameRenderer-after-update");
    }

    @Inject(
            method = "renderWorld",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
                    opcode = 180,
                    ordinal = 0
            )
    )
    private void skycore$onWorldRender(
            RenderTickCounter tickCounter,
            CallbackInfo ci,
            @Local(ordinal = 2) Matrix4f matrix4f
    ) {
        ProjectionMatrixCapture.capture(
                new Matrix4f(RenderSystem.getProjectionMatrix()),
                new Matrix4f(matrix4f)
        );

        MatrixStack matrixStack = new MatrixStack();
        matrixStack.multiplyPositionMatrix(matrix4f);
        WorldDrawHelper.setLastProjMat(new Matrix4f(RenderSystem.getProjectionMatrix()));
        WorldDrawHelper.setLastModMat(new Matrix4f(RenderSystem.getModelViewMatrix()));
        WorldDrawHelper.setLastWorldSpaceMatrix(new Matrix4f(matrix4f));
        float tickDelta = tickCounter.getTickDelta(false);
        EventManager.call(new RenderWorldEvent(tickDelta, matrixStack));
        WorldDrawHelper.onEventRender3D(matrixStack);
        FogBlur.INSTANCE.process(this.getFarPlaneDistance());
    }

    @Redirect(
            method = "renderWorld",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
                    opcode = 180,
                    ordinal = 0
            )
    )
    private boolean skycore$forceRenderHandForFreeCamera(GameRenderer instance) {
        if (FreeCamera.INSTANCE.isEnabled() && FreeCamera.INSTANCE.isDetached()) {
            return true;
        }
        return this.renderHand;
    }

    @Inject(method = "renderHand", at = @At("HEAD"))
    private void skycore$renderHandPre(Camera camera, float tickDelta, Matrix4f matrix4f, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options == null) {
            return;
        }
        RenderHandEvent event = new RenderHandEvent(client.options.getPerspective().isFirstPerson());
        EventManager.call(event);
        EventManager.call(new FirstPersonHandEvent.Pre());
        if (event.isThirdperson()) {
            this.skycore$savedHandPerspective = client.options.getPerspective();
            if (this.skycore$savedHandPerspective != Perspective.FIRST_PERSON) {
                client.options.setPerspective(Perspective.FIRST_PERSON);
            }
        }
    }

    @Inject(method = "renderHand", at = @At("RETURN"))
    private void skycore$renderHandPost(Camera camera, float tickDelta, Matrix4f matrix4f, CallbackInfo ci) {
        EventManager.call(new FirstPersonHandEvent.Post());
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.skycore$savedHandPerspective != null && client.options != null) {
            client.options.setPerspective(this.skycore$savedHandPerspective);
            this.skycore$savedHandPerspective = null;
        }
    }

    @Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
    private void skycore$hideTotem(ItemStack stack, CallbackInfo ci) {
        if (NoRenderFilter.shouldCancel(NoRenderFilter.Type.TOTEM) && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            ci.cancel();
        }
    }

    @ModifyArg(
            method = "findCrosshairTarget",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/projectile/ProjectileUtil;raycast(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/EntityHitResult;"
            ),
            index = 4
    )
    private Predicate<Entity> skycore$modifyEntityPredicate(Predicate<Entity> original) {
        return entity -> {
            if (!original.test(entity)) {
                return false;
            }
            GameRendererEvent event = new GameRendererEvent(entity);
            EventManager.call(event);
            return !event.isCancelled();
        };
    }
}
