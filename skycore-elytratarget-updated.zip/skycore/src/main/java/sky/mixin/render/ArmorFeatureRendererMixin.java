package sky.mixin.render;

import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.feature.ArmorFeatureRenderer;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.access.MinecraftAccess;
import sky.model.CustomModelRenderer;

@Mixin(ArmorFeatureRenderer.class)
public abstract class ArmorFeatureRendererMixin implements MinecraftAccess {
    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/BipedEntityRenderState;FF)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$skipArmorForCustomModel(MatrixStack matrixStack, VertexConsumerProvider bufferIn,
                                                 int packedLightIn, BipedEntityRenderState state, float limbSwing,
                                                 float limbSwingAmount, CallbackInfo ci) {
        if (!(state instanceof PlayerEntityRenderState playerState) || mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(playerState.id);
        if (entity instanceof LivingEntity living && CustomModelRenderer.shouldApply(living)) {
            ci.cancel();
        }
    }
}
