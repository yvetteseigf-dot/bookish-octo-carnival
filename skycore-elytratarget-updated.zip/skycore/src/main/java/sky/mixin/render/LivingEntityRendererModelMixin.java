package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.access.MinecraftAccess;
import sky.event.render.ArmorLayerEvent;
import sky.model.CustomModelRenderer;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererModelMixin implements MinecraftAccess {
    @Shadow
    public abstract EntityModel<?> getModel();

    @Inject(
            method = "getRenderLayer(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;ZZZ)Lnet/minecraft/client/render/RenderLayer;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$hideVanillaPlayerModel(
            LivingEntityRenderState state,
            boolean showBody,
            boolean translucent,
            boolean showOutline,
            CallbackInfoReturnable<RenderLayer> cir
    ) {
        if (!((Object) this instanceof PlayerEntityRenderer)
                || !(state instanceof PlayerEntityRenderState playerState)
                || mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(playerState.id);
        if (entity instanceof LivingEntity living
                && CustomModelRenderer.shouldApply(living)
                && CustomModelRenderer.getTextureIdentifier() != null) {
            cir.setReturnValue(null);
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;pop()V",
                    ordinal = 0
            )
    )
    private void skycore$fireLayerHeadEvent(
            LivingEntityRenderState state,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        if (!(state instanceof PlayerEntityRenderState playerState) || mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(playerState.id);
        if (entity instanceof LivingEntity living) {
            EventManager.call(new ArmorLayerEvent(living, matrices, getModel()));
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;iterator()Ljava/util/Iterator;",
                    ordinal = 0
            )
    )
    private void skycore$renderCustomPlayerModel(
            LivingEntityRenderState state,
            MatrixStack matrices,
            VertexConsumerProvider vertexConsumers,
            int light,
            CallbackInfo ci
    ) {
        if (!((Object) this instanceof PlayerEntityRenderer)
                || !(state instanceof PlayerEntityRenderState playerState)
                || mc.world == null) {
            return;
        }

        Entity entity = mc.world.getEntityById(playerState.id);
        if (!(entity instanceof LivingEntity living) || !CustomModelRenderer.shouldApply(living)) {
            return;
        }

        Identifier texture = CustomModelRenderer.getTextureIdentifier();
        if (texture == null) {
            return;
        }

        EntityModel<?> model = getModel();
        if (!(model instanceof BipedEntityModel<?> bipedModel)) {
            return;
        }

        RenderLayer layer = RenderLayer.getEntityCutoutNoCull(texture);
        VertexConsumer consumer = vertexConsumers.getBuffer(layer);
        int overlay = LivingEntityRenderer.getOverlay(state, 0.0F);
        CustomModelRenderer.renderCustomModel(bipedModel, matrices, consumer, light, overlay, -1);
    }
}
