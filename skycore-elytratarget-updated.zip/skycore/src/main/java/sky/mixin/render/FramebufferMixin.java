package sky.mixin.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.Framebuffer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.module.visuals.CustomCrystal;
import sky.render.framebuffer.AutoResizingFramebuffer;

@Mixin(Framebuffer.class)
public abstract class FramebufferMixin {
    @Inject(method = "beginWrite", at = @At("HEAD"), cancellable = true)
    private void skycore$redirectCrystalMaskCapture(boolean setViewport, CallbackInfo ci) {
        if (!CustomCrystal.INSTANCE.isRenderingMask()) {
            return;
        }
        AutoResizingFramebuffer mask = CustomCrystal.INSTANCE.getActiveCaptureMask();
        if (mask == null) {
            return;
        }
        Framebuffer self = (Framebuffer) (Object) this;
        if (self != MinecraftClient.getInstance().getFramebuffer()) {
            return;
        }
        mask.beginWrite(setViewport);
        ci.cancel();
    }
}
