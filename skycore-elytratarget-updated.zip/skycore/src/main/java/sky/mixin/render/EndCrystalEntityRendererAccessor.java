package sky.mixin.render;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.EndCrystalEntityRenderer;
import net.minecraft.client.render.entity.model.EndCrystalEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(EndCrystalEntityRenderer.class)
public interface EndCrystalEntityRendererAccessor {
    @Accessor("model")
    EndCrystalEntityModel skycore$getModel();

    @Accessor("END_CRYSTAL")
    static RenderLayer skycore$getEndCrystalLayer() {
        throw new AssertionError();
    }
}
