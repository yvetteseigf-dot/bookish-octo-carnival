package sky.mixin.render;

import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.render.AmbienceSkyRenderer;

@Mixin(SkyRendering.class)
public class SkyRenderingMixin {
    @Inject(method = "renderSky", at = @At("HEAD"), cancellable = true)
    private void skycore$replaceVanillaSky(float red, float green, float blue, CallbackInfo ci) {
        if (!AmbienceSkyRenderer.shouldReplaceVanillaSky()) {
            return;
        }

        try {
            AmbienceSkyRenderer.renderSky(red, green, blue, new MatrixStack());
            ci.cancel();
        } catch (Throwable ignored) {
        }
    }
}
