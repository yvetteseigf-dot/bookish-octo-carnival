package sky.mixin.render;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.render.FovEvent;

@Mixin(GameRenderer.class)
public abstract class GameRendererFovMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void skycore$modifyFov(Camera camera, float tickDelta, boolean changingFov, CallbackInfoReturnable<Float> cir) {
        float vanilla = cir.getReturnValueF();
        int fovInt = Math.round(vanilla);
        FovEvent event = new FovEvent(fovInt);
        EventManager.call(event);
        if (event.isCancelled() || event.getFov() != fovInt) {
            cir.setReturnValue(Math.min(150.0F, event.getFov()));
        }
    }
}
