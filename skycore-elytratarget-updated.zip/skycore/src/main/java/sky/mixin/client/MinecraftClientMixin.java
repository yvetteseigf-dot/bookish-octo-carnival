package sky.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.RunArgs;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.SkyClientInit;
import sky.cape.CapeSimulationHolder;
import sky.event.player.ItemUseEvent;
import sky.event.player.RotationTickEvent;
import sky.event.input.HandleInputEvent;
import sky.event.render.GameLoopEvent;
import sky.model.CapePhysicsSimulation;
import sky.render.HudProjectionManager;
import sky.render.DrawHelper;
import sky.screen.MainMenuScreen;
import sky.ui.animation.InventoryCloseAnimation;
import sky.util.network.TickRotationSync;

@Mixin(MinecraftClient.class)
public class MinecraftClientMixin {
    @Unique
    private long lastHookTime = Util.getMeasuringTimeNano();

    @Unique
    private int accumulatedCalls = 0;

    @Inject(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/debug/DebugRenderer;<init>(Lnet/minecraft/client/MinecraftClient;)V"
            )
    )
    private void skycore$initRendering(RunArgs args, CallbackInfo ci) {
        SkyClientInit.initRendering();
    }

    @Inject(method = "doItemUse", at = @At("HEAD"), cancellable = true)
    private void skycore$doItemUse(CallbackInfo ci) {
        ItemUseEvent event = new ItemUseEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            ci.cancel();
        }
    }

    @Inject(method = "render", at = @At("HEAD"))
    private void skycore$gameUpdate(boolean tick, CallbackInfo ci) {
        long now = Util.getMeasuringTimeNano();
        long delta = now - lastHookTime;

        accumulatedCalls += (int) (delta / 4166666L);
        lastHookTime += (long) accumulatedCalls * 4166666L;
        accumulatedCalls = Math.min(accumulatedCalls, 65);

        while (accumulatedCalls > 0) {
            EventManager.call(new GameLoopEvent());
            accumulatedCalls--;
        }
    }

    @Inject(method = "setScreen", at = @At("HEAD"), cancellable = true)
    private void skycore$inventoryCloseAnim(Screen screen, CallbackInfo ci) {
        MinecraftClient self = (MinecraftClient) (Object) this;
        if (InventoryCloseAnimation.tryBeginClose(self.currentScreen, screen)) {
            ci.cancel();
        }
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void skycore$clearOrphanHandledScreen(CallbackInfo ci) {
        MinecraftClient self = (MinecraftClient) (Object) this;
        if (self.player == null && self.currentScreen instanceof HandledScreen<?>) {
            InventoryCloseAnimation.cancel();
            self.setScreen(null);
        }
        EventManager.call(new RotationTickEvent());
        TickRotationSync.captureFromPlayer();
    }

    @Inject(method = "setScreen", at = @At("TAIL"))
    private void skycore$prepareMainMenuScreen(Screen screen, CallbackInfo ci) {
        HudProjectionManager.forceEnd();
        if (screen instanceof MainMenuScreen) {
            DrawHelper.ensureMainFramebuffer();
        }
    }

    @Inject(method = "render", at = @At("RETURN"))
    private void skycore$resetRenderState(boolean tick, CallbackInfo ci) {
        InventoryCloseAnimation.endFrame();
        if (HudProjectionManager.isActive()) {
            HudProjectionManager.forceEnd();
        }
    }

    @Redirect(
            method = "handleInputEvents",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/option/GameOptions;setPerspective(Lnet/minecraft/client/option/Perspective;)V"
            )
    )
    private void skycore$setPerspective(GameOptions options, Perspective perspective) {
        HandleInputEvent event = new HandleInputEvent();
        EventManager.call(event);
        if (event.isCancelled()) {
            return;
        }

        options.setPerspective(perspective);

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player instanceof AbstractClientPlayerEntity player) {
            CapePhysicsSimulation simulation = ((CapeSimulationHolder) player).getSimulation();
            if (simulation != null) {
                simulation.points.clear();
                simulation.sticks.clear();
                simulation.init(16);
            }
        }
    }
}
