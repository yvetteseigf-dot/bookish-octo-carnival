package sky.mixin.client;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.math.Smoother;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.config.BindCapture;
import sky.hud.HudManager;
import sky.event.input.KeyInputEvent;
import sky.event.input.MouseUpdateMouseEvent;
import sky.hud.HudEditor;
import sky.util.render.HudScaleUtil;

@Mixin(Mouse.class)
public class MouseMixin {
    @Shadow @Final private MinecraftClient client;
    @Shadow private double cursorDeltaX;
    @Shadow private double cursorDeltaY;
    @Shadow private Smoother cursorXSmoother;
    @Shadow private Smoother cursorYSmoother;

    @Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
    private void skycore$onMouseButtonHead(long window, int button, int action, int mods, CallbackInfo ci) {
        if (window != client.getWindow().getHandle()) {
            return;
        }

        if (BindCapture.hasActive() && action == 1 && button >= 0) {
            BindCapture.applyKey(button);
            ci.cancel();
            return;
        }

        if (action == 1) {
            double[] mouse = HudScaleUtil.getScaledMouse();
            if (HudManager.getInstance().watermark.handleMouseClicked(mouse[0], mouse[1], button)) {
                ci.cancel();
                return;
            }
        }

        if (button != -1 && !BindCapture.hasActive() && !(client.currentScreen instanceof ChatScreen)) {
            EventManager.call(new KeyInputEvent(button, action == 1));
        }
    }

    @Inject(method = "onMouseButton", at = @At("TAIL"))
    private void skycore$onMouseButtonTail(long window, int button, int action, int mods, CallbackInfo ci) {
        HudEditor.getInstance().onMouseButton(button, action);
    }

    @Inject(method = "updateMouse", at = @At("HEAD"), cancellable = true)
    private void skycore$updateMouse(double timeDelta, CallbackInfo ci) {
        if (client.player == null) {
            return;
        }

        double sensitivity = ((Double) client.options.getMouseSensitivity().getValue()) * 0.6D + 0.2D;
        double scaled = sensitivity * sensitivity * sensitivity * 8.0D;
        double deltaX;
        double deltaY;

        if (client.options.smoothCameraEnabled) {
            deltaX = cursorXSmoother.smooth(cursorDeltaX * scaled, timeDelta * scaled);
            deltaY = cursorYSmoother.smooth(cursorDeltaY * scaled, timeDelta * scaled);
        } else if (client.options.getPerspective().isFirstPerson() && client.player.isUsingSpyglass()) {
            cursorXSmoother.clear();
            cursorYSmoother.clear();
            deltaX = cursorDeltaX * sensitivity * sensitivity * sensitivity;
            deltaY = cursorDeltaY * sensitivity * sensitivity * sensitivity;
        } else {
            cursorXSmoother.clear();
            cursorYSmoother.clear();
            deltaX = cursorDeltaX * scaled;
            deltaY = cursorDeltaY * scaled;
        }

        int invert = ((Boolean) client.options.getInvertYMouse().getValue()) ? -1 : 1;
        MouseUpdateMouseEvent event = new MouseUpdateMouseEvent(deltaX, deltaY * invert);
        EventManager.call(event);

        if (!event.isCancelled()) {
            client.getTutorialManager().onUpdateMouse(event.getYaw(), event.getPitch());
            client.player.changeLookDirection(event.getYaw(), event.getPitch());
        }

        cursorDeltaX = 0.0D;
        cursorDeltaY = 0.0D;
        ci.cancel();
    }
}
