package sky.mixin.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientSessionAccessor {
    @Mutable
    @Accessor("session")
    void skycore$setSession(Session session);

    @Accessor("itemUseCooldown")
    void skycore$setItemUseCooldown(int cooldown);
}
