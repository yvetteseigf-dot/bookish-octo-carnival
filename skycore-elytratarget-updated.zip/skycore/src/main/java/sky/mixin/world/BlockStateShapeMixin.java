package sky.mixin.world;

import com.darkmagician6.eventapi.EventManager;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import sky.event.world.BlockCollideShapeEvent;

@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BlockStateShapeMixin {
    @Inject(
            method = "getCollisionShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$collisionShape(BlockView world, BlockPos pos, ShapeContext context,
                                        CallbackInfoReturnable<VoxelShape> cir) {
        BlockCollideShapeEvent event =
                new BlockCollideShapeEvent(pos);
        EventManager.call(event);
        if (event.getVoxelShape() != null) {
            cir.setReturnValue(event.getVoxelShape());
        } else if (event.isCancelled()) {
            cir.setReturnValue(VoxelShapes.empty());
        }
    }

    @Inject(method = "getRaycastShape", at = @At("HEAD"), cancellable = true)
    private void skycore$raycastShape(BlockView world, BlockPos pos, CallbackInfoReturnable<VoxelShape> cir) {
        BlockCollideShapeEvent event =
                new BlockCollideShapeEvent(pos);
        EventManager.call(event);
        if (event.isCancelled()) {
            cir.setReturnValue(VoxelShapes.empty());
        }
    }

    @Inject(
            method = "getOutlineShape(Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/block/ShapeContext;)Lnet/minecraft/util/shape/VoxelShape;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$outlineShape(BlockView world, BlockPos pos, ShapeContext context,
                                      CallbackInfoReturnable<VoxelShape> cir) {
        BlockCollideShapeEvent event =
                new BlockCollideShapeEvent(pos);
        EventManager.call(event);
        if (event.isCancelled()) {
            cir.setReturnValue(VoxelShapes.empty());
        }
    }
}
