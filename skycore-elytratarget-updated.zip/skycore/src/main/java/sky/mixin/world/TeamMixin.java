package sky.mixin.world;

import net.minecraft.client.MinecraftClient;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import sky.module.misc.NameProtect;
import sky.util.text.TextUtil;

@Mixin(Team.class)
public class TeamMixin {
    @ModifyArg(
            method = "decorateName(Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/text/MutableText;append(Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;",
                    ordinal = 0
            ),
            index = 0
    )
    private Text skycore$decorateName(Text original) {
        if (MinecraftClient.getInstance().player == null || original == null) {
            return original;
        }

        String source = original.getString();
        String replaced = NameProtect.getCustomName(source);
        if (source.equals(replaced)) {
            return original;
        }

        return TextUtil.replaceLiteral(original, source, replaced);
    }
}
