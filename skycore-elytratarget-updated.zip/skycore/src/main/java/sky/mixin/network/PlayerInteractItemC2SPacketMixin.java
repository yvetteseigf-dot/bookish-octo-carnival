package sky.mixin.network;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.util.network.TickRotationSync;

@Mixin(PlayerInteractItemC2SPacket.class)
public abstract class PlayerInteractItemC2SPacketMixin {
    @Shadow
    @Final
    @Mutable
    private int sequence;

    @Shadow
    @Final
    @Mutable
    private float yaw;

    @Shadow
    @Final
    @Mutable
    private float pitch;

    @Inject(method = "<init>(Lnet/minecraft/util/Hand;IFF)V", at = @At("RETURN"))
    private void skycore$syncRotation(
            Hand hand, int sequence, float yaw, float pitch, CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (this.sequence == 0 && client.world != null) {
            PendingUpdateManager pending = client.world.getPendingUpdateManager().incrementSequence();
            try {
                this.sequence = pending.getSequence();
            } finally {
                pending.close();
            }
        }
        if (!TickRotationSync.isCaptured() || client.player == null) {
            return;
        }
        if (!client.player.isGliding()) {
            return;
        }
        this.yaw = TickRotationSync.yaw();
        this.pitch = TickRotationSync.pitch();
    }
}
