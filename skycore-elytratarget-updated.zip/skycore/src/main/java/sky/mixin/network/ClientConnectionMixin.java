package sky.mixin.network;

import com.darkmagician6.eventapi.EventManager;
import io.netty.channel.ChannelHandlerContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import sky.session.SilentPacketUtil;
import sky.event.network.PacketSendEvent;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {
    @Inject(
            method = "send(Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$onSendPacket(Packet<?> packet, CallbackInfo ci) {
        if (SilentPacketUtil.consumeSilent(packet)) {
            skycore$syncSelectedSlot(packet);
            return;
        }

        PacketSendEvent event = new PacketSendEvent(
                packet,
                PacketSendEvent.PacketType.SEND
        );
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
            return;
        }
        skycore$syncSelectedSlot(packet);
    }

    @Inject(
            method = "channelRead0(Lio/netty/channel/ChannelHandlerContext;Lnet/minecraft/network/packet/Packet;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void skycore$onReceivePacket(ChannelHandlerContext context, Packet<?> packet, CallbackInfo ci) {
        PacketSendEvent event = new PacketSendEvent(
                packet,
                PacketSendEvent.PacketType.RECEIVE
        );
        EventManager.call(event);
        if (event.isCancel()) {
            ci.cancel();
        }
    }

    @Unique
    private void skycore$syncSelectedSlot(Packet<?> packet) {
        if (!(packet instanceof UpdateSelectedSlotC2SPacket slotPacket)) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.interactionManager == null) {
            return;
        }
        ((ClientPlayerInteractionManagerAccessor) client.interactionManager)
                .skycore$setLastSelectedSlot(slotPacket.getSelectedSlot());
    }
}
