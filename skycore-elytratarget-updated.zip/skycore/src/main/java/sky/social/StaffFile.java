package sky.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import sky.config.AbstractConfigFile;
import sky.config.ClientPaths;

/** Persisted staff-name list, accepting both historic string and object entries. */
public final class StaffFile extends AbstractConfigFile<List<StaffFile.StaffEntry>> {
    public StaffFile() {
        super(ClientPaths.STAFF_FILE_REL, false);
    }

    public List<StaffEntry> getStaff() {
        return new ArrayList<>(data);
    }

    public void removeStaff(String name) {
        remove(name);
    }

    public boolean contains(String name) {
        return isStaff(name);
    }

    public boolean remove(String name) {
        if (name == null) {
            return false;
        }
        boolean removed = data.removeIf(staff -> staff.getName().equalsIgnoreCase(name.trim()));
        if (removed) {
            save();
        }
        return removed;
    }

    public boolean isStaff(String name) {
        if (name == null) {
            return false;
        }
        String normalized = name.trim();
        return data.stream().anyMatch(staff -> staff.getName().equalsIgnoreCase(normalized));
    }

    public void clearStaff() {
        if (!data.isEmpty()) {
            data.clear();
            save();
        }
    }

    public void clear() {
        clearStaff();
    }

    private void loadProperty(JsonObject object, String property, Consumer<JsonElement> consumer) {
        JsonElement element = object.get(property);
        if (element != null && !element.isJsonNull()) {
            consumer.accept(element);
        }
    }

    public Collection<String> getItems() {
        List<String> names = new ArrayList<>(data.size());
        for (StaffEntry staff : data) {
            names.add(staff.getName());
        }
        return Collections.unmodifiableList(names);
    }

    @Override
    protected void initializeData() {
        data = new ArrayList<>();
    }

    public void addStaff(String name) {
        if (name == null || name.trim().isEmpty()) {
            return;
        }
        String normalized = name.trim();
        if (!isStaff(normalized)) {
            data.add(new StaffEntry(normalized));
            save();
        }
    }

    public void add(String name) {
        addStaff(name);
    }

    @Override
    protected void deserializeData(JsonObject object) {
        data.clear();
        JsonArray staff = object.getAsJsonArray("staff");
        if (staff == null) {
            return;
        }
        for (JsonElement element : staff) {
            if (element.isJsonPrimitive()) {
                String name = element.getAsString();
                if (name != null && !name.isBlank()) {
                    data.add(new StaffEntry(name.trim()));
                }
            } else if (element.isJsonObject()) {
                loadProperty(element.getAsJsonObject(), "name", name -> {
                    String text = name.getAsString();
                    if (text != null && !text.isBlank()) {
                        data.add(new StaffEntry(text.trim()));
                    }
                });
            }
        }
    }

    @Override
    protected void handleLoadError(Exception exception) {
        if (data == null) {
            initializeData();
        }
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        JsonArray staff = new JsonArray();
        for (StaffEntry entry : data) {
            staff.add(new JsonPrimitive(entry.getName()));
        }
        object.add("staff", staff);
        return object;
    }

    public static final class StaffEntry {
        private final String name;

        public StaffEntry(String name) {
            this.name = name;
        }

        public String getName() {
            return name;
        }
    }
}
