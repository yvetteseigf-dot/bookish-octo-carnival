package sky.social;

import net.minecraft.text.Text;

import java.util.Objects;

public final class StaffPlayer {
    private final Text prefix;
    private final String name;
    private final boolean vanished;

    public StaffPlayer(String name, Text prefix, boolean vanished) {
        this.name = name;
        this.prefix = prefix == null ? Text.empty() : prefix;
        this.vanished = vanished;
    }

    public String getName() {
        return name;
    }

    public Text getPrefix() {
        return prefix;
    }

    public boolean isVanished() {
        return vanished;
    }

    @Override
    public boolean equals(Object object) {
        return object == this || object instanceof StaffPlayer other && Objects.equals(name, other.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
