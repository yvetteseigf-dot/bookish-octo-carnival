package sky.social;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import sky.config.AbstractConfigFile;
import sky.config.ClientPaths;

/** Persisted friends list, including the time each entry was added. */
public final class FriendsFile extends AbstractConfigFile<List<FriendsFile.FriendEntry>> {
    public FriendsFile() {
        super(ClientPaths.FRIENDS_FILE_REL);
    }

    public boolean isFriend(String name) {
        return name != null && data.stream().anyMatch(friend -> friend.getName().equalsIgnoreCase(name.trim()));
    }

    @Override
    protected void initializeData() {
        data = new ArrayList<>();
    }

    private void loadProperty(JsonObject object, String property, Consumer<JsonElement> consumer) {
        JsonElement element = object.get(property);
        if (element != null && !element.isJsonNull()) {
            consumer.accept(element);
        }
    }

    @Override
    protected JsonObject serializeData() {
        JsonObject object = new JsonObject();
        JsonArray friends = new JsonArray();
        for (FriendEntry friend : data) {
            JsonObject value = new JsonObject();
            value.addProperty("name", friend.getName());
            value.addProperty("addedTime", friend.getAddedTime().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
            friends.add(value);
        }
        object.add("friends", friends);
        return object;
    }

    public void add(String name) {
        addFriend(name);
    }

    public void clearFriends() {
        if (!data.isEmpty()) {
            data.clear();
            save();
        }
    }

    @Override
    protected void deserializeData(JsonObject object) {
        data.clear();
        if (!object.has("friends")) {
            return;
        }
        JsonArray friends = object.getAsJsonArray("friends");
        if (friends == null) {
            return;
        }
        for (JsonElement element : friends) {
            if (!element.isJsonObject()) {
                continue;
            }
            JsonObject value = element.getAsJsonObject();
            loadProperty(value, "name", name -> loadProperty(value, "addedTime", addedTime -> {
                try {
                    data.add(new FriendEntry(
                            name.getAsString(),
                            LocalDateTime.parse(addedTime.getAsString(), DateTimeFormatter.ISO_LOCAL_DATE_TIME)
                    ));
                } catch (Exception exception) {
                    System.err.println("Could not load friend entry: " + exception.getMessage());
                }
            }));
        }
    }

    public void removeFriend(String name) {
        if (name == null) {
            return;
        }
        if (data.removeIf(friend -> friend.getName().equalsIgnoreCase(name.trim()))) {
            save();
        }
    }

    public List<FriendEntry> getFriends() {
        return new ArrayList<>(data);
    }

    @Override
    protected void handleLoadError(Exception exception) {
        if (data == null) {
            initializeData();
        }
    }

    public Collection<String> getItems() {
        List<String> names = data.stream().map(FriendEntry::getName).toList();
        return Collections.unmodifiableList(names);
    }

    public void addFriend(String name) {
        if (name == null || name.trim().isEmpty()) {
            return;
        }
        String normalized = name.trim();
        if (!isFriend(normalized)) {
            data.add(new FriendEntry(normalized, LocalDateTime.now()));
            save();
        }
    }

    public static final class FriendEntry {
        private final String name;
        private final LocalDateTime addedTime;

        public FriendEntry(String name, LocalDateTime addedTime) {
            this.name = name;
            this.addedTime = addedTime;
        }

        public LocalDateTime getAddedTime() {
            return addedTime;
        }

        @Override
        public String toString() {
            return name + " (" + addedTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME) + ")";
        }

        public String getName() {
            return name;
        }
    }
}
