package sky.social;

import com.darkmagician6.eventapi.EventManager;
import com.darkmagician6.eventapi.EventTarget;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import sky.SkyInit;
import sky.event.player.PlayerUpdateEvent;
import sky.module.visuals.Interface;
import sky.access.MinecraftAccess;

/** Tracks which players on the current server are staff, including ones hidden from the tab list. */
public final class StaffManager implements MinecraftAccess {
    private static final StaffManager INSTANCE = new StaffManager();
    private static final Locale LOCALE = Locale.ROOT;
    private static final Pattern NAME_PATTERN = Pattern.compile("^\\w{3,16}$");
    private static final String[] DONATION_SYMBOLS = {"ꔅ", "ꔉ", "ꔓ", "ꔗ", "ꔡ", "ꔥ", "ꔩ", "ꔳ", "ꔷ"};
    private static final Set<String> HARDCODED_STAFF = Set.of(
            "NimuvaM",
            "N0RK",
            "tipok12k",
            "mist1kman",
            "xproblemaxq",
            "repaction",
            "ovs9nka",
            "lash1k_",
            "vilkaaa",
            "alles_fur_dich",
            "vzrivatelpiva",
            "MelissAZeRo_",
            "MsTank",
            "palpemambo",
            "6ubaa",
            "NebesniyDemon_",
            "Boss_kPOC",
            "Melankholia",
            "Flower_lll",
            "TrapJoker",
            "SaskeIzNaruto",
            "Zloy__banan4ik",
            "Kramas",
            "DiraMan",
            "Kotikk_01",
            "MoonLight",
            "maviushka",
            "InfinityDeath",
            "MrDomer",
            "XenTai4IK",
            "meowikis",
            "Mari0netka4iter",
            "3lobiy_Geniy",
            "dixenRW",
            "O_Komary_O",
            "Zwiex",
            "MineFix909",
            "vmbill",
            "trapshark");

    private final List<StaffPlayer> staff = new ArrayList<>();

    private StaffManager() {
        EventManager.register(this);
    }

    public static StaffManager getInstance() {
        return INSTANCE;
    }

    @EventTarget
    public void onUpdate(PlayerUpdateEvent event) {
        if (mc.player == null || mc.world == null) {
            return;
        }
        if ((mc.player.age & 9) != 0) {
            return;
        }
        if (!shouldUpdate()) {
            return;
        }
        update();
    }

    public void update() {
        List<StaffPlayer> online = getOnlineStaff();
        List<StaffPlayer> vanished = getVanishedStaff();
        online.sort(Comparator.comparing(StaffPlayer::getName, String.CASE_INSENSITIVE_ORDER));
        vanished.sort(Comparator.comparing(StaffPlayer::getName, String.CASE_INSENSITIVE_ORDER));
        synchronized (staff) {
            staff.clear();
            staff.addAll(online);
            staff.addAll(vanished);
        }
    }

    public List<StaffPlayer> getStaff() {
        synchronized (staff) {
            return List.copyOf(staff);
        }
    }

    public List<StaffPlayer> getVanishedStaff() {
        if (mc.world == null || mc.getNetworkHandler() == null) {
            return Collections.emptyList();
        }

        Set<String> visibleNames = mc.getNetworkHandler().getPlayerList().stream()
                .filter(Objects::nonNull)
                .map(entry -> entry.getProfile().getName())
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        Scoreboard scoreboard = mc.world.getScoreboard();
        List<StaffPlayer> vanished = new ArrayList<>();
        List<Team> teams = scoreboard.getTeams().stream()
                .sorted(Comparator.comparing(Team::getName))
                .toList();
        for (Team team : teams) {
            String name = team.getPlayerList().stream().findFirst().orElse(null);
            if (name == null || !NAME_PATTERN.matcher(name).matches()) {
                continue;
            }
            if (visibleNames.contains(name)) {
                continue;
            }
            String displayName = team.getDisplayName().getString().trim();
            if (displayName.startsWith("npc")
                    || displayName.startsWith("collideRule_")
                    || displayName.startsWith("FS_")
                    || displayName.startsWith("STAFF-")
                    || displayName.startsWith("HELPER-")
                    || displayName.startsWith("ADMIN-")
                    || displayName.startsWith("MODER-")) {
                continue;
            }
            Text prefix = team.getPrefix();
            if (isStaffPrefix(prefix.getString()) || HARDCODED_STAFF.contains(name)) {
                vanished.add(new StaffPlayer(name, prefix, true));
            }
        }
        return vanished;
    }

    private List<StaffPlayer> getOnlineStaff() {
        if (mc.world == null || mc.getNetworkHandler() == null) {
            return Collections.emptyList();
        }

        Set<String> trackedNames = SkyInit.getInstance().getStaffManager().getStaff().stream()
                .map(entry -> entry.getName())
                .filter(Objects::nonNull)
                .map(name -> name.toLowerCase(LOCALE))
                .collect(Collectors.toSet());

        List<StaffPlayer> online = new ArrayList<>();
        for (PlayerListEntry listEntry : mc.getNetworkHandler().getPlayerList()) {
            if (listEntry == null) {
                continue;
            }
            if (listEntry.getProfile() == null) {
                continue;
            }
            String name = listEntry.getProfile().getName();
            if (name == null) {
                continue;
            }

            Text prefix = Text.empty();
            for (Team team : mc.world.getScoreboard().getTeams()) {
                if (team.getPlayerList().contains(name)) {
                    prefix = team.getPrefix();
                    break;
                }
            }

            Text displayName = listEntry.getDisplayName();
            boolean donator = displayName != null && containsDonationSymbol(displayName.getString().trim());
            if (trackedNames.contains(name.toLowerCase(LOCALE))
                    || isStaffPrefix(prefix.getString())
                    || donator
                    || HARDCODED_STAFF.contains(name)) {
                online.add(new StaffPlayer(name, prefix, false));
            }
        }
        return online;
    }

    private boolean shouldUpdate() {
        return Interface.INSTANCE.isEnabled() && Interface.INSTANCE.isStaffListEnabled();
    }

    private static boolean isStaffPrefix(String prefix) {
        String stripped = Formatting.strip(prefix);
        if (stripped == null || stripped.isEmpty()) {
            return false;
        }
        stripped = stripped.toLowerCase(LOCALE);
        // Server tab-prefix stems (Russian staff ranks must match scoreboard text)
        return stripped.contains("helper")
                || stripped.contains("moder")
                || stripped.contains("admin")
                || stripped.contains("curator")
                || stripped.contains("builder")
                || stripped.contains("yt")
                || stripped.contains("кур")
                || stripped.contains("тех.админ")
                || stripped.contains("s.kurator")
                || stripped.contains("поддержка")
                || stripped.contains("сотруд")
                || containsDonationSymbol(stripped);
    }

    private static boolean containsDonationSymbol(String value) {
        if (value == null) {
            return false;
        }
        for (String symbol : DONATION_SYMBOLS) {
            if (value.contains(symbol)) {
                return true;
            }
        }
        return false;
    }
}
