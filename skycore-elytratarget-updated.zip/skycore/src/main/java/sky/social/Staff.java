package sky.social;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.command.CommandSource;
import sky.SkyInit;
import sky.util.text.CommandFeedback;
import sky.command.Command;
import sky.command.PlayerArgumentType;
import sky.command.StaffArgumentType;

public final class Staff extends Command {
    public Staff() {
        super("staff");
    }

    @Override
    public void execute(LiteralArgumentBuilder<CommandSource> builder) {
        builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes(context -> {
            String player = context.getArgument("player", String.class);
            if (SkyInit.getInstance().getStaffManager().contains(player)) {
                CommandFeedback.displayInfo("Already added " + player);
            } else {
                SkyInit.getInstance().getStaffManager().add(player);
                StaffManager.getInstance().update();
                CommandFeedback.displayInfo("Added " + player);
            }
            return 1;
        })));

        builder.then(literal("remove").then(arg("player", StaffArgumentType.create()).executes(context -> {
            String player = context.getArgument("player", String.class);
            SkyInit.getInstance().getStaffManager().remove(player);
            StaffManager.getInstance().update();
            CommandFeedback.displayInfo(player + " removed from staff");
            return 1;
        })));

        builder.then(literal("list").executes(context -> {
            CommandFeedback.displayInfo(SkyInit.getInstance().getStaffManager().getItems().toString());
            return 1;
        }));

        builder.then(literal("clear").executes(context -> {
            SkyInit.getInstance().getStaffManager().clear();
            StaffManager.getInstance().update();
            CommandFeedback.displayInfo("Staff list cleared");
            return 1;
        }));
    }
}
