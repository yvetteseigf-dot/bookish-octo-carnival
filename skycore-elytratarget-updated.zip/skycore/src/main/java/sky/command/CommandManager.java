package sky.command;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommandSource;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.command.CommandSource;

import java.util.ArrayList;
import java.util.List;
import sky.config.Bind;
import sky.config.Cfg;
import sky.macro.Macro;
import sky.misc.Neuro;
import sky.session.Rct;
import sky.session.Vclip;
import sky.social.Friend;
import sky.social.Staff;
import sky.waypoint.Gps;

public class CommandManager {
    private final List<Command> commands;
    private final CommandSource source;
    private final CommandDispatcher<CommandSource> dispatcher;

    private String prefix;

    public CommandManager() {
        prefix = ".";
        dispatcher = new CommandDispatcher<>();
        source = new ClientCommandSource(null, MinecraftClient.getInstance());
        commands = new ArrayList<>();
        registerCommand(new Bind());
        registerCommand(new Cfg());
        registerCommand(new Vclip());
        registerCommand(new Friend());
        registerCommand(new Macro());
        registerCommand(new Rct());
        registerCommand(new Staff());
        registerCommand(new Gps());
        registerCommand(new Neuro());
    }

    public void registerCommand(Command command) {
        if (command != null) {
            command.register(dispatcher);
            commands.add(command);
        }
    }

    /** Prefers the live network command source so suggestions resolve against the joined server. */
    public CommandSource getSource() {
        ClientPlayNetworkHandler networkHandler = MinecraftClient.getInstance().getNetworkHandler();
        if (networkHandler != null) {
            return networkHandler.getCommandSource();
        }
        return source;
    }

    public String getPrefix() {
        return prefix;
    }

    public List<Command> getCommands() {
        return commands;
    }

    public CommandDispatcher<CommandSource> getDispatcher() {
        return dispatcher;
    }
}
