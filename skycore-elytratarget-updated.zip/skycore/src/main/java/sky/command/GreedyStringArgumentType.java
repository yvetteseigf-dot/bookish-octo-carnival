package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public class GreedyStringArgumentType implements ArgumentType<String> {
    public static GreedyStringArgumentType create() {
        return new GreedyStringArgumentType();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        StringBuilder text = new StringBuilder();
        while (reader.canRead()) {
            text.append(reader.read());
        }
        return text.toString();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return new CompletableFuture<>();
    }

    @Override
    public Collection<String> getExamples() {
        return List.of();
    }
}
