package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import sky.SkyInit;
import sky.module.Module;
import sky.module.combat.AttackAura;
import sky.module.combat.HitBox;
import sky.module.movement.Sprint;

/** Command argument that resolves a registered module by name. */
public class ModuleArgumentType implements ArgumentType<Module> {
    private static final Collection<String> EXAMPLES = List.of("AttackAura", "Sprint", "HitBox");

    public static ModuleArgumentType create() {
        return new ModuleArgumentType();
    }

    @Override
    public Module parse(StringReader reader) throws CommandSyntaxException {
        String name = reader.readString();
        Module module = SkyInit.getInstance().getModuleManager().getModule(name);
        if (module == null) {
            throw new DynamicCommandExceptionType(
                    missing -> Text.literal(missing.toString() + " does not exist.")).create(name);
        }
        return module;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        List<String> names = new ArrayList<>();
        for (Module module : SkyInit.getInstance().getModuleManager().getModules()) {
            names.add(module.getName());
        }
        return CommandSource.suggestMatching(names, builder);
    }

    @Override
    public Collection<String> getExamples() {
        return EXAMPLES;
    }
}
