package sky.command;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import sky.SkyInit;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;
import java.util.List;
import sky.config.CustomMetaFile;
import sky.theme.ThemeRegistry;

/**
 * Chat-level handler for the local {@code .cfg}/{@code .config} commands, so they are
 * consumed client-side instead of being forwarded to the server.
 */
public final class ConfigCommand {
    private static final String[] PREFIXES = {".cfg", ".config"};

    private ConfigCommand() {
    }

    public static boolean handle(String message) {
        if (message == null) {
            return false;
        }
        String trimmed = message.trim();
        String args = null;
        for (String prefix : PREFIXES) {
            if (trimmed.equalsIgnoreCase(prefix)) {
                args = "";
                break;
            }
            if (trimmed.regionMatches(true, 0, prefix + " ", 0, prefix.length() + 1)) {
                args = trimmed.substring(prefix.length()).trim();
                break;
            }
        }
        if (args == null) {
            return false;
        }
        execute(args);
        return true;
    }

    private static void execute(String args) {
        CustomMetaFile configManager = SkyInit.getInstance().getConfigManager();
        if (configManager == null) {
            return;
        }
        if (args.isEmpty()) {
            send("Usage: .cfg save/load/remove/list/dir/clear/reset <name>");
            return;
        }
        String[] parts = args.split("\\s+");
        switch (parts[0].toLowerCase()) {
            case "save" -> {
                if (parts.length < 2) {
                    send("Specify a name: .cfg save <name>");
                    return;
                }
                configManager.saveConfig(parts[1]);
                send("Config \"" + parts[1] + "\" saved!");
            }
            case "load" -> {
                if (parts.length < 2) {
                    send("Specify a name: .cfg load <name>");
                    return;
                }
                if (!configManager.configExists(parts[1])) {
                    send("Config \"" + parts[1] + "\" not found.");
                    return;
                }
                if (!configManager.loadConfig(parts[1])) {
                    send("Failed to load config \"" + parts[1] + "\". Check the log.");
                    return;
                }
                send("Config \"" + parts[1] + "\" loaded!");
            }
            case "remove", "delete" -> {
                if (parts.length < 2) {
                    send("Specify a name: .cfg remove <name>");
                    return;
                }
                if (!configManager.configExists(parts[1])) {
                    send("Config \"" + parts[1] + "\" not found.");
                    return;
                }
                configManager.deleteConfig(parts[1]);
                send("Config \"" + parts[1] + "\" deleted!");
            }
            case "list" -> {
                List<String> names = configManager.getConfigNames();
                if (names.isEmpty()) {
                    send("Config list is empty!");
                    return;
                }
                send("Configs:");
                for (String name : names) {
                    MutableText line = Text.literal(name).formatted(Formatting.WHITE);
                    line.append(clickable(" [Load]", ".cfg load " + name, Formatting.GREEN, "Load " + name));
                    line.append(clickable(" [Delete]", ".cfg remove " + name, Formatting.RED, "Delete " + name));
                    send(line);
                }
            }
            case "dir" -> openConfigDirectory(configManager);
            case "clear" -> {
                for (String name : configManager.getConfigNames()) {
                    configManager.deleteConfig(name);
                }
                send("Config list cleared!");
            }
            case "reset" -> {
                configManager.resetToDefaults();
                send("Config reset!");
            }
            default -> send("Unknown command. Use: save, load, remove, list, dir, clear, reset");
        }
    }

    private static void openConfigDirectory(CustomMetaFile configManager) {
        try {
            File directory = configManager.getConfigDirectory();
            if (!directory.exists()) {
                directory.mkdirs();
            }
            if (Desktop.isDesktopSupported()) {
                Desktop.getDesktop().open(directory);
            } else {
                Runtime.getRuntime().exec(new String[] {"explorer", directory.getAbsolutePath()});
            }
            send("Folder: " + directory.getAbsolutePath());
        } catch (IOException exception) {
            send("Failed to open folder: " + configManager.getConfigDirectory().getAbsolutePath());
        }
    }

    private static MutableText clickable(String label, String command, Formatting color, String hover) {
        return Text.literal(label).setStyle(Style.EMPTY
                .withColor(color)
                .withClickEvent(new ClickEvent(ClickEvent.Action.SUGGEST_COMMAND, command))
                .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, Text.literal(hover))));
    }

    private static void send(String message) {
        send(Text.literal(message).formatted(Formatting.GRAY));
    }

    private static void send(Text message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            MutableText brand = Text.literal("SkyCore").setStyle(Style.EMPTY
                    .withColor(TextColor.fromRgb(ThemeRegistry.getCurrent().getSwatchColor().getRGB() & 0xFFFFFF)));
            MutableText separator = Text.literal(" / ").formatted(Formatting.DARK_GRAY);
            client.player.sendMessage(Text.empty().append(brand).append(separator).append(message), false);
        }
    }
}
