package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.command.CommandSource;
import sky.SkyInit;
import sky.macro.MacrosFile;

/** Command argument that completes against saved macro names. */
public final class MacroArgumentType implements ArgumentType<String> {
    public static MacroArgumentType create() {
        return new MacroArgumentType();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        return reader.readString();
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        List<String> names = new ArrayList<>();
        for (MacrosFile.MacroEntry entry : SkyInit.getInstance().getMacroManager().getMacros()) {
            names.add(entry.getName());
        }
        return CommandSource.suggestMatching(names, builder);
    }

    @Override
    public Collection<String> getExamples() {
        return List.of("hello", "grief");
    }
}
