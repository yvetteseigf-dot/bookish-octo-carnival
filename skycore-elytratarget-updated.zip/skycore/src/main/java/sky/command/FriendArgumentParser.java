package sky.command;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import sky.SkyInit;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class FriendArgumentParser implements ArgumentType<String> {
    public static FriendArgumentParser create() {
        return new FriendArgumentParser();
    }

    @Override
    public String parse(StringReader reader) throws CommandSyntaxException {
        String name = reader.readString();
        if (!SkyInit.getInstance().getFriendManager().isFriend(name)) {
            throw new DynamicCommandExceptionType(friend -> Text.literal("You don't have a friend named " + name)).create(name);
        }
        return name;
    }

    @Override
    public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
        return CommandSource.suggestMatching(SkyInit.getInstance().getFriendManager().getItems(), builder);
    }

    @Override
    public Collection<String> getExamples() {
        return List.of();
    }
}
