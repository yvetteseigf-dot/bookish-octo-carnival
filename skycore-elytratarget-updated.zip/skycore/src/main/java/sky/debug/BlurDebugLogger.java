package sky.debug;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import sky.render.framebuffer.BlurManager;
import sky.render.shader.LegacyShaderManager;
import sky.render.shader.ShaderLibrary;
import sky.render.shader.ManagedShader;

public final class BlurDebugLogger {
    public static final boolean ENABLED = false;
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore/Blur");
    public static final boolean VERBOSE = true;

    private BlurDebugLogger() {
    }

    public static void summary(String message, String stage) {
        log(message, stage);
    }

    public static void log(String message, String stage) {
    }

    public static void once(String stage, String key, String message) {
        log(key, message);
    }

    public static String describeKawase() {
        BlurManager blurManager = BlurManager.BLUR;
        String blurredDescription = blurManager.blurred == null
                ? "null"
                : blurManager.blurred.textureWidth + "x" + blurManager.blurred.textureHeight
                + " fbo=" + blurManager.blurred.fbo + " tex=" + blurManager.blurred.getColorAttachment();
        return String.format(
                "hasCaptured=%s kawaseApplied=%s sampleTex=%d blurred=%s",
                blurManager.hasCapturedFrame(),
                blurManager.isKawaseApplied(),
                blurManager.getSampleTexture(),
                blurredDescription
        );
    }

    public static void stateChange(String state, String stage) {
    }

    public static void logf(String stage, String format, Object... args) {
    }

    public static void dumpUniform(String programId, int name, String stage) {
    }

    public static String describeKawasePrograms() {
        return String.format(
                "kawaseReady=%s downId=%s upId=%s",
                LegacyShaderManager.isKawaseReady(),
                programId(LegacyShaderManager.kawaseDownProgram()),
                programId(LegacyShaderManager.kawaseUpProgram())
        );
    }

    public static void every(long intervalMs, String stage, String key, String message) {
        log(stage, message);
    }

    public static void dumpGl(String stage) {
    }

    public static String describeRegistryShader(String name) {
        return ShaderLibrary.getRegistry()
                .find(name)
                .map(BlurDebugLogger::describeProgram)
                .orElse("missing");
    }

    private static String describeProgram(ManagedShader program) {
        return "linked=" + program.isLinked() + " id=" + program.getProgramId();
    }

    private static String programId(LegacyShaderManager.LegacyGlProgram program) {
        return program == null ? "null" : Integer.toString(program.programId);
    }
}
