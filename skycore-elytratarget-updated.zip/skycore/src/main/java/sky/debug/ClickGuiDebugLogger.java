package sky.debug;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Color;

public final class ClickGuiDebugLogger {
    private static final Logger LOGGER = LoggerFactory.getLogger("Skycore/ClickGui");
    public static final boolean ENABLED = false;

    private ClickGuiDebugLogger() {
    }

    private static String formatColor(Color color) {
        return String.format(
                "rgba(%d,%d,%d,%d)",
                color.getRed(),
                color.getGreen(),
                color.getBlue(),
                color.getAlpha()
        );
    }

    public static void log(String stage, String message) {
    }

    public static void color(String color, String fade, Color stage, float name) {
    }
}
