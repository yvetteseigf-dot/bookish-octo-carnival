package sky.model;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import sky.SkyInit;
import sky.access.MinecraftAccess;
import sky.module.visuals.CustomModels;

/** Entry point used by the player renderer to swap in one of the cosmetic models. */
public final class CustomModelRenderer implements MinecraftAccess {
    public static final Identifier RABBIT_TEXTURE = Identifier.of("skycore", "textures/models/rabbit.png");
    public static final Identifier FREDDY_TEXTURE = Identifier.of("skycore", "textures/models/freddy.png");
    public static final Identifier WHITE_DEMON_TEXTURE = Identifier.of("skycore", "textures/models/whitedemon.png");
    public static final Identifier RED_DEMON_TEXTURE = Identifier.of("skycore", "textures/models/reddemon.png");
    public static final Identifier AMOGUS_TEXTURE = Identifier.of("skycore", "textures/models/amogus.png");

    private CustomModelRenderer() {
    }

    public static void renderCustomModel(BipedEntityModel<?> source, MatrixStack matrices, VertexConsumer consumer,
                                         int light, int overlay, int color) {
        CustomModels module = CustomModels.INSTANCE;
        CustomModelParts parts = CustomModelParts.getInstance();

        if (module.models.is("Crazy Rabbit")) {
            parts.renderRabbit(matrices, source, consumer, light, overlay, color);
        } else if (module.models.is("White Demon") || module.models.is("Red Demon")) {
            parts.renderDemon(matrices, source, consumer, light, overlay, color);
        } else if (module.models.is("Freddy Bear")) {
            parts.renderFreddy(matrices, source, consumer, light, overlay, color);
        } else if (module.models.is("Amogus")) {
            parts.renderAmogus(matrices, consumer, light, overlay, color);
        }
    }

    public static boolean shouldApply(LivingEntity entity) {
        if (entity == null || mc.player == null) {
            return false;
        }

        CustomModels module = CustomModels.INSTANCE;
        if (!module.isEnabled()) {
            return false;
        }

        if (entity == mc.player) {
            return true;
        }
        if (!module.friends.isEnabled()) {
            return false;
        }
        String name = entity instanceof PlayerEntity player
                ? player.getGameProfile().getName()
                : entity.getName().getString();
        return SkyInit.getInstance().getFriendManager().isFriend(name);
    }

    public static Identifier getTextureIdentifier() {
        CustomModels module = CustomModels.INSTANCE;

        if (module.models.is("Crazy Rabbit")) {
            return RABBIT_TEXTURE;
        }

        if (module.models.is("Freddy Bear")) {
            return FREDDY_TEXTURE;
        }

        if (module.models.is("White Demon")) {
            return WHITE_DEMON_TEXTURE;
        }

        if (module.models.is("Red Demon")) {
            return RED_DEMON_TEXTURE;
        }

        if (module.models.is("Amogus")) {
            return AMOGUS_TEXTURE;
        }

        return null;
    }
}
