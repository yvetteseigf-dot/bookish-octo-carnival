package sky.model;

import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

/** Propeller beanie worn by the pets; the rotor only spins while the wearer is airborne. */
public final class PropellerHatModel {
    private final ModelPart cap;
    private final ModelPart propeller;

    public PropellerHatModel(ModelPart root) {
        this.cap = root.getChild("cap");
        this.propeller = root.getChild("propeller");
    }

    public static TexturedModelData getTexturedModelData() {
        ModelData modelData = new ModelData();
        ModelPartData root = modelData.getRoot();

        root.addChild("cap", ModelPartBuilder.create().uv(0, 15)
                        .cuboid(-5.0F, -4.0F, -5.0F, 10.0F, 4.0F, 10.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -5.0F, 0.0F));

        root.addChild("propeller", ModelPartBuilder.create().uv(0, 0)
                        .cuboid(-0.5F, -2.0F, -0.5F, 1.0F, 2.0F, 1.0F, Dilation.NONE)
                        .uv(0, 3)
                        .cuboid(-7.5F, -3.0F, -1.5F, 15.0F, 1.0F, 3.0F, Dilation.NONE)
                        .uv(0, 29)
                        .cuboid(-1.5F, -3.0F, -7.5F, 3.0F, 1.0F, 15.0F, Dilation.NONE),
                ModelTransform.pivot(0.0F, -9.0F, 0.0F));

        return TexturedModelData.of(modelData, 64, 64);
    }

    public void render(MatrixStack matrices, VertexConsumerProvider consumers, Identifier texture, int light,
                       float age, boolean flying) {
        this.propeller.yaw = flying ? age * 1.35F : 0.0F;

        VertexConsumer consumer = consumers.getBuffer(RenderLayer.getEntityTranslucent(texture));
        this.cap.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV, -1);
        this.propeller.render(matrices, consumer, light, OverlayTexture.DEFAULT_UV, -1);
    }
}
